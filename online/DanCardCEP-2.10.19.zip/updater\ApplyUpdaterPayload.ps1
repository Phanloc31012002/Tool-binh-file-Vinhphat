[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [int]$ParentProcessId,
    [Parameter(Mandatory = $true)]
    [string]$StageRoot,
    [string]$UpdaterHome = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'

function Write-HiddenLauncher {
    param([string]$UpdaterHome, [string]$UpdaterScript)

    $launcherPath = Join-Path $UpdaterHome 'CongCuBinh-AutoUpdate.vbs'
    $command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$UpdaterScript`" -Quiet"
    $vbsLine = 'CreateObject("Wscript.Shell").Run "' + $command.Replace('"', '""') + '", 0, False'
    [System.IO.File]::WriteAllText($launcherPath, $vbsLine + [Environment]::NewLine, [System.Text.Encoding]::ASCII)
    return $launcherPath
}

function Set-MinuteCheckSchedule {
    param([string]$UpdaterHome)
    try {
        $updaterScript = Join-Path $UpdaterHome 'DanCardUpdater.ps1'
        if (-not (Test-Path -LiteralPath $updaterScript)) { return }
        $launcherPath = Write-HiddenLauncher -UpdaterHome $UpdaterHome -UpdaterScript $updaterScript
        $taskCommand = "wscript.exe `"$launcherPath`""
        & schtasks.exe /Create /TN 'CongCuBinh-AutoUpdate-Recurring' /TR $taskCommand /SC MINUTE /MO 1 /F *> $null
        if ($LASTEXITCODE -eq 0) {
            [System.IO.File]::WriteAllText((Join-Path $UpdaterHome 'recurring-schedule.txt'), 'wscript-minute-1', [System.Text.Encoding]::ASCII)
            # Dọn task cũ có PowerShell trực tiếp để không còn cửa sổ CMD chớp.
            & schtasks.exe /Delete /TN 'CongCuBinh-AutoUpdate' /F *> $null
        }
    } catch {}
}

function Set-MinuteCheckConfig {
    param([string]$UpdaterHome)
    try {
        $configPath = Join-Path $UpdaterHome 'update-config.json'
        if (-not (Test-Path -LiteralPath $configPath)) { return }
        $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $config | Add-Member -NotePropertyName manifestUrl -NotePropertyValue 'https://dancard-update.an-ard--etup-23.workers.dev/latest.json' -Force
        $config | Add-Member -NotePropertyName checkIntervalMinutes -NotePropertyValue 1 -Force
        $nextPath = "$configPath.next"
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($nextPath, ($config | ConvertTo-Json -Depth 8), $utf8NoBom)
        Move-Item -LiteralPath $nextPath -Destination $configPath -Force
    } catch {}
}

$deadline = [DateTime]::UtcNow.AddSeconds(45)
while ((Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) -and [DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Milliseconds 250
}

try {
    foreach ($name in @('DanCardUpdater.ps1', 'SetupShortcuts.ps1', 'ApplyUpdaterPayload.ps1', 'CongCuBinh.ico', 'update-config.json')) {
        $source = Join-Path $StageRoot $name
        if (-not (Test-Path -LiteralPath $source)) { continue }
        $target = Join-Path $UpdaterHome $name
        $next = "$target.next"
        Copy-Item -LiteralPath $source -Destination $next -Force
        Move-Item -LiteralPath $next -Destination $target -Force
    }
    $shortcutSetup = Join-Path $UpdaterHome 'SetupShortcuts.ps1'
    if (Test-Path -LiteralPath $shortcutSetup) {
        & $shortcutSetup -UpdaterHome $UpdaterHome -Quiet
    }
    Set-MinuteCheckConfig -UpdaterHome $UpdaterHome
    Set-MinuteCheckSchedule -UpdaterHome $UpdaterHome
} finally {
    Remove-Item -LiteralPath $StageRoot -Recurse -Force -ErrorAction SilentlyContinue
}
