// ============================================================
//  Dàn card đa kích thước - Adobe Illustrator ExtendScript
//  Tác giả: LỘC (Code dạo) / Lần Tồn
//
//  Hỗ trợ nhiều loại card, chọn khi chạy:
//    - 9.2 x 5.6 : 20 chỗ (12 dọc + 6 phải + 2 dưới)
//                  số mẫu: 1,2,4,5,10,20
//    - 8.7 x 5.5 : 22 chỗ (18 ngang + 4 dọc)
//                  số mẫu: 1,2,11,22
//    - 15.2 x 7.2 (voucher) : 8 chỗ. Khi chọn sẽ hỏi thêm
//                  "có ghép card 9.2x5.6?":
//                    KHÔNG -> 8 voucher ngang (2 cột x 4 hàng)
//                    CÓ    -> 8 voucher ngang + 3 card 9.2x5.6 dải dưới
//                  (selection lẫn lộn, tool tự đo phân loại)
//    (Thêm loại mới: khai báo trong LAYOUTS bên dưới)
//
//  Chọn (n mẫu x 2) object: mỗi hàng [trước][sau].
//  Tự clip + Expand Appearance. Mặt trước->AB1, mặt sau->AB2 (đối xứng).
//  Loại in: In nhanh / Cardoffset (thêm dòng ghi chú).
// ============================================================

// ============================================================
//  HÀM CHÍNH cho CEP: dcDan(layoutKey, voucherWithCard)
//  - layoutKey: key loại card (vd "9.2x5.6", "voucher15.2x7.2"...)
//  - voucherWithCard: true nếu voucher ghép card 9.2x5.6
//  Trả về chuỗi kết quả để panel hiện. Bắt đầu bằng "OK:" nếu thành công,
//  "ERR:" nếu lỗi/hủy.
// ============================================================

// ============================================================
//  Dịch lỗi ExtendScript sang tiếng Việt dễ hiểu.
//  Dùng: catch (e) { return "ERR: " + dcMoTaLoi(e); }
// ============================================================
function dcMoTaLoi(e) {
  var num = -1,
    msg = "";
  try {
    num = e.number;
  } catch (x) {}
  try {
    msg = e.toString();
  } catch (x) {}
  var line = "";
  try {
    if (e.line) line = " (dòng " + e.line + ")";
  } catch (x) {}

  var giaiThich = {
    45: "Đối tượng không hợp lệ — có object đã bị xóa hoặc thay đổi trong lúc xử lý. Thử chọn lại object và chạy lại.",
    21: "Giá trị nằm ngoài phạm vi cho phép.",
    1200: "Lỗi thao tác trên đối tượng đồ họa (có thể do object bị khóa/ẩn hoặc đã xóa).",
    1302: "Không có đối tượng nào được chọn phù hợp.",
    9001: "Không tìm thấy file (kiểm tra đường dẫn pon).",
    8: "Không đủ bộ nhớ.",
    24: "Biến chưa được định nghĩa (lỗi lập trình).",
  };

  var moTa = giaiThich[num];
  if (moTa) return "Lỗi " + num + ": " + moTa + line;
  // không có trong bảng -> hiện thông báo gốc gọn
  return (num >= 0 ? "Lỗi " + num + ": " : "Lỗi: ") + msg + line;
}

// ============================================================
//  ĐO KHỔ DÙNG CHUNG — theo khung Transform của Illustrator
//  Mọi lệnh đo khổ đi qua dcDoKhung(item, cáchĐoCũ): cờ bật thì lấy khung
//  Transform (clip → khung clip, group → khung group), không đo được mới rơi
//  về cách đo riêng của từng lệnh; cờ tắt thì đo y như các bản trước.
//  Panel đặt cờ trước mỗi lệnh (tick "Transform" ở header, tiền tố evalJsx).
//  Từ 22/10 (anh Lộc: "toàn bộ dùng Transform để dàn"): mặc định BẬT; tick ở header
//  tắt được để so với cách cũ. Nút "Đo khung" (dcDoKhungChon) in số đo đối chiếu.
// ============================================================
var DC_DUNG_SAI_KHO_MM = 0.5; // dung sai khổ chung (mm)
if (typeof dcDoTheoKhungTransform === "undefined")
  var dcDoTheoKhungTransform = true;

// Khung đúng như bảng Transform hiện: clip group → khung mask (kể cả compound path, cờ
// clipping nằm trên path con của compound); group thường → hợp khung các con đang hiện (bằng
// khung group khi Illustrator tính đúng, và vẫn đúng khi Illustrator gộp cả phần ảnh bị mask
// che); còn lại → khung hình. Illustrator đang bật "Use Preview Bounds" thì lấy visibleBounds.
// Trả [l,t,r,b] hoặc null khi object hỏng/không đo được. Không ném lỗi.
var DC_KHUNG_TOI_DA_CON = 200; // group đông con hơn thì lấy thẳng khung group cho nhanh
function dcKhungThanhPham(item) {
  var previewBounds = false;
  try {
    previewBounds =
      app.preferences.getBooleanPreference("includeStrokeInBounds") === true;
  } catch (prefError) {}
  function boundsOf(it) {
    try {
      var b = previewBounds ? it.visibleBounds : it.geometricBounds;
      if (b && b.length === 4) return [b[0], b[1], b[2], b[3]];
    } catch (boundsError) {}
    return null;
  }
  function isMask(child) {
    try {
      if (child.clipping === true) return true;
      if (child.typename === "CompoundPathItem") {
        var paths = child.pathItems;
        for (var k = 0; k < paths.length; k++)
          if (paths[k].clipping === true) return true;
      }
    } catch (maskError) {}
    return false;
  }
  function union(a, b) {
    if (!a) return b;
    if (!b) return a;
    return [
      Math.min(a[0], b[0]),
      Math.max(a[1], b[1]),
      Math.max(a[2], b[2]),
      Math.min(a[3], b[3]),
    ];
  }
  // Con không có khung thật (bảng Transform của Illustrator bỏ qua): ẩn, guide, khung rỗng
  // (group không con, path không điểm — Illustrator trả [0,0,0,0] ở gốc toạ độ, hợp vào sẽ
  // kéo khung ra tới gốc, như voucher 15,2 × 7,2 bị báo "không nằm vừa" ngày 22/10).
  function lyDoBo(child, frame) {
    try {
      if (child.hidden === true) return "ẩn";
    } catch (hiddenError) {}
    try {
      if (child.guides === true) return "guide";
    } catch (guideError) {}
    if (!frame) return "không đo được";
    if (frame[2] - frame[0] <= 0.001 && frame[1] - frame[3] <= 0.001)
      return "khung rỗng";
    return "";
  }
  // Mask của clip group không luôn là con trực tiếp: Illustrator hay bọc nó trong một group
  // thường (file voucher 22/10: clip group → group → path [mask], trong khi geometric/visibleBounds
  // của clip group báo cả phần ảnh bị che, 367 mm thay vì 18 mm). Tìm mask qua các group thường
  // lồng nhau; không vào clip group con vì mask trong đó là của nó, không phải của group này.
  function timMask(group, depth) {
    if (depth > 4) return null;
    var children = null,
      count = 0;
    try {
      children = group.pageItems;
      count = children.length;
    } catch (childError) {
      return null;
    }
    for (var i = 0; i < count; i++) if (isMask(children[i])) return children[i];
    for (var j = 0; j < count; j++) {
      var typename = null,
        clipped = false;
      try {
        typename = children[j].typename;
        clipped = children[j].clipped === true;
      } catch (childError2) {
        continue;
      }
      if (typename !== "GroupItem" || clipped) continue;
      var mask = timMask(children[j], depth + 1);
      if (mask) return mask;
    }
    return null;
  }
  function frameOf(it, depth) {
    if (!it || depth > 8) return null;
    var typename = null,
      clipped = false;
    try {
      typename = it.typename;
    } catch (typeError) {
      return null;
    }
    if (typename !== "GroupItem") return boundsOf(it);
    try {
      clipped = it.clipped === true;
    } catch (clipError) {}
    var children = null,
      count = 0;
    try {
      children = it.pageItems;
      count = children.length;
    } catch (childError) {
      return boundsOf(it);
    }
    if (clipped) {
      var mask = timMask(it, 0);
      return (mask && boundsOf(mask)) || boundsOf(it);
    }
    if (count === 0) return null; // group rỗng: không có khung
    if (count > DC_KHUNG_TOI_DA_CON) return boundsOf(it);
    var acc = null;
    for (var j = 0; j < count; j++) {
      var frame = frameOf(children[j], depth + 1);
      if (lyDoBo(children[j], frame)) continue;
      acc = union(acc, frame);
    }
    return acc || boundsOf(it);
  }
  return frameOf(item, 0);
}

function dcDoKhung(item, legacy) {
  if (dcDoTheoKhungTransform) {
    var khung = dcKhungThanhPham(item);
    if (khung) return khung;
  }
  return legacy(item);
}

// Khung Transform của object, dự phòng geometricBounds; null khi không đo được. Dùng ở các lệnh
// dàn luôn đo theo Transform (CTL Offset, Keo gáy, Catalogue), không phụ thuộc tick.
function dcKhungHoacBounds(item) {
  var khung = null;
  try {
    khung = dcKhungThanhPham(item);
  } catch (khungError) {}
  if (khung) return khung;
  try {
    var g = item.geometricBounds;
    if (g && g.length === 4 && g[2] > g[0] && g[1] > g[3])
      return [g[0], g[1], g[2], g[3]];
  } catch (boundsError) {}
  return null;
}

// Gom các câu cảnh báo phóng không đều thành một đoạn nối vào kết quả OK ("" khi không có).
function dcCauCanhBaoPhong(canhBao) {
  if (!canhBao || !canhBao.length) return "";
  return " Lưu ý: " + canhBao.join(" | ");
}

// Chuẩn bị một trang để dàn (CTL Offset, Keo gáy, Catalogue): KHÔNG raster — anh Lộc 22/10:
// "bỏ auto biến thành hình… toàn bộ dùng Transform để dàn". Đo khung Transform, phóng về đúng
// khổ nhập bằng ma trận theo trục tài liệu quanh tâm (trang nguồn xoay sẵn vẫn đúng), nét co
// giãn theo cùng tỉ lệ. Khung đã đúng (lệch ≤ 0,05 mm) thì không đụng. Trả về chính object;
// phóng không đều quá 0,5 % thì ghi câu cảnh báo vào canhBao (nếu truyền).
var DC_DUNG_SAI_PHONG_MM = 0.05;
function dcChuanBiTrangDan(doc, item, rongMm, caoMm, canhBao, nhan) {
  var MM = 2.834645669;
  var khung = dcKhungHoacBounds(item);
  if (!khung) throw new Error("không đo được khung Transform của trang.");
  var w = (khung[2] - khung[0]) / MM,
    h = (khung[1] - khung[3]) / MM;
  if (!(w > 0 && h > 0))
    throw new Error("không đo được khung Transform của trang.");
  if (
    Math.abs(w - rongMm) <= DC_DUNG_SAI_PHONG_MM &&
    Math.abs(h - caoMm) <= DC_DUNG_SAI_PHONG_MM
  )
    return item;
  var sx = (rongMm / w) * 100,
    sy = (caoMm / h) * 100;
  // Tham số thứ 6 của transform() là HỆ SỐ nhân nét (1 = giữ nguyên), không phải phần trăm như
  // resize(): nét co giãn cùng trang → (sx + sy) / 200. Đưa (sx + sy) / 2 là nét phình ×100.
  item.transform(
    app.getScaleMatrix(sx, sy),
    true,
    true,
    true,
    true,
    (sx + sy) / 200,
    Transformation.CENTER,
  );
  if (canhBao && Math.abs(sx - sy) > 0.5) {
    var pct = function (v) {
      return (Math.round(v * 10) / 10).toFixed(1).replace(".", ",") + " %";
    };
    canhBao.push(
      (nhan ? nhan + ": " : "") +
        "phóng không đều " +
        pct(sx) +
        " × " +
        pct(sy) +
        " (nguồn " +
        dcMmText(w * MM) +
        " × " +
        dcMmText(h * MM) +
        " mm) — chữ/nét có thể méo nhẹ.",
    );
  }
  return item;
}

// Mọi object Dàn Card tạo ra (group kết quả, PON duplicate, ghi chú offset) đều gắn note này;
// dọn mẻ cũ chỉ xoá object có note, không bao giờ xoá object của người dùng.
var DC_NOTE_DAN_CARD = "DANCARD_DAN_CARD_OUTPUT";

// So hai tham chiếu object Illustrator (wrapper khác nhau vẫn là một object khi trùng uuid).
function dcCungObject(a, b) {
  if (a === b) return true;
  try {
    return !!(a && b && a.uuid && a.uuid === b.uuid);
  } catch (uuidError) {}
  return false;
}
// uuid của object (chuỗi) hoặc null khi Illustrator không có.
function dcUuidCua(item) {
  try {
    var id = item.uuid;
    if (id) return String(id);
  } catch (uuidError) {}
  return null;
}
// Tập object cần giữ, dựng MỘT lần: gồm từng object trong danh sách và các group cha của nó
// (tới layer). Tra bằng uuid khi có, so tham chiếu khi không — tránh N×M lần đọc DOM.
function dcTapObject(items, keToTien) {
  var tap = { uuids: {}, refs: [], rong: true };
  if (!items) return tap;
  for (var i = 0; i < items.length; i++) {
    var node = items[i],
      depth = 0;
    while (node && depth++ < 32) {
      tap.rong = false;
      var id = dcUuidCua(node);
      if (id) tap.uuids[id] = true;
      else tap.refs.push(node);
      if (!keToTien) break;
      var parent = null;
      try {
        parent = node.parent;
        if (!parent || parent.typename === "Layer") break;
      } catch (parentError) {
        break;
      }
      node = parent;
    }
  }
  return tap;
}
function dcTrongTap(tap, item) {
  if (!tap || tap.rong) return false;
  var id = dcUuidCua(item);
  if (id && tap.uuids[id]) return true;
  for (var i = 0; i < tap.refs.length; i++) if (tap.refs[i] === item) return true;
  return false;
}
// item có nằm trong protectList, hoặc là tổ tiên (group cha) của một object trong đó không.
function dcDuocBaoVe(item, protectList) {
  return dcTrongTap(dcTapObject(protectList, true), item);
}

// Câu báo số object lạ được giữ lại trong vùng artboard ("" khi không có).
function dcCauGiuObjectLa(kept, sep) {
  if (!(kept > 0)) return "";
  return (
    sep +
    "Giữ lại " +
    kept +
    " object không do tool tạo trong vùng artboard (kết quả cũ dàn bằng bản trước thì xoá tay)."
  );
}

// Khung bao của bài cũ còn trên canvas (object cấp trên cùng của mọi layer đang hiện, kể cả
// layer khoá), bỏ object trong skipItems (nguồn đang chọn) và object phủ gần hết canvas (nền làm
// việc). Dùng để tờ mới né cả bài cũ đã bị xoá khung ở lượt trước, không chỉ né artboard.
function dcVungBaiCu(doc, canvasRect, skipItems) {
  var rects = [];
  var canvasW = canvasRect[2] - canvasRect[0],
    canvasH = canvasRect[1] - canvasRect[3];
  var boQua = dcTapObject(skipItems, false); // dựng một lần, tra bằng uuid
  var layerCount = 0;
  try {
    layerCount = doc.layers.length;
  } catch (layersError) {
    return rects;
  }
  for (var li = 0; li < layerCount; li++) {
    var layer = doc.layers[li],
      items = null,
      count = 0;
    try {
      if (layer.visible === false) continue;
      items = layer.pageItems;
      count = items.length;
    } catch (layerError) {
      continue;
    }
    for (var i = 0; i < count; i++) {
      var it = items[i],
        b = null;
      try {
        if (it.hidden === true) continue;
        b = it.geometricBounds;
      } catch (itemError) {
        continue;
      }
      if (!b || !(b[2] > b[0]) || !(b[1] > b[3])) continue;
      if (b[2] - b[0] >= canvasW * 0.92 && b[1] - b[3] >= canvasH * 0.92) continue;
      if (!dcTrongTap(boQua, it)) rects.push([b[0], b[1], b[2], b[3]]);
    }
  }
  return rects;
}

// Số đo pt → chữ mm, một chữ số lẻ, dấu phẩy kiểu Việt ("92,0").
function dcMmText(pt) {
  return (pt / 2.834645669).toFixed(1).replace(".", ",");
}

// Số đo khung [l,t,r,b] → "92,00 × 56,00 mm" (2 số lẻ); null → "không đo được".
function dcKhungText(b) {
  if (!b) return "không đo được";
  function mm(pt) {
    return (pt / 2.834645669).toFixed(2).replace(".", ",");
  }
  return mm(b[2] - b[0]) + " × " + mm(b[1] - b[3]) + " mm";
}

// Cây khung của một object (cho nút Đo khung): từng con tới 3 cấp, mỗi dòng ghi loại, cờ
// ([clip] group có mask, [mask] đường clip, [guide], [ẩn], [compound n đường, k mask]), khung
// Transform tool đọc được, cùng geometricBounds/visibleBounds thô để đối chiếu. Tối đa 80 dòng.
function dcCayKhung(item, depth, out) {
  var MAX_DONG = 80;
  var kids = null,
    count = 0;
  try {
    if (item.typename === "GroupItem") {
      kids = item.pageItems;
      count = kids.length;
    }
  } catch (kidsError) {}
  for (var k = 0; k < count; k++) {
    if (out.length >= MAX_DONG) {
      out.push("   … (còn nữa, chỉ in " + MAX_DONG + " dòng)");
      return;
    }
    var it = kids[k],
      ten = "object",
      co = "";
    try {
      ten = it.typename;
    } catch (typeError) {}
    try {
      if (it.clipped === true) co += " [clip]";
    } catch (clipError) {}
    try {
      if (it.clipping === true) co += " [mask]";
    } catch (maskError) {}
    try {
      if (it.guides === true) co += " [guide]";
    } catch (guideError) {}
    try {
      if (it.hidden === true) co += " [ẩn]";
    } catch (hiddenError) {}
    try {
      if (ten === "CompoundPathItem") {
        var pp = it.pathItems,
          nMask = 0;
        for (var q = 0; q < pp.length; q++) if (pp[q].clipping === true) nMask++;
        co += " [compound " + pp.length + " đường, " + nMask + " mask]";
      }
    } catch (compoundError) {}
    var khung = dcKhungThanhPham(it),
      geo = null,
      vis = null;
    try {
      geo = it.geometricBounds;
    } catch (geoError) {}
    try {
      vis = it.visibleBounds;
    } catch (visError) {}
    var bo = "";
    if (co.indexOf("[ẩn]") >= 0) bo = "ẩn";
    else if (co.indexOf("[guide]") >= 0) bo = "guide";
    else if (!khung) bo = "không đo được";
    else if (khung[2] - khung[0] <= 0.001 && khung[1] - khung[3] <= 0.001)
      bo = "khung rỗng";
    var lui = "";
    for (var d = 0; d < depth; d++) lui += "  ";
    out.push(
      "   " +
        lui +
        "- con " +
        (k + 1) +
        ": " +
        ten +
        " " +
        dcKhungText(khung) +
        co +
        " [geo " +
        dcKhungText(geo) +
        " | vis " +
        dcKhungText(vis) +
        "]" +
        (bo ? " (" + bo + " → bỏ)" : ""),
    );
    if (depth < 3) dcCayKhung(it, depth + 1, out);
  }
}

// Nút "Đo khung" ở header: in khung Transform (cách đo mới) và visibleBounds (cách đo cũ) của
// từng object đang chọn để đối chiếu với bảng Transform của Illustrator; group thường liệt kê
// thêm từng con cấp 1 (con rỗng/guide ghi "bỏ"). Hiện bằng bảng ScriptUI cuộn được, chữ chép
// được (alert của CEP cắt mất dòng). Không đụng tài liệu.
function dcDoKhungChon() {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu.";
    var sel = app.activeDocument.selection;
    if (!sel || !sel.length) return "ERR: Hãy chọn object cần đo khung.";
    var previewBounds = false;
    try {
      previewBounds =
        app.preferences.getBooleanPreference("includeStrokeInBounds") === true;
    } catch (prefError) {}
    var MAX = 20,
      lines = [];
    for (var i = 0; i < sel.length && i < MAX; i++) {
      var it = sel[i],
        loai = "object";
      try {
        loai = it.typename;
        if (loai === "GroupItem" && it.clipped === true) loai += " (clip)";
      } catch (typeError) {}
      var khung = dcKhungThanhPham(it),
        cu = null,
        geoGoc = null;
      try {
        geoGoc = it.geometricBounds;
      } catch (geoError) {}
      try {
        cu = it.visibleBounds;
      } catch (boundsError) {}
      var lech =
        khung &&
        cu &&
        (Math.abs(khung[2] - khung[0] - (cu[2] - cu[0])) > 0.0284 ||
          Math.abs(khung[1] - khung[3] - (cu[1] - cu[3])) > 0.0284);
      var dong =
        i +
        1 +
        ". " +
        loai +
        "\n   Transform: " +
        dcKhungText(khung) +
        "\n   Cách cũ (visibleBounds): " +
        dcKhungText(cu) +
        (lech ? "   ← KHÁC" : "") +
        "\n   geometricBounds thô: " +
        dcKhungText(geoGoc);
      var cay = [];
      try {
        dcCayKhung(it, 0, cay);
      } catch (treeError) {}
      if (cay.length) dong += "\n" + cay.join("\n");
      lines.push(dong);
    }
    if (sel.length > MAX)
      lines.push("… và " + (sel.length - MAX) + " object nữa.");
    var text =
      "Đo khung " +
      sel.length +
      " object đang chọn (mm, 2 số lẻ). " +
      (previewBounds
        ? "Illustrator đang bật Use Preview Bounds (tính cả nét)."
        : "Use Preview Bounds: tắt.") +
      "\n\n" +
      lines.join("\n");
    try {
      if (typeof Window === "function") {
        var w = new Window("dialog", "Đo khung — đối chiếu với bảng Transform");
        var box = w.add("edittext", undefined, text, {
          multiline: true,
          readonly: true,
          scrolling: true,
        });
        box.preferredSize = [560, 360];
        var ok = w.add("button", undefined, "OK", { name: "ok" });
        ok.onClick = function () {
          w.close(1);
        };
        w.show();
      }
    } catch (dialogError) {}
    return "OK: " + text;
  } catch (e) {
    return "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString());
  }
}

// Thư mục chứa file jsx này (để tìm assets đi kèm extension); null nếu không rõ.
var dcJsxFolder = null;
try {
  dcJsxFolder = new File($.fileName).parent;
} catch (jsxFolderError) {}

// File icon ghi chú CTL/Keo gáy: ưu tiên DanCardCEP/assets/icon.ai theo thư mục extension
// (panel truyền dcExtensionRoot, hoặc suy từ vị trí jsx), cuối cùng là đường dẫn cũ trên
// máy anh Lộc. Không có file nào → null, lệnh dàn bỏ qua icon chứ không dừng.
var DC_THIEU_ICON_GHI_CHU =
  " Không có icon ghi chú (thiếu DanCardCEP/assets/icon.ai); ghi chú vẫn được điền.";
function dcNoteIconFile() {
  var candidates = [];
  try {
    if (typeof dcExtensionRoot === "string" && dcExtensionRoot)
      candidates.push(dcExtensionRoot + "/assets/icon.ai");
  } catch (rootError) {}
  try {
    if (dcJsxFolder && dcJsxFolder.parent)
      candidates.push(String(dcJsxFolder.parent.fsName) + "/assets/icon.ai");
  } catch (folderError) {}
  candidates.push("C:/Users/ADMIN/Downloads/icon.ai");
  for (var i = 0; i < candidates.length; i++) {
    try {
      var file = new File(candidates[i]);
      if (file.exists) return file;
    } catch (fileError) {}
  }
  return null;
}

// dcDan: wrapper bắt mọi lỗi -> trả thông báo rõ ràng cho panel.
function dcDan(SEL_LAYOUT_KEY, VOUCHER_WITH_CARD_ARG) {
  try {
    var r = _dcDanCore(SEL_LAYOUT_KEY, VOUCHER_WITH_CARD_ARG);
    // nhánh cũ có thể return undefined -> coi như xong
    if (r === undefined || r === null) return "OK: đã dàn xong.";
    return r;
  } catch (e) {
    return "ERR: " + dcMoTaLoi(e);
  }
}

// Lõi dàn card: xử lý toàn bộ (đo KT, clip, import pon, dàn, căn giữa).
function _dcDanCore(SEL_LAYOUT_KEY, VOUCHER_WITH_CARD_ARG) {
  if (app.documents.length === 0) {
    return "ERR: Chưa mở tài liệu nào.";
  }
  var doc = app.activeDocument;
  var MM = 2.834645669;
  var _DC_RESULT = "OK: đã dàn xong."; // kết quả trả về panel
  // Gom cảnh báo expand để báo 1 lần cuối (dùng chung cho mọi nhánh).
  var expandWarnings = [];

  // ============================================================
  //  HỘP CẢNH BÁO có ICON TAM GIÁC (⚠) vẽ bằng ScriptUI.
  //  Dùng thay alert() cho mọi thông báo LỖI / CẢNH BÁO.
  //  title: tiêu đề cửa sổ (mặc định "Cảnh báo").
  // ============================================================
  function warn(msg, title) {
    try {
      var w = new Window("dialog", title || "Cảnh báo");
      w.orientation = "column";
      w.alignChildren = "fill";
      w.margins = 18;
      w.spacing = 12;

      var row = w.add("group");
      row.orientation = "row";
      row.alignChildren = "top";
      row.spacing = 14;

      // --- Icon tam giác cảnh báo (vẽ bằng graphics onDraw của panel) ---
      var ico = row.add("panel");
      ico.preferredSize = [56, 56];
      ico.margins = 0;
      ico.borderStyle = "none";
      ico.onDraw = function () {
        var g = this.graphics;
        var yellow = g.newBrush(g.BrushType.SOLID_COLOR, [1, 0.75, 0, 1]);
        var black = g.newBrush(g.BrushType.SOLID_COLOR, [0.12, 0.12, 0.12, 1]);
        // Vẽ hình đa giác (dùng cho icon cảnh báo tam giác).
        function poly(pts, brush) {
          g.newPath();
          g.moveTo(pts[0][0], pts[0][1]);
          for (var i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
          g.closePath();
          g.fillPath(brush);
        }
        var cx = 28;
        // tam giác vàng
        poly(
          [
            [cx, 6],
            [50, 50],
            [6, 50],
          ],
          yellow,
        );
        // thân dấu chấm than (hình chữ nhật hẹp, hơi thon xuống)
        poly(
          [
            [cx - 2.5, 20],
            [cx + 2.5, 20],
            [cx + 1.8, 35],
            [cx - 1.8, 35],
          ],
          black,
        );
        // chấm dưới (bát giác xấp xỉ hình tròn)
        var dcx = cx,
          dcy = 42,
          rr = 3;
        var dot = [];
        for (var a = 0; a < 8; a++) {
          var ang = (Math.PI * 2 * a) / 8;
          dot.push([dcx + rr * Math.cos(ang), dcy + rr * Math.sin(ang)]);
        }
        poly(dot, black);
      };

      // --- Nội dung text ---
      // Nếu msg có phần "*** ... ***" (cảnh báo) -> tách ra, làm NỔI BẬT.
      var mainMsg = msg,
        redMsg = null;
      var starIdx = msg.indexOf("*** ");
      if (starIdx >= 0) {
        mainMsg = msg.substring(0, starIdx).replace(/\s+$/, "");
        redMsg = msg.substring(starIdx);
      }
      var col = row.add("group");
      col.orientation = "column";
      col.alignChildren = "left";
      col.spacing = 8;
      if (mainMsg) {
        var t1 = col.add("statictext", undefined, mainMsg, { multiline: true });
        t1.preferredSize.width = 360;
      }
      if (redMsg) {
        // Bọc khung ký tự để NỔI BẬT (không phụ thuộc màu - luôn thấy).
        var boxed =
          "\u25B6\u25B6\u25B6 CHÚ Ý \u25C0\u25C0\u25C0\n" +
          redMsg.replace(/\*\*\*/g, "").replace(/^\s+|\s+$/g, "");
        var t2 = col.add("statictext", undefined, boxed, { multiline: true });
        t2.preferredSize.width = 360;
        // Thử tô ĐỎ + ĐẬM (nếu bản Illustrator hỗ trợ; không thì vẫn thấy khung).
        try {
          var g2 = t2.graphics;
          g2.foregroundColor = g2.newPen(
            g2.PenType.SOLID_COLOR,
            [0.92, 0.12, 0.12],
            1,
          );
        } catch (e) {}
        try {
          var f = t2.graphics.font;
          t2.graphics.font = ScriptUI.newFont(
            f.name,
            "BOLD",
            (f.size || 12) + 2,
          );
        } catch (e) {}
      }

      var gb = w.add("group");
      gb.alignment = "right";
      var okB = gb.add("button", undefined, "Đã hiểu", { name: "ok" });
      okB.active = true;
      w.show();
    } catch (e) {
      // Nếu ScriptUI vẽ lỗi (bản AI cũ) -> fallback alert thường có ký tự cảnh báo.
      alert("(!) " + msg);
    }
  }

  // ============================================================
  //  HỘP THÀNH CÔNG có ICON DẤU TICK (✓) vẽ bằng ScriptUI.
  //  Dùng thay alert() cho các thông báo THÀNH CÔNG.
  // ============================================================
  function okBox(msg, title) {
    try {
      var w = new Window("dialog", title || "Hoàn tất");
      w.orientation = "column";
      w.alignChildren = "fill";
      w.margins = 18;
      w.spacing = 12;

      var row = w.add("group");
      row.orientation = "row";
      row.alignChildren = "top";
      row.spacing = 14;

      var ico = row.add("panel");
      ico.preferredSize = [56, 56];
      ico.margins = 0;
      ico.borderStyle = "none";
      ico.onDraw = function () {
        var g = this.graphics;
        var green = g.newBrush(g.BrushType.SOLID_COLOR, [0.18, 0.72, 0.35, 1]);
        var white = g.newPen(g.PenType.SOLID_COLOR, [1, 1, 1, 1], 5);
        // vòng tròn xanh (đa giác 20 cạnh)
        var cx = 28,
          cy = 28,
          r = 22;
        g.newPath();
        g.moveTo(cx + r, cy);
        for (var a = 1; a <= 20; a++) {
          var ang = (Math.PI * 2 * a) / 20;
          g.lineTo(cx + r * Math.cos(ang), cy + r * Math.sin(ang));
        }
        g.closePath();
        g.fillPath(green);
        // dấu tick trắng (2 đoạn thẳng)
        g.newPath();
        g.moveTo(17, 29);
        g.lineTo(25, 37);
        g.lineTo(40, 19);
        g.strokePath(white);
      };

      var txt = row.add("statictext", undefined, msg, {
        multiline: true,
      });
      txt.preferredSize.width = 360;

      var gb = w.add("group");
      gb.alignment = "right";
      var okB = gb.add("button", undefined, "OK", { name: "ok" });
      okB.active = true;
      w.show();
    } catch (e) {
      alert(msg);
    }
  }

  // ============================================================
  //  THANH TIẾN TRÌNH (progress bar)
  //  Dùng palette window để cửa sổ không chặn thao tác script.
  //  prog.start(tổng bước, tiêu đề) -> prog.step(nhãn) -> prog.done()
  //  Nhãn từng bước giúp thấy khúc nào đứng lâu.
  // ============================================================
  var prog = (function () {
    var win = null,
      bar = null,
      txt = null,
      cur = 0,
      total = 1,
      t0 = 0;
    // Bắt đầu thanh tiến trình: đặt tổng số bước + tiêu đề.
    function start(totalSteps, title) {
      try {
        total = totalSteps > 0 ? totalSteps : 1;
        cur = 0;
        t0 = new Date().getTime();
        win = new Window("palette", title || "Đang xử lý...");
        win.orientation = "column";
        win.alignChildren = "fill";
        win.margins = 16;
        win.spacing = 8;
        win.preferredSize.width = 360;
        txt = win.add("statictext", undefined, "Bắt đầu...");
        txt.preferredSize.width = 328;
        bar = win.add("progressbar", undefined, 0, total);
        bar.preferredSize = [328, 14];
        win.show();
        win.update();
      } catch (e) {
        win = null;
      }
    }
    // Tiến 1 bước, cập nhật nhãn tiến trình.
    function step(label) {
      cur++;
      try {
        if (!win) return;
        var el = ((new Date().getTime() - t0) / 1000).toFixed(1);
        txt.text =
          "(" + cur + "/" + total + ") " + (label || "") + "  [" + el + "s]";
        bar.value = cur;
        win.update();
      } catch (e) {}
    }
    // Đóng thanh tiến trình.
    function done() {
      try {
        if (win) win.close();
      } catch (e) {}
      win = null;
    }
    return { start: start, step: step, done: done };
  })();
  //  Mỗi layout gồm:
  //    name    : tên hiển thị
  //    w, h    : kích thước card (mm) - card nằm ngang (w >= h)
  //    total   : tổng số chỗ
  //    divisors: mảng số mẫu hợp lệ
  //    front(oL,oT,ctx) : hàm trả mảng slot mặt trước
  //    back(oL,oT,ctx)  : hàm trả mảng slot mặt sau (đối xứng)
  //  ctx chứa: W,H (đã nhân MM), G (khe), ROT.
  //  Đường dẫn file pon lấy từ dan_card_config.txt (key = đường dẫn),
  //  KHÔNG khai báo trong code nữa.
  // ============================================================
  var LAYOUTS = [
    {
      name: "9.2 x 5.6  (20 chỗ)",
      key: "9.2x5.6",
      w: 92,
      h: 56,
      total: 20,
      divisors: [1, 2, 4, 5, 10, 20],
      front: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var vW = H,
          vH = W,
          leftW = 4 * vW,
          leftH = 3 * vH,
          slots = [],
          row,
          col;
        // cột phải 6 ngang
        var rL = oL + leftW + G;
        for (row = 0; row < 6; row++)
          slots.push({ cx: rL + W / 2, cy: oT - row * H - H / 2, rot: 0 });
        // khối 12 dọc, mỗi hàng PHẢI->TRÁI, xoay ROT+180
        var fRot = ROT + 180;
        for (row = 0; row < 3; row++)
          for (col = 3; col >= 0; col--)
            slots.push({
              cx: oL + col * vW + vW / 2,
              cy: oT - row * vH - vH / 2,
              rot: fRot,
            });
        // dải 2 dưới
        var botT = oT - (leftH + G);
        for (col = 0; col < 2; col++)
          slots.push({ cx: oL + col * W + W / 2, cy: botT - H / 2, rot: 0 });
        return slots;
      },
      back: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var vW = H,
          vH = W,
          leftW = 4 * vW,
          leftH = 3 * vH,
          slots = [],
          row,
          col;
        // cột 6 ngang TRÁI
        for (row = 0; row < 6; row++)
          slots.push({ cx: oL + W / 2, cy: oT - row * H - H / 2, rot: 0 });
        // khối 12 dọc phải, xoay ROT, lấp TRÁI->PHẢI
        var bRot = ROT + 360;
        var b12 = oL + W + G;
        for (row = 0; row < 3; row++)
          for (col = 0; col < 4; col++)
            slots.push({
              cx: b12 + col * vW + vW / 2,
              cy: oT - row * vH - vH / 2,
              rot: bRot,
            });
        // dải 2 dưới-PHẢI
        var botT = oT - (leftH + G);
        var rightEdge = b12 + leftW;
        for (col = 0; col < 2; col++) {
          var Lx = rightEdge - (col + 1) * W + W / 2;
          slots.push({ cx: Lx, cy: botT - H / 2, rot: 0 });
        }
        return slots;
      },
    },
    {
      name: "9 x 5.5  (20 chỗ)",
      key: "9x5.5",
      w: 90,
      h: 55,
      total: 20,
      divisors: [1, 2, 4, 5, 10, 20],
      front: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var vW = H,
          vH = W,
          leftW = 4 * vW,
          leftH = 3 * vH,
          slots = [],
          row,
          col;
        // cột phải 6 ngang
        var rL = oL + leftW + G;
        for (row = 0; row < 6; row++)
          slots.push({ cx: rL + W / 2, cy: oT - row * H - H / 2, rot: 0 });
        // khối 12 dọc, mỗi hàng PHẢI->TRÁI, xoay ROT+180
        var fRot = ROT + 180;
        for (row = 0; row < 3; row++)
          for (col = 3; col >= 0; col--)
            slots.push({
              cx: oL + col * vW + vW / 2,
              cy: oT - row * vH - vH / 2,
              rot: fRot,
            });
        // dải 2 dưới
        var botT = oT - (leftH + G);
        for (col = 0; col < 2; col++)
          slots.push({ cx: oL + col * W + W / 2, cy: botT - H / 2, rot: 0 });
        return slots;
      },
      back: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var vW = H,
          vH = W,
          leftW = 4 * vW,
          leftH = 3 * vH,
          slots = [],
          row,
          col;
        // cột 6 ngang TRÁI
        for (row = 0; row < 6; row++)
          slots.push({ cx: oL + W / 2, cy: oT - row * H - H / 2, rot: 0 });
        // khối 12 dọc phải, xoay ROT, lấp TRÁI->PHẢI
        var bRot = ROT + 360;
        var b12 = oL + W + G;
        for (row = 0; row < 3; row++)
          for (col = 0; col < 4; col++)
            slots.push({
              cx: b12 + col * vW + vW / 2,
              cy: oT - row * vH - vH / 2,
              rot: bRot,
            });
        // dải 2 dưới-PHẢI
        var botT = oT - (leftH + G);
        var rightEdge = b12 + leftW;
        for (col = 0; col < 2; col++) {
          var Lx = rightEdge - (col + 1) * W + W / 2;
          slots.push({ cx: Lx, cy: botT - H / 2, rot: 0 });
        }
        return slots;
      },
    },
    {
      name: "9.2 x 5.2  (21 chỗ)",
      key: "9.2x5.2",
      w: 92,
      h: 52,
      total: 21,
      divisors: [1, 3, 7, 21],
      blockGap: 5, // khe 2 cụm = 5mm
      front: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var vW = H,
          vH = W,
          slots = [],
          row,
          col;
        // khối 18 DỌC: 6 cột x 3 hàng, theo CỘT (trái->phải), mỗi cột trên->dưới
        for (col = 0; col < 6; col++)
          for (row = 0; row < 3; row++)
            slots.push({
              cx: oL + col * vW + vW / 2,
              cy: oT - row * vH - vH / 2,
              rot: ROT,
            });
        // dải 3 NGANG dưới, cách khối 5mm (G), căn MÉP PHẢI khối 18
        var blockW = 6 * vW; // bề rộng khối 18
        var botT = oT - (3 * vH + G);
        var rightEdge = oL + blockW; // mép phải khối 18
        for (col = 0; col < 3; col++) {
          // đặt 3 thẻ căn về phải: thẻ phải nhất sát mép phải
          var cx = rightEdge - (3 - col) * W + W / 2;
          slots.push({ cx: cx, cy: botT - H / 2, rot: 0 });
        }
        return slots;
      },
      back: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var vW = H,
          vH = W,
          slots = [],
          row,
          col;
        // khối 18 dọc: đảo cột trái<->phải, xoay đối đầu (ROT+180)
        var bRot = ROT + 180;
        for (col = 0; col < 6; col++)
          for (row = 0; row < 3; row++) {
            var mcol = 5 - col;
            slots.push({
              cx: oL + mcol * vW + vW / 2,
              cy: oT - row * vH - vH / 2,
              rot: bRot,
            });
          }
        // dải 3 ngang dưới, đảo trái<->phải
        var botT = oT - (3 * vH + G);
        for (col = 0; col < 3; col++) {
          var mc = 2 - col;
          slots.push({ cx: oL + mc * W + W / 2, cy: botT - H / 2, rot: 0 });
        }
        return slots;
      },
    },
    {
      name: "8.7 x 5.5  (22 chỗ)",
      key: "8.7x5.5",
      w: 87,
      h: 55,
      total: 22,
      divisors: [1, 2, 11, 22],
      blockGap: 0, // khe giữa các khối = 0
      sendToBack: true, // đưa cụm xuống dưới cùng sau khi dàn
      front: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var slots = [],
          row,
          col;
        // khối 18 ngang: 3 cột x 6 hàng, thứ tự theo CỘT trên->dưới
        for (col = 0; col < 3; col++)
          for (row = 0; row < 6; row++)
            slots.push({
              cx: oL + col * W + W / 2,
              cy: oT - row * H - H / 2,
              rot: 0,
            });
        // cột phải 4 dọc
        var rL = oL + 3 * W + G;
        for (row = 0; row < 4; row++)
          slots.push({ cx: rL + H / 2, cy: oT - row * W - W / 2, rot: ROT });
        return slots;
      },
      back: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          G = c.G,
          ROT = c.ROT;
        var slots = [],
          row,
          col;
        var bRot = ROT + 180;
        // khối 18 ngang ở PHẢI (sau cột dọc rộng H + khe G)
        // Lấp theo cột nhưng ĐẢO cột (mcol = 2-col) để khớp lưng mặt trước:
        // mặt trước cột trái->phải, mặt sau cột phải->trái.
        var blockL = oL + H + G;
        for (col = 0; col < 3; col++) {
          var mcol = 2 - col;
          for (row = 0; row < 6; row++)
            slots.push({
              cx: blockL + mcol * W + W / 2,
              cy: oT - row * H - H / 2,
              rot: 0,
            });
        }
        // cột 4 dọc ở TRÁI, xoay đối đầu
        for (row = 0; row < 4; row++)
          slots.push({ cx: oL + H / 2, cy: oT - row * W - W / 2, rot: bRot });
        return slots;
      },
    },
    {
      name: "10.2 x 15.2  (6 chỗ)",
      key: "10.2x15.2",
      w: 152,
      h: 102,
      total: 6,
      divisors: [1, 2, 3, 6],
      front: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          slots = [],
          row,
          col;
        // lưới 2 cột x 3 hàng, thẻ NGANG, thứ tự theo HÀNG trái->phải, trên->dưới
        for (row = 0; row < 3; row++)
          for (col = 0; col < 2; col++)
            slots.push({
              cx: oL + col * W + W / 2,
              cy: oT - row * H - H / 2,
              rot: 0,
            });
        return slots; // 6
      },
      back: function (oL, oT, c) {
        var W = c.W,
          H = c.H,
          slots = [],
          row,
          col;
        // đối xứng ngang: mỗi hàng đảo trái<->phải (mcol = 1-col)
        for (row = 0; row < 3; row++)
          for (col = 0; col < 2; col++) {
            var mcol = 1 - col;
            slots.push({
              cx: oL + mcol * W + W / 2,
              cy: oT - row * H - H / 2,
              rot: 0,
            });
          }
        return slots;
      },
    },
    // ----------------------------------------------------------
    //  VOUCHER 15.2 x 7.2 (152 x 72 mm)
    //  Cờ isVoucher: khi chọn loại này sẽ hiện thêm bảng phụ
    //  hỏi "có ghép card 9.2x5.6 không?".
    //   - KHÔNG card: 8 voucher NGANG (152 rộng x 72 cao), lưới 2 cột x 4 hàng.
    //                 Mặt trước: cột PHẢI 1-2-3-4 (trên->dưới), cột TRÁI 5-6-7-8.
    //                 Mặt sau : đối xứng ngang (đổi cột trái<->phải).
    //   - CÓ card   : 8 voucher NGANG + dải 3 card 9.2x5.6 (nhánh riêng bên dưới).
    // ----------------------------------------------------------
    {
      name: "15.2 x 7.2  (voucher, 8 chỗ)",
      key: "15.2x7.2",
      w: 152,
      h: 72,
      total: 8,
      divisors: [1, 2, 4, 8],
      isVoucher: true, // bật bảng phụ ghép card
      front: function (oL, oT, c) {
        // Voucher NGANG: mỗi ô rộng W(152), cao H(72). Lưới 2 cột x 4 hàng.
        // Thứ tự lấp: cột PHẢI trước (1-2-3-4 trên->dưới), rồi cột TRÁI (5-6-7-8).
        var W = c.W,
          H = c.H;
        var slots = [],
          row;
        // cột phải (col index 1)
        for (row = 0; row < 4; row++)
          slots.push({
            cx: oL + 1 * W + W / 2,
            cy: oT - row * H - H / 2,
            rot: 0,
          });
        // cột trái (col index 0)
        for (row = 0; row < 4; row++)
          slots.push({
            cx: oL + 0 * W + W / 2,
            cy: oT - row * H - H / 2,
            rot: 0,
          });
        return slots; // 8
      },
      back: function (oL, oT, c) {
        // Mặt sau đối xứng ngang: 1-2-3-4 ở cột TRÁI, 5-6-7-8 ở cột PHẢI.
        var W = c.W,
          H = c.H;
        var slots = [],
          row;
        // cột trái (col 0) cho 1-4
        for (row = 0; row < 4; row++)
          slots.push({
            cx: oL + 0 * W + W / 2,
            cy: oT - row * H - H / 2,
            rot: 0,
          });
        // cột phải (col 1) cho 5-8
        for (row = 0; row < 4; row++)
          slots.push({
            cx: oL + 1 * W + W / 2,
            cy: oT - row * H - H / 2,
            rot: 0,
          });
        return slots;
      },
    },
  ];

  // ============================================================
  //  CHỌN LOẠI CARD theo tham số (thay cho dialog ScriptUI)
  //  layoutKey khớp với LAYOUTS[i].key. Không tìm thấy -> lỗi.
  // ============================================================
  var LAYOUT = null;
  for (var li = 0; li < LAYOUTS.length; li++) {
    if (LAYOUTS[li].key === SEL_LAYOUT_KEY) {
      LAYOUT = LAYOUTS[li];
      break;
    }
  }
  if (!LAYOUT) {
    return "ERR: Không tìm thấy loại card '" + SEL_LAYOUT_KEY + "'.";
  }

  // Voucher ghép card: nhận từ tham số (thay dialog)
  var VOUCHER_WITH_CARD = LAYOUT.isVoucher && VOUCHER_WITH_CARD_ARG === true;

  // Voucher CÓ ghép card đi theo nhánh riêng rồi kết thúc.
  if (VOUCHER_WITH_CARD) {
    try {
      runVoucherWithCard();
    } catch (e) {
      var num = -1;
      try {
        num = e.number;
      } catch (x) {}
      if (num === 45 || num === 1200) {
        return "ERR: Voucher sai kích thước (cần 15.2x7.2cm).";
      }
      return "ERR: " + dcMoTaLoi(e);
    }
    return _DC_RESULT;
  }

  // ============================================================
  //  KIỂM TRA SELECTION
  // ============================================================
  var sel = doc.selection;
  if (!sel || sel.length < 1) {
    return "ERR: Chưa chọn object nào để dàn.";
  }

  // Phát hiện số cột -> quyết định in 1 mặt (1 cột) hay 2 mặt (2 cột).
  var nCols = detectColumns(sel, LAYOUT.w * MM);
  var TWO_SIDES = nCols >= 2; // >=2 cột coi là in 2 mặt

  var nModels;
  if (TWO_SIDES) {
    // 2 mặt: mỗi mẫu 2 object (trước + sau) -> số mẫu = object / 2.
    if (sel.length % 2 !== 0) {
      return (
        "ERR: In 2 mặt cần số object chẵn (mỗi mẫu 2: trước+sau). Đang chọn " +
        sel.length +
        " object lẻ."
      );
    }
    nModels = sel.length / 2;
  } else {
    // 1 mặt: mỗi object là 1 mẫu -> số mẫu = số object đang chọn.
    nModels = sel.length;
  }

  // ---- PHÁT HIỆN CON ĐÔI SỚM (layout 9.2x5.6): quy đổi slot ----
  //  Con đôi (cạnh dài ~184mm) chiếm 2 slot; con thường 1 slot.
  //  Đếm theo MẪU (2 mặt -> mỗi cặp là 1 mẫu; đo mặt trước).
  var _hasDoubleEarly = false;
  var _nDblEarly = 0;
  if (LAYOUT.key === "9.2x5.6") {
    var _stepMdl = TWO_SIDES ? 2 : 1;
    for (var _di = 0; _di < sel.length; _di += _stepMdl) {
      var _sd = visSizeMM(sel[_di]);
      var _hi = Math.max(_sd.w, _sd.h);
      if (Math.abs(_hi - 184) <= 6) {
        _hasDoubleEarly = true;
        _nDblEarly++;
      }
    }
  }

  var okDiv = false;
  for (var d = 0; d < LAYOUT.divisors.length; d++)
    if (LAYOUT.divisors[d] === nModels) okDiv = true;
  // Có con đôi -> KHÔNG kiểm tra divisor (mixed tự xử lý slot).
  //  Chỉ cần tổng slot quy đổi = con thường*1 + con đôi*2 <= 20 và khớp.
  if (_hasDoubleEarly) {
    var _nNorm = nModels - _nDblEarly;
    var _choBo = _nNorm * 1 + _nDblEarly * 2; // chỗ quy đổi 1 bộ mẫu
    // Tổng chỗ 1 bộ phải là ước của 20 (để nhân đều k lần).
    var _kFill = LAYOUT.total / _choBo;
    var _kInt = _choBo > 0 && LAYOUT.total % _choBo === 0;
    if (!_kInt) {
      return (
        "ERR: Số mẫu không đều. Chỗ quy đổi (nhỏ + đôi×2) = " +
        _choBo +
        " phải là ước của " +
        LAYOUT.total +
        " (1,2,4,5,10,20). " +
        "Chọn lại số con (đôi=2 chỗ, nhỏ=1 chỗ)."
      );
    }
    // Số slot đôi thực dùng = nĐôi × k, không quá 5.
    var _slotDbl = _nDblEarly * _kFill;
    if (_slotDbl > 5) {
      return (
        "ERR: Card đôi chiếm tối đa 5 chỗ đôi. Đang cần " +
        _slotDbl +
        " chỗ đôi (nĐôi " +
        _nDblEarly +
        " × nhân " +
        _kFill +
        ")."
      );
    }
    okDiv = true;
  }
  if (!okDiv) {
    return (
      "ERR: Số mẫu " +
      nModels +
      " không hợp lệ cho khổ này. " +
      "Cần chọn số object sao cho số mẫu là: " +
      LAYOUT.divisors.join(", ") +
      "."
    );
  }
  var perModel = _hasDoubleEarly ? 1 : LAYOUT.total / nModels;

  // ============================================================
  //  BƯỚC 2: BẢNG CẤU HÌNH
  // ============================================================
  var dlg = new Window(
    "dialog",
    "Dàn " + LAYOUT.name + " - " + nModels + " mẫu",
  );
  dlg.orientation = "column";
  dlg.alignChildren = "fill";
  dlg.margins = 16;
  dlg.spacing = 10;
  dlg.add(
    "statictext",
    undefined,
    "Số mẫu: " + nModels + "  |  Mỗi mẫu: " + perModel + " chỗ",
  );
  var g1 = dlg.add("group");
  g1.add("statictext", undefined, "Rộng thẻ (mm):");
  var inW = g1.add("edittext", undefined, "" + LAYOUT.w);
  inW.characters = 6;
  var g2 = dlg.add("group");
  g2.add("statictext", undefined, "Cao thẻ (mm):");
  var inH = g2.add("edittext", undefined, "" + LAYOUT.h);
  inH.characters = 6;
  var g3 = dlg.add("group");
  g3.add("statictext", undefined, "Khe giữa khối (mm):");
  var inG = g3.add("edittext", undefined, "2");
  inG.characters = 6;
  if (typeof LAYOUT.blockGap === "number") {
    // Layout tự quy định khe giữa khối: điền sẵn và khoá ô, không để gõ số vô nghĩa.
    inG.text = "" + LAYOUT.blockGap;
    inG.enabled = false;
  }
  var pRot = dlg.add("panel", undefined, "Chiều xoay thẻ dọc");
  pRot.orientation = "row";
  pRot.margins = 10;
  var r90 = pRot.add("radiobutton", undefined, "90°");
  var rm90 = pRot.add("radiobutton", undefined, "-90°");
  r90.value = true;
  var pType = dlg.add("panel", undefined, "Loại in");
  pType.orientation = "row";
  pType.margins = 10;
  var tFast = pType.add("radiobutton", undefined, "In nhanh");
  var tOffset = pType.add("radiobutton", undefined, "Cardoffset");
  tFast.value = true;
  var gGhi = dlg.add("group");
  gGhi.add("statictext", undefined, "Ghi chú (cardoffset):");
  var inNote = gGhi.add(
    "edittext",
    undefined,
    "cardoffset - cán mờ - bỏ hộp nhựa",
  );
  inNote.characters = 30;
  var gBtn = dlg.add("group");
  gBtn.alignment = "right";
  gBtn.add("button", undefined, "Hủy", { name: "cancel" });
  gBtn.add("button", undefined, "Dàn", { name: "ok" });
  if (dlg.show() !== 1) return "OK: Đã hủy, chưa thay đổi gì.";

  // Ép chuỗi thành số (nhận cả dấu phẩy "9,2"); lỗi thì trả giá trị mặc định d.
  function num(t, d) {
    var v = parseFloat(String(t).replace(",", "."));
    return isNaN(v) ? d : v;
  }
  var W = num(inW.text, LAYOUT.w) * MM,
    H = num(inH.text, LAYOUT.h) * MM;
  // Nếu layout khai báo blockGap thì ép dùng số đó, bỏ qua ô nhập khe (có báo lại).
  var G =
    typeof LAYOUT.blockGap === "number"
      ? LAYOUT.blockGap * MM
      : num(inG.text, 2) * MM;
  var kheBiBoQua =
    typeof LAYOUT.blockGap === "number" &&
    Math.abs(num(inG.text, LAYOUT.blockGap) - LAYOUT.blockGap) > 0.001
      ? " Khe giữa khối theo layout: " +
        LAYOUT.blockGap +
        " mm (ô nhập bị bỏ qua)."
      : "";
  var ROT = r90.value ? 90 : -90;
  var IS_OFFSET = tOffset.value;
  var NOTE_TEXT = inNote.text;
  var CTX = { W: W, H: H, G: G, ROT: ROT };

  // ============================================================
  //  HỆ THỐNG CONFIG (đường dẫn file pon)
  //  - Lần đầu: hỏi người dùng chọn file config, nhớ vị trí.
  //  - Config dạng text: mỗi dòng "key = đường dẫn"
  //      9.2x5.6 = D:/.../pon1.ai
  //  - Nếu thiếu config/dòng/file pon -> hỏi chọn file pon tay.
  // ============================================================

  // File nhớ vị trí config (lưu ở thư mục preferences người dùng)
  function memoFile() {
    return new File(Folder.userData + "/dan_card_config_path.txt");
  }
  // Đọc đường dẫn pon đã lưu (bộ nhớ tạm 1 dòng).
  function readMemo() {
    var f = memoFile();
    if (f.exists) {
      f.encoding = "UTF-8";
      f.open("r");
      var p = f.read();
      f.close();
      return (p || "").replace(/^\s+|\s+$/g, "");
    }
    return "";
  }
  // Lưu đường dẫn pon vào bộ nhớ tạm.
  function writeMemo(path) {
    var f = memoFile();
    try {
      f.encoding = "UTF-8";
      f.open("w");
      f.write(path);
      f.close();
    } catch (e) {}
  }

  // Lấy file config: dùng vị trí đã nhớ, nếu chưa có/không tồn tại -> hỏi chọn.
  // Nếu chưa có file config nào -> hỏi có muốn TẠO MỚI không.
  function getConfigFile() {
    var saved = readMemo();
    if (saved) {
      var sf = new File(saved);
      if (sf.exists) return sf;
    }
    // hỏi chọn file config có sẵn
    var chosen = File.openDialog(
      "Chọn file config (dan_card_config.txt) - Cancel để tạo mới",
      "*.txt",
    );
    if (chosen && chosen.exists) {
      writeMemo(chosen.fsName);
      return chosen;
    }
    // chưa chọn -> hỏi tạo file config mới để tự lưu đường dẫn về sau
    var wantCreate = confirm(
      "Chưa có file config.\nTạo file config mới để tool tự nhớ đường dẫn pon?",
    );
    if (wantCreate) {
      var nf = File.saveDialog(
        "Lưu file config mới (dan_card_config.txt)",
        "*.txt",
      );
      if (nf) {
        try {
          nf.encoding = "UTF-8";
          nf.open("w");
          nf.write("# Config đường dẫn file pon - Tool Dàn Card (tự sinh)\n");
          nf.close();
          writeMemo(nf.fsName);
          return nf;
        } catch (e) {}
      }
    }
    return null;
  }

  // Đọc config -> object { key: path }
  function parseConfig(cf) {
    var map = {};
    if (!cf || !cf.exists) return map;
    cf.encoding = "UTF-8";
    cf.open("r");
    var txt = cf.read();
    cf.close();
    var lines = txt.split(/\r\n|\r|\n/);
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].replace(/^\s+|\s+$/g, "");
      if (!line || line.charAt(0) === "#") continue; // bỏ dòng trống/chú thích
      var eq = line.indexOf("=");
      if (eq < 0) continue;
      var k = line.substring(0, eq).replace(/^\s+|\s+$/g, "");
      var v = line.substring(eq + 1).replace(/^\s+|\s+$/g, "");
      if (k) map[k] = v;
    }
    return map;
  }

  // Ghi/cập nhật một dòng "key = path" vào file config.
  // Nếu key đã có -> thay đường dẫn. Nếu chưa -> thêm dòng mới cuối file.
  // Trả về true nếu ghi thành công.
  function saveConfigEntry(cf, key, path) {
    if (!cf) return false;
    try {
      // đọc nội dung hiện có (nếu file tồn tại)
      var lines = [];
      if (cf.exists) {
        cf.encoding = "UTF-8";
        cf.open("r");
        var txt = cf.read();
        cf.close();
        lines = txt.split(/\r\n|\r|\n/);
      }
      // tìm dòng chứa key (bỏ qua dòng trống/chú thích) để thay
      var replaced = false;
      for (var i = 0; i < lines.length; i++) {
        var ln = lines[i].replace(/^\s+|\s+$/g, "");
        if (!ln || ln.charAt(0) === "#") continue;
        var eq = ln.indexOf("=");
        if (eq < 0) continue;
        var k = ln.substring(0, eq).replace(/^\s+|\s+$/g, "");
        if (k === key) {
          lines[i] = key + " = " + path;
          replaced = true;
          break;
        }
      }
      if (!replaced) {
        // bỏ bớt dòng trống thừa ở cuối rồi thêm dòng mới
        while (
          lines.length > 0 &&
          lines[lines.length - 1].replace(/^\s+|\s+$/g, "") === ""
        )
          lines.pop();
        lines.push(key + " = " + path);
      }
      cf.encoding = "UTF-8";
      cf.open("w");
      cf.write(lines.join("\n") + "\n");
      cf.close();
      return true;
    } catch (e) {
      return false;
    }
  }
  // Ưu tiên: config (dan_card_config.txt) -> hỏi chọn tay (+ tự lưu vào config).
  function resolvePonPath(layout) {
    // 1) thử config
    var cf = getConfigFile();
    if (cf) {
      var map = parseConfig(cf);
      var p = map[layout.key];
      if (p) {
        var pf = new File(p);
        if (pf.exists) return pf.fsName;
      }
    }
    // 2) hỏi chọn file pon tay
    var chosen = File.openDialog(
      "Chọn file pon cho " + layout.name + " (.ai)",
      "*.ai",
    );
    if (chosen && chosen.exists) {
      // Tự ghi đường dẫn vừa chọn vào config để lần sau khỏi chọn lại.
      if (cf && layout.key) {
        var saved = saveConfigEntry(cf, layout.key, chosen.fsName);
        if (saved)
          okBox(
            "Đã lưu đường dẫn pon vào config:\n" +
              layout.key +
              " = " +
              chosen.fsName +
              "\n\nLần sau sẽ tự dùng, khỏi chọn tay.",
            "Đã lưu config",
          );
      }
      return chosen.fsName;
    }
    return null;
  }

  // Mọi luồng Dàn Card dùng chung artboard của pon 9.2x5.6.
  // Pon này có thể để trắng: khi đó importPon chỉ lấy artboard, không
  // nhân bản bất kỳ object pon nào và cách dàn vẫn giữ nguyên.
  var COMMON_ARTBOARD_LAYOUT = {
    name: "artboard chung 9.2x5.6",
    key: "9.2x5.6",
  };

  // ============================================================
  //  XÓA ARTBOARD 2 + NỘI DUNG (dùng khi in 1 mặt)
  //  Xóa mọi object có tâm nằm trong vùng AB index 1 (pon thừa của
  //  trang 2), rồi xóa artboard đó. Chỉ giữ lại AB1 để dàn 1 mặt.
  // ============================================================
  function removeSecondArtboard(d, protectList) {
    var result = { removed: 0, kept: 0 };
    if (!d || d.artboards.length < 2) return result;
    var rc = d.artboards[1].artboardRect; // [l, t, r, b]
    // chỉ xoá object DO TOOL TẠO có tâm trong vùng AB2; object lạ giữ lại và đếm
    result = dcDonObjectTool(d, [rc], protectList);
    // xóa artboard index 1
    try {
      d.artboards.remove(1);
    } catch (e) {}
    return result;
  }

  // ============================================================
  //  PHÁT HIỆN SỐ CỘT (1 hay 2) TỪ PHÂN BỐ X CỦA SELECTION
  //  Gom tâm X của các object thành nhóm. 1 nhóm -> 1 cột (in 1 mặt),
  //  2 nhóm -> 2 cột (in 2 mặt). Ngưỡng gom: nửa bề rộng 1 card.
  //  Trả về số nhóm cột (1, 2, hoặc nhiều hơn nếu bố trí lạ).
  // ============================================================
  function detectColumns(selection, cardWmm) {
    var xs = [];
    for (var i = 0; i < selection.length; i++) {
      var c = cbC(selection[i]);
      xs.push(c[0]);
    }
    xs.sort(function (a, b) {
      return a - b;
    });
    // ngưỡng: 2 object cùng cột nếu X cách nhau < 0.5 * bề rộng card.
    var thr = 0.5 * cardWmm;
    var groups = 1;
    for (var j = 1; j < xs.length; j++) {
      if (xs[j] - xs[j - 1] > thr) groups++;
    }
    return groups;
  }

  // ============================================================
  //  ĐẢM BẢO ĐỦ 2 ARTBOARD
  //  Nếu file chỉ có 1 artboard -> tạo thêm artboard thứ 2 bằng cách
  //  nhân bản AB1 và đặt ngay bên phải (cách 10mm). Nếu 0 artboard thì
  //  không làm gì (trường hợp cực hiếm).
  // ============================================================
  function ensureTwoArtboards(d) {
    if (!d || d.artboards.length >= 2) return;
    if (d.artboards.length === 0) return;
    var r = d.artboards[0].artboardRect; // [l, t, r, b]
    var w = r[2] - r[0];
    var gap = 10 * MM;
    // artboard 2 đặt bên phải AB1
    var nl = r[2] + gap;
    var nr = nl + w;
    try {
      d.artboards.add([nl, r[1], nr, r[3]]);
    } catch (e) {}
  }

  // ============================================================
  //  XÓA OBJECT TRONG ARTBOARD CŨ
  //  Xóa mọi top-level pageItem có TÂM nằm trong vùng bao của các
  //  artboard hiện có, TRỪ những object trong protectList (các object
  //  mẻ mới dùng để dàn). Mọi thứ ngoài vùng artboard được giữ nguyên.
  // ============================================================
  function clearOldArtboardContent(d, protectList) {
    if (!d || d.artboards.length === 0) return { removed: 0, kept: 0 };
    var rects = [];
    for (var a = 0; a < d.artboards.length; a++)
      rects.push(d.artboards[a].artboardRect);
    return dcDonObjectTool(d, rects, protectList);
  }

  // Dọn object cấp trên cùng trên các layer không khoá/ẩn, CHỈ trong khung bao chung của rects
  // (ngoài vùng không đụng, như bản 2.18):
  //  - object có note DC_NOTE_DAN_CARD → xoá;
  //  - object lạ → GIỮ, đếm vào kept để báo;
  //  - object trong protectList hoặc là group cha của nó → giữ, không đếm.
  function dcDonObjectTool(d, rects, protectList) {
    var L = 1e12,
      T = -1e12,
      R = -1e12,
      B = 1e12;
    for (var ri = 0; ri < rects.length; ri++) {
      var rc = rects[ri];
      if (rc[0] < L) L = rc[0];
      if (rc[1] > T) T = rc[1];
      if (rc[2] > R) R = rc[2];
      if (rc[3] < B) B = rc[3];
    }
    var baoVe = dcTapObject(protectList, true);
    var toRemove = [],
      kept = 0;
    for (var li = 0; li < d.layers.length; li++) {
      var lay = d.layers[li];
      var locked = false,
        hid = false;
      try {
        locked = lay.locked;
        hid = !lay.visible;
      } catch (e) {}
      if (locked || hid) continue; // bỏ layer khóa/ẩn
      var pit = lay.pageItems;
      for (var p = 0; p < pit.length; p++) {
        var it = pit[p];
        var gb;
        try {
          gb = it.geometricBounds;
        } catch (e) {
          continue;
        }
        var cx = (gb[0] + gb[2]) / 2,
          cy = (gb[1] + gb[3]) / 2;
        if (!(cx >= L && cx <= R && cy <= T && cy >= B)) continue; // ngoài vùng: không đụng
        var isLocked = false,
          isHidden = false;
        try {
          isLocked = it.locked;
          isHidden = it.hidden;
        } catch (e) {}
        if (isLocked || isHidden) continue;
        if (dcTrongTap(baoVe, it)) continue; // giữ object mẻ mới và group cha của nó
        var cuaTool = false;
        try {
          cuaTool = it.note === DC_NOTE_DAN_CARD;
        } catch (e) {}
        if (cuaTool) toRemove.push(it);
        else kept++;
      }
    }
    for (var r = 0; r < toRemove.length; r++) {
      try {
        toRemove[r].remove();
      } catch (e) {}
    }
    return { removed: toRemove.length, kept: kept };
  }

  // ============================================================
  //  IMPORT ARTBOARD + PON TỪ FILE PON
  //  Mở file pon -> tạo artboard giống hệt trong file gốc + duplicate pon
  //  -> xóa artboard cũ. Nếu không có ponFile hoặc lỗi -> bỏ qua, dùng
  //  artboard sẵn có.
  // ============================================================
  function importPon(ponPath) {
    if (!ponPath) return doc; // không cấu hình -> giữ nguyên artboard hiện tại
    var pf = new File(ponPath);
    if (!pf.exists) {
      warn(
        "Không tìm thấy file pon:\n" +
          ponPath +
          "\n\n" +
          "Sẽ dùng artboard sẵn có của file hiện tại.",
      );
      return doc;
    }

    var destDoc = doc;
    var destName = destDoc.name; // lưu tên để tìm lại sau
    var oldAbCount = destDoc.artboards.length;

    // ===== TĂNG TỐC: tắt cảnh báo + giảm redraw khi mở/đóng pon =====
    // app.open/close là khúc nặng nhất. Tắt hộp cảnh báo và hạn chế
    // Illustrator vẽ lại màn hình trong lúc thao tác để nhanh hơn.
    var _oldUIL = app.userInteractionLevel;
    try {
      app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    } catch (e) {}

    var resultDoc = destDoc;
    try {
      resultDoc = importPonCore(pf, destDoc, destName, oldAbCount);
    } finally {
      // khôi phục mức tương tác
      try {
        app.userInteractionLevel = _oldUIL;
      } catch (e) {}
    }
    return resultDoc;
  }

  // Phần lõi của importPon.
  function importPonCore(pf, destDoc, destName, oldAbCount) {
    // mở file pon
    var ponDoc = app.open(pf);
    app.activeDocument = ponDoc;

    // Lưu tọa độ artboard pon
    var abRects = [];
    for (var a = 0; a < ponDoc.artboards.length; a++) {
      abRects.push(ponDoc.artboards[a].artboardRect.slice(0));
    }

    // Chuyển active về document gốc để duplicate an toàn.
    app.activeDocument = destDoc;
    var destLayer = destDoc.activeLayer;

    // ===== TỐI ƯU (cách 1): thay vì duplicate TỪNG object (chậm ~0.4s/cái),
    // ===== Group pon rồi duplicate 1 lần (nhanh hơn duplicate từng cái) =====
    var dupped = [];
    var ponTopItems = [];
    for (var i = 0; i < ponDoc.pageItems.length; i++)
      ponTopItems.push(ponDoc.pageItems[i]);

    if (ponTopItems.length === 0) {
      // pon rỗng
    } else if (ponTopItems.length === 1) {
      try {
        dupped.push(
          ponTopItems[0].duplicate(destLayer, ElementPlacement.PLACEATEND),
        );
      } catch (e) {}
    } else {
      // group mọi object pon -> duplicate group 1 lần -> ungroup ở card
      app.activeDocument = ponDoc;
      var ponGroup = ponDoc.groupItems.add();
      for (i = ponTopItems.length - 1; i >= 0; i--) {
        try {
          ponTopItems[i].move(ponGroup, ElementPlacement.PLACEATBEGINNING);
        } catch (e) {}
      }
      var destGroup = null;
      try {
        destGroup = ponGroup.duplicate(destLayer, ElementPlacement.PLACEATEND);
      } catch (e) {}
      // ungroup ở card (pon đóng ngay sau, không cần trả lại)
      app.activeDocument = destDoc;
      if (destGroup) {
        for (i = destGroup.pageItems.length - 1; i >= 0; i--) {
          try {
            var child = destGroup.pageItems[i];
            child.move(destLayer, ElementPlacement.PLACEATEND);
            dupped.push(child);
          } catch (e) {}
        }
        try {
          destGroup.remove();
        } catch (e) {}
      }
    }

    // đóng file pon (không lưu) - app.open lại nhanh (~0.5s) nên không giữ mở
    try {
      app.activeDocument = ponDoc;
      ponDoc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {}

    // lấy lại document gốc theo tên (phòng tham chiếu stale)
    var dd = null;
    for (i = 0; i < app.documents.length; i++) {
      if (app.documents[i].name === destName) {
        dd = app.documents[i];
        break;
      }
    }
    if (dd) {
      destDoc = dd;
      app.activeDocument = destDoc;
    }

    // Nếu file pon không có artboard -> giữ nguyên, không xóa gì
    if (abRects.length === 0) return destDoc;

    // Tạo artboard mới theo abRects
    for (a = 0; a < abRects.length; a++) {
      destDoc.artboards.add(abRects[a]);
    }
    // Xóa artboard CŨ (các artboard index 0..oldAbCount-1)
    if (destDoc.artboards.length > abRects.length) {
      for (a = oldAbCount - 1; a >= 0; a--) {
        try {
          destDoc.artboards.remove(a);
        } catch (e) {}
      }
    }

    // ===== BÙ CHÊNH LỆCH RULER ORIGIN =====
    // Pon duplicate giữ tọa độ theo file pon; artboard add theo abRects.
    // Nếu 2 file khác ruler origin -> pon lệch so với artboard. Dịch pon cho khớp.
    if (dupped.length > 0) {
      var wl = 1e12,
        wt = -1e12,
        wr = -1e12,
        wb = 1e12;
      for (a = 0; a < abRects.length; a++) {
        var rr = abRects[a];
        if (rr[0] < wl) wl = rr[0];
        if (rr[1] > wt) wt = rr[1];
        if (rr[2] > wr) wr = rr[2];
        if (rr[3] < wb) wb = rr[3];
      }
      var wantCx = (wl + wr) / 2,
        wantCy = (wt + wb) / 2;
      var pl = 1e12,
        pt = -1e12,
        pr = -1e12,
        pb = 1e12;
      for (i = 0; i < dupped.length; i++) {
        var gb2 = dupped[i].geometricBounds;
        if (gb2[0] < pl) pl = gb2[0];
        if (gb2[1] > pt) pt = gb2[1];
        if (gb2[2] > pr) pr = gb2[2];
        if (gb2[3] < pb) pb = gb2[3];
      }
      var ponCx = (pl + pr) / 2,
        ponCy = (pt + pb) / 2;
      var dx = wantCx - ponCx,
        dy = wantCy - ponCy;
      if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) {
        for (i = 0; i < dupped.length; i++) {
          try {
            dupped[i].translate(dx, dy);
          } catch (e) {}
        }
      }
      // PON là của tool: gắn note để mẻ sau dọn đúng.
      for (i = 0; i < dupped.length; i++) {
        try {
          dupped[i].note = DC_NOTE_DAN_CARD;
        } catch (e) {}
      }
    }

    return destDoc;
  }

  // (importPon sẽ được gọi sau khi tạo xong models — xem bên dưới)

  // ============================================================
  //  HÀM DÙNG CHUNG
  // ============================================================
  function clipBounds(item) {
    // visibleUnion = nội dung thật (đã giao clip mask, bỏ mask thừa).
    // Dùng cho ghép cặp (theo Y) và căn giữa cụm.
    var acc = { val: null };
    visibleUnion(item, acc);
    if (acc.val) return acc.val;
    try {
      return item.visibleBounds;
    } catch (e) {}
    return item.geometricBounds;
  }
  // Trả về tâm (center) của object theo clip bounds.
  function cbC(item) {
    var g = clipBounds(item);
    return [(g[0] + g[2]) / 2, (g[1] + g[3]) / 2];
  }

  // Đo kích thước bằng visibleUnion (nội dung thật, đã giao clip mask,
  // bỏ mask thừa). Đây là cách đo dùng cho kiểm tra + clip.
  // theoNoiDung = true: đo nội dung thật dù cờ Transform đang bật (dùng khi
  // phán xét kết quả tự sửa khổ — khung clip vừa tạo luôn "đúng", chỉ nội dung mới nói thật).
  function visSizeMM(item, theoNoiDung) {
    var acc = { val: null };
    visibleUnion(item, acc, theoNoiDung === true);
    var g = acc.val;
    if (!g) {
      try {
        g = item.visibleBounds;
      } catch (e) {
        try {
          g = item.geometricBounds;
        } catch (e2) {
          g = null;
        }
      }
    }
    if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] }; // không đo được
    return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
  }

  // Tìm object con (thường là ảnh/hình BACKGROUND) có kích thước khớp W×H
  // nhất bên trong item. Trả về bounds [l,t,r,b] hoặc null nếu không có
  // cái nào khớp trong dung sai.
  function findFrameBounds(item, wantWmm, wantHmm, tolMm) {
    var wHi = Math.max(wantWmm, wantHmm),
      wLo = Math.min(wantWmm, wantHmm);
    var best = null,
      bestErr = 1e9;
    function scan(it) {
      try {
        var b = it.geometricBounds;
        var w = (b[2] - b[0]) / MM,
          h = (b[1] - b[3]) / MM;
        var hi = Math.max(w, h),
          lo = Math.min(w, h);
        var err = Math.abs(hi - wHi) + Math.abs(lo - wLo);
        if (err < bestErr) {
          bestErr = err;
          best = b;
        }
      } catch (e) {}
      if (it.typename === "GroupItem") {
        try {
          for (var i = 0; i < it.pageItems.length; i++) scan(it.pageItems[i]);
        } catch (e) {}
      }
    }
    scan(item);
    if (best && bestErr <= tolMm) return best;
    return null;
  }

  // Tạo RasterizeOptions chuẩn (500ppi, trong suốt, Art Optimized, giữ spot).
  function makeRasterOptions() {
    var ro = new RasterizeOptions();
    try {
      ro.resolution = 500; // ppi
    } catch (e) {}
    try {
      ro.transparency = true; // nền trong suốt
    } catch (e) {}
    try {
      ro.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
    } catch (e) {}
    try {
      ro.convertSpotColors = false; // Giữ nguyên màu spot
    } catch (e) {}
    try {
      ro.padding = 0; // Đệm thêm 0
    } catch (e) {}
    try {
      ro.clippingMask = false;
    } catch (e) {}
    return ro;
  }

  // Tự sửa object sai KT. 2 chiến lược:
  //  A) Có object con (background) khớp W×H -> rasterize theo bounds đó
  //     (cắt sạch phần tràn) -> ra đúng KT.
  //  B) KHÔNG có background -> rasterize CẢ object thành ảnh, rồi CLIP về
  //     W×H tại TÂM ARTBOARD (mốc do người dùng chọn).
  // Luôn làm trên BẢN SAO: đo lại đạt khổ mới xoá nguồn và trả bản mới;
  // không đạt thì xoá hết bản sao/raster thử, nguồn vector còn nguyên.
  // Trả về {ok, item}. ok=false nếu cả 2 đều không ra đúng khổ.
  function autoFixByBackground(item, wantWmm, wantHmm) {
    var Wmm = wantWmm * MM,
      Hmm = wantHmm * MM;
    var wantHi = Math.max(wantWmm, wantHmm),
      wantLo = Math.min(wantWmm, wantHmm);
    var tol = DC_DUNG_SAI_KHO_MM;

    function dungKho(candidate) {
      // Đo theo NỘI DUNG: khung clip vừa tạo luôn đúng W×H, không nói lên gì cả.
      var s = visSizeMM(candidate, true);
      var hi = Math.max(s.w, s.h),
        lo = Math.min(s.w, s.h);
      return Math.abs(hi - wantHi) <= tol && Math.abs(lo - wantLo) <= tol;
    }
    function xoaNhe(o) {
      try {
        if (o) o.remove();
      } catch (e) {}
    }
    // Chạy một chiến lược trên bản sao mới; trả object kết quả hoặc null (đã dọn rác).
    // Mọi object chiến lược tạo ra được ghi vào `tao` để dọn khi lỗi giữa chừng.
    function thu(strategy) {
      var copy = null,
        result = null,
        tao = [];
      try {
        copy = item.duplicate();
        result = strategy(copy, tao);
      } catch (e) {
        result = null;
      }
      if (result && dungKho(result)) return result;
      xoaNhe(result);
      for (var ti = tao.length - 1; ti >= 0; ti--)
        if (tao[ti] !== result) xoaNhe(tao[ti]);
      // Chiến lược A/B có thể đã raster xong bản sao (copy không còn); xoá nếu còn.
      if (copy && copy !== result) xoaNhe(copy);
      return null;
    }

    // --- Chiến lược A: theo background ---
    var frame = findFrameBounds(item, wantWmm, wantHmm, 2.0);
    var fixed = null;
    if (frame)
      fixed = thu(function (copy, tao) {
        var ra = doc.rasterize(copy, frame, makeRasterOptions());
        tao.push(ra);
        return ra;
      });

    // --- Chiến lược B: raster cả object rồi clip tại tâm artboard ---
    if (!fixed)
      fixed = thu(function (copy, tao) {
        var raAll = doc.rasterize(copy, undefined, makeRasterOptions());
        tao.push(raAll);
        var abIdx = doc.artboards.getActiveArtboardIndex();
        var rect = doc.artboards[abIdx].artboardRect; // [l,t,r,b]
        var acx = (rect[0] + rect[2]) / 2,
          acy = (rect[1] + rect[3]) / 2;
        var lay = raAll.layer;
        // khung W×H tại tâm artboard
        var mrect = lay.pathItems.rectangle(
          acy + Hmm / 2,
          acx - Wmm / 2,
          Wmm,
          Hmm,
        );
        tao.push(mrect);
        // di chuyển ảnh sao cho tâm ảnh trùng tâm artboard trước khi clip
        var rb = raAll.geometricBounds;
        var rcx = (rb[0] + rb[2]) / 2,
          rcy = (rb[1] + rb[3]) / 2;
        raAll.translate(acx - rcx, acy - rcy);
        var grp = lay.groupItems.add();
        tao.push(grp);
        mrect.move(grp, ElementPlacement.PLACEATBEGINNING);
        raAll.move(grp, ElementPlacement.PLACEATEND);
        mrect.clipping = true;
        grp.clipped = true;
        return grp;
      });

    if (!fixed) return { ok: false, item: item };
    xoaNhe(item);
    return { ok: true, item: fixed };
  }

  // Phá hiệu ứng/appearance của object (Object > Expand Appearance).
  function expandAppearance(item) {
    try {
      app.selection = null;
      item.selected = true;
      app.executeMenuCommand("expandStyle");
      var s = app.selection;
      if (s && s.length === 1) {
        var r = s[0];
        app.selection = null;
        return r;
      }
      // selection sau expand không đúng 1 -> trả item gốc, GHI LẠI để báo.
      expandWarnings.push(
        "expandStyle: selection = " +
          (s ? s.length : "null") +
          " (mong đợi 1) -> giữ object gốc chưa expand.",
      );
      app.selection = null;
    } catch (e) {
      expandWarnings.push("expandStyle lỗi: " + e);
    }
    return item;
  }

  // Tự cắt (clip) object về đúng khung chữ nhật kích thước card.
  function autoClip(item, wantWmm, wantHmm) {
    // Nếu object ĐÃ là clip group -> đã đúng khung, KHÔNG clip lại.
    try {
      if (item.typename === "GroupItem" && item.clipped)
        return expandAppearance(item);
    } catch (e) {}

    // Tâm theo nội dung thật (visibleUnion, đã giao clip mask). Đến bước
    // này object đã qua kiểm tra/flatten nên visibleUnion = đúng vùng W×H.
    var acc = { val: null };
    visibleUnion(item, acc);
    var ocx, ocy;
    if (acc.val) {
      ocx = (acc.val[0] + acc.val[2]) / 2;
      ocy = (acc.val[1] + acc.val[3]) / 2;
    } else {
      var vb;
      try {
        vb = item.visibleBounds;
      } catch (e) {
        vb = item.geometricBounds;
      }
      ocx = (vb[0] + vb[2]) / 2;
      ocy = (vb[1] + vb[3]) / 2;
    }
    var lay = item.layer;

    // Khuôn đúng hướng hiện tại của card, tâm khuôn = tâm nội dung thật.
    var clipW = wantWmm != null ? wantWmm * MM : W;
    var clipH = wantHmm != null ? wantHmm * MM : H;
    var rect = lay.pathItems.rectangle(
      ocy + clipH / 2,
      ocx - clipW / 2,
      clipW,
      clipH,
    );

    var grp = lay.groupItems.add();
    rect.move(grp, ElementPlacement.PLACEATBEGINNING);
    item.move(grp, ElementPlacement.PLACEATEND);
    rect.clipping = true;
    grp.clipped = true;
    return expandAppearance(grp);
  }

  // Card đang clip thì đo theo mask; card thường đo vùng nhìn thấy.
  function cardSizeMM(item) {
    try {
      if (item.typename === "GroupItem" && item.clipped === true) {
        var p = item.pageItems;
        for (var i = 0; i < p.length; i++) {
          try {
            if (p[i].clipping === true) {
              var mb = p[i].geometricBounds;
              return { w: (mb[2] - mb[0]) / MM, h: (mb[1] - mb[3]) / MM };
            }
          } catch (e) {}
        }
      }
    } catch (e) {}
    return visSizeMM(item);
  }

  // Nếu object dọc còn khổ đích ngang (hoặc ngược lại), clip bằng W/H đảo
  // cho đúng hướng hiện tại, expand xong mới xoay về hướng khổ đích.
  function cardClipPlan(item, isBack, targetWmm, targetHmm) {
    var s = cardSizeMM(item);
    var currentLandscape = s && s.w >= s.h;
    var targetLandscape = targetWmm >= targetHmm;
    if (s && s.w > 0 && s.h > 0 && currentLandscape !== targetLandscape) {
      return {
        clipW: targetHmm,
        clipH: targetWmm,
        rotate: isBack ? -90 : 90,
      };
    }
    return { clipW: targetWmm, clipH: targetHmm, rotate: 0 };
  }

  function rotateAfterAutoClip(item, rotateDeg) {
    if (rotateDeg) {
      try {
        item.rotate(rotateDeg);
      } catch (e) {}
    }
    return item;
  }

  //  Tính bounds "VISIBLE THẬT" (bỏ object vô hình)
  function isVisibleLeaf(it) {
    try {
      if (it.hidden === true) return false;
      if (it.guides === true) return false;
    } catch (e) {}
    try {
      if (it.typename === "PathItem")
        return it.filled === true || it.stroked === true;
      if (it.typename === "CompoundPathItem") {
        if (it.pathItems.length > 0) {
          var p0 = it.pathItems[0];
          return p0.filled === true || p0.stroked === true;
        }
        return false;
      }
    } catch (e) {}
    return true; // text, raster, placed... coi là thấy
  }
  // Đo vùng bao THẬT của object (gộp mọi phần nhìn thấy, bỏ vùng trong suốt,
  // xử lý cả group có clip mask). Kết quả gộp vào acc.val.
  // Bật "Đo khổ theo bảng Transform" thì lấy thẳng khung Transform (khung clip).
  function visibleUnion(item, acc, theoNoiDung) {
    function merge(b) {
      if (!b) return;
      if (!acc.val) {
        acc.val = b.slice(0);
        return;
      }
      var a = acc.val;
      if (b[0] < a[0]) a[0] = b[0];
      if (b[1] > a[1]) a[1] = b[1];
      if (b[2] > a[2]) a[2] = b[2];
      if (b[3] < a[3]) a[3] = b[3];
    }
    if (dcDoTheoKhungTransform && !theoNoiDung) {
      var khungTransform = dcKhungThanhPham(item);
      if (khungTransform) {
        merge(khungTransform);
        return;
      }
    }
    // An toàn: object có thể đã bị xóa/không hợp lệ -> bỏ qua, tránh Error 45.
    var _tn;
    try {
      _tn = item.typename;
    } catch (e) {
      return;
    }
    if (_tn === "GroupItem") {
      var clipped = false;
      try {
        clipped = item.clipped;
      } catch (e) {}
      if (clipped) {
        // Tìm clip mask để lấy VÙNG GIỚI HẠN (không dùng thẳng làm kết quả,
        // vì mask có thể lớn thừa hơn nội dung thật).
        var pit = item.pageItems;
        var maskB = null;
        for (var i = 0; i < pit.length; i++) {
          var isc = false;
          try {
            isc = pit[i].clipping === true;
          } catch (e) {}
          if (isc) {
            maskB = pit[i].geometricBounds;
            break;
          }
        }
        // Đo nội dung THẬT (leaf có fill/stroke) bên trong, bỏ qua chính mask.
        var inner = { val: null };
        for (i = 0; i < pit.length; i++) {
          var isMask = false;
          try {
            isMask = pit[i].clipping === true;
          } catch (e) {}
          if (isMask) continue; // bỏ đường mask
          visibleUnion(pit[i], inner, true);
        }
        var res = inner.val;
        // Giao nội dung thật với vùng mask (nội dung tràn ngoài mask bị cắt).
        if (res && maskB) {
          var gx0 = Math.max(res[0], maskB[0]);
          var gy1 = Math.min(res[1], maskB[1]);
          var gx2 = Math.min(res[2], maskB[2]);
          var gy3 = Math.max(res[3], maskB[3]);
          if (gx2 > gx0 && gy1 > gy3) merge([gx0, gy1, gx2, gy3]);
          else merge(maskB); // giao rỗng -> fallback mask
        } else if (res) {
          merge(res);
        } else if (maskB) {
          merge(maskB);
        }
        return;
      }
      var pit2 = item.pageItems;
      for (var j = 0; j < pit2.length; j++) visibleUnion(pit2[j], acc, true);
      return;
    }
    if (isVisibleLeaf(item)) {
      try {
        merge(item.visibleBounds);
      } catch (e) {}
    }
  }

  // sắp hàng theo Y. 2 mặt: ghép cặp theo HÀNG bằng hàm chung của KTS (trái =
  // trước, phải = sau; hàng lẻ con thì báo lỗi). 1 mặt: mỗi object là 1 hàng độc lập.
  var items = [];
  for (var i = 0; i < sel.length; i++) {
    var cb = clipBounds(sel[i]);
    items.push({
      o: sel[i],
      x: (cb[0] + cb[2]) / 2,
      y: (cb[1] + cb[3]) / 2,
      item: sel[i],
      bounds: cb,
      cx: (cb[0] + cb[2]) / 2,
      cy: (cb[1] + cb[3]) / 2,
    });
  }
  items.sort(function (a, b) {
    return b.y - a.y;
  });
  var rows = [];
  if (TWO_SIDES) {
    if (items.length % 2 !== 0) {
      var cauLe = "Số object lẻ - in 2 mặt cần mỗi hàng 2 (trước+sau).";
      warn(cauLe);
      return "ERR: " + cauLe;
    }
    try {
      var cardPairs = dcKtsPairSourceRecords(items, 0.01);
    } catch (cardPairError) {
      warn(cardPairError.message);
      return "ERR: " + cardPairError.message;
    }
    for (i = 0; i < cardPairs.length; i++)
      rows.push([
        { o: cardPairs[i].front.item, x: cardPairs[i].front.cx, y: cardPairs[i].front.cy },
        { o: cardPairs[i].back.item, x: cardPairs[i].back.cx, y: cardPairs[i].back.cy },
      ]);
  } else {
    // 1 mặt: mỗi object 1 hàng, chỉ có "trước".
    for (i = 0; i < items.length; i++) rows.push([items[i]]);
  }

  // Con đôi dùng riêng khổ 18.4 x 5.6; phần dàn card đôi phía dưới giữ nguyên.
  var DBL_LONG = 184,
    DBL_TOL = 6;
  function isDoubleItem(o) {
    var s = visSizeMM(o);
    var hi = Math.max(s.w, s.h);
    return Math.abs(hi - DBL_LONG) <= DBL_TOL;
  }

  // ----- KIỂM TRA KÍCH THƯỚC (dung sai +-0.5mm) -----
  // Luồng bản dàn card ok: đúng khổ chỉ clip; sai khổ mới auto-fix/raster.
  var TOL = DC_DUNG_SAI_KHO_MM;
  var curW = W / MM,
    curH = H / MM;
  var badInfo = [];
  for (var ri = 0; ri < rows.length; ri++) {
    for (var ci = 0; ci < rows[ri].length; ci++) {
      var it = rows[ri][ci].o;
      var itemIsDouble = isDoubleItem(it);
      var targetW = itemIsDouble ? 184 : curW;
      var targetH = itemIsDouble ? 56 : curH;
      var wantHi = Math.max(targetW, targetH),
        wantLo = Math.min(targetW, targetH);

      var isClipped = false;
      try {
        isClipped = it.typename === "GroupItem" && it.clipped;
      } catch (e) {}
      if (isClipped) continue;

      var s = visSizeMM(it);
      var hi = Math.max(s.w, s.h),
        lo = Math.min(s.w, s.h);
      if (Math.abs(hi - wantHi) <= TOL && Math.abs(lo - wantLo) <= TOL)
        continue;

      // Tự sửa trên bản sao: ok thì nguồn đã được thay, không thì nguồn còn nguyên.
      var fix = autoFixByBackground(it, targetW, targetH);
      if (fix.ok) {
        rows[ri][ci].o = fix.item;
        continue;
      }
      badInfo.push({ w: s.w, h: s.h });
    }
  }
  if (badInfo.length > 0) {
    var d0 = badInfo[0];
    return (
      "ERR: Sai kích thước. " +
      badInfo.length +
      " object không khớp khổ " +
      curW.toFixed(1) +
      "x" +
      curH.toFixed(1) +
      "cm (vd object đo được " +
      d0.w.toFixed(1) +
      "x" +
      d0.h.toFixed(1) +
      "). Đã thử tự sửa (tìm nền + rasterize) nhưng không được. " +
      "Cách sửa: chỉnh object về đúng khổ, hoặc bỏ nền thừa/object lạ."
    );
  }

  // ----- BẮT ĐẦU THANH TIẾN TRÌNH -----
  // Tổng bước ước lượng: dọn + (mỗi model 1 bước clip) + import + dàn trước
  // + (dàn sau nếu 2 mặt) + hoàn tất.
  var totalSteps = 1 + rows.length + 1 + 1 + (TWO_SIDES ? 1 : 0) + 1;
  prog.start(totalSteps, "Đang dàn " + LAYOUT.name);

  // Xóa nội dung trong 2 artboard cũ (kết quả dàn mẻ trước), giữ lại
  // các object đang chọn (sel) dù chúng ở đâu. Làm TRƯỚC khi clip vì
  // clip/expand sẽ xóa selection hiện hành.
  prog.step("Dọn nội dung artboard cũ...");
  // Bảo vệ object HIỆN TẠI của từng hàng (sau tự sửa, có thể là bản mới thay nguồn).
  var protectSel = [];
  for (var pri = 0; pri < rows.length; pri++)
    for (var pci = 0; pci < rows[pri].length; pci++)
      protectSel.push(rows[pri][pci].o);
  var donCu = clearOldArtboardContent(doc, protectSel);

  var models = [];
  var hasDouble = false;
  for (i = 0; i < rows.length; i++) {
    prog.step("Cắt (clip) mẫu " + (i + 1) + "/" + rows.length + "...");
    var dbl = LAYOUT.key === "9.2x5.6" && isDoubleItem(rows[i][0].o);
    if (dbl) hasDouble = true;
    var targetW = dbl ? 184 : curW,
      targetH = dbl ? 56 : curH;
    var frontPlan = cardClipPlan(rows[i][0].o, false, targetW, targetH);
    var backPlan = TWO_SIDES
      ? cardClipPlan(rows[i][1].o, true, targetW, targetH)
      : null;
    if (TWO_SIDES) {
      models.push({
        front: rotateAfterAutoClip(
          autoClip(rows[i][0].o, frontPlan.clipW, frontPlan.clipH),
          frontPlan.rotate,
        ),
        back: rotateAfterAutoClip(
          autoClip(rows[i][1].o, backPlan.clipW, backPlan.clipH),
          backPlan.rotate,
        ),
        isDouble: dbl,
      });
    } else {
      models.push({
        front: rotateAfterAutoClip(
          autoClip(rows[i][0].o, frontPlan.clipW, frontPlan.clipH),
          frontPlan.rotate,
        ),
        back: null,
        isDouble: dbl,
      });
    }
  }
  if (models.length !== nModels) {
    prog.done();
    warn("Số hàng (" + models.length + ") != số mẫu.");
    return "ERR: Số hàng (" + models.length + ") != số mẫu.";
  }

  // Nhân bản object src, đặt tâm vào (cx,cy), xoay rotateDeg độ.
  function makeAt(src, cx, cy, rotateDeg) {
    var c = src.duplicate();
    if (rotateDeg) c.rotate(rotateDeg);
    var ctr = cbC(c);
    c.translate(cx - ctr[0], cy - ctr[1]);
    return c;
  }

  // Đổ object vào các ô (slot) của 1 mặt (trước/sau) theo bản đồ vị trí.
  function fillFace(slots, whichFace) {
    var copies = [];
    for (var m = 0; m < nModels; m++) {
      var src = whichFace === "front" ? models[m].front : models[m].back;
      var start = m * perModel;
      for (var k = 0; k < perModel; k++) {
        var s = slots[start + k];
        copies.push(makeAt(src, s.cx, s.cy, s.rot));
      }
    }
    return copies;
  }

  // ---- CON ĐÔI (layout 9.2x5.6): đổ con đôi vào slot đôi, con thường vào slot đơn ----
  //  whichFace: "front"/"back". Trả về mảng copies.
  //  Slot đôi ưu tiên: dải 2 dưới (1) -> khối 12 cột phải->trái, hàng 1+2 (4). Max 5.
  function fillFaceMixed(whichFace) {
    var c = CTX;
    var Wc = c.W,
      Hc = c.H,
      G = c.G,
      ROT = c.ROT;
    var vW = Hc,
      vH = Wc,
      leftW = 4 * vW,
      leftH = 3 * vH;
    var oL = 0,
      oT = 0;
    var isFront = whichFace === "front";
    var botT = oT - (leftH + G);

    // --- slot ĐÔI (theo mặt) ---
    var dbl = [];
    if (isFront) {
      // dải dưới: giữa 2 ô trái
      dbl.push({ cx: oL + Wc, cy: botT - Hc / 2, kind: "duoi", rot: 0 });
      // khối 12: cột phải->trái, hàng 1+2, xoay đứng như card thường (ROT+180)
      for (var col = 3; col >= 0; col--)
        dbl.push({
          cx: oL + col * vW + vW / 2,
          cy: oT - 2 * vH,
          kind: "k12",
          col: col,
          rot: ROT + 180,
        });
    } else {
      // BACK đối xứng: khối 12 nằm bên phải, dải dưới bên phải
      var b12 = oL + Wc + G;
      var rightEdge = b12 + leftW;
      // dải dưới-phải: giữa 2 ô
      dbl.push({ cx: rightEdge - Wc, cy: botT - Hc / 2, kind: "duoi", rot: 0 });
      // khối 12 back: cột trái->phải (đối xứng), hàng 1+2, xoay như card thường (ROT+360)
      for (var col2 = 0; col2 < 4; col2++)
        dbl.push({
          cx: b12 + col2 * vW + vW / 2,
          cy: oT - 2 * vH,
          kind: "k12",
          col: col2,
          rot: ROT + 360,
        });
    }

    // --- slot ĐƠN đầy đủ (đánh tag để loại ô bị con đôi chiếm) ---
    var singles = [];
    if (isFront) {
      var rL = oL + leftW + G;
      for (var r = 0; r < 6; r++)
        singles.push({
          cx: rL + Wc / 2,
          cy: oT - r * Hc - Hc / 2,
          rot: 0,
          tag: "phai" + r,
        });
      for (var row = 0; row < 3; row++)
        for (var cc = 3; cc >= 0; cc--)
          singles.push({
            cx: oL + cc * vW + vW / 2,
            cy: oT - row * vH - vH / 2,
            rot: ROT + 180,
            tag: "k12_" + row + "_" + cc,
          });
      for (var d1 = 0; d1 < 2; d1++)
        singles.push({
          cx: oL + d1 * Wc + Wc / 2,
          cy: botT - Hc / 2,
          rot: 0,
          tag: "duoi" + d1,
        });
    } else {
      for (var r2 = 0; r2 < 6; r2++)
        singles.push({
          cx: oL + Wc / 2,
          cy: oT - r2 * Hc - Hc / 2,
          rot: 0,
          tag: "phai" + r2,
        });
      var b12b = oL + Wc + G;
      for (var row2 = 0; row2 < 3; row2++)
        for (var cc2 = 0; cc2 < 4; cc2++)
          singles.push({
            cx: b12b + cc2 * vW + vW / 2,
            cy: oT - row2 * vH - vH / 2,
            rot: ROT + 360,
            tag: "k12_" + row2 + "_" + cc2,
          });
      var rEdge = b12b + leftW;
      for (var d2 = 0; d2 < 2; d2++) {
        var Lx = rEdge - (d2 + 1) * Wc + Wc / 2;
        singles.push({ cx: Lx, cy: botT - Hc / 2, rot: 0, tag: "duoi" + d2 });
      }
    }

    // tách models: đôi / thường (giữ thứ tự chọn)
    var dblModels = [],
      normModels = [];
    for (var mi = 0; mi < nModels; mi++) {
      if (models[mi].isDouble) dblModels.push(models[mi]);
      else normModels.push(models[mi]);
    }

    // Hệ số nhân k = total / (nNhỏ + nĐôi×2). Mỗi mẫu nhân k bản.
    var choBo = normModels.length * 1 + dblModels.length * 2;
    var kFill = choBo > 0 ? Math.floor(LAYOUT.total / choBo) : 1;
    if (kFill < 1) kFill = 1;

    // Số slot đôi cần = nĐôi × k. Chọn bấy nhiêu slot đôi (dải dưới -> khối 12).
    var needDbl = dblModels.length * kFill;
    if (needDbl > dbl.length) needDbl = dbl.length;

    // loại ô đơn bị slot đôi chiếm
    var blocked = {};
    for (var u = 0; u < needDbl; u++) {
      var ds = dbl[u];
      if (ds.kind === "duoi") {
        blocked["duoi0"] = true;
        blocked["duoi1"] = true;
      } else {
        blocked["k12_1_" + ds.col] = true;
        blocked["k12_2_" + ds.col] = true;
      }
    }
    var freeSingle = [];
    for (var s2 = 0; s2 < singles.length; s2++)
      if (!blocked[singles[s2].tag]) freeSingle.push(singles[s2]);

    // đặt CON ĐÔI: GOM cùng mẫu liền nhau (mẫu i lấp k slot liên tiếp).
    var copies = [];
    for (var du = 0; du < needDbl; du++) {
      var mIdx = Math.floor(du / kFill); // mẫu đổi sau mỗi k slot
      if (mIdx >= dblModels.length) mIdx = dblModels.length - 1;
      var mdl = dblModels[mIdx];
      var src = isFront ? mdl.front : mdl.back;
      var sl = dbl[du];
      copies.push(makeAt(src, sl.cx, sl.cy, sl.rot));
    }
    // đặt CON NHỎ: GOM cùng mẫu liền nhau (mẫu i lấp k ô liên tiếp).
    for (var nu = 0; nu < freeSingle.length; nu++) {
      if (normModels.length === 0) break;
      var mIdx2 = Math.floor(nu / kFill);
      if (mIdx2 >= normModels.length) mIdx2 = normModels.length - 1;
      var mdl2 = normModels[mIdx2];
      var src2 = isFront ? mdl2.front : mdl2.back;
      var fs = freeSingle[nu];
      copies.push(makeAt(src2, fs.cx, fs.cy, fs.rot));
    }
    return copies;
    return copies;
  }

  // Tính vùng bao chung của nhiều bản copy (để căn giữa cả cụm).
  function copiesClipBounds(copies) {
    var l = 1e9,
      t = -1e9,
      r = -1e9,
      b = 1e9;
    for (var i = 0; i < copies.length; i++) {
      var g = clipBounds(copies[i]);
      if (g[0] < l) l = g[0];
      if (g[1] > t) t = g[1];
      if (g[2] > r) r = g[2];
      if (g[3] < b) b = g[3];
    }
    return [l, t, r, b];
  }
  // Gom các bản copy thành group rồi căn giữa vào artboard abIndex.
  function groupAndCenter(copies, abIndex) {
    if (copies.length === 0) return null;
    var cbb = copiesClipBounds(copies);
    var ccx = (cbb[0] + cbb[2]) / 2,
      ccy = (cbb[1] + cbb[3]) / 2;
    var ab = doc.artboards[abIndex],
      rect = ab.artboardRect;
    var abCx = (rect[0] + rect[2]) / 2,
      abCy = (rect[1] + rect[3]) / 2;
    var grp = doc.groupItems.add();
    for (var i = 0; i < copies.length; i++) copies[i].moveToBeginning(grp);
    grp.translate(abCx - ccx, abCy - ccy);
    grp.note = DC_NOTE_DAN_CARD; // để mẻ sau nhận ra và dọn đúng object của tool
    return grp;
  }

  // ============================================================
  //  CHẠY
  // ============================================================
  // Import artboard chung 9.2x5.6. Pon trắng sẽ không có object để duplicate.
  prog.step("Mở artboard chung 9.2x5.6...");
  var ponPath = resolvePonPath(COMMON_ARTBOARD_LAYOUT);
  if (ponPath) {
    var newDoc = importPon(ponPath);
    if (newDoc && newDoc.typename === "Document") doc = newDoc; // cập nhật tham chiếu
  } else {
    warn("Không có file pon -> dùng artboard sẵn có của file hiện tại.");
  }

  if (TWO_SIDES) {
    ensureTwoArtboards(doc);
  } else {
    // AB2 nằm trong vùng chung đã đếm ở clearOldArtboardContent → không cộng dồn kept.
    removeSecondArtboard(doc, protectSel);
  }

  var useMixed = hasDouble && LAYOUT.key === "9.2x5.6";

  prog.step("Dàn mặt trước...");
  var fCopies = useMixed
    ? fillFaceMixed("front")
    : fillFace(LAYOUT.front(0, 0, CTX), "front");
  var fGrp = groupAndCenter(fCopies, 0);
  var bGrp = null;
  if (TWO_SIDES) {
    prog.step("Dàn mặt sau...");
    var bCopies = useMixed
      ? fillFaceMixed("back")
      : fillFace(LAYOUT.back(0, 0, CTX), "back");
    bGrp = groupAndCenter(bCopies, 1);
  }

  // Đưa xuống dưới cùng (Send to Back) nếu layout yêu cầu
  if (LAYOUT.sendToBack) {
    try {
      if (fGrp) fGrp.zOrder(ZOrderMethod.SENDTOBACK);
    } catch (e) {}
    try {
      if (bGrp) bGrp.zOrder(ZOrderMethod.SENDTOBACK);
    } catch (e) {}
  }

  if (IS_OFFSET) {
    var ab = doc.artboards[0];
    var rect = ab.artboardRect;
    var abL = rect[0],
      abR = rect[2],
      abB = rect[3];
    var lay = doc.activeLayer;
    var tf = lay.textFrames.add();
    tf.contents = NOTE_TEXT;
    tf.note = DC_NOTE_DAN_CARD;
    try {
      tf.textRange.characterAttributes.size = 14;
    } catch (e) {}
    var tb = tf.geometricBounds;
    var tw = tb[2] - tb[0],
      th = tb[1] - tb[3];
    tf.position = [(abL + abR) / 2 - tw / 2 - 30 * MM, abB + 5.5 * MM + th];
  }

  app.redraw();
  prog.step("Hoàn tất!");
  prog.done();

  var doneMsg =
    "Đã dàn xong " +
    nModels +
    " mẫu (" +
    LAYOUT.name +
    ")!\n" +
    "Mỗi mẫu " +
    perModel +
    " chỗ.\n" +
    (TWO_SIDES
      ? "In 2 mặt: mặt trước -> AB1, mặt sau -> AB2."
      : "In 1 mặt: chỉ dàn AB1.") +
    (IS_OFFSET ? "\n+ Ghi chú cardoffset." : "") +
    (kheBiBoQua ? "\n" + kheBiBoQua.replace(/^ /, "") : "") +
    dcCauGiuObjectLa(donCu.kept, "\n");
  if (kheBiBoQua) _DC_RESULT += kheBiBoQua;
  if (donCu.kept > 0 && LAYOUT.key !== "9.2x5.6")
    _DC_RESULT += dcCauGiuObjectLa(donCu.kept, " ");
  // Ưu tiên cảnh báo SAI KÍCH THƯỚC (đo trước raster). Có thì báo đỏ, xem kỹ.
  if (badInfo.length > 0) {
    var d0 = badInfo[0];
    doneMsg +=
      "\n\n*** CẢNH BÁO: CÓ " +
      badInfo.length +
      " CON SAI KÍCH THƯỚC ***\n" +
      "(Object không khớp khổ " +
      curW.toFixed(1) +
      "×" +
      curH.toFixed(1) +
      "cm - ví dụ đo được " +
      d0.w.toFixed(1) +
      "×" +
      d0.h.toFixed(1) +
      "cm.)\n" +
      "HÃY XEM XÉT THẬT KỸ TRƯỚC KHI BẤM OK!";
    warn(doneMsg, "Xong - CÓ SAI KÍCH THƯỚC (xem kỹ!)");
  } else if (expandWarnings.length > 0) {
    doneMsg +=
      "\n\n[!] " +
      expandWarnings.length +
      " object không expand được (có thể còn hiệu ứng/appearance chưa phá):\n- " +
      expandWarnings.join("\n- ");
    warn(doneMsg, "Xong (có cảnh báo)");
  } else {
    okBox(doneMsg, "Dàn xong");
  }

  // ============================================================
  //  NHÁNH RIÊNG: VOUCHER 15.2x7.2 + GHÉP CARD 9.2x5.6
  //  - Selection lẫn cả voucher (152x72) và card (92x56), mỗi loại
  //    theo cặp [trước][sau] xếp thành hàng.
  //  - Tự đo visibleUnion từng object để phân loại theo kích thước.
  //  - Voucher: 8 chỗ NGANG (2 cột x 4 hàng). Card: 3 chỗ dải dưới.
  //  - Clip voucher theo 152x72, card theo 92x56 (2 khuôn khác nhau).
  //  - Import pon key "15.2x7.2" (file ghép), căn cả cụm vào artboard.
  // ============================================================
  function runVoucherWithCard() {
    var VW = 152,
      VH = 72, // voucher (mm)
      CW = 92,
      CH = 56; // card (mm)
    var VWmm = VW * MM,
      VHmm = VH * MM,
      CWmm = CW * MM,
      CHmm = CH * MM;

    // ----- Bảng cấu hình gọn cho voucher+card -----
    var dlg = new Window("dialog", "Dàn voucher 15.2x7.2 + card 9.2x5.6");
    dlg.orientation = "column";
    dlg.alignChildren = "fill";
    dlg.margins = 16;
    dlg.spacing = 10;
    dlg.add(
      "statictext",
      undefined,
      "Chọn: voucher (chia hết 8) + card (chia hết 3), lẫn lộn cũng được.",
    );
    var pType = dlg.add("panel", undefined, "Loại in");
    pType.orientation = "row";
    pType.margins = 10;
    var tFast = pType.add("radiobutton", undefined, "In nhanh");
    var tOffset = pType.add("radiobutton", undefined, "Cardoffset");
    tFast.value = true;
    var gGhi = dlg.add("group");
    gGhi.add("statictext", undefined, "Ghi chú (cardoffset):");
    var inNote = gGhi.add(
      "edittext",
      undefined,
      "cardoffset - cán mờ - bỏ hộp nhựa",
    );
    inNote.characters = 30;
    var gBtn = dlg.add("group");
    gBtn.alignment = "right";
    gBtn.add("button", undefined, "Hủy", { name: "cancel" });
    gBtn.add("button", undefined, "Dàn", { name: "ok" });
    if (dlg.show() !== 1) {
      _DC_RESULT = "OK: Đã hủy, chưa thay đổi gì.";
      return;
    }
    var IS_OFFSET = tOffset.value;
    var NOTE_TEXT = inNote.text;

    // ----- Kiểm tra selection -----
    var sel = doc.selection;
    if (!sel || sel.length < 2) {
      _DC_RESULT = "ERR: Chưa chọn object voucher/card.";
      return;
    }

    // ----- Đo kích thước visible thật của từng object để phân loại -----
    // Voucher ~152x72, card ~92x56. So khoảng cách tới 2 mẫu chuẩn.
    function visSize(it) {
      // Nội dung thật (visibleUnion, đã giao clip mask, bỏ mask thừa).
      var acc = { val: null };
      visibleUnion(it, acc);
      var g = acc.val;
      if (!g) {
        try {
          g = it.visibleBounds;
        } catch (e) {
          g = it.geometricBounds;
        }
      }
      return {
        w: (g[2] - g[0]) / MM,
        h: (g[1] - g[3]) / MM,
        cx: (g[0] + g[2]) / 2,
        cy: (g[1] + g[3]) / 2,
      };
    }
    // "kích thước bất kể xoay": lấy max/min để so cạnh dài/ngắn.
    function longShort(s) {
      var lo = Math.min(s.w, s.h),
        hi = Math.max(s.w, s.h);
      return { hi: hi, lo: lo };
    }
    var TOL = 0.5; // mm - dung sai kích thước
    var vouchers = [],
      cards = [],
      offSize = []; // object lệch quá 0.5mm so với loại gần nhất
    for (var i = 0; i < sel.length; i++) {
      var s = visSize(sel[i]);
      var ls = longShort(s);
      // khoảng cách tới voucher(152,72) và card(92,56)
      var dV = Math.abs(ls.hi - 152) + Math.abs(ls.lo - 72);
      var dC = Math.abs(ls.hi - 92) + Math.abs(ls.lo - 56);
      var rec = { o: sel[i], cx: s.cx, cy: s.cy };
      if (dV <= dC) {
        // gán voucher; kiểm tra sai số chặt 0.5mm
        if (Math.abs(ls.hi - 152) > TOL || Math.abs(ls.lo - 72) > TOL)
          offSize.push({
            idx: i + 1,
            w: ls.hi,
            lo: ls.lo,
            want: "voucher 152x72",
          });
        else vouchers.push(rec);
      } else {
        if (Math.abs(ls.hi - 92) > TOL || Math.abs(ls.lo - 56) > TOL)
          offSize.push({ idx: i + 1, w: ls.hi, lo: ls.lo, want: "card 92x56" });
        else cards.push(rec);
      }
    }
    if (offSize.length > 0) {
      var um =
        "Có " +
        offSize.length +
        "/" +
        sel.length +
        " object KHÔNG đúng kích thước (dung sai +-0.5mm).\n\n" +
        "Voucher cần 152x72, card cần 92x56. Kiểm tra lại object đã chọn / KT.";
      _DC_RESULT =
        "ERR: Sai kích thước. " +
        offSize.length +
        "/" +
        sel.length +
        " object không khớp (voucher cần 15.2x7.2cm, card 9.2x5.6cm). " +
        "Cách sửa: chỉnh object về đúng khổ rồi chạy lại.";
      return;
    }

    // ----- Kiểm tra số lượng: voucher chẵn & chia hết 8, card chẵn & chia hết 3 -----
    if (vouchers.length === 0) {
      _DC_RESULT = "ERR: Không thấy voucher (cần ~152x72mm).";
      return;
    }
    if (vouchers.length % 2 !== 0) {
      _DC_RESULT =
        "ERR: Số voucher lẻ (" +
        vouchers.length +
        "). In 2 mặt cần chẵn (mỗi mẫu 2: trước+sau).";
      return;
    }
    var nV = vouchers.length / 2;
    if (8 % nV !== 0) {
      _DC_RESULT =
        "ERR: Có " +
        nV +
        " mẫu voucher, không chia đều 8 chỗ. " +
        "Cần 1, 2, 4 hoặc 8 mẫu.";
      return;
    }
    var haveCard = cards.length > 0;
    var nC = 0,
      perCard = 0;
    if (haveCard) {
      if (cards.length % 2 !== 0) {
        _DC_RESULT =
          "ERR: Số card lẻ (" +
          cards.length +
          "). In 2 mặt cần chẵn (mỗi mẫu 2: trước+sau).";
        return;
      }
      nC = cards.length / 2;
      if (3 % nC !== 0) {
        _DC_RESULT =
          "ERR: Có " +
          nC +
          " mẫu card, không chia đều 3 chỗ. " +
          "Cần 1 hoặc 3 mẫu.";
        return;
      }
      perCard = 3 / nC;
    }
    var perV = 8 / nV;

    // ----- Ghép cặp trong từng nhóm theo Y, rồi trong cặp sắp X (trước=trái) -----
    function pairUp(arr) {
      arr.sort(function (a, b) {
        return b.cy - a.cy;
      });
      var out = [];
      for (var k = 0; k < arr.length; k += 2) {
        var pair = [arr[k], arr[k + 1]];
        pair.sort(function (a, b) {
          return a.cx - b.cx;
        });
        out.push(pair);
      }
      return out;
    }
    var vRows = pairUp(vouchers);
    var cRows = haveCard ? pairUp(cards) : [];

    // ----- Clip theo khuôn W x H chỉ định (phiên bản có tham số) -----
    function autoClipWH(item, Wmm, Hmm) {
      try {
        if (item.typename === "GroupItem" && item.clipped)
          return expandAppearance(item);
      } catch (e) {}
      // Tâm theo nội dung thật (visibleUnion, đã giao clip mask).
      var acc = { val: null };
      visibleUnion(item, acc);
      var ocx, ocy;
      if (acc.val) {
        ocx = (acc.val[0] + acc.val[2]) / 2;
        ocy = (acc.val[1] + acc.val[3]) / 2;
      } else {
        var vb;
        try {
          vb = item.visibleBounds;
        } catch (e) {
          vb = item.geometricBounds;
        }
        ocx = (vb[0] + vb[2]) / 2;
        ocy = (vb[1] + vb[3]) / 2;
      }
      var lay = item.layer;
      var rect = lay.pathItems.rectangle(
        ocy + Hmm / 2,
        ocx - Wmm / 2,
        Wmm,
        Hmm,
      );
      var grp = lay.groupItems.add();
      rect.move(grp, ElementPlacement.PLACEATBEGINNING);
      item.move(grp, ElementPlacement.PLACEATEND);
      rect.clipping = true;
      grp.clipped = true;
      return expandAppearance(grp);
    }

    // Xóa nội dung 2 artboard cũ (mẻ trước), giữ selection mẻ mới.
    // Làm TRƯỚC khi clip (clip/expand sẽ xóa selection).
    var protectSelV = [];
    for (var psv = 0; psv < sel.length; psv++) protectSelV.push(sel[psv]);
    var donCuV = clearOldArtboardContent(doc, protectSelV);

    var vModels = [];
    for (i = 0; i < vRows.length; i++)
      vModels.push({
        front: autoClipWH(vRows[i][0].o, VWmm, VHmm),
        back: autoClipWH(vRows[i][1].o, VWmm, VHmm),
      });
    var cModels = [];
    for (i = 0; i < cRows.length; i++)
      cModels.push({
        front: autoClipWH(cRows[i][0].o, CWmm, CHmm),
        back: autoClipWH(cRows[i][1].o, CWmm, CHmm),
      });

    // ----- Import artboard chung 9.2x5.6 (pon trắng, không duplicate pon) -----
    var ponPath = resolvePonPath(COMMON_ARTBOARD_LAYOUT);
    if (ponPath) {
      var newDoc = importPon(ponPath);
      if (newDoc && newDoc.typename === "Document") doc = newDoc;
    } else {
      warn("Không có file pon -> dùng artboard sẵn có của file hiện tại.");
    }

    // Đảm bảo đủ 2 artboard (tự tạo nếu thiếu).
    ensureTwoArtboards(doc);

    // ----- Bản đồ slot -----
    // Voucher NGANG (rộng 152, cao 72): 2 cột x 4 hàng.
    // Mặt trước: cột trái 1-2-3-4 (trên->dưới), cột phải 5-6-7-8.
    // Mặt sau : đối xứng ngang (đổi cột trái<->phải).
    function voucherFront(oL, oT) {
      var slots = [],
        col,
        row;
      for (col = 0; col < 2; col++)
        for (row = 0; row < 4; row++)
          slots.push({
            cx: oL + col * VWmm + VWmm / 2,
            cy: oT - row * VHmm - VHmm / 2,
            rot: 0,
          });
      return slots; // thứ tự: (c0r0,c0r1,c0r2,c0r3, c1r0..c1r3) = 1..8
    }
    // Bản đồ vị trí mặt SAU của voucher (8 chỗ).
    function voucherBack(oL, oT) {
      var slots = [],
        col,
        row;
      for (col = 0; col < 2; col++) {
        var mcol = 1 - col;
        for (row = 0; row < 4; row++)
          slots.push({
            cx: oL + mcol * VWmm + VWmm / 2,
            cy: oT - row * VHmm - VHmm / 2,
            rot: 0,
          });
      }
      return slots;
    }
    // Card dải dưới: 3 chỗ ngang. Mặt trước 1-2-3 (trái->phải),
    // mặt sau 3-2-1 (đối xứng ngang).
    function cardFront(oL, oT) {
      var slots = [];
      for (var col = 0; col < 3; col++)
        slots.push({
          cx: oL + col * CWmm + CWmm / 2,
          cy: oT - CHmm / 2,
          rot: 0,
        });
      return slots;
    }
    // Bản đồ vị trí mặt SAU của card ghép trong voucher (3 chỗ).
    function cardBack(oL, oT) {
      var slots = [];
      for (var col = 0; col < 3; col++) {
        var mcol = 2 - col;
        slots.push({
          cx: oL + mcol * CWmm + CWmm / 2,
          cy: oT - CHmm / 2,
          rot: 0,
        });
      }
      return slots;
    }

    // ----- makeAt + fill (dùng chung, mỗi nhóm models riêng) -----
    function makeAt(src, cx, cy, rotateDeg) {
      var c = src.duplicate();
      if (rotateDeg) c.rotate(rotateDeg);
      var ctr = cbC(c);
      c.translate(cx - ctr[0], cy - ctr[1]);
      return c;
    }
    // Dàn voucher + card vào CÙNG một cụm (đặt liền nhau như file mẫu:
    // khối voucher phía trên, dải card ngay dưới). Ta dựng theo toạ độ
    // tương đối rồi căn cả cụm vào tâm artboard.
    // Gốc (0,0) = góc trên-trái khối voucher.
    function buildFace(which) {
      var copies = [];
      // voucher
      var vslots = which === "front" ? voucherFront(0, 0) : voucherBack(0, 0);
      for (var m = 0; m < nV; m++) {
        var vsrc = which === "front" ? vModels[m].front : vModels[m].back;
        var vstart = m * perV;
        for (var k = 0; k < perV; k++) {
          var vs = vslots[vstart + k];
          copies.push(makeAt(vsrc, vs.cx, vs.cy, vs.rot));
        }
      }
      // card dải dưới: đặt ngay dưới khối voucher (voucher cao 4*VH).
      //  - Mặt TRƯỚC: căn mép TRÁI khối voucher (oLcard = 0).
      //  - Mặt SAU  : căn mép PHẢI khối voucher (mirror ngang để khớp lưng
      //    khi lật giấy). Dịch phải = (rộng khối voucher) - (rộng dải card).
      if (haveCard) {
        var botT = 0 - 4 * VHmm; // đáy khối voucher
        var voucherBlockW = 2 * VWmm; // khối voucher = 2 cột
        var cardStripW = 3 * CWmm; // dải card = 3 card
        var oLcard = which === "front" ? 0 : voucherBlockW - cardStripW;
        var cslots =
          which === "front" ? cardFront(oLcard, botT) : cardBack(oLcard, botT);
        for (m = 0; m < nC; m++) {
          var csrc = which === "front" ? cModels[m].front : cModels[m].back;
          var cstart = m * perCard;
          for (k = 0; k < perCard; k++) {
            var cs = cslots[cstart + k];
            copies.push(makeAt(csrc, cs.cx, cs.cy, cs.rot));
          }
        }
      }
      return copies;
    }

    // Căn giữa 1 object/group vào tâm artboard.
    function centerToAB(copies, abIndex) {
      if (copies.length === 0) return null;
      var l = 1e9,
        t = -1e9,
        r = -1e9,
        b = 1e9;
      for (var j = 0; j < copies.length; j++) {
        var g = clipBounds(copies[j]);
        if (g[0] < l) l = g[0];
        if (g[1] > t) t = g[1];
        if (g[2] > r) r = g[2];
        if (g[3] < b) b = g[3];
      }
      var ccx = (l + r) / 2,
        ccy = (t + b) / 2;
      var ab = doc.artboards[abIndex],
        rect = ab.artboardRect;
      var abCx = (rect[0] + rect[2]) / 2,
        abCy = (rect[1] + rect[3]) / 2;
      var grp = doc.groupItems.add();
      for (j = 0; j < copies.length; j++) copies[j].moveToBeginning(grp);
      grp.translate(abCx - ccx, abCy - ccy);
      grp.note = DC_NOTE_DAN_CARD; // để mẻ sau nhận ra và dọn đúng object của tool
      return grp;
    }

    var fGrp = centerToAB(buildFace("front"), 0);
    var bGrp = centerToAB(buildFace("back"), 1);

    // ----- Cardoffset: ghi chú lên mặt trước -----
    if (IS_OFFSET) {
      var ab0 = doc.artboards[0];
      var r0 = ab0.artboardRect;
      var abL = r0[0],
        abR = r0[2],
        abB = r0[3];
      var lay = doc.activeLayer;
      var tf = lay.textFrames.add();
      tf.contents = NOTE_TEXT;
      tf.note = DC_NOTE_DAN_CARD;
      try {
        tf.textRange.characterAttributes.size = 14;
      } catch (e) {}
      var tb = tf.geometricBounds;
      var tw = tb[2] - tb[0],
        th = tb[1] - tb[3];
      tf.position = [(abL + abR) / 2 - tw / 2 - 30 * MM, abB + 5.5 * MM + th];
    }

    app.redraw();
    var msg =
      "Đã dàn xong voucher 15.2x7.2 (" + nV + " mẫu, " + perV + " chỗ/mẫu)";
    if (haveCard)
      msg += "\n+ card 9.2x5.6 (" + nC + " mẫu, " + perCard + " chỗ/mẫu)";
    msg += "\nMặt trước -> AB1, mặt sau -> AB2.";
    if (IS_OFFSET) msg += "\n+ Ghi chú cardoffset.";
    msg += dcCauGiuObjectLa(donCuV.kept, "\n");
    if (donCuV.kept > 0) _DC_RESULT += dcCauGiuObjectLa(donCuV.kept, " ");
    if (expandWarnings.length > 0) {
      msg +=
        "\n\n[!] " +
        expandWarnings.length +
        " object không expand được:\n- " +
        expandWarnings.join("\n- ");
      warn(msg, "Xong (có cảnh báo)");
    } else {
      okBox(msg, "Dàn xong");
    }
  }

  // Ghi chú con đôi ra panel (chẩn đoán nhận diện 18.4cm).
  if (LAYOUT.key === "9.2x5.6") {
    if (_hasDoubleEarly) {
      _DC_RESULT =
        "OK: Đã dàn. Nhận diện " +
        _nDblEarly +
        " con đôi (18.4×5.6) + " +
        (nModels - _nDblEarly) +
        " con thường.";
    } else {
      _DC_RESULT =
        "OK: Đã dàn " + nModels + " con thường (không có con đôi 18.4).";
    }
    if (donCu.kept > 0) _DC_RESULT += dcCauGiuObjectLa(donCu.kept, " ");
  }

  // kết thúc dcDan: trả kết quả OK
  return _DC_RESULT;
}

// ============================================================
//  TAB DẤU CẮT: chạy độc lập với các luồng dàn hiện có.
//  Chọn từng bài, hoặc chọn group dàn mà các bài con là clipping group.
// ============================================================
var dcAutoCutMarksVersion = 2;
function dcThemDauCatTuDong(lengthText, edgeText, gapText) {
  var doc = null,
    markLayer = null,
    originalLayer = null;
  var oldCoordinates = null,
    restoreCoordinates = false;
  var originalMarkLocked = false,
    originalMarkVisible = true,
    capturedMarkState = false;
  var createdMarkLayer = false,
    createdLines = [],
    completed = false;
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";

    oldCoordinates = app.coordinateSystem;
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    restoreCoordinates = true;
    doc = app.activeDocument;
    originalLayer = doc.activeLayer;
    var sel = doc.selection;
    if (!sel || sel.length === 0)
      return "ERR: Chọn các bài cần tạo dấu cắt trước.";

    function parseMm(value, label, allowZero) {
      var n = parseFloat(
        String(value === undefined || value === null ? "" : value).replace(
          ",",
          ".",
        ),
      );
      if (!isFinite(n) || n < 0 || (!allowZero && n === 0))
        throw new Error(
          label + (allowZero ? " phải là số từ 0 mm." : " phải lớn hơn 0 mm."),
        );
      return n;
    }

    var MM = 2.834645669;
    var cutLength = parseMm(lengthText, "Dài nét") * MM;
    var edgeThreshold = parseMm(edgeText, "Ngưỡng mép") * MM;
    var cutGap =
      (gapText === undefined || gapText === null || gapText === ""
        ? 0
        : parseMm(gapText, "Cách bài", true)) * MM;
    var edgeEpsilon = 0.05;

    // Khung bài = khung Transform (clip group → khung clip, group → khung group).
    function itemBounds(item) {
      return dcDoKhung(item, function (it) {
        var isClipped = false;
        try {
          isClipped = it.typename === "GroupItem" && it.clipped === true;
        } catch (e) {}
        if (isClipped) {
          try {
            var children = it.pageItems;
            for (var ci = 0; ci < children.length; ci++) {
              if (children[ci].clipping === true)
                return children[ci].geometricBounds.slice(0);
            }
          } catch (e) {}
        }
        try {
          return it.visibleBounds.slice(0);
        } catch (e) {}
        try {
          return it.geometricBounds.slice(0);
        } catch (e) {}
        return null;
      });
    }

    function isCutMarkItem(item) {
      try {
        if (item.note === "DANCARD_AUTO_CUT_MARK") return true;
        // Các bản cũ chưa gắn thẻ cho dấu cắt. Chỉ nhận diện những nét thẳng, hở,
        // màu đen, dày 1 pt của chúng, không bao giờ nhận cả bài nằm trên layer PON.
        if (
          !item.layer ||
          item.layer.name !== "Dau cat tu dong" ||
          item.typename !== "PathItem" ||
          item.closed ||
          item.filled ||
          !item.stroked ||
          Math.abs(item.strokeWidth - 1) > 0.001 ||
          item.pathPoints.length !== 2
        )
          return false;
        var color = item.strokeColor;
        if (
          color.typename !== "CMYKColor" ||
          color.cyan !== 0 ||
          color.magenta !== 0 ||
          color.yellow !== 0 ||
          color.black !== 100
        )
          return false;
        var a = item.pathPoints[0].anchor,
          b = item.pathPoints[1].anchor;
        if (
          Math.abs(a[0] - b[0]) > edgeEpsilon &&
          Math.abs(a[1] - b[1]) > edgeEpsilon
        )
          return false;
        for (var pi = 0; pi < 2; pi++) {
          var p = item.pathPoints[pi];
          for (var axis = 0; axis < 2; axis++)
            if (
              Math.abs(p.leftDirection[axis] - p.anchor[axis]) > 0.001 ||
              Math.abs(p.rightDirection[axis] - p.anchor[axis]) > 0.001
            )
              return false;
        }
        return true;
      } catch (e) {
        return false;
      }
    }

    // Một group dàn card thường chứa nhiều clipping group, mỗi group là 1 bài.
    // Chỉ tách kiểu group này để không tách các chi tiết của một artwork đơn lẻ.
    function collectCards(item, output) {
      if (!item || isCutMarkItem(item)) return;
      var isGroup = false,
        isClipped = false;
      try {
        isGroup = item.typename === "GroupItem";
        isClipped = item.clipped === true;
      } catch (e) {}
      if (isGroup && !isClipped) {
        var directCards = [];
        try {
          for (var i = 0; i < item.pageItems.length; i++) {
            var child = item.pageItems[i];
            if (isCutMarkItem(child)) continue;
            if (child.typename === "GroupItem" && child.clipped === true)
              directCards.push(child);
          }
        } catch (e) {}
        if (directCards.length >= 2) {
          for (var d = 0; d < directCards.length; d++)
            output.push(directCards[d]);
          return;
        }
      }
      output.push(item);
    }

    function artboardFor(bounds) {
      var cx = (bounds[0] + bounds[2]) / 2;
      var cy = (bounds[1] + bounds[3]) / 2;
      for (var ai = 0; ai < doc.artboards.length; ai++) {
        var rect = doc.artboards[ai].artboardRect;
        if (cx >= rect[0] && cx <= rect[2] && cy <= rect[1] && cy >= rect[3])
          return ai;
      }
      return -1;
    }

    var rawCards = [];
    for (var si = 0; si < sel.length; si++) collectCards(sel[si], rawCards);

    var cards = [];
    var skipped = 0;
    for (var ri = 0; ri < rawCards.length; ri++) {
      var bounds = itemBounds(rawCards[ri]);
      if (!bounds || bounds[2] <= bounds[0] || bounds[1] <= bounds[3]) {
        skipped++;
        continue;
      }
      var abIndex = artboardFor(bounds);
      if (abIndex < 0) {
        skipped++;
        continue;
      }
      cards.push({ bounds: bounds, abIndex: abIndex });
    }
    if (cards.length === 0)
      return "ERR: Không tìm thấy bài hợp lệ nằm trong artboard.";

    for (var li = 0; li < doc.layers.length; li++) {
      if (doc.layers[li].name === "Dau cat tu dong") {
        markLayer = doc.layers[li];
        break;
      }
    }
    if (!markLayer) {
      markLayer = doc.layers.add();
      createdMarkLayer = true;
      markLayer.name = "Dau cat tu dong";
    }
    originalMarkLocked = markLayer.locked;
    originalMarkVisible = markLayer.visible;
    capturedMarkState = true;
    markLayer.locked = false;
    markLayer.visible = true;
    doc.activeLayer = markLayer;

    var cutColor = new CMYKColor();
    cutColor.cyan = 0;
    cutColor.magenta = 0;
    cutColor.yellow = 0;
    cutColor.black = 100;
    var drawn = 0;
    var drawnLines = {};
    var existingDuplicates = 0;

    function fitsArtboard(p1, p2, rect) {
      return (
        p1[0] >= rect[0] &&
        p1[0] <= rect[2] &&
        p2[0] >= rect[0] &&
        p2[0] <= rect[2] &&
        p1[1] >= rect[3] &&
        p1[1] <= rect[1] &&
        p2[1] >= rect[3] &&
        p2[1] <= rect[1]
      );
    }

    function overlapsCard(p1, p2, owner, allowOwner) {
      var minX = Math.min(p1[0], p2[0]);
      var maxX = Math.max(p1[0], p2[0]);
      var minY = Math.min(p1[1], p2[1]);
      var maxY = Math.max(p1[1], p2[1]);
      for (var oi = 0; oi < cards.length; oi++) {
        if (cards[oi].abIndex !== cards[owner].abIndex) continue;
        if (oi === owner && allowOwner) continue;
        var other = cards[oi].bounds;

        // Với nét hướng ra vùng trống, cạnh bài kế bên là nút cắt chung:
        // bỏ nét chạy dọc cạnh đó. Khi sát mép giấy, nét được đảo vào trong
        // thì cho phép nó trùng cạnh chung; lineKey sẽ giữ lại đúng một nét.
        if (oi !== owner) {
          var isHorizontal = Math.abs(p1[1] - p2[1]) <= edgeEpsilon;
          var isVertical = Math.abs(p1[0] - p2[0]) <= edgeEpsilon;
          var runsOnOtherEdge =
            (isHorizontal &&
              (Math.abs(p1[1] - other[1]) <= edgeEpsilon ||
                Math.abs(p1[1] - other[3]) <= edgeEpsilon) &&
              Math.min(maxX, other[2]) - Math.max(minX, other[0]) >
                edgeEpsilon) ||
            (isVertical &&
              (Math.abs(p1[0] - other[0]) <= edgeEpsilon ||
                Math.abs(p1[0] - other[2]) <= edgeEpsilon) &&
              Math.min(maxY, other[1]) - Math.max(minY, other[3]) >
                edgeEpsilon);
          if (runsOnOtherEdge) {
            if (!allowOwner) return true;
            continue;
          }
        }
        if (
          maxX > other[0] &&
          minX < other[2] &&
          maxY > other[3] &&
          minY < other[1]
        )
          return true;
      }
      return false;
    }

    function lineKey(p1, p2, abIndex) {
      var a = p1[0].toFixed(3) + "," + p1[1].toFixed(3);
      var b = p2[0].toFixed(3) + "," + p2[1].toFixed(3);
      if (a > b) {
        var swap = a;
        a = b;
        b = swap;
      }
      return abIndex + "|" + a + "|" + b;
    }

    function drawLine(p1, p2, owner, rect, allowOwner) {
      if (!fitsArtboard(p1, p2, rect)) return;
      // Nét chỉ nằm trong vùng trống. Trường hợp sát mép giấy mới cho
      // phép nét đi vào chính bài đó theo quy tắc lật vào trong.
      if (overlapsCard(p1, p2, owner, allowOwner)) return;
      var key = lineKey(p1, p2, cards[owner].abIndex);
      if (drawnLines[key]) {
        existingDuplicates++;
        return;
      }
      var line = markLayer.pathItems.add();
      createdLines.push(line);
      line.setEntirePath([p1, p2]);
      line.closed = false;
      line.filled = false;
      line.stroked = true;
      line.strokeColor = cutColor;
      line.strokeWidth = 1;
      try {
        line.note = "DANCARD_AUTO_CUT_MARK";
      } catch (tagError) {}
      drawnLines[key] = true;
      drawn++;
    }

    // Dùng lại layer sẵn có, không xoá dấu cắt trên đó và cũng không vẽ trùng
    // một nét giống hệt khi người dùng bấm nút lần nữa.
    for (var mi = 0; mi < markLayer.pathItems.length; mi++) {
      var previousMark = markLayer.pathItems[mi];
      if (!isCutMarkItem(previousMark)) continue;
      try {
        if (previousMark.pathPoints.length !== 2) continue;
        var p1 = previousMark.pathPoints[0].anchor.slice(0);
        var p2 = previousMark.pathPoints[1].anchor.slice(0);
        var previousBoard = artboardFor(previousMark.geometricBounds);
        if (previousBoard >= 0)
          drawnLines[lineKey(p1, p2, previousBoard)] = true;
      } catch (readMarkError) {}
    }

    for (var ci = 0; ci < cards.length; ci++) {
      var card = cards[ci].bounds;
      var rect = doc.artboards[cards[ci].abIndex].artboardRect;
      var leftDir = card[0] - rect[0] < edgeThreshold ? 1 : -1;
      var rightDir = rect[2] - card[2] < edgeThreshold ? -1 : 1;
      var topDir = rect[1] - card[1] < edgeThreshold ? -1 : 1;
      var bottomDir = card[3] - rect[3] < edgeThreshold ? 1 : -1;
      var leftInside = leftDir > 0;
      var rightInside = rightDir < 0;
      var topInside = topDir < 0;
      var bottomInside = bottomDir > 0;

      // Nét ngang tại bốn góc.
      drawLine(
        [card[0] + leftDir * cutGap, card[1]],
        [card[0] + leftDir * (cutGap + cutLength), card[1]],
        ci,
        rect,
        leftInside,
      );
      drawLine(
        [card[2] + rightDir * cutGap, card[1]],
        [card[2] + rightDir * (cutGap + cutLength), card[1]],
        ci,
        rect,
        rightInside,
      );
      drawLine(
        [card[0] + leftDir * cutGap, card[3]],
        [card[0] + leftDir * (cutGap + cutLength), card[3]],
        ci,
        rect,
        leftInside,
      );
      drawLine(
        [card[2] + rightDir * cutGap, card[3]],
        [card[2] + rightDir * (cutGap + cutLength), card[3]],
        ci,
        rect,
        rightInside,
      );

      // Nét dọc tại bốn góc.
      drawLine(
        [card[0], card[1] + topDir * cutGap],
        [card[0], card[1] + topDir * (cutGap + cutLength)],
        ci,
        rect,
        topInside,
      );
      drawLine(
        [card[2], card[1] + topDir * cutGap],
        [card[2], card[1] + topDir * (cutGap + cutLength)],
        ci,
        rect,
        topInside,
      );
      drawLine(
        [card[0], card[3] + bottomDir * cutGap],
        [card[0], card[3] + bottomDir * (cutGap + cutLength)],
        ci,
        rect,
        bottomInside,
      );
      drawLine(
        [card[2], card[3] + bottomDir * cutGap],
        [card[2], card[3] + bottomDir * (cutGap + cutLength)],
        ci,
        rect,
        bottomInside,
      );
    }

    completed = true;
    if (drawn === 0) {
      if (existingDuplicates > 0)
        return "OK: Dấu cắt phù hợp đã tồn tại; không tạo nét trùng.";
      return "OK: Không có khoảng trống phù hợp để đặt dấu cắt.";
    }

    try {
      markLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
    } catch (e) {}
    try {
      app.redraw();
    } catch (redrawError) {}
    var msg =
      "OK: Đã thêm " + drawn + " nét dấu cắt cho " + cards.length + " bài.";
    if (skipped > 0) msg += " Bỏ qua " + skipped + " object ngoài artboard.";
    return msg;
  } catch (e) {
    return "ERR: " + e.toString();
  } finally {
    if (!completed) {
      for (var cleanup = createdLines.length - 1; cleanup >= 0; cleanup--)
        try {
          createdLines[cleanup].remove();
        } catch (removeLineError) {}
    }
    if (doc && originalLayer)
      try {
        doc.activeLayer = originalLayer;
      } catch (restoreLayerError) {}
    if (markLayer && capturedMarkState) {
      try {
        if (!completed) markLayer.visible = originalMarkVisible;
        markLayer.locked = originalMarkLocked;
      } catch (restoreMarkStateError) {}
    }
    if (!completed && createdMarkLayer)
      try {
        markLayer.remove();
      } catch (removeLayerError) {}
    if (restoreCoordinates)
      try {
        app.coordinateSystem = oldCoordinates;
      } catch (restoreCoordinatesError) {}
  }
}

// ============================================================
//  TAB DAN TOI UU: 1 mau -> 1 to giay, khong dat pon.
//  Chi dung cac day/hang hinh chu nhat de co the cat bang dao thang.
//  Moi lan chay tao artboard va layer moi, khong sua bai nguon.
// ============================================================
var dcDanToiUuVersion = 2;
function dcDanToiUuV2(pageWidthText, pageHeightText) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";

    var doc = app.activeDocument;
    var selection = doc.selection;
    if (!selection || selection.length === 0)
      return "ERR: Chọn một bài mẫu trước khi dàn.";

    var MM = 2.834645669;
    var MARGIN = 3 * MM;
    var EPS = 0.01;

    function parseCentimeters(value, label) {
      var n = parseFloat(
        String(value === undefined || value === null ? "" : value).replace(
          ",",
          ".",
        ),
      );
      if (!isFinite(n) || n <= 0)
        throw new Error(label + " phải là số cm lớn hơn 0.");
      return n * 10 * MM;
    }

    function boundsOf(item) {
      try {
        return item.visibleBounds.slice(0);
      } catch (e) {}
      try {
        return item.geometricBounds.slice(0);
      } catch (e2) {}
      return null;
    }

    // Luu lai selection truoc khi tao layer/artboard de source khong bi doi.
    var sources = [];
    var sourceBounds = null;
    for (var si = 0; si < selection.length; si++) {
      var source = selection[si];
      var sb = boundsOf(source);
      if (!sb || sb[2] - sb[0] <= EPS || sb[1] - sb[3] <= EPS) continue;
      sources.push(source);
      if (!sourceBounds) sourceBounds = sb.slice(0);
      else {
        sourceBounds[0] = Math.min(sourceBounds[0], sb[0]);
        sourceBounds[1] = Math.max(sourceBounds[1], sb[1]);
        sourceBounds[2] = Math.max(sourceBounds[2], sb[2]);
        sourceBounds[3] = Math.min(sourceBounds[3], sb[3]);
      }
    }
    if (sources.length === 0 || !sourceBounds)
      return "ERR: Selection hiện tại không có artwork hợp lệ để dàn.";

    var paperW = parseCentimeters(pageWidthText, "Ngang giấy");
    var paperH = parseCentimeters(pageHeightText, "Dọc giấy");
    var usableW = paperW - 2 * MARGIN;
    var usableH = paperH - 2 * MARGIN;
    if (usableW <= EPS || usableH <= EPS)
      return "ERR: Khổ giấy phải lớn hơn lề an toàn 3 mm mỗi cạnh.";

    var sourceW = sourceBounds[2] - sourceBounds[0];
    var sourceH = sourceBounds[1] - sourceBounds[3];
    if (sourceW <= EPS || sourceH <= EPS)
      return "ERR: Không đo được kích thước bài mẫu.";

    function floorFit(space, size) {
      if (size <= EPS) return 0;
      return Math.floor((space + EPS) / size);
    }

    // Mot day la hinh chu nhat co the cat bang dao thang. Khac voi ban dau,
    // day nay co the nam trong mot nhanh cua bo cuc: tool tach giay thanh cac
    // vung chu nhat (guillotine) de tan dung khoang trong hinh chu L.
    function makeStripPlan(
      direction,
      normalBands,
      rotatedBands,
      regionW,
      regionH,
    ) {
      var normalCells =
        direction === "row"
          ? floorFit(regionW, sourceW)
          : floorFit(regionH, sourceH);
      var rotatedCells =
        direction === "row"
          ? floorFit(regionW, sourceH)
          : floorFit(regionH, sourceW);
      if (
        (normalBands > 0 && normalCells <= 0) ||
        (rotatedBands > 0 && rotatedCells <= 0)
      )
        return null;

      var count = normalBands * normalCells + rotatedBands * rotatedCells;
      if (count <= 0) return null;
      var plan = {
        kind: "strips",
        direction: direction,
        count: count,
        normalCount: normalBands * normalCells,
        rotatedCount: rotatedBands * rotatedCells,
        bands: [],
      };
      if (normalBands > 0)
        plan.bands.push({
          angle: 0,
          repeat: normalBands,
          cells: normalCells,
          cellW: sourceW,
          cellH: sourceH,
        });
      if (rotatedBands > 0)
        plan.bands.push({
          angle: 90,
          repeat: rotatedBands,
          cells: rotatedCells,
          cellW: sourceH,
          cellH: sourceW,
        });
      return plan;
    }

    function planComplexity(plan) {
      if (!plan) return 999999;
      if (plan.kind === "empty") return 0;
      if (plan.kind === "strips") return plan.bands.length;
      return 1 + planComplexity(plan.first) + planComplexity(plan.second);
    }

    function isBetter(candidate, best) {
      if (!candidate) return false;
      if (!best) return true;
      if (candidate.count !== best.count) return candidate.count > best.count;
      // Cung so luong thi uu tien giu nguyen chieu doc va it nhanh cat hon.
      if (candidate.normalCount !== best.normalCount)
        return candidate.normalCount > best.normalCount;
      return planComplexity(candidate) < planComplexity(best);
    }

    function bestStripPlan(regionW, regionH) {
      var best = null;
      var normalRowMax = floorFit(regionH, sourceH);
      for (var normalRows = 0; normalRows <= normalRowMax; normalRows++) {
        var rowRemain = regionH - normalRows * sourceH;
        var rotatedRows = floorFit(rowRemain, sourceW);
        var rowPlan = makeStripPlan(
          "row",
          normalRows,
          rotatedRows,
          regionW,
          regionH,
        );
        if (isBetter(rowPlan, best)) best = rowPlan;
      }

      var normalColumnMax = floorFit(regionW, sourceW);
      for (
        var normalColumns = 0;
        normalColumns <= normalColumnMax;
        normalColumns++
      ) {
        var columnRemain = regionW - normalColumns * sourceW;
        var rotatedColumns = floorFit(columnRemain, sourceH);
        var columnPlan = makeStripPlan(
          "column",
          normalColumns,
          rotatedColumns,
          regionW,
          regionH,
        );
        if (isBetter(columnPlan, best)) best = columnPlan;
      }
      return best;
    }

    function addCutValue(values, seen, value, total) {
      if (value <= EPS || total - value <= EPS) return;
      var key = Math.round(value * 1000);
      if (seen[key]) return;
      seen[key] = true;
      values.push(value);
    }

    function cutValues(total) {
      var values = [],
        seen = {},
        i;
      for (i = 1; i <= floorFit(total, sourceW); i++) {
        addCutValue(values, seen, i * sourceW, total);
        addCutValue(values, seen, total - i * sourceW, total);
      }
      for (i = 1; i <= floorFit(total, sourceH); i++) {
        addCutValue(values, seen, i * sourceH, total);
        addCutValue(values, seen, total - i * sourceH, total);
      }
      return values;
    }

    // Hai cap tach la du de lay duoc bo cuc hinh chu L nhu 4 dung + 5 xoay,
    // nhung van giu thoi gian tinh nhanh voi cac bai nho.
    var planMemo = {};
    function solveRegion(regionW, regionH, depth) {
      var memoKey =
        Math.round(regionW * 1000) +
        "x" +
        Math.round(regionH * 1000) +
        "x" +
        depth;
      if (planMemo[memoKey]) return planMemo[memoKey];

      var best = bestStripPlan(regionW, regionH);
      if (!best || depth <= 0) {
        if (!best)
          best = { kind: "empty", count: 0, normalCount: 0, rotatedCount: 0 };
        planMemo[memoKey] = best;
        return best;
      }

      var cuts = cutValues(regionW);
      for (var vi = 0; vi < cuts.length; vi++) {
        var leftPlan = solveRegion(cuts[vi], regionH, depth - 1);
        var rightPlan = solveRegion(regionW - cuts[vi], regionH, depth - 1);
        var verticalPlan = {
          kind: "splitV",
          cut: cuts[vi],
          first: leftPlan,
          second: rightPlan,
          count: leftPlan.count + rightPlan.count,
          normalCount: leftPlan.normalCount + rightPlan.normalCount,
          rotatedCount: leftPlan.rotatedCount + rightPlan.rotatedCount,
        };
        if (isBetter(verticalPlan, best)) best = verticalPlan;
      }

      cuts = cutValues(regionH);
      for (var hi = 0; hi < cuts.length; hi++) {
        var topPlan = solveRegion(regionW, cuts[hi], depth - 1);
        var bottomPlan = solveRegion(regionW, regionH - cuts[hi], depth - 1);
        var horizontalPlan = {
          kind: "splitH",
          cut: cuts[hi],
          first: topPlan,
          second: bottomPlan,
          count: topPlan.count + bottomPlan.count,
          normalCount: topPlan.normalCount + bottomPlan.normalCount,
          rotatedCount: topPlan.rotatedCount + bottomPlan.rotatedCount,
        };
        if (isBetter(horizontalPlan, best)) best = horizontalPlan;
      }
      planMemo[memoKey] = best;
      return best;
    }

    var bestPlan = solveRegion(usableW, usableH, 2);
    if (!bestPlan || bestPlan.count <= 0)
      return "ERR: Bài mẫu không nằm vừa trong vùng in sau khi trừ lề 3 mm.";

    function uniqueLayerName(base) {
      var candidate = base;
      var suffix = 2;
      var found = true;
      while (found) {
        found = false;
        for (var li = 0; li < doc.layers.length; li++) {
          try {
            if (doc.layers[li].name === candidate) {
              found = true;
              candidate = base + " " + suffix;
              suffix++;
              break;
            }
          } catch (e) {}
        }
      }
      return candidate;
    }

    // Tao artboard moi ben phai artboard/artwork hien co de tuyet doi khong
    // de len bai dang lam. Khoang cach giua cac to la 10 mm.
    var farRight = sourceBounds[2];
    var topMost = sourceBounds[1];
    for (var ai = 0; ai < doc.artboards.length; ai++) {
      var oldRect = doc.artboards[ai].artboardRect;
      farRight = Math.max(farRight, oldRect[2]);
      topMost = Math.max(topMost, oldRect[1]);
    }
    var sheetLeft = farRight + 10 * MM;
    var sheetTop = topMost;
    var sheetRect = [
      sheetLeft,
      sheetTop,
      sheetLeft + paperW,
      sheetTop - paperH,
    ];
    var sheetIndex = doc.artboards.length;
    var sheet = doc.artboards.add(sheetRect);
    try {
      sheet.name = "Dan toi uu " + (sheetIndex + 1);
      doc.artboards.setActiveArtboardIndex(sheetIndex);
    } catch (e) {}

    var contentLayer = doc.layers.add();
    contentLayer.name = uniqueLayerName("Dan toi uu");
    try {
      contentLayer.locked = false;
      contentLayer.visible = true;
      doc.activeLayer = contentLayer;
    } catch (e) {}

    var cutLayer = doc.layers.add();
    cutLayer.name = uniqueLayerName("Duong dao - Dan toi uu");
    try {
      cutLayer.locked = false;
      cutLayer.visible = true;
      cutLayer.printable = true;
    } catch (e) {}

    function duplicateSourceSet() {
      // Trường hợp thông thường: người dùng chọn đúng 1 artwork/group. Giữ
      // nguyên kiểu object của bản sao, không bọc thêm group để có thể đặt pon
      // ngay trên toàn bộ selection sau khi dàn.
      if (sources.length === 1)
        return sources[0].duplicate(contentLayer, ElementPlacement.PLACEATEND);

      // Nhiều object cùng được chọn vẫn được coi là một bài phức hợp; chỉ khi
      // đó mới gom riêng từng bản sao để các chi tiết không bị tách rời nhau.
      var group = contentLayer.groupItems.add();
      for (var di = 0; di < sources.length; di++) {
        sources[di].duplicate(group, ElementPlacement.PLACEATEND);
      }
      return group;
    }

    function placeCopy(left, top, angle) {
      var copy = duplicateSourceSet();
      if (angle === 90) copy.rotate(90);
      var cb = boundsOf(copy);
      if (!cb) throw new Error("Không đo được bản sao để đặt vào tờ giấy.");
      copy.translate(left - cb[0], top - cb[1]);
      return copy;
    }

    var safeLeft = sheetLeft + MARGIN;
    var safeTop = sheetTop - MARGIN;
    var safeRight = sheetRect[2] - MARGIN;
    var safeBottom = sheetRect[3] + MARGIN;
    var outputItems = [];
    var placedBands = [];
    var bandIndex = 0;

    function placeStripPlan(plan, left, top, regionW, regionH) {
      var x, y, band, repeat, cell;
      if (plan.direction === "row") {
        y = top;
        for (var rb = 0; rb < plan.bands.length; rb++) {
          band = plan.bands[rb];
          for (repeat = 0; repeat < band.repeat; repeat++) {
            x = left;
            for (cell = 0; cell < band.cells; cell++) {
              outputItems.push(placeCopy(x, y, band.angle));
              x += band.cellW;
            }
            placedBands.push({
              index: bandIndex++,
              direction: "row",
              left: left,
              right: x,
              top: y,
              bottom: y - band.cellH,
              cellW: band.cellW,
              cellH: band.cellH,
              cells: band.cells,
              regionLeft: left,
              regionRight: left + regionW,
              regionTop: top,
              regionBottom: top - regionH,
            });
            y -= band.cellH;
          }
        }
      } else {
        x = left;
        for (var cb = 0; cb < plan.bands.length; cb++) {
          band = plan.bands[cb];
          for (repeat = 0; repeat < band.repeat; repeat++) {
            y = top;
            for (cell = 0; cell < band.cells; cell++) {
              outputItems.push(placeCopy(x, y, band.angle));
              y -= band.cellH;
            }
            placedBands.push({
              index: bandIndex++,
              direction: "column",
              left: x,
              right: x + band.cellW,
              top: top,
              bottom: y,
              cellW: band.cellW,
              cellH: band.cellH,
              cells: band.cells,
              regionLeft: left,
              regionRight: left + regionW,
              regionTop: top,
              regionBottom: top - regionH,
            });
            x += band.cellW;
          }
        }
      }
    }

    function placePlan(plan, left, top, regionW, regionH) {
      if (!plan || plan.count <= 0) return;
      if (plan.kind === "strips") {
        placeStripPlan(plan, left, top, regionW, regionH);
        return;
      }
      if (plan.kind === "splitV") {
        placePlan(plan.first, left, top, plan.cut, regionH);
        placePlan(
          plan.second,
          left + plan.cut,
          top,
          regionW - plan.cut,
          regionH,
        );
        return;
      }
      if (plan.kind === "splitH") {
        placePlan(plan.first, left, top, regionW, plan.cut);
        placePlan(
          plan.second,
          left,
          top - plan.cut,
          regionW,
          regionH - plan.cut,
        );
      }
    }

    placePlan(bestPlan, safeLeft, safeTop, usableW, usableH);

    // Layer rieng mau hong: cac duong nay cho phep cat theo thu tu day truoc,
    // roi ha dao tach cac o trong tung day. Khong group chung voi artwork.
    var cutColor = new CMYKColor();
    cutColor.cyan = 0;
    cutColor.magenta = 100;
    cutColor.yellow = 0;
    cutColor.black = 0;
    var lineKeys = {};
    var drawnLines = 0;

    function addCutLine(x1, y1, x2, y2) {
      var a = x1.toFixed(3) + "," + y1.toFixed(3);
      var b = x2.toFixed(3) + "," + y2.toFixed(3);
      var key = a < b ? a + "|" + b : b + "|" + a;
      if (lineKeys[key]) return;
      var line = cutLayer.pathItems.add();
      line.setEntirePath([
        [x1, y1],
        [x2, y2],
      ]);
      line.filled = false;
      line.stroked = true;
      line.strokeWidth = 0.25;
      line.strokeColor = cutColor;
      lineKeys[key] = true;
      drawnLines++;
    }

    for (var pi = 0; pi < placedBands.length; pi++) {
      var placed = placedBands[pi];
      if (placed.direction === "row") {
        // Cat ngang truoc de tach day; cac net doc sau do tach tung con.
        addCutLine(
          placed.regionLeft,
          placed.top,
          placed.regionRight,
          placed.top,
        );
        addCutLine(
          placed.regionLeft,
          placed.bottom,
          placed.regionRight,
          placed.bottom,
        );
        for (var vx = 0; vx <= placed.cells; vx++) {
          addCutLine(
            placed.left + vx * placed.cellW,
            placed.top,
            placed.left + vx * placed.cellW,
            placed.bottom,
          );
        }
      } else {
        // Cat doc truoc de tach day; cac net ngang sau do tach tung con.
        addCutLine(
          placed.left,
          placed.regionTop,
          placed.left,
          placed.regionBottom,
        );
        addCutLine(
          placed.right,
          placed.regionTop,
          placed.right,
          placed.regionBottom,
        );
        for (var hy = 0; hy <= placed.cells; hy++) {
          addCutLine(
            placed.left,
            placed.top - hy * placed.cellH,
            placed.right,
            placed.top - hy * placed.cellH,
          );
        }
      }
    }

    try {
      cutLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      doc.selection = null;
      for (var oi = 0; oi < outputItems.length; oi++)
        outputItems[oi].selected = true;
      doc.activeLayer = contentLayer;
      app.redraw();
    } catch (e) {}

    var orientationText = "giữ nguyên chiều";
    if (bestPlan.rotatedCount > 0) {
      if (bestPlan.normalCount > 0) orientationText = "có kết hợp xoay 90 độ";
      else orientationText = "xoay 90 độ";
    }
    return (
      "OK: Đã tạo 1 artboard " +
      (paperW / (10 * MM)).toFixed(2) +
      " x " +
      (paperH / (10 * MM)).toFixed(2) +
      " cm, dàn được " +
      outputItems.length +
      " con (" +
      orientationText +
      "). Lề 3 mm đã được giữ; đã vẽ " +
      drawnLines +
      " đường dao."
    );
  } catch (e) {
    return "ERR: " + dcMoTaLoi(e);
  }
}

// ============================================================
//  TAB DAN TOI UU v4
//  - Mac dinh: moi mau (hoac cap truoc/sau) ra mot to rieng.
//  - Tick gop mau: nhieu mau chung mot to, duoc chia lan luot vao slot.
//  - Artboard moi tu xep theo luoi canvas, trai sang phai roi xuong hang.
//  - Tach hinh chu nhat de tan dung khoang trong chu L, van cat dao duoc.
// ============================================================
var dcDanToiUuVersion = 24;
// Chỉ gọi sau khi dựng thành công. Chỉ xoá khung, không bao giờ xoá bài bên trong.
function dcRemoveOldCanvasArtboards(doc, oldCount) {
  var removed = 0;
  app.activeDocument = doc;
  if (
    !(oldCount >= 0 && Math.floor(oldCount) === oldCount) ||
    doc.artboards.length <= oldCount
  )
    return { removed: 0, firstNewIndex: oldCount, warning: "" };
  for (var i = oldCount - 1; i >= 0; i--) {
    try {
      doc.artboards[i].remove();
      removed++;
    } catch (removeError) {}
  }
  var remaining = oldCount - removed,
    warning = "";
  if (remaining > 0)
    warning =
      " Chưa xóa được " + remaining + " artboard cũ; kết quả mới vẫn được giữ.";
  return { removed: removed, firstNewIndex: remaining, warning: warning };
}

// Ghi chu duoc dat tren artboard mat truoc dau tien. Nhan ban giu nguyen
// dinh dang, chi doi toa do de khoang cach voi mep artboard luon giong nhau.
function dcCopyToiUuNoteToOddArtboards(prefixListText) {
  return dcCopyToiUuNoteToArtboards(prefixListText, true);
}
function dcCopyToiUuNoteToAllArtboards(prefixListText) {
  return dcCopyToiUuNoteToArtboards(prefixListText, false);
}
function dcCopyToiUuNoteToArtboards(prefixListText, twoSided) {
  var previousCoordinates = app.coordinateSystem;
  var copied = [],
    sourceTextFrame = null,
    originalTextContents = "";
  try {
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";

    var doc = app.activeDocument;
    var selection = doc.selection;
    if (!selection || selection.length === 0)
      return "ERR: Chọn ghi chú trên artboard đầu tiên cần điền.";

    var EPS = 0.01;
    function boundsOf(item) {
      try {
        var visible = item.visibleBounds;
        return [visible[0], visible[1], visible[2], visible[3]];
      } catch (e) {}
      try {
        var geometric = item.geometricBounds;
        return [geometric[0], geometric[1], geometric[2], geometric[3]];
      } catch (e2) {}
      return null;
    }

    function findArtboardAt(x, y) {
      for (var i = 0; i < doc.artboards.length; i++) {
        var rect = doc.artboards[i].artboardRect;
        if (
          x >= rect[0] - EPS &&
          x <= rect[2] + EPS &&
          y <= rect[1] + EPS &&
          y >= rect[3] - EPS
        )
          return i;
      }
      return -1;
    }

    function parsePrefixes(text) {
      var raw = String(text === undefined || text === null ? "" : text).split(
        ",",
      );
      var result = [];
      for (var i = 0; i < raw.length; i++) {
        var value = raw[i].replace(/^\s+|\s+$/g, "");
        if (value) result.push(value);
      }
      return result;
    }

    function collectTextFrames(item, output) {
      if (!item) return;
      try {
        if (item.typename === "TextFrame") {
          output.push(item);
          return;
        }
      } catch (e) {}
      try {
        if (item.typename === "GroupItem") {
          for (var i = 0; i < item.pageItems.length; i++)
            collectTextFrames(item.pageItems[i], output);
        }
      } catch (e2) {}
    }

    var records = [];
    var sourceIndex = -1;
    for (var si = 0; si < selection.length; si++) {
      var sourceBounds = boundsOf(selection[si]);
      if (!sourceBounds) continue;
      var centerX = (sourceBounds[0] + sourceBounds[2]) / 2;
      var centerY = (sourceBounds[1] + sourceBounds[3]) / 2;
      var itemArtboard = findArtboardAt(centerX, centerY);
      if (itemArtboard < 0)
        return "ERR: Ghi chú đang chọn nằm ngoài artboard. Đặt nó vào artboard đầu tiên cần điền.";
      if (sourceIndex < 0) sourceIndex = itemArtboard;
      else if (sourceIndex !== itemArtboard)
        return "ERR: Chỉ chọn ghi chú trên một artboard trong một lần copy.";
      records.push({ item: selection[si], bounds: sourceBounds });
    }
    if (records.length === 0) return "ERR: Không đọc được ghi chú đang chọn.";
    if (twoSided && sourceIndex % 2 !== 0)
      return "ERR: Ghi chú phải nằm trên artboard mặt trước (artboard số lẻ).";

    var targetIndexes = [];
    var step = twoSided ? 2 : 1;
    for (var ai = sourceIndex + step; ai < doc.artboards.length; ai += step)
      targetIndexes.push(ai);

    var prefixes = parsePrefixes(prefixListText);
    var usePrefixes = prefixes.length > 0;
    if (targetIndexes.length === 0 && (twoSided || !usePrefixes))
      return (
        "ERR: Chưa có artboard " +
        (twoSided ? "mặt trước " : "") +
        "tiếp theo để copy ghi chú."
      );
    var prefixRecordIndex = -1;
    var prefixTextIndex = -1;
    if (usePrefixes) {
      if (prefixes.length !== targetIndexes.length + 1)
        return (
          "ERR: Cần " +
          (targetIndexes.length + 1) +
          " nội dung cho artboard " +
          (sourceIndex + 1) +
          ", " +
          (sourceIndex + 1 + step) +
          ", ...; hiện đang có " +
          prefixes.length +
          "."
        );

      var selectedTextFrames = [];
      for (var tri = 0; tri < records.length; tri++) {
        var recordTextFrames = [];
        collectTextFrames(records[tri].item, recordTextFrames);
        for (var tfi = 0; tfi < recordTextFrames.length; tfi++) {
          selectedTextFrames.push({
            frame: recordTextFrames[tfi],
            recordIndex: tri,
            textIndex: tfi,
          });
        }
      }
      if (selectedTextFrames.length !== 1)
        return "ERR: Khi nhập nội dung, hãy chọn một ghi chú có đúng một TextFrame (có thể nằm trong group).";

      prefixRecordIndex = selectedTextFrames[0].recordIndex;
      prefixTextIndex = selectedTextFrames[0].textIndex;
      originalTextContents = selectedTextFrames[0].frame.contents;
      sourceTextFrame = selectedTextFrames[0].frame;
      sourceTextFrame.contents = prefixes[0] + " - " + originalTextContents;
    }

    var sourceRect = doc.artboards[sourceIndex].artboardRect;
    for (var ri = 0; ri < records.length; ri++) {
      records[ri].bounds = boundsOf(records[ri].item);
      if (!records[ri].bounds)
        throw new Error("Không đo được ghi chú sau khi thêm nội dung.");
      records[ri].leftOffset = records[ri].bounds[0] - sourceRect[0];
      records[ri].topOffset = records[ri].bounds[1] - sourceRect[1];
    }

    for (var ti = 0; ti < targetIndexes.length; ti++) {
      var targetRect = doc.artboards[targetIndexes[ti]].artboardRect;
      for (ri = 0; ri < records.length; ri++) {
        var copy = records[ri].item.duplicate();
        copied.push(copy);
        var copyBounds = boundsOf(copy);
        if (!copyBounds) {
          try {
            copy.remove();
          } catch (removeError) {}
          throw new Error("Không đo được bản sao ghi chú.");
        }
        copy.translate(
          targetRect[0] + records[ri].leftOffset - copyBounds[0],
          targetRect[1] + records[ri].topOffset - copyBounds[1],
        );
        if (usePrefixes && ri === prefixRecordIndex) {
          var copyTextFrames = [];
          collectTextFrames(copy, copyTextFrames);
          if (copyTextFrames.length <= prefixTextIndex)
            throw new Error("Không tìm được TextFrame trên bản sao ghi chú.");
          copyTextFrames[prefixTextIndex].contents =
            prefixes[ti + 1] + " - " + originalTextContents;
          // Noi dung co do dai khac nhau co the lam bounds doi. Canh lai lan
          // nua de vi tri hien thi trung voi ghi chu tren artboard nguon.
          var prefixedCopyBounds = boundsOf(copy);
          if (!prefixedCopyBounds)
            throw new Error("Không đo được bản sao sau khi thêm nội dung.");
          copy.translate(
            targetRect[0] + records[ri].leftOffset - prefixedCopyBounds[0],
            targetRect[1] + records[ri].topOffset - prefixedCopyBounds[1],
          );
        }
      }
    }

    try {
      if (copied.length) {
        doc.selection = null;
        for (var ci = 0; ci < copied.length; ci++) copied[ci].selected = true;
        doc.artboards.setActiveArtboardIndex(targetIndexes[0]);
      }
    } catch (selectError) {}
    app.redraw();
    return (
      "OK: Đã copy " +
      records.length +
      " ghi chú từ artboard " +
      (sourceIndex + 1) +
      " sang " +
      targetIndexes.length +
      (twoSided
        ? " artboard mặt trước tiếp theo."
        : " artboard tiếp theo (bài 1 mặt).") +
      (usePrefixes ? " Đã thêm nội dung theo thứ tự đã nhập." : "")
    );
  } catch (e) {
    for (var cleanup = copied.length - 1; cleanup >= 0; cleanup--) {
      try {
        copied[cleanup].remove();
      } catch (removeCopyError) {}
    }
    if (sourceTextFrame) {
      try {
        sourceTextFrame.contents = originalTextContents;
      } catch (restoreTextError) {}
    }
    return "ERR: " + dcMoTaLoi(e);
  } finally {
    app.coordinateSystem = previousCoordinates;
  }
}

// Thuần hình học: chốt vai trái/phải trước khi xếp. Không dùng EPS số học nhỏ xíu
// làm dung sai canh hàng, cũng không ghép cặp các object liền nhau theo thứ tự Y.
function dcKtsPairSourceRecords(records, epsilon) {
  var pending = records.slice(0),
    pairs = [],
    EPS = epsilon || 0.01;
  pending.sort(function (a, b) {
    if (a.cy !== b.cy) return b.cy - a.cy;
    return a.cx - b.cx;
  });
  while (pending.length) {
    var anchor = pending.shift(),
      row = [anchor];
    var high = anchor.cy,
      low = anchor.cy;
    var minHeight = anchor.bounds[1] - anchor.bounds[3];
    for (var i = 0; i < pending.length; i++) {
      var candidate = pending[i];
      var nextHeight = Math.min(
        minHeight,
        candidate.bounds[1] - candidate.bounds[3],
      );
      var nextHigh = Math.max(high, candidate.cy),
        nextLow = Math.min(low, candidate.cy);
      // Tối đa một phần tư khung thấp hơn: chấp nhận lệch nhỏ nhưng không thể
      // nối các hàng kề nhau thành một qua một chuỗi chênh lệch sát nút liên tiếp.
      if (nextHigh - nextLow <= nextHeight * 0.25 + EPS) {
        row.push(candidate);
        pending.splice(i--, 1);
        high = nextHigh;
        low = nextLow;
        minHeight = nextHeight;
      }
    }
    if (row.length % 2 !== 0)
      throw new Error(
        "Không ghép rõ cặp trước/sau: mỗi hàng cần đủ object trái và phải. Hãy canh lại hàng nguồn.",
      );
    row.sort(function (a, b) {
      return a.cx - b.cx;
    });
    for (var r = 0; r < row.length; r += 2) {
      if (
        row[r].bounds[2] > row[r + 1].bounds[0] + EPS ||
        row[r + 1].cx - row[r].cx <= EPS
      )
        throw new Error(
          "Hai mặt nguồn đang chồng ngang hoặc không phân biệt được trái/phải. Hãy đặt mỗi cặp cạnh nhau.",
        );
      pairs.push({ front: row[r], back: row[r + 1] });
    }
  }
  return pairs;
}

// Tìm một trình tự cắt tách bằng dao thẳng, sao cho ít nhát cắt nhất trong
// các thứ tự chẻ đã thử. Nhát cắt không bao giờ đi xuyên qua hình chữ nhật thành phẩm nào.
// null nghĩa là chưa chứng minh được trình tự nào trong lượt tìm có giới hạn này (không an toàn để dùng).
function dcKtsKnifePlan(slots, width, height) {
  var EPS = 0.01,
    budget = 30000,
    memo = {};
  if (!slots.length || slots.length > 128) return null;
  function lengthOf(cuts) {
    var n = 0;
    for (var i = 0; i < cuts.length; i++)
      n += cuts[i].axis === "H" ? cuts[i].w : cuts[i].h;
    return n;
  }
  function trim(bounds, region) {
    var r = { x: region.x, y: region.y, w: region.w, h: region.h },
      cuts = [];
    function add(axis, at) {
      cuts.push({ axis: axis, at: at, x: r.x, y: r.y, w: r.w, h: r.h });
    }
    if (bounds.x > r.x + EPS) {
      add("V", bounds.x);
      r.w -= bounds.x - r.x;
      r.x = bounds.x;
    }
    if (bounds.x + bounds.w < r.x + r.w - EPS) {
      add("V", bounds.x + bounds.w);
      r.w = bounds.w;
    }
    if (bounds.y > r.y + EPS) {
      add("H", bounds.y);
      r.h -= bounds.y - r.y;
      r.y = bounds.y;
    }
    if (bounds.y + bounds.h < r.y + r.h - EPS) {
      add("H", bounds.y + bounds.h);
      r.h = bounds.h;
    }
    return cuts;
  }
  function cutPattern(cuts, region) {
    function q(n) {
      return Math.round(n * 100);
    }
    var parts = [q(region.w), q(region.h)];
    for (var i = 0; i < cuts.length; i++) {
      var c = cuts[i];
      parts.push(
        c.axis,
        q(c.at - (c.axis === "H" ? region.y : region.x)),
        q(c.x - region.x),
        q(c.y - region.y),
        q(c.w),
        q(c.h),
      );
    }
    return parts.join(",");
  }
  function solve(ids) {
    var key = "p" + ids.join(",");
    if (memo[key] !== undefined) return memo[key];
    var x = width,
      y = height,
      right = 0,
      bottom = 0;
    for (var i = 0; i < ids.length; i++) {
      var s = slots[ids[i]];
      x = Math.min(x, s.x);
      y = Math.min(y, s.y);
      right = Math.max(right, s.x + s.w);
      bottom = Math.max(bottom, s.y + s.h);
    }
    var bounds = { x: x, y: y, w: right - x, h: bottom - y };
    if (ids.length === 1)
      return (memo[key] = {
        bounds: bounds,
        cuts: [],
        cutLength: 0,
        workCount: 0,
      });
    var best = null;
    for (var axis = 0; axis < 2 && budget > 0; axis++) {
      var edges = [],
        low = axis ? y : x,
        high = axis ? bottom : right;
      for (i = 0; i < ids.length; i++) {
        s = slots[ids[i]];
        edges.push(axis ? s.y : s.x);
        edges.push(axis ? s.y + s.h : s.x + s.w);
      }
      edges.sort(function (a, b) {
        return a - b;
      });
      for (var ei = 0; ei < edges.length && budget > 0; ei++) {
        var at = edges[ei];
        if (
          at <= low + EPS ||
          at >= high - EPS ||
          (ei && Math.abs(at - edges[ei - 1]) <= EPS)
        )
          continue;
        var first = [],
          second = [],
          crossed = false;
        for (i = 0; i < ids.length; i++) {
          if (--budget <= 0) {
            crossed = true;
            break;
          }
          s = slots[ids[i]];
          var start = axis ? s.y : s.x,
            end = start + (axis ? s.h : s.w);
          if (start < at - EPS && end > at + EPS) {
            crossed = true;
            break;
          }
          if (end <= at + EPS) first.push(ids[i]);
          else second.push(ids[i]);
        }
        if (crossed || !first.length || !second.length) continue;
        var a = solve(first),
          b = solve(second);
        if (!a || !b) continue;
        var ar = {
          x: x,
          y: y,
          w: axis ? bounds.w : at - x,
          h: axis ? at - y : bounds.h,
        };
        var br = {
          x: axis ? x : at,
          y: axis ? at : y,
          w: axis ? bounds.w : right - at,
          h: axis ? bottom - at : bounds.h,
        };
        var cut = {
          axis: axis ? "H" : "V",
          at: at,
          x: x,
          y: y,
          w: bounds.w,
          h: bounds.h,
        };
        var trimA = trim(a.bounds, ar),
          trimB = trim(b.bounds, br);
        var ac = trimA.concat(a.cuts),
          bc = trimB.concat(b.cuts);
        var cuts = [cut].concat(ac, bc);
        var cutLength = lengthOf(cuts);
        var workA = trimA.length + a.workCount,
          workB = trimB.length + b.workCount;
        // Các mảnh đã tách rời mà giống hệt nhau thì chồng lên cắt chung được.
        // Trình tự dùng lại được này chỉ tính một lần, không tính riêng cho từng mảnh.
        var workCount = 1 + workA + workB;
        if (cutPattern(ac, ar) === cutPattern(bc, br))
          workCount = 1 + Math.max(workA, workB);
        var improve = false;
        if (best === null) improve = true;
        else if (workCount < best.workCount) improve = true;
        else if (workCount === best.workCount) {
          if (cuts.length < best.cuts.length) improve = true;
          else if (
            cuts.length === best.cuts.length &&
            cutLength < best.cutLength - EPS
          )
            improve = true;
        }
        if (improve)
          best = {
            bounds: bounds,
            cuts: cuts,
            cutLength: cutLength,
            workCount: workCount,
          };
      }
    }
    memo[key] = best;
    return best;
  }
  var ids = [];
  for (var i = 0; i < slots.length; i++) ids.push(i);
  var result = solve(ids);
  if (!result) return null;
  var edgeCuts = trim(result.bounds, { x: 0, y: 0, w: width, h: height });
  var cuts = edgeCuts.concat(result.cuts);
  return {
    cuts: cuts,
    cutCount: cuts.length,
    cutLength: lengthOf(cuts),
    workCount: edgeCuts.length + result.workCount,
  };
}

// Sắp lại thứ tự các dải nguyên vẹn, tách ra độc lập được. Các kiểu cắt giống nhau
// sẽ thành những khối nằm kề nhau (vd cả bốn hàng lớn nằm trên hàng nhỏ).
// Việc này không làm đổi số lượng lẫn kích thước thật của bất kỳ mẫu nào.
function dcKtsKnifeBandVariants(slots) {
  var EPS = 0.01,
    variants = [];
  for (var axis = 0; axis < 2; axis++) {
    var borders = [0];
    for (var i = 0; i < slots.length; i++) {
      var s = slots[i],
        start = axis ? s.x : s.y,
        end = start + (axis ? s.w : s.h);
      borders.push(start, end);
    }
    borders.sort(function (a, b) {
      return a - b;
    });
    var edges = [];
    for (i = 0; i < borders.length; i++) {
      var at = borders[i],
        crossed = false;
      if (edges.length && at <= edges[edges.length - 1] + EPS) continue;
      for (var si = 0; si < slots.length; si++) {
        s = slots[si];
        start = axis ? s.x : s.y;
        end = start + (axis ? s.w : s.h);
        if (start < at - EPS && end > at + EPS) {
          crossed = true;
          break;
        }
      }
      if (!crossed) edges.push(at);
    }
    if (edges.length < 3) continue;
    var bands = [];
    for (var ei = 1; ei < edges.length; ei++) {
      var from = edges[ei - 1],
        to = edges[ei],
        band = {
          from: from,
          size: to - from,
          cells: [],
          area: 0,
          key: "",
          order: ei,
        };
      var signatures = [];
      for (si = 0; si < slots.length; si++) {
        s = slots[si];
        start = axis ? s.x : s.y;
        end = start + (axis ? s.w : s.h);
        if (
          start < from - EPS ||
          end > to + EPS ||
          (start + end) / 2 < from ||
          (start + end) / 2 >= to
        )
          continue;
        band.cells.push(s);
        band.area = Math.max(band.area, s.w * s.h);
        signatures.push(
          [
            Math.round((axis ? s.y : s.x) * 100),
            Math.round((start - from) * 100),
            Math.round(s.w * 100),
            Math.round(s.h * 100),
          ].join(","),
        );
      }
      signatures.sort();
      band.key = signatures.join("|");
      bands.push(band);
    }
    bands.sort(function (a, b) {
      if (Math.abs(a.area - b.area) > EPS) return b.area - a.area;
      if (a.key < b.key) return -1;
      if (a.key > b.key) return 1;
      return a.order - b.order;
    });
    var reordered = [],
      offset = 0;
    for (var bi = 0; bi < bands.length; bi++) {
      var b = bands[bi];
      for (si = 0; si < b.cells.length; si++) {
        s = b.cells[si];
        reordered.push({
          x: s.x + (axis ? offset - b.from : 0),
          y: s.y + (axis ? 0 : offset - b.from),
          w: s.w,
          h: s.h,
          angle: s.angle,
          modelIndex: s.modelIndex,
        });
      }
      offset += b.size;
    }
    if (reordered.length === slots.length) variants.push(reordered);
  }
  return variants;
}

// Tìm kiếm guillotine có giới hạn và tất định. Mỗi vùng trống là một mảnh
// riêng mà dao thẳng cắt tới được, không bao giờ là một hốc MaxRects chồng lấn.
// Hình học tính bằng pt; mọi thao tác ghi vào app do bộ dựng KTS sẵn có đảm nhận.
// Bộ sinh phương án thuần ES3; không ghi gì vào Illustrator/tài liệu/ứng dụng.
// Trả về một bố cục chẻ cho mỗi số lượng chính xác của nhóm khổ lớn hơn.
// Mặc định mỗi mẫu gốc đều có mặt ít nhất một lần. Với
// allowPartialCoverage, tối đa hoá khổ lớn trước rồi mới tới các con nhỏ lấp chỗ.
// repeatLargest cho phép mẫu lặp lại vượt quá số lượng đã chọn.
// Phía gọi nên kiểm tra
// và xếp hạng các phương án này bằng dcKtsKnifePlan trước khi dùng bộ dựng.
// null là phương án dự phòng tường minh khi lượt tìm chạm giới hạn, không hề khẳng định là bất khả thi.
function dcKtsSlicingProfilePlan(specs, width, height, options) {
  var EPS = 0.0001,
    groups = [],
    i,
    j,
    k;
  var maxPoints = 56,
    maxStates = 2800,
    maxTransitions = 5000000;
  var maxProfile = 40,
    maxCopies = 128;
  options = options || {};
  if (
    !specs ||
    !specs.length ||
    !(width > EPS && height > EPS) ||
    !isFinite(width) ||
    !isFinite(height)
  )
    return null;

  for (i = 0; i < specs.length; i++) {
    var spec = specs[i];
    if (
      !spec ||
      !(spec.w > EPS && spec.h > EPS) ||
      !isFinite(spec.w) ||
      !isFinite(spec.h)
    )
      return null;
    var shortEdge = Math.min(spec.w, spec.h),
      longEdge = Math.max(spec.w, spec.h);
    var found = -1;
    for (j = 0; j < groups.length; j++) {
      if (
        Math.abs(groups[j].w - longEdge) <= EPS &&
        Math.abs(groups[j].h - shortEdge) <= EPS
      ) {
        found = j;
        break;
      }
    }
    if (found < 0) {
      if (groups.length >= 2) return null;
      found = groups.length;
      groups.push({
        w: longEdge,
        h: shortEdge,
        area: longEdge * shortEdge,
        modelIndices: [],
        minimum: 0,
      });
    }
    groups[found].modelIndices.push(i);
    groups[found].minimum++;
  }
  if (groups.length !== 2) return null;
  // Trục profile chính xác lấy theo hình lớn hơn, để chiều số lượng luôn
  // nhỏ ngay cả khi rất nhiều con hình nhỏ nằm vừa trong một dải còn thừa.
  if (groups[0].area < groups[1].area) groups = [groups[1], groups[0]];
  var partial = options.allowPartialCoverage === true;
  var minimumA = groups[0].minimum,
    minimumB = groups[1].minimum;
  if (partial) {
    minimumA = 0;
    minimumB = 0;
  }
  var maximumA = Math.floor(
    (width * height - minimumB * groups[1].area + EPS) / groups[0].area,
  );
  if (partial && options.repeatLargest !== true)
    maximumA = Math.min(maximumA, groups[0].minimum);
  if (
    partial &&
    options.desiredGroupCounts &&
    options.desiredGroupCounts[0] !== undefined &&
    options.desiredGroupCounts[0] !== null
  )
    maximumA = Math.min(maximumA, Math.floor(options.desiredGroupCounts[0]));
  var copyBound = Math.floor(
    (width * height) / Math.min(groups[0].area, groups[1].area) + EPS,
  );
  if (maximumA < minimumA || maximumA > maxProfile || copyBound > maxCopies)
    return null;

  var edges = [];
  function addEdge(value) {
    for (var ei = 0; ei < edges.length; ei++)
      if (Math.abs(edges[ei] - value) <= EPS) return;
    edges.push(value);
  }
  addEdge(groups[0].w);
  addEdge(groups[0].h);
  addEdge(groups[1].w);
  addEdge(groups[1].h);
  edges.sort(function (a, b) {
    return a - b;
  });
  function normalPositions(maximum) {
    var positions = [0];
    // Toạ độ normal-pattern là tổng các độ dài cạnh hình chữ nhật thành phẩm.
    // Chỉ chèn vào sau vị trí hiện tại nên việc mở rộng là hữu hạn
    // và có thứ tự mà không cần làm tròn/thay đổi kích thước thành phẩm của bài.
    for (var pi = 0; pi < positions.length; pi++) {
      for (var ei = 0; ei < edges.length; ei++) {
        var at = positions[pi] + edges[ei];
        if (at > maximum + EPS) continue;
        if (Math.abs(at - maximum) <= EPS) at = maximum;
        var place = 0;
        while (place < positions.length && positions[place] < at - EPS) place++;
        if (place < positions.length && Math.abs(positions[place] - at) <= EPS)
          continue;
        if (positions.length >= maxPoints) return null;
        positions.splice(place, 0, at);
      }
    }
    if (maximum > positions[positions.length - 1] + EPS) {
      if (positions.length >= maxPoints) return null;
      positions.push(maximum);
    }
    return positions;
  }
  var xs = normalPositions(width),
    ys = normalPositions(height);
  if (!xs || !ys || xs.length * ys.length > maxStates) return null;
  function floorPosition(positions, available) {
    var low = 0,
      high = positions.length - 1;
    while (low < high) {
      var mid = Math.floor((low + high + 1) / 2);
      if (positions[mid] <= available + EPS) low = mid;
      else high = mid - 1;
    }
    return low;
  }
  function q(value) {
    return Math.round(value * 10000);
  }
  function signatureLeaf(w, h, pw, ph) {
    return "L," + [q(w), q(h), q(pw), q(ph)].join(",");
  }
  function preferred(candidate, previous) {
    if (!previous) return true;
    if (candidate.small !== previous.small)
      return candidate.small > previous.small;
    if (candidate.work !== previous.work) return candidate.work < previous.work;
    if (candidate.cutCount !== previous.cutCount)
      return candidate.cutCount < previous.cutCount;
    return candidate.cutLength < previous.cutLength - EPS;
  }

  var dp = [],
    transitions = 0,
    stopped = false;
  for (i = 0; i < xs.length; i++) {
    dp[i] = [];
    for (j = 0; j < ys.length; j++) {
      var regionW = xs[i],
        regionH = ys[j],
        records = [];
      for (k = 0; k <= maximumA; k++) records.push(null);
      records[0] = {
        small: 0,
        total: 0,
        tree: null,
        cutCount: 0,
        cutLength: 0,
        work: 0,
        signature: "E",
      };
      dp[i][j] = records;
      for (var groupIndex = 0; groupIndex < 2; groupIndex++) {
        var group = groups[groupIndex];
        for (var orientation = 0; orientation < 2; orientation++) {
          var leafW = group.w,
            leafH = group.h;
          if (orientation === 1) {
            leafW = group.h;
            leafH = group.w;
          }
          if (leafW > regionW + EPS || leafH > regionH + EPS) continue;
          var aQuantity = 0,
            bQuantity = 1;
          if (groupIndex === 0) {
            aQuantity = 1;
            bQuantity = 0;
          }
          if (aQuantity > maximumA) continue;
          var leafCuts = 0,
            leafLength = 0;
          if (regionW > leafW + EPS) {
            leafCuts++;
            leafLength += regionH;
          }
          if (regionH > leafH + EPS) {
            leafCuts++;
            leafLength += leafW;
          }
          var leaf = {
            small: bQuantity,
            total: 1,
            cutCount: leafCuts,
            cutLength: leafLength,
            work: leafCuts,
            signature: signatureLeaf(regionW, regionH, leafW, leafH),
            tree: {
              groupIndex: groupIndex,
              w: leafW,
              h: leafH,
              regionW: regionW,
              regionH: regionH,
            },
          };
          if (preferred(leaf, records[aQuantity])) records[aQuantity] = leaf;
        }
      }

      // Xén dải trống ngoài cùng một lần cho cả bố cục hiện có, thay vì
      // bắt khoảng trống đó phải có mặt trong lộ trình cắt tách của từng nút lá.
      // Điều này quan trọng với các hàng lặp lại thẳng hàng và việc cắt chồng.
      function adoptTrimmed(source, axis, capacity) {
        var trimLength = regionH;
        if (axis === "H") trimLength = regionW;
        for (var quantity = 0; quantity <= maximumA; quantity++) {
          var inner = source[quantity];
          if (!inner || !inner.total) continue;
          if (++transitions > maxTransitions) {
            stopped = true;
            return;
          }
          var trimmed = {
            small: inner.small,
            total: inner.total,
            cutCount: inner.cutCount + 1,
            cutLength: inner.cutLength + trimLength,
            work: inner.work + 1,
          };
          if (!preferred(trimmed, records[quantity])) continue;
          trimmed.tree = {
            trimAxis: axis,
            at: capacity,
            a: inner.tree,
            regionW: regionW,
            regionH: regionH,
          };
          trimmed.signature =
            "T" +
            axis +
            "," +
            [q(regionW), q(regionH), q(capacity)].join(",") +
            "(" +
            inner.signature +
            ")";
          records[quantity] = trimmed;
        }
      }
      for (var tx = 1; tx < i && !stopped; tx++)
        adoptTrimmed(dp[tx][j], "V", xs[tx]);
      for (var ty = 1; ty < j && !stopped; ty++)
        adoptTrimmed(dp[i][ty], "H", ys[ty]);
      if (stopped) return null;

      function combine(
        first,
        second,
        axis,
        at,
        secondCapacity,
        secondAvailable,
      ) {
        var residualTrim = 0,
          residualLength = 0;
        if (secondAvailable > secondCapacity + EPS) {
          residualTrim = 1;
          residualLength = regionH;
          if (axis === "H") residualLength = regionW;
        }
        for (var qa = 0; qa <= maximumA; qa++) {
          var left = first[qa];
          if (!left || !left.total) continue;
          for (var qb = 0; qa + qb <= maximumA; qb++) {
            var right = second[qb];
            if (!right || !right.total) continue;
            if (++transitions > maxTransitions) {
              stopped = true;
              return;
            }
            var total = left.total + right.total;
            if (total > maxCopies) continue;
            var outputQuantity = qa + qb,
              small = left.small + right.small;
            if (
              options.desiredGroupCounts &&
              options.desiredGroupCounts[1] !== undefined &&
              options.desiredGroupCounts[1] !== null &&
              small > options.desiredGroupCounts[1]
            )
              continue;
            var previous = records[outputQuantity];
            if (previous && small < previous.small) continue;
            var cutCount = 1 + left.cutCount + right.cutCount + residualTrim;
            var work = 1 + left.work + right.work + residualTrim;
            // Các mảnh bằng nhau đã tách rời và có lộ trình đầy đủ giống hệt nhau
            // thì được chồng lên nhau. Bằng nhau là xét theo hình học, không xét đó là bài nào.
            if (!residualTrim && left.signature === right.signature)
              work = 1 + Math.max(left.work, right.work);
            var cutLength = regionH;
            if (axis === "H") cutLength = regionW;
            cutLength += left.cutLength + right.cutLength + residualLength;
            var candidate = {
              small: small,
              total: total,
              cutCount: cutCount,
              cutLength: cutLength,
              work: work,
            };
            if (!preferred(candidate, previous)) continue;
            candidate.tree = {
              axis: axis,
              at: at,
              a: left.tree,
              b: right.tree,
              secondCapacity: secondCapacity,
              secondAvailable: secondAvailable,
              regionW: regionW,
              regionH: regionH,
            };
            candidate.signature =
              axis +
              "," +
              [q(regionW), q(regionH), q(at), q(secondCapacity)].join(",") +
              "(" +
              left.signature +
              ")(" +
              right.signature +
              ")";
            records[outputQuantity] = candidate;
          }
        }
      }
      for (var xi = 1; xi < i && !stopped; xi++) {
        var rightIndex = floorPosition(xs, regionW - xs[xi]);
        if (rightIndex)
          combine(
            dp[xi][j],
            dp[rightIndex][j],
            "V",
            xs[xi],
            xs[rightIndex],
            regionW - xs[xi],
          );
      }
      for (var yi = 1; yi < j && !stopped; yi++) {
        var bottomIndex = floorPosition(ys, regionH - ys[yi]);
        if (bottomIndex)
          combine(
            dp[i][yi],
            dp[i][bottomIndex],
            "H",
            ys[yi],
            ys[bottomIndex],
            regionH - ys[yi],
          );
      }
      if (stopped) return null;
    }
  }

  var plans = [],
    resultRecords = dp[xs.length - 1][ys.length - 1];
  function expand(tree, x, y, slots, cuts) {
    if (!tree) return;
    var w = tree.regionW,
      h = tree.regionH;
    function cut(axis, at, rx, ry, rw, rh) {
      cuts.push({ axis: axis, at: at, x: rx, y: ry, w: rw, h: rh });
    }
    if (tree.trimAxis !== undefined) {
      var absoluteAt = x + tree.at;
      if (tree.trimAxis === "H") absoluteAt = y + tree.at;
      cut(tree.trimAxis, absoluteAt, x, y, w, h);
      expand(tree.a, x, y, slots, cuts);
      return;
    }
    if (tree.groupIndex !== undefined) {
      slots.push({
        x: x,
        y: y,
        w: tree.w,
        h: tree.h,
        groupIndex: tree.groupIndex,
      });
      if (w > tree.w + EPS) {
        cut("V", x + tree.w, x, y, w, h);
        w = tree.w;
      }
      if (h > tree.h + EPS) cut("H", y + tree.h, x, y, w, h);
      return;
    }
    if (tree.axis === "V") {
      cut("V", x + tree.at, x, y, w, h);
      expand(tree.a, x, y, slots, cuts);
      var bx = x + tree.at,
        bw = w - tree.at;
      if (tree.secondAvailable > tree.secondCapacity + EPS)
        cut("V", bx + tree.secondCapacity, bx, y, bw, h);
      expand(tree.b, bx, y, slots, cuts);
    } else {
      cut("H", y + tree.at, x, y, w, h);
      expand(tree.a, x, y, slots, cuts);
      var by = y + tree.at,
        bh = h - tree.at;
      if (tree.secondAvailable > tree.secondCapacity + EPS)
        cut("H", by + tree.secondCapacity, x, by, w, bh);
      expand(tree.b, x, by, slots, cuts);
    }
  }
  var largestAvailable = maximumA;
  if (partial) {
    // Không đánh đổi một con lớn lấy vài con nhỏ hơn. Chỉ đưa cho
    // phía gọi profile khổ lớn khả thi cao nhất.
    while (
      largestAvailable >= 0 &&
      (!resultRecords[largestAvailable] ||
        !resultRecords[largestAvailable].total)
    )
      largestAvailable--;
    if (largestAvailable < 0) return null;
    minimumA = largestAvailable;
    maximumA = largestAvailable;
  }
  for (k = minimumA; k <= maximumA; k++) {
    var record = resultRecords[k];
    if (!record || record.small < minimumB) continue;
    // null/undefined để khổ đó được tự do lặp lại. Ví dụ,
    // [groups[0].minimum, null] giữ mỗi mẫu lớn đã chuẩn bị đúng một lần
    // và chỉ tối đa hoá số con của mẫu nhỏ hơn.
    if (options.desiredGroupCounts) {
      if (
        !partial &&
        options.desiredGroupCounts[0] !== undefined &&
        options.desiredGroupCounts[0] !== null &&
        options.desiredGroupCounts[0] !== k
      )
        continue;
      if (
        options.desiredGroupCounts[1] !== undefined &&
        options.desiredGroupCounts[1] !== null &&
        options.desiredGroupCounts[1] !== record.small
      )
        continue;
    }
    var slots = [],
      cuts = [],
      counts = [],
      assigned = [0, 0],
      area = 0;
    for (i = 0; i < specs.length; i++) counts.push(0);
    expand(record.tree, 0, 0, slots, cuts);
    for (i = 0; i < slots.length; i++) {
      var slot = slots[i],
        gid = slot.groupIndex,
        groupModels = groups[gid].modelIndices;
      slot.modelIndex = groupModels[assigned[gid] % groupModels.length];
      assigned[gid]++;
      counts[slot.modelIndex]++;
      var original = specs[slot.modelIndex];
      slot.angle = 0;
      if (
        Math.abs(slot.w - original.w) > EPS ||
        Math.abs(slot.h - original.h) > EPS
      )
        slot.angle = 90;
      delete slot.groupIndex;
      area += slot.w * slot.h;
    }
    var minimum = counts[0];
    for (i = 1; i < counts.length; i++) minimum = Math.min(minimum, counts[i]);
    var length = 0;
    for (i = 0; i < cuts.length; i++) {
      if (cuts[i].axis === "H") length += cuts[i].w;
      else length += cuts[i].h;
    }
    var coverageCounts = [];
    var unplacedModelIndices = [];
    for (i = 0; i < counts.length; i++) {
      if (counts[i] > 0) coverageCounts.push(1);
      else {
        coverageCounts.push(0);
        unplacedModelIndices.push(i);
      }
    }
    plans.push({
      slots: slots,
      counts: counts,
      count: slots.length,
      minimum: minimum,
      area: area,
      balancedCounts: coverageCounts,
      groupCounts: assigned,
      cuts: cuts,
      cutCount: cuts.length,
      cutLength: length,
      workCount: record.work,
      estimatedWorkCount: record.work,
      unplacedModelIndices: unplacedModelIndices,
      partialCoverage: partial,
      source: "normal-pattern-slicing",
    });
  }
  if (!plans.length) return null;
  plans.sort(function (a, b) {
    if (a.count !== b.count) return b.count - a.count;
    if (a.workCount !== b.workCount) return a.workCount - b.workCount;
    if (a.cutCount !== b.cutCount) return a.cutCount - b.cutCount;
    if (Math.abs(a.cutLength - b.cutLength) > EPS)
      return a.cutLength - b.cutLength;
    return a.groupCounts[0] - b.groupCounts[0];
  });
  return {
    plans: plans,
    best: plans[0],
    groups: groups,
    operations: transitions,
    stateCount: xs.length * ys.length,
    normalWidths: xs,
    normalHeights: ys,
  };
}

function dcKtsMixedSizePlan(specs, width, height) {
  var EPS = 0.01,
    smallestArea = Infinity,
    largestArea = 0,
    largestSpec = null,
    fittingSources = 0;
  if (
    !(width > EPS && height > EPS) ||
    !isFinite(width) ||
    !isFinite(height) ||
    !specs ||
    !specs.length
  )
    throw new Error("Không có vùng in/mẫu hợp lệ.");
  for (var si = 0; si < specs.length; si++) {
    var s = specs[si];
    if (!(s.w > EPS && s.h > EPS) || !isFinite(s.w) || !isFinite(s.h))
      throw new Error("Không đo được kích thước mẫu " + (si + 1) + ".");
    if (
      (s.w <= width + EPS && s.h <= height + EPS) ||
      (s.h <= width + EPS && s.w <= height + EPS)
    )
      fittingSources++;
    smallestArea = Math.min(smallestArea, s.w * s.h);
    if (s.w * s.h > largestArea) {
      largestArea = s.w * s.h;
      largestSpec = s;
    }
  }
  if (!fittingSources)
    throw new Error("Mẫu không vừa vùng in; không tự thu nhỏ bài.");
  // Giờ nguồn nào cũng lặp lại được. Ưu tiên bậc kích thước từ lớn xuống nhỏ; chỉ chia đều
  // các mẫu trong cùng một bậc. Chấp nhận sai số li ti thường gặp của bounds Illustrator.
  var sizeOrder = [],
    priorityGroups = [],
    priorityIndex = [];
  var areaTolerance = 0.2 * (largestSpec.w + largestSpec.h) + 0.04;
  for (si = 0; si < specs.length; si++) sizeOrder.push(si);
  sizeOrder.sort(function (a, b) {
    var difference = specs[b].w * specs[b].h - specs[a].w * specs[a].h;
    if (Math.abs(difference) > EPS) return difference;
    return a - b;
  });
  for (var oi = 0; oi < sizeOrder.length; oi++) {
    si = sizeOrder[oi];
    var sourceArea = specs[si].w * specs[si].h;
    if (
      !priorityGroups.length ||
      priorityGroups[priorityGroups.length - 1] - sourceArea > areaTolerance
    )
      priorityGroups.push(sourceArea);
    priorityIndex[si] = priorityGroups.length - 1;
  }
  function tierCounts(counts) {
    var totals = [];
    for (var ti = 0; ti < priorityGroups.length; ti++) totals.push(0);
    for (var mi = 0; mi < counts.length; mi++)
      totals[priorityIndex[mi]] += counts[mi];
    return totals;
  }
  // Các lượt xếp thử không rasterize hay vẽ lại host. Việc kiểm chứng đường dao
  // dùng phép chẻ có giới hạn kèm ghi nhớ kết quả, tối đa 128 hình chữ nhật mỗi lần.
  // Giới hạn tường minh giúp đầu vào rất nhỏ không làm treo JSX.
  // Lặp lại các mẫu lớn cho tới khi không còn vừa nữa, rồi lấp bằng các mẫu
  // nhỏ hơn. Nguồn nhỏ hơn không chắc có slot khi lưới mẫu lớn đã kín.
  var theoreticalLimit = Math.ceil((width * height) / smallestArea);
  if (theoreticalLimit > 10000 || specs.length > 100)
    throw new Error(
      "Quá nhiều vị trí/mẫu để ghép; hãy chia thành nhóm nhỏ hơn.",
    );
  var limit = Math.min(theoreticalLimit, 128);
  var best = null,
    knifeCache = {};
  function knifeFor(cells) {
    var geometry = [];
    for (var i = 0; i < cells.length; i++) {
      var c = cells[i];
      geometry.push(
        [
          Math.round(c.x * 10000),
          Math.round(c.y * 10000),
          Math.round(c.w * 10000),
          Math.round(c.h * 10000),
        ].join(","),
      );
    }
    var key = "k" + geometry.join("|");
    if (knifeCache[key] === undefined)
      knifeCache[key] = dcKtsKnifePlan(cells, width, height);
    return knifeCache[key];
  }
  function less(a, b) {
    if (!b) return true;
    for (var i = 0; i < a.length; i++) {
      if (a[i] < b[i] - EPS) return true;
      if (a[i] > b[i] + EPS) return false;
    }
    return false;
  }
  function preferPlan(candidate, previous) {
    if (previous === null) return true;
    // Bậc lớn hơn thắng trước mọi bậc nhỏ hơn, không đánh đổi theo tổng số con.
    for (var ti = 0; ti < priorityGroups.length; ti++)
      if (candidate.priorityCounts[ti] !== previous.priorityCounts[ti])
        return candidate.priorityCounts[ti] > previous.priorityCounts[ti];
    // Khi ưu tiên đó đã ngang nhau, bên nhiều con lấp chỗ hơn sẽ thắng, tiếp đến là
    // ít lượt dao cắt chồng hơn, ít nhát cắt hơn và tổng chiều dài cắt ngắn hơn.
    if (candidate.count !== previous.count)
      return candidate.count > previous.count;
    if (candidate.workCount !== previous.workCount)
      return candidate.workCount < previous.workCount;
    if (candidate.cutCount !== previous.cutCount)
      return candidate.cutCount < previous.cutCount;
    if (Math.abs(candidate.cutLength - previous.cutLength) > EPS)
      return candidate.cutLength < previous.cutLength;
    return candidate.area > previous.area + EPS;
  }
  // Xếp lại nguyên cả vùng, không chỉ các hốc của bước tham lam. Phép DP
  // normal-pattern có giới hạn này tối đa hoá số con khổ lớn lặp lại và chứng minh
  // một cây chẻ. Trường hợp chưa hỗ trợ/quá hai khổ thì dùng bộ tìm tổng quát bên dưới.
  var profiles = dcKtsSlicingProfilePlan(specs, width, height, {
    allowPartialCoverage: true,
    repeatLargest: true,
  });
  if (profiles) {
    for (var pi = 0; pi < profiles.plans.length; pi++) {
      var profile = profiles.plans[pi];
      profile.priorityCounts = tierCounts(profile.counts);
      profile.largeCount = profile.priorityCounts[0];
      var profileKnife = knifeFor(profile.slots);
      if (profileKnife && profileKnife.workCount <= profile.workCount) {
        profile.cuts = profileKnife.cuts;
        profile.cutCount = profileKnife.cutCount;
        profile.cutLength = profileKnife.cutLength;
        profile.workCount = profileKnife.workCount;
      }
      if (preferPlan(profile, best)) best = profile;
    }
  }
  function splitFree(free, index, cell, splitRule, cuts) {
    var r = free[index],
      dw = r.w - cell.w,
      dh = r.h - cell.h;
    var x2 = cell.x + cell.w,
      y2 = cell.y + cell.h;
    free.splice(index, 1);
    function add(x, y, w, h) {
      if (w > EPS && h > EPS) free.push({ x: x, y: y, w: w, h: h });
    }
    function cut(axis, at, region) {
      cuts.push({
        axis: axis,
        at: at,
        x: region.x,
        y: region.y,
        w: region.w,
        h: region.h,
      });
    }
    // Có hai thứ tự cắt thẳng; thử cả hai quy tắc phần dư dài/ngắn,
    // cùng với dải hàng/cột cố định để các mép xén kề nhau thẳng hàng.
    // Rẽ nhánh tường minh: ExtendScript đời cũ có thể tính sai các toán tử
    // ba ngôi nối chuỗi có chứa phép so sánh (nhất là quy tắc số 0).
    var horizontal = false;
    if (splitRule === 0) horizontal = dw <= dh;
    else if (splitRule === 1) horizontal = dw > dh;
    else if (splitRule === 2) horizontal = true;
    if (horizontal) {
      if (dh > EPS) cut("H", y2, r);
      if (dw > EPS) cut("V", x2, { x: r.x, y: r.y, w: r.w, h: cell.h });
      add(x2, r.y, dw, cell.h);
      add(r.x, y2, r.w, dh);
    } else {
      if (dw > EPS) cut("V", x2, r);
      if (dh > EPS) cut("H", y2, { x: r.x, y: r.y, w: cell.w, h: r.h });
      add(r.x, y2, cell.w, dh);
      add(x2, r.y, dw, r.h);
    }
  }
  function splitMaxRects(free, cell) {
    var next = [],
      x2 = cell.x + cell.w,
      y2 = cell.y + cell.h;
    function add(x, y, w, h) {
      if (w > EPS && h > EPS) next.push({ x: x, y: y, w: w, h: h });
    }
    for (var i = 0; i < free.length; i++) {
      var r = free[i],
        rx2 = r.x + r.w,
        ry2 = r.y + r.h;
      if (
        cell.x >= rx2 - EPS ||
        x2 <= r.x + EPS ||
        cell.y >= ry2 - EPS ||
        y2 <= r.y + EPS
      ) {
        next.push(r);
        continue;
      }
      if (cell.x > r.x + EPS) add(r.x, r.y, cell.x - r.x, r.h);
      if (x2 < rx2 - EPS) add(x2, r.y, rx2 - x2, r.h);
      if (cell.y > r.y + EPS) add(r.x, r.y, r.w, cell.y - r.y);
      if (y2 < ry2 - EPS) add(r.x, y2, r.w, ry2 - y2);
    }
    for (i = next.length - 1; i >= 0; i--)
      for (var j = 0; j < next.length; j++) {
        if (i === j) continue;
        var a = next[i],
          b = next[j];
        if (
          a.x >= b.x - EPS &&
          a.y >= b.y - EPS &&
          a.x + a.w <= b.x + b.w + EPS &&
          a.y + a.h <= b.y + b.h + EPS
        ) {
          next.splice(i, 1);
          break;
        }
      }
    return next;
  }
  var operations = 0;
  for (var strategy = 0; strategy < 4; strategy++) {
    for (var splitRule = 0; splitRule < 5; splitRule++) {
      for (var seed = 0; seed < Math.min(specs.length, 4); seed++) {
        var free = [{ x: 0, y: 0, w: width, h: height }],
          slots = [],
          counts = [],
          area = 0;
        var cuts = [];
        for (si = 0; si < specs.length; si++) counts.push(0);
        while (slots.length < limit && operations < 400000) {
          var chosen = null,
            chosenScore = null;
          for (si = 0; si < specs.length; si++) {
            s = specs[si];
            for (var fi = 0; fi < free.length; fi++) {
              var r = free[fi];
              for (var rotation = 0; rotation < 2; rotation++) {
                if (++operations >= 400000) break;
                var w = rotation ? s.h : s.w,
                  h = rotation ? s.w : s.h;
                if (w > r.w + EPS || h > r.h + EPS) continue;
                var shortSide = Math.min(r.w - w, r.h - h),
                  longSide = Math.max(r.w - w, r.h - h);
                var waste = r.w * r.h - w * h,
                  order = (si - seed + specs.length) % specs.length;
                var score;
                if (strategy === 0)
                  score = [
                    shortSide,
                    longSide,
                    waste,
                    order,
                    r.y,
                    r.x,
                    rotation,
                  ];
                else if (strategy === 1)
                  score = [
                    waste,
                    shortSide,
                    longSide,
                    order,
                    r.y,
                    r.x,
                    rotation,
                  ];
                else if (strategy === 2)
                  score = [r.y, r.x, -w * h, order, rotation];
                else
                  score = [
                    -w * h,
                    shortSide,
                    longSide,
                    order,
                    r.y,
                    r.x,
                    rotation,
                  ];
                // Dùng hết bậc lớn nhất còn vừa trước, lặp đều các mẫu của bậc
                // đó. Chỉ sau đó bậc nhỏ hơn mới được chiếm phần chỗ còn dư.
                score = [priorityIndex[si], counts[si]].concat(score);
                if (less(score, chosenScore)) {
                  chosenScore = score;
                  chosen = {
                    x: r.x,
                    y: r.y,
                    w: w,
                    h: h,
                    angle: rotation ? 90 : 0,
                    modelIndex: si,
                  };
                  var chosenFreeIndex = fi;
                }
              }
            }
          }
          if (!chosen) break;
          slots.push(chosen);
          counts[chosen.modelIndex]++;
          area += chosen.w * chosen.h;
          if (splitRule === 4) free = splitMaxRects(free, chosen);
          else splitFree(free, chosenFreeIndex, chosen, splitRule, cuts);
        }
        var minCount = counts[0],
          priorities = tierCounts(counts);
        for (si = 1; si < counts.length; si++)
          minCount = Math.min(minCount, counts[si]);
        if (!slots.length) continue;
        var knife = knifeFor(slots);
        if (knife) cuts = knife.cuts;
        else if (splitRule === 4) continue; // Xếp dày mà chưa chứng minh được đường dao thì không hợp lệ.
        var workCount = knife ? knife.workCount : cuts.length;
        var bandVariants = dcKtsKnifeBandVariants(slots);
        for (var vi = 0; vi < bandVariants.length; vi++) {
          var bandKnife = knifeFor(bandVariants[vi]);
          if (
            bandKnife &&
            (bandKnife.workCount < workCount ||
              (bandKnife.workCount === workCount &&
                bandKnife.cutCount < cuts.length))
          ) {
            slots = bandVariants[vi];
            cuts = bandKnife.cuts;
            workCount = bandKnife.workCount;
          }
        }
        var cutLength = 0;
        for (var ci = 0; ci < cuts.length; ci++)
          cutLength += cuts[ci].axis === "H" ? cuts[ci].w : cuts[ci].h;
        var trial = {
          slots: slots,
          counts: counts,
          count: slots.length,
          minimum: minCount,
          area: area,
          largeCount: priorities[0],
          priorityCounts: priorities,
          balancedCounts: counts.slice(0),
          cuts: cuts,
          cutCount: cuts.length,
          cutLength: cutLength,
          workCount: workCount,
        };
        if (preferPlan(trial, best)) best = trial;
      }
    }
  }
  if (!best)
    throw new Error(
      "Không ghép được mẫu trên một tờ; hãy tăng khổ giấy hoặc bớt mẫu.",
    );
  // Cách chia guillotine cố định có thể để lại các mảnh trống kề nhau mà nếu
  // đổi thứ tự cắt thì dùng chung được. Kiểm tra phần hình học thực tế
  // còn lại, nhưng chỉ nhận thêm con mới khi đã chứng minh được đường dao.
  var holeChecks = 0;
  while (best.count < Math.min(limit, 128) && holeChecks < 128) {
    var actualFree = [{ x: 0, y: 0, w: width, h: height }];
    for (var bi = 0; bi < best.slots.length; bi++)
      actualFree = splitMaxRects(actualFree, best.slots[bi]);
    var extra = null,
      extraKnife = null,
      extraScore = null;
    for (si = 0; si < specs.length; si++)
      for (var ri = 0; ri < 2; ri++) {
        var ew = ri ? specs[si].h : specs[si].w,
          eh = ri ? specs[si].w : specs[si].h;
        if (
          extraScore &&
          (priorityIndex[si] > extraScore[0] ||
            (priorityIndex[si] === extraScore[0] &&
              best.counts[si] > extraScore[1]))
        )
          continue;
        for (var afi = 0; afi < actualFree.length && holeChecks < 128; afi++) {
          var ar = actualFree[afi];
          if (ew > ar.w + EPS || eh > ar.h + EPS) continue;
          var candidate = {
            x: ar.x,
            y: ar.y,
            w: ew,
            h: eh,
            angle: ri ? 90 : 0,
            modelIndex: si,
          };
          holeChecks++;
          var candidateKnife = knifeFor(best.slots.concat([candidate]));
          if (!candidateKnife) continue;
          var extraCandidateScore = [
            priorityIndex[si],
            best.counts[si],
            candidateKnife.workCount,
            candidateKnife.cutCount,
            candidateKnife.cutLength,
            ar.y,
            ar.x,
            ri,
          ];
          if (less(extraCandidateScore, extraScore)) {
            extra = candidate;
            extraKnife = candidateKnife;
            extraScore = extraCandidateScore;
          }
        }
      }
    if (!extra) break;
    best.slots.push(extra);
    best.counts[extra.modelIndex]++;
    best.count++;
    best.priorityCounts[priorityIndex[extra.modelIndex]]++;
    best.largeCount = best.priorityCounts[0];
    best.area += extra.w * extra.h;
    best.cuts = extraKnife.cuts;
    best.cutCount = extraKnife.cutCount;
    best.cutLength = extraKnife.cutLength;
    best.workCount = extraKnife.workCount;
    best.minimum = best.counts[0];
    for (si = 1; si < best.counts.length; si++)
      best.minimum = Math.min(best.minimum, best.counts[si]);
  }
  var finalBands = dcKtsKnifeBandVariants(best.slots);
  for (var fbi = 0; fbi < finalBands.length; fbi++) {
    var finalKnife = knifeFor(finalBands[fbi]);
    if (
      finalKnife &&
      (finalKnife.workCount < best.workCount ||
        (finalKnife.workCount === best.workCount &&
          finalKnife.cutCount < best.cutCount))
    ) {
      best.slots = finalBands[fbi];
      best.cuts = finalKnife.cuts;
      best.workCount = finalKnife.workCount;
      best.cutCount = finalKnife.cutCount;
      best.cutLength = finalKnife.cutLength;
    }
  }
  best.capacityLimited = best.count >= limit && theoreticalLimit > limit;
  best.unplacedModelIndices = [];
  for (si = 0; si < best.counts.length; si++)
    if (best.counts[si] === 0) best.unplacedModelIndices.push(si);
  return best;
}

function dcDanToiUu(
  pageWidthText,
  pageHeightText,
  twoSidedArg,
  multiPerArtboardArg,
) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";

    var doc = app.activeDocument;
    var oldCanvasArtboardCount = doc.artboards.length;
    var selection = doc.selection;
    if (!selection || selection.length === 0)
      return "ERR: Chọn ít nhất một artwork trước khi dàn.";

    var MM = 2.834645669;
    var MARGIN = 3 * MM;
    var EPS = 0.01;
    var twoSided = twoSidedArg === true;
    // Mac dinh: moi mau la mot to rieng. Chi khi tick tren panel moi gop
    // nhieu mau vao chung mot to va chia lan luot cac vi tri.
    var multiPerArtboard = multiPerArtboardArg === true;

    function parseCentimeters(value, label) {
      var n = parseFloat(
        String(value === undefined || value === null ? "" : value).replace(
          ",",
          ".",
        ),
      );
      if (!isFinite(n) || n <= 0)
        throw new Error(label + " phải là số cm lớn hơn 0.");
      return n * 10 * MM;
    }

    // Khung thành phẩm: theo bảng Transform khi cờ bật, không thì visibleBounds như cũ.
    function boundsOf(item) {
      return dcDoKhung(item, function (it) {
        try {
          return it.visibleBounds.slice(0);
        } catch (e) {}
        try {
          return it.geometricBounds.slice(0);
        } catch (e2) {}
        return null;
      });
    }

    function itemRecord(item) {
      var bounds = boundsOf(item);
      if (
        !bounds ||
        bounds[2] - bounds[0] <= EPS ||
        bounds[1] - bounds[3] <= EPS
      )
        return null;
      return {
        item: item,
        bounds: bounds,
        cx: (bounds[0] + bounds[2]) / 2,
        cy: (bounds[1] + bounds[3]) / 2,
      };
    }

    var raw = [];
    var sourceBounds = null;
    for (var si = 0; si < selection.length; si++) {
      var record = itemRecord(selection[si]);
      if (!record) continue;
      raw.push(record);
      if (!sourceBounds) sourceBounds = record.bounds.slice(0);
      else {
        sourceBounds[0] = Math.min(sourceBounds[0], record.bounds[0]);
        sourceBounds[1] = Math.max(sourceBounds[1], record.bounds[1]);
        sourceBounds[2] = Math.max(sourceBounds[2], record.bounds[2]);
        sourceBounds[3] = Math.min(sourceBounds[3], record.bounds[3]);
      }
    }
    if (raw.length === 0 || !sourceBounds)
      return "ERR: Selection hiện tại không có artwork hợp lệ để dàn.";

    if (twoSided && (raw.length < 2 || raw.length % 2 !== 0))
      return "ERR: Dàn 2 mặt cần chọn số object chẵn: từng cặp trái = trước, phải = sau.";

    var models = [];
    var mi;
    if (twoSided) {
      var lockedPairs = dcKtsPairSourceRecords(raw, EPS);
      for (mi = 0; mi < lockedPairs.length; mi++)
        models.push({
          front: lockedPairs[mi].front.item,
          back: lockedPairs[mi].back.item,
        });
    } else {
      raw.sort(function (a, b) {
        if (Math.abs(a.cy - b.cy) > EPS) return b.cy - a.cy;
        return a.cx - b.cx;
      });
      for (mi = 0; mi < raw.length; mi++)
        models.push({ front: raw[mi].item, back: null });
    }

    var referenceBounds = boundsOf(models[0].front);
    if (!referenceBounds) return "ERR: Không đo được kích thước bài mẫu.";
    var sourceW = referenceBounds[2] - referenceBounds[0];
    var sourceH = referenceBounds[1] - referenceBounds[3];

    var modelSpecs = [],
      mixedSizes = false;
    function measuredSize(item, sideLabel) {
      var b = boundsOf(item);
      if (!b) throw new Error("Không đo được " + sideLabel + " của mẫu.");
      return { w: b[2] - b[0], h: b[1] - b[3] };
    }
    for (mi = 0; mi < models.length; mi++) {
      var spec = measuredSize(models[mi].front, "mặt trước");
      if (twoSided) {
        var backSpec = measuredSize(models[mi].back, "mặt sau");
        var khoTol = DC_DUNG_SAI_KHO_MM * MM;
        if (
          Math.abs(spec.w - backSpec.w) > khoTol ||
          Math.abs(spec.h - backSpec.h) > khoTol
        )
          throw new Error(
            "Hai mặt của mẫu " +
              (mi + 1) +
              " phải cùng kích thước: trước " +
              dcMmText(spec.w) +
              "×" +
              dcMmText(spec.h) +
              " mm, sau " +
              dcMmText(backSpec.w) +
              "×" +
              dcMmText(backSpec.h) +
              " mm (lệch quá " +
              dcMmText(DC_DUNG_SAI_KHO_MM * MM) +
              " mm).",
          );
        spec.w = Math.max(spec.w, backSpec.w);
        spec.h = Math.max(spec.h, backSpec.h);
      }
      modelSpecs.push(spec);
      if (Math.abs(spec.w - sourceW) > 0.2 || Math.abs(spec.h - sourceH) > 0.2)
        mixedSizes = true;
    }
    if (mixedSizes && !multiPerArtboard)
      throw new Error(
        "Tick Dàn nhiều mẫu vào một tờ để ghép các kích thước khác nhau.",
      );

    var paperW = parseCentimeters(pageWidthText, "Ngang giấy");
    var paperH = parseCentimeters(pageHeightText, "Dọc giấy");
    var usableW = paperW - 2 * MARGIN;
    var usableH = paperH - 2 * MARGIN;
    if (usableW <= EPS || usableH <= EPS)
      return "ERR: Khổ giấy phải lớn hơn lề an toàn 3 mm mỗi cạnh.";

    function floorFit(space, size) {
      if (size <= EPS) return 0;
      return Math.floor((space + EPS) / size);
    }

    function makeStripPlan(
      direction,
      normalBands,
      rotatedBands,
      regionW,
      regionH,
    ) {
      var normalCells =
        direction === "row"
          ? floorFit(regionW, sourceW)
          : floorFit(regionH, sourceH);
      var rotatedCells =
        direction === "row"
          ? floorFit(regionW, sourceH)
          : floorFit(regionH, sourceW);
      if (
        (normalBands > 0 && normalCells <= 0) ||
        (rotatedBands > 0 && rotatedCells <= 0)
      )
        return null;
      var count = normalBands * normalCells + rotatedBands * rotatedCells;
      if (count <= 0) return null;
      var plan = {
        kind: "strips",
        direction: direction,
        count: count,
        normalCount: normalBands * normalCells,
        rotatedCount: rotatedBands * rotatedCells,
        bands: [],
      };
      if (normalBands > 0)
        plan.bands.push({
          angle: 0,
          repeat: normalBands,
          cells: normalCells,
          cellW: sourceW,
          cellH: sourceH,
        });
      if (rotatedBands > 0)
        plan.bands.push({
          angle: 90,
          repeat: rotatedBands,
          cells: rotatedCells,
          cellW: sourceH,
          cellH: sourceW,
        });
      return plan;
    }

    function planComplexity(plan) {
      if (!plan) return 999999;
      if (plan.kind === "empty") return 0;
      if (plan.kind === "strips") return plan.bands.length;
      return 1 + planComplexity(plan.first) + planComplexity(plan.second);
    }

    function isBetter(candidate, best) {
      if (!candidate) return false;
      if (!best) return true;
      if (candidate.count !== best.count) return candidate.count > best.count;
      if (candidate.normalCount !== best.normalCount)
        return candidate.normalCount > best.normalCount;
      return planComplexity(candidate) < planComplexity(best);
    }

    function bestStripPlan(regionW, regionH) {
      var best = null;
      var normalRowMax = floorFit(regionH, sourceH);
      var normalRows, rowRemain, rotatedRows, rowPlan;
      for (normalRows = 0; normalRows <= normalRowMax; normalRows++) {
        rowRemain = regionH - normalRows * sourceH;
        rotatedRows = floorFit(rowRemain, sourceW);
        rowPlan = makeStripPlan(
          "row",
          normalRows,
          rotatedRows,
          regionW,
          regionH,
        );
        if (isBetter(rowPlan, best)) best = rowPlan;
      }

      var normalColumnMax = floorFit(regionW, sourceW);
      var normalColumns, columnRemain, rotatedColumns, columnPlan;
      for (
        normalColumns = 0;
        normalColumns <= normalColumnMax;
        normalColumns++
      ) {
        columnRemain = regionW - normalColumns * sourceW;
        rotatedColumns = floorFit(columnRemain, sourceH);
        columnPlan = makeStripPlan(
          "column",
          normalColumns,
          rotatedColumns,
          regionW,
          regionH,
        );
        if (isBetter(columnPlan, best)) best = columnPlan;
      }
      return best;
    }

    function addCutValue(values, seen, value, total) {
      if (value <= EPS || total - value <= EPS) return;
      var key = Math.round(value * 1000);
      if (seen[key]) return;
      seen[key] = true;
      values.push(value);
    }

    function cutValues(total) {
      var values = [],
        seen = {},
        i;
      for (i = 1; i <= floorFit(total, sourceW); i++) {
        addCutValue(values, seen, i * sourceW, total);
        addCutValue(values, seen, total - i * sourceW, total);
      }
      for (i = 1; i <= floorFit(total, sourceH); i++) {
        addCutValue(values, seen, i * sourceH, total);
        addCutValue(values, seen, total - i * sourceH, total);
      }
      return values;
    }

    var planMemo = {};
    function solveRegion(regionW, regionH, depth) {
      var memoKey =
        Math.round(regionW * 1000) +
        "x" +
        Math.round(regionH * 1000) +
        "x" +
        depth;
      if (planMemo[memoKey]) return planMemo[memoKey];

      var best = bestStripPlan(regionW, regionH);
      if (!best || depth <= 0) {
        if (!best)
          best = { kind: "empty", count: 0, normalCount: 0, rotatedCount: 0 };
        planMemo[memoKey] = best;
        return best;
      }

      var cuts = cutValues(regionW);
      var vi, leftPlan, rightPlan, verticalPlan;
      for (vi = 0; vi < cuts.length; vi++) {
        leftPlan = solveRegion(cuts[vi], regionH, depth - 1);
        rightPlan = solveRegion(regionW - cuts[vi], regionH, depth - 1);
        verticalPlan = {
          kind: "splitV",
          cut: cuts[vi],
          first: leftPlan,
          second: rightPlan,
          count: leftPlan.count + rightPlan.count,
          normalCount: leftPlan.normalCount + rightPlan.normalCount,
          rotatedCount: leftPlan.rotatedCount + rightPlan.rotatedCount,
        };
        if (isBetter(verticalPlan, best)) best = verticalPlan;
      }

      cuts = cutValues(regionH);
      var hi, topPlan, bottomPlan, horizontalPlan;
      for (hi = 0; hi < cuts.length; hi++) {
        topPlan = solveRegion(regionW, cuts[hi], depth - 1);
        bottomPlan = solveRegion(regionW, regionH - cuts[hi], depth - 1);
        horizontalPlan = {
          kind: "splitH",
          cut: cuts[hi],
          first: topPlan,
          second: bottomPlan,
          count: topPlan.count + bottomPlan.count,
          normalCount: topPlan.normalCount + bottomPlan.normalCount,
          rotatedCount: topPlan.rotatedCount + bottomPlan.rotatedCount,
        };
        if (isBetter(horizontalPlan, best)) best = horizontalPlan;
      }
      planMemo[memoKey] = best;
      return best;
    }

    var mixedPlan = mixedSizes
      ? dcKtsMixedSizePlan(modelSpecs, usableW, usableH)
      : null;
    var bestPlan = mixedPlan || solveRegion(usableW, usableH, 2);
    if (!bestPlan || bestPlan.count <= 0)
      return "ERR: Bài mẫu không nằm vừa trong vùng in sau khi trừ lề 3 mm.";

    function askContinueUneven(modelCount, slotCount, sheetCount) {
      var dialog = new Window("dialog", "Dàn nhiều loại");
      dialog.orientation = "column";
      dialog.alignChildren = "fill";
      dialog.margins = 18;
      dialog.spacing = 12;
      var message = dialog.add(
        "statictext",
        undefined,
        slotCount +
          " vị trí trên " +
          sheetCount +
          " tờ không chia đều cho " +
          modelCount +
          " mẫu. Nếu tiếp tục, tool sẽ giữ các con cùng mẫu gần nhau; một vài mẫu sẽ được lặp thêm 1 con.",
        { multiline: true },
      );
      message.preferredSize.width = 340;
      var actions = dialog.add("group");
      actions.alignment = "right";
      var stopped = actions.add("button", undefined, "Dừng lại");
      var continued = actions.add("button", undefined, "Tiếp tục");
      var accepted = false;
      stopped.onClick = function () {
        accepted = false;
        dialog.close();
      };
      continued.onClick = function () {
        accepted = true;
        dialog.close();
      };
      dialog.show();
      return accepted;
    }

    var multiSheetCount = 1;
    var multiTotalSlots = bestPlan.count;
    var multiExtraSlots = 0;
    if (multiPerArtboard && !mixedSizes) {
      // Mot to co the khong chua het cac mau. Tao du so to de moi mau xuat
      // hien it nhat mot lan, sau do moi lap cac mau dau cho cac slot con du.
      multiSheetCount = Math.ceil(models.length / bestPlan.count);
      multiTotalSlots = multiSheetCount * bestPlan.count;
      multiExtraSlots = multiTotalSlots % models.length;
      if (models.length > 1 && multiExtraSlots !== 0) {
        if (!askContinueUneven(models.length, multiTotalSlots, multiSheetCount))
          return "ERR: Đã dừng dàn vì số mẫu không chia đều cho số vị trí trên các tờ.";
      }
    }

    // Mac dinh giu moi mau tren mot to rieng. Khi tick gop mau, xep cac ban
    // sao cung mau lien nhau trong cac slot de cat va phan loai de hon.
    var outputBatches = [];
    if (mixedSizes) {
      outputBatches.push(models);
    } else if (multiPerArtboard) {
      var groupedModels = [];
      var copiesPerModel = Math.floor(multiTotalSlots / models.length);
      var remainderCopies = multiTotalSlots % models.length;
      for (mi = 0; mi < models.length; mi++) {
        var copiesForThisModel =
          copiesPerModel + (mi < remainderCopies ? 1 : 0);
        for (var copyIndex = 0; copyIndex < copiesForThisModel; copyIndex++)
          groupedModels.push(models[mi]);
      }
      for (
        var multiSheetIndex = 0;
        multiSheetIndex < multiSheetCount;
        multiSheetIndex++
      ) {
        var batch = [];
        for (var batchSlot = 0; batchSlot < bestPlan.count; batchSlot++)
          batch.push(
            groupedModels[multiSheetIndex * bestPlan.count + batchSlot],
          );
        outputBatches.push(batch);
      }
    } else if (models.length === 1) {
      outputBatches.push(models);
    } else {
      for (mi = 0; mi < models.length; mi++) outputBatches.push([models[mi]]);
    }

    function uniqueLayerName(base) {
      var candidate = base;
      var suffix = 2;
      var found = true;
      while (found) {
        found = false;
        for (var li = 0; li < doc.layers.length; li++) {
          try {
            if (doc.layers[li].name === candidate) {
              found = true;
              candidate = base + " " + suffix;
              suffix++;
              break;
            }
          } catch (e) {}
        }
      }
      return candidate;
    }

    function addOutputLayer(name) {
      var layer = doc.layers.add();
      layer.name = uniqueLayerName(name);
      try {
        layer.locked = false;
        layer.visible = true;
      } catch (e) {}
      return layer;
    }

    // PON giấy luôn đi theo chính artboard vừa sinh, không phụ thuộc khổ nhập
    // hay vị trí artwork. Giữ tách layer để không lẫn với bài và PON cắt.
    function addPaperPonAtCorners(layer, rect) {
      var markLength = 3 * MM;
      var strokeWidth = 1.995;
      var black = new CMYKColor();
      black.cyan = 0;
      black.magenta = 0;
      black.yellow = 0;
      black.black = 100;
      function draw(x1, y1, x2, y2) {
        var mark = layer.pathItems.add();
        mark.setEntirePath([
          [x1, y1],
          [x2, y2],
        ]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = strokeWidth;
      }
      // Kích thước artboard là tâm của bốn PON giấy.  Không dịch cả cụm
      // vào trong theo nửa stroke, nếu không khổ artboard sẽ sai so với PON.
      var left = rect[0];
      var top = rect[1];
      var right = rect[2];
      var bottom = rect[3];
      draw(left, top, left + markLength, top);
      draw(left, top, left, top - markLength);
      draw(right - markLength, top, right, top);
      draw(right, top, right, top - markLength);
      draw(left, bottom, left + markLength, bottom);
      draw(left, bottom, left, bottom + markLength);
      draw(right - markLength, bottom, right, bottom);
      draw(right, bottom, right, bottom + markLength);
    }

    function prepareOutputLayer(layer) {
      if (!layer) return;
      // Khong phu thuoc layer dang active cua file nguon (co the dang khoa/
      // template), vi duplicate vao layer do se gay Error 8705.
      try {
        layer.locked = false;
        layer.visible = true;
        doc.activeLayer = layer;
      } catch (e) {}
    }

    var pageGap = 10 * MM;
    var frontLayer = addOutputLayer(
      twoSided ? "Dan toi uu - Mat truoc" : "Dan toi uu",
    );
    var backLayer = twoSided ? addOutputLayer("Dan toi uu - Mat sau") : null;

    function rectsOverlap(a, b) {
      return (
        a[0] < b[2] - EPS &&
        a[2] > b[0] + EPS &&
        a[3] < b[1] - EPS &&
        a[1] > b[3] + EPS
      );
    }

    function rectContains(outer, inner) {
      return (
        outer[0] <= inner[0] + EPS &&
        outer[1] >= inner[1] - EPS &&
        outer[2] >= inner[2] - EPS &&
        outer[3] <= inner[3] + EPS
      );
    }

    function readCanvasBounds() {
      // Khong doc toan bo file AI tai day: file nang co the lam Illustrator treo.
      // Canvas thuong la 14400 pt; Large Canvas co scaleFactor nho hon 1.
      var halfSize = 7200;
      try {
        if (doc.scaleFactor && doc.scaleFactor < 1)
          halfSize = halfSize / doc.scaleFactor;
      } catch (e) {}
      return [-halfSize, halfSize, halfSize, -halfSize];
    }

    // Giữ các artboard sẵn có làm vùng bận. Các tờ mới tìm ô trống theo thứ tự
    // từ trái sang phải, hết bề ngang canvas thì tự xuống hàng tiếp theo.
    var canvasRect = readCanvasBounds();
    var canvasWidth = canvasRect[2] - canvasRect[0];
    var canvasHeight = canvasRect[1] - canvasRect[3];
    var occupiedRects = [];
    for (var ai = 0; ai < doc.artboards.length; ai++) {
      try {
        var existingRect = doc.artboards[ai].artboardRect.slice(0);
        var existingWidth = existingRect[2] - existingRect[0];
        var existingHeight = existingRect[1] - existingRect[3];
        // Artboard lon phu gan het canvas la nen lam viec, khong phai mot to
        // can tranh. Bo qua no de cac to moi co the xep vao ben trong.
        if (
          existingWidth >= canvasWidth * 0.92 &&
          existingHeight >= canvasHeight * 0.92
        )
          continue;
        occupiedRects.push(existingRect);
      } catch (e) {}
    }
    // Bài cũ còn trên canvas (khung đã xoá ở lượt trước) cũng là vùng bận.
    var sourceItemsKts = [];
    for (var sk = 0; sk < raw.length; sk++) sourceItemsKts.push(raw[sk].item);
    occupiedRects = occupiedRects.concat(
      dcVungBaiCu(doc, canvasRect, sourceItemsKts),
    );
    var sourceAlreadyCovered = false;
    for (var oi = 0; oi < occupiedRects.length; oi++) {
      if (rectContains(occupiedRects[oi], sourceBounds)) {
        sourceAlreadyCovered = true;
        break;
      }
    }
    if (!sourceAlreadyCovered) occupiedRects.push(sourceBounds.slice(0));

    var layoutLeft = canvasRect[0] + pageGap;
    var layoutTop = canvasRect[1] - pageGap;
    var layoutRight = canvasRect[2] - pageGap;
    var layoutBottom = canvasRect[3] + pageGap;
    var layoutCursorLeft = layoutLeft;
    var layoutCursorTop = layoutTop;

    function reserveOutputPosition() {
      var bundleW = twoSided ? paperW * 2 + pageGap : paperW;
      var bundleH = paperH;
      var candidateLeft = layoutCursorLeft;
      var candidateTop = layoutCursorTop;
      var attempts = 0;
      while (attempts++ < 5000) {
        if (candidateLeft + bundleW > layoutRight + EPS) {
          candidateLeft = layoutLeft;
          candidateTop -= bundleH + pageGap;
          continue;
        }
        if (candidateTop - bundleH < layoutBottom - EPS)
          throw new Error(
            "Không còn chỗ trong canvas để tạo tờ mới. Hãy xóa/bớt artboard cũ hoặc bài cũ còn trên canvas, hoặc mở tài liệu Large Canvas.",
          );

        var bundleRect = [
          candidateLeft,
          candidateTop,
          candidateLeft + bundleW,
          candidateTop - bundleH,
        ];
        var blocker = null;
        for (var ri = 0; ri < occupiedRects.length; ri++) {
          if (rectsOverlap(bundleRect, occupiedRects[ri])) {
            blocker = occupiedRects[ri];
            break;
          }
        }
        if (blocker) {
          candidateLeft = blocker[2] + pageGap;
          continue;
        }

        occupiedRects.push(bundleRect);
        layoutCursorLeft = candidateLeft + bundleW + pageGap;
        layoutCursorTop = candidateTop;
        var frontRect = [
          candidateLeft,
          candidateTop,
          candidateLeft + paperW,
          candidateTop - paperH,
        ];
        var backRect = null;
        if (twoSided)
          backRect = [
            frontRect[2] + pageGap,
            candidateTop,
            frontRect[2] + pageGap + paperW,
            candidateTop - paperH,
          ];
        return { frontRect: frontRect, backRect: backRect };
      }
      throw new Error(
        "Không tìm được vị trí trong canvas để đặt artboard mới.",
      );
    }

    function addOutputArtboard(rect, name) {
      var index = doc.artboards.length;
      try {
        var board = doc.artboards.add(rect);
        try {
          board.name = name + " " + (index + 1);
        } catch (e) {}
        return index;
      } catch (e) {
        throw new Error(
          "Không tạo được artboard trong vị trí đã tính. Hãy thử đóng và mở lại tài liệu, sau đó chạy lại.",
        );
      }
    }

    function collectSlots(plan, left, top, regionW, regionH, output) {
      if (!plan || plan.count <= 0) return;
      if (plan.kind === "splitV") {
        collectSlots(plan.first, left, top, plan.cut, regionH, output);
        collectSlots(
          plan.second,
          left + plan.cut,
          top,
          regionW - plan.cut,
          regionH,
          output,
        );
        return;
      }
      if (plan.kind === "splitH") {
        collectSlots(plan.first, left, top, regionW, plan.cut, output);
        collectSlots(
          plan.second,
          left,
          top - plan.cut,
          regionW,
          regionH - plan.cut,
          output,
        );
        return;
      }
      if (plan.kind !== "strips") return;

      var x, y, band, repeat, cell;
      if (plan.direction === "row") {
        y = top;
        for (var rb = 0; rb < plan.bands.length; rb++) {
          band = plan.bands[rb];
          for (repeat = 0; repeat < band.repeat; repeat++) {
            x = left;
            for (cell = 0; cell < band.cells; cell++) {
              output.push({
                x: x,
                y: y,
                angle: band.angle,
                w: band.cellW,
                h: band.cellH,
              });
              x += band.cellW;
            }
            y -= band.cellH;
          }
        }
      } else {
        x = left;
        for (var cb = 0; cb < plan.bands.length; cb++) {
          band = plan.bands[cb];
          for (repeat = 0; repeat < band.repeat; repeat++) {
            y = top;
            for (cell = 0; cell < band.cells; cell++) {
              output.push({
                x: x,
                y: y,
                angle: band.angle,
                w: band.cellW,
                h: band.cellH,
              });
              y -= band.cellH;
            }
            x += band.cellW;
          }
        }
      }
    }

    function slotEdgeDistance(a, b) {
      var aRight = a.x + a.w;
      var aBottom = a.y - a.h;
      var bRight = b.x + b.w;
      var bBottom = b.y - b.h;
      var dx = 0;
      var dy = 0;
      if (aRight < b.x) dx = b.x - aRight;
      else if (bRight < a.x) dx = a.x - bRight;
      if (aBottom > b.y) dy = aBottom - b.y;
      else if (bBottom > a.y) dy = bBottom - a.y;
      return dx * dx + dy * dy;
    }

    function isBeforeOnSheet(a, b) {
      if (Math.abs(a.y - b.y) > EPS) return a.y > b.y;
      return a.x < b.x;
    }

    // Batch gop mau co the chua nhieu ban sao cua mot mau. Gan tung cum mau
    // vao cac slot ke nhau, va giu cung chieu truoc (dung/nam) de sau khi
    // cat de phan loai hon. Chi khi het slot cung chieu moi qua cum xoay 90 do.
    function orderSlotsForBatch(sourceSlots, batch) {
      if (!multiPerArtboard || batch.length !== sourceSlots.length)
        return sourceSlots;
      var remaining = sourceSlots.slice(0);
      var ordered = [];
      var batchIndex = 0;
      while (batchIndex < batch.length && remaining.length > 0) {
        var model = batch[batchIndex];
        var runLength = 1;
        while (
          batchIndex + runLength < batch.length &&
          batch[batchIndex + runLength] === model
        )
          runLength++;

        var cluster = [];
        var preferredAngle = null;
        for (var clusterIndex = 0; clusterIndex < runLength; clusterIndex++) {
          var picked = -1;
          if (cluster.length === 0) {
            for (
              var firstIndex = 0;
              firstIndex < remaining.length;
              firstIndex++
            ) {
              if (
                picked < 0 ||
                isBeforeOnSheet(remaining[firstIndex], remaining[picked])
              )
                picked = firstIndex;
            }
            if (picked >= 0) preferredAngle = remaining[picked].angle;
          } else {
            var bestDistance = -1;
            var hasPreferredAngle = false;
            for (
              var preferredIndex = 0;
              preferredIndex < remaining.length;
              preferredIndex++
            ) {
              if (remaining[preferredIndex].angle === preferredAngle) {
                hasPreferredAngle = true;
                break;
              }
            }
            for (
              var candidateIndex = 0;
              candidateIndex < remaining.length;
              candidateIndex++
            ) {
              // Con cung mau da dat dung (hoac nam) thi uu tien no nam trong
              // cum cung chieu. Khi khong con slot do moi chuyen qua chieu kia.
              if (
                hasPreferredAngle &&
                remaining[candidateIndex].angle !== preferredAngle
              )
                continue;
              var nearestDistance = -1;
              for (
                var neighborIndex = 0;
                neighborIndex < cluster.length;
                neighborIndex++
              ) {
                var distance = slotEdgeDistance(
                  remaining[candidateIndex],
                  cluster[neighborIndex],
                );
                if (nearestDistance < 0 || distance < nearestDistance)
                  nearestDistance = distance;
              }
              if (
                picked < 0 ||
                nearestDistance < bestDistance - EPS ||
                (Math.abs(nearestDistance - bestDistance) <= EPS &&
                  isBeforeOnSheet(remaining[candidateIndex], remaining[picked]))
              ) {
                picked = candidateIndex;
                bestDistance = nearestDistance;
              }
            }
          }
          cluster.push(remaining[picked]);
          remaining.splice(picked, 1);
        }
        for (var appendIndex = 0; appendIndex < cluster.length; appendIndex++)
          ordered.push(cluster[appendIndex]);
        batchIndex += runLength;
      }
      return ordered;
    }

    function copyAt(source, layer, left, top, angle, slotWidth, slotHeight) {
      var copy = source.duplicate(layer, ElementPlacement.PLACEATEND);
      if (angle !== 0) copy.rotate(angle);
      var bounds = boundsOf(copy);
      if (!bounds) throw new Error("Không đo được bản sao để đặt vào tờ giấy.");
      if (slotWidth !== undefined) {
        left += (slotWidth - (bounds[2] - bounds[0])) / 2;
        top -= (slotHeight - (bounds[1] - bounds[3])) / 2;
      }
      copy.translate(left - bounds[0], top - bounds[1]);
      return copy;
    }

    function allBounds(items) {
      var merged = null;
      for (var bi = 0; bi < items.length; bi++) {
        var b = boundsOf(items[bi]);
        if (!b) continue;
        if (!merged) merged = b.slice(0);
        else {
          merged[0] = Math.min(merged[0], b[0]);
          merged[1] = Math.max(merged[1], b[1]);
          merged[2] = Math.max(merged[2], b[2]);
          merged[3] = Math.min(merged[3], b[3]);
        }
      }
      return merged;
    }

    function centerItems(items, artboardRect) {
      var bounds = allBounds(items);
      if (!bounds) return;
      var targetX = (artboardRect[0] + artboardRect[2]) / 2;
      var targetY = (artboardRect[1] + artboardRect[3]) / 2;
      var currentX = (bounds[0] + bounds[2]) / 2;
      var currentY = (bounds[1] + bounds[3]) / 2;
      var dx = targetX - currentX;
      var dy = targetY - currentY;
      for (var ci = 0; ci < items.length; ci++) items[ci].translate(dx, dy);
    }

    var firstFrontIndex = -1;
    for (var batchIndex = 0; batchIndex < outputBatches.length; batchIndex++) {
      var batch = outputBatches[batchIndex];
      var outputPosition = reserveOutputPosition();
      var frontRect = outputPosition.frontRect;
      var frontIndex = addOutputArtboard(
        frontRect,
        twoSided ? "Dan toi uu - Mat truoc" : "Dan toi uu",
      );
      if (firstFrontIndex < 0) firstFrontIndex = frontIndex;

      var backRect = outputPosition.backRect;
      if (twoSided) addOutputArtboard(backRect, "Dan toi uu - Mat sau");

      var frontSafeLeft = frontRect[0] + MARGIN;
      var frontSafeTop = frontRect[1] - MARGIN;
      var slots = [];
      if (mixedSizes) {
        // Canh giữa hình học slot dùng chung đúng một lần, không canh riêng
        // bounds bài của từng mặt. Chênh lệch nhỏ khi đo mặt trước/mặt sau
        // không được làm lệch độ khớp hai mặt.
        var mixedRight = 0,
          mixedBottom = 0;
        for (
          var boundSlot = 0;
          boundSlot < mixedPlan.slots.length;
          boundSlot++
        ) {
          var boundCell = mixedPlan.slots[boundSlot];
          mixedRight = Math.max(mixedRight, boundCell.x + boundCell.w);
          mixedBottom = Math.max(mixedBottom, boundCell.y + boundCell.h);
        }
        var mixedDx = (usableW - mixedRight) / 2,
          mixedDy = (usableH - mixedBottom) / 2;
        for (
          var mixedSlot = 0;
          mixedSlot < mixedPlan.slots.length;
          mixedSlot++
        ) {
          var cell = mixedPlan.slots[mixedSlot];
          slots.push({
            x: frontSafeLeft + mixedDx + cell.x,
            y: frontSafeTop - mixedDy - cell.y,
            w: cell.w,
            h: cell.h,
            angle: cell.angle,
            modelIndex: cell.modelIndex,
          });
        }
      } else
        collectSlots(
          bestPlan,
          frontSafeLeft,
          frontSafeTop,
          usableW,
          usableH,
          slots,
        );
      if (slots.length !== bestPlan.count)
        return "ERR: Lỗi tạo vị trí dàn. Hãy thử lại.";
      if (!mixedSizes) slots = orderSlotsForBatch(slots, batch);

      // Cả hai mặt dùng đúng cùng một bảng gán mẫu vào slot đã ghi lại.
      var slotModels = [];
      for (var mappedSlot = 0; mappedSlot < slots.length; mappedSlot++)
        slotModels.push(
          mixedSizes
            ? models[slots[mappedSlot].modelIndex]
            : batch[mappedSlot % batch.length],
        );

      var frontItems = [];
      var backItems = [];
      var slotIndex;
      prepareOutputLayer(frontLayer);
      for (slotIndex = 0; slotIndex < slots.length; slotIndex++) {
        var model = slotModels[slotIndex];
        var frontItem = copyAt(
          model.front,
          frontLayer,
          slots[slotIndex].x,
          slots[slotIndex].y,
          slots[slotIndex].angle,
          mixedSizes ? slots[slotIndex].w : undefined,
          mixedSizes ? slots[slotIndex].h : undefined,
        );
        frontItems.push(frontItem);
      }
      if (!mixedSizes) centerItems(frontItems, frontRect);

      if (twoSided) {
        var backSafeLeft = backRect[0] + MARGIN;
        var backSafeTop = backRect[1] - MARGIN;
        prepareOutputLayer(backLayer);
        for (slotIndex = 0; slotIndex < slots.length; slotIndex++) {
          model = slotModels[slotIndex];
          var slot = slots[slotIndex];
          var relativeX = slot.x - frontSafeLeft;
          var relativeY = frontSafeTop - slot.y;
          var mirroredLeft = backSafeLeft + usableW - relativeX - slot.w;
          var mirroredTop = backSafeTop - relativeY;
          var backAngle = slot.angle === 90 ? -90 : 0;
          var backItem = copyAt(
            model.back,
            backLayer,
            mirroredLeft,
            mirroredTop,
            backAngle,
            mixedSizes ? slot.w : undefined,
            mixedSizes ? slot.h : undefined,
          );
          backItems.push(backItem);
        }
        if (!mixedSizes) centerItems(backItems, backRect);
      }
    }

    var cleanup = dcRemoveOldCanvasArtboards(doc, oldCanvasArtboardCount);
    firstFrontIndex = cleanup.firstNewIndex;
    var removedSourceCount = 0,
      remainingSourceCount = 0,
      sourceCleanupWarnings = 0;
    if (mixedSizes) {
      // Chỉ xoá nguồn sau khi mọi con mặt trước/mặt sau theo kế hoạch đã được
      // dựng thành công. Nguồn không dùng tới thì không bao giờ bị dời hay xoá.
      // Một mẫu có thể có nhiều con nhưng chỉ bị xoá một lần.
      for (mi = 0; mi < models.length; mi++) {
        if (mixedPlan.counts[mi] === 0) {
          remainingSourceCount++;
          continue;
        }
        var removedPair = true;
        try {
          models[mi].front.remove();
        } catch (removeFrontError) {
          removedPair = false;
        }
        if (twoSided) {
          try {
            models[mi].back.remove();
          } catch (removeBackError) {
            removedPair = false;
          }
        }
        if (removedPair) removedSourceCount++;
        else sourceCleanupWarnings++;
      }
    }
    var outputWasSelected = false;
    try {
      doc.artboards.setActiveArtboardIndex(firstFrontIndex);
      // Illustrator xu ly cham neu gan mot mang hang tram PageItem vao
      // doc.selection. Layer.hasSelectedArtwork la thao tac native, chon toan
      // bo bai vua dan ma khong bat JSX duyet tung object o buoc ket thuc.
      doc.selection = null;
      frontLayer.hasSelectedArtwork = true;
      if (backLayer) backLayer.hasSelectedArtwork = true;
      prepareOutputLayer(frontLayer);
      outputWasSelected = true;
    } catch (e) {}

    var sheetCount = outputBatches.length;
    var detail =
      "Đã tạo " +
      sheetCount +
      " artboard và canh giữa artwork; các tờ đã tự xuống hàng khi hết bề ngang.";
    if (twoSided)
      detail =
        "Đã tạo " +
        sheetCount +
        " cặp artboard trước/sau đối xứng và canh giữa artwork; các cặp đã tự xuống hàng khi hết bề ngang.";
    if (mixedSizes) {
      detail +=
        " Ghép nhiều kích thước; số con từng mẫu: " +
        mixedPlan.counts.join(", ") +
        ".";
      detail += " Tự nhân bản tối đa con lớn trước, rồi lấp con nhỏ.";
      detail +=
        " Đã xóa " +
        removedSourceCount +
        " mẫu nguồn đã dàn; còn " +
        remainingSourceCount +
        " mẫu chưa dàn được giữ nguyên.";
      if (sourceCleanupWarnings)
        detail +=
          " Không xóa được hết nguồn của " +
          sourceCleanupWarnings +
          " mẫu; hãy kiểm tra layer khóa.";
      if (mixedPlan.capacityLimited)
        detail +=
          " Đã đạt giới hạn 128 con/tờ của tìm kiếm ghép; chưa lấp hết phần dư.";
    } else if (multiPerArtboard && models.length > 1) {
      if (multiExtraSlots === 0)
        detail += " Đã dàn đều " + models.length + " mẫu.";
      else
        detail +=
          " Đã dàn đủ " +
          models.length +
          " mẫu; " +
          multiExtraSlots +
          " slot dư lặp mẫu đầu theo từng cụm.";
    } else if (sheetCount > 1) {
      detail += " Mỗi mẫu được dàn đầy trên một tờ riêng.";
    }
    if (!outputWasSelected)
      detail +=
        " Artwork nằm trên layer Dan toi uu; Illustrator không thể tự chọn tất cả trong tài liệu này.";
    return "OK:[[COUNT:" + bestPlan.count + "]] " + detail + cleanup.warning;
  } catch (e) {
    return "ERR: " + dcMoTaLoi(e);
  }
}

// ============================================================
//  DÀN OFFSET — TỰ TRỞ (in 2 mặt trên 1 tờ giấy, 1 artboard)
//
//  Nửa trái tờ giấy là mặt trước, nửa phải là mặt sau, đối xứng
//  qua tim dọc của tờ giấy. In xong lật ngang tờ giấy rồi in lại
//  bằng chính bản kẽm đó, cắt ra là mỗi con đủ 2 mặt.
//
//  Mỗi cặp nguồn được chọn ăn một chỗ trên tờ, theo thứ tự chọn.
//  Dàn tới đâu con nguồn mất tới đó; cặp chưa dàn được để nguyên
//  tại chỗ cũ để dàn tiếp vào tờ sau. Chỉ tạo đúng 1 artboard.
//
//  Tool tự thử xoay 90°, tự thử bóp bài tối đa N mm mỗi chiều
//  nếu nhờ vậy dàn thêm được con, và không đánh pon.
// ============================================================
var dcDanTuTroVersion = 12;

function dcDanTuTro(
  pageWidthText,
  pageHeightText,
  marginText,
  maxBopText,
  repeatToFillArg,
  modeArg,
) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";

    var doc = app.activeDocument;
    var oldCanvasArtboardCount = doc.artboards.length;
    var selection = doc.selection;
    if (!selection || selection.length === 0)
      return "ERR: Hãy chọn cặp mặt trước + mặt sau trước khi dàn.";

    var MM = 2.834645669;
    var EPS = 0.01;

    function parseNumberText(value, label, minValue, maxValue) {
      var text = String(
        value === undefined || value === null ? "" : value,
      ).replace(",", ".");
      var n = parseFloat(text);
      if (!isFinite(n)) throw new Error(label + " phải là số.");
      if (n < minValue - EPS)
        throw new Error(label + " không được nhỏ hơn " + minValue + ".");
      if (maxValue !== null && n > maxValue + EPS)
        throw new Error(label + " không được lớn hơn " + maxValue + ".");
      return n;
    }

    function isUsableBounds(bounds) {
      return (
        bounds &&
        bounds.length >= 4 &&
        isFinite(bounds[0]) &&
        isFinite(bounds[1]) &&
        isFinite(bounds[2]) &&
        isFinite(bounds[3]) &&
        bounds[2] - bounds[0] > EPS &&
        bounds[1] - bounds[3] > EPS
      );
    }

    // Khung thành phẩm: theo bảng Transform khi cờ bật, không thì visibleBounds như cũ.
    function boundsOf(item) {
      return dcDoKhung(item, function (it) {
        try {
          var visible = it.visibleBounds.slice(0);
          if (isUsableBounds(visible)) return visible;
        } catch (e) {}
        try {
          var geometric = it.geometricBounds.slice(0);
          if (isUsableBounds(geometric)) return geometric;
        } catch (e2) {}
        return null;
      });
    }

    function sizeOfBounds(bounds) {
      if (!bounds) return null;
      var w = bounds[2] - bounds[0];
      var h = bounds[1] - bounds[3];
      if (!isFinite(w) || !isFinite(h) || w <= 0 || h <= 0) return null;
      return { width: w, height: h };
    }

    function itemRecord(item) {
      var bounds = boundsOf(item);
      if (
        !bounds ||
        bounds[2] - bounds[0] <= EPS ||
        bounds[1] - bounds[3] <= EPS
      )
        return null;
      return {
        item: item,
        bounds: bounds,
        cx: (bounds[0] + bounds[2]) / 2,
        cy: (bounds[1] + bounds[3]) / 2,
      };
    }

    // ---- gom selection, ghép thành từng cặp trước/sau ----
    var raw = [];
    var skippedSelection = [];
    var sourceBounds = null;
    for (var si = 0; si < selection.length; si++) {
      var record = itemRecord(selection[si]);
      if (!record) {
        var itemType = "không rõ loại";
        try {
          itemType = selection[si].typename;
        } catch (selectionTypeError) {}
        skippedSelection.push(si + 1 + " (" + itemType + ")");
        continue;
      }
      raw.push(record);
      if (!sourceBounds) sourceBounds = record.bounds.slice(0);
      else {
        sourceBounds[0] = Math.min(sourceBounds[0], record.bounds[0]);
        sourceBounds[1] = Math.max(sourceBounds[1], record.bounds[1]);
        sourceBounds[2] = Math.max(sourceBounds[2], record.bounds[2]);
        sourceBounds[3] = Math.min(sourceBounds[3], record.bounds[3]);
      }
    }
    if (raw.length === 0 || !sourceBounds)
      return "ERR: Selection hiện tại không có artwork hợp lệ để dàn.";

    if (raw.length < 2 || raw.length % 2 !== 0) {
      var selectionInfo =
        " Tool nhận " +
        selection.length +
        " object, đọc hợp lệ " +
        raw.length +
        ".";
      if (skippedSelection.length)
        selectionInfo +=
          " Không đọc được khung: " + skippedSelection.join(", ") + ".";
      return (
        "ERR: Dàn tự trở cần chọn số object chẵn: từng cặp trái = mặt trước, phải = mặt sau." +
        selectionInfo
      );
    }

    // Ghép cặp theo HÀNG bằng hàm chung của KTS (vai trái/phải chốt theo hình
    // học, hàng lẻ con thì báo lỗi, không ghép chéo hàng).
    var pairs = [];
    var pi;
    try {
      var pairedRecords = dcKtsPairSourceRecords(raw, 0.01);
    } catch (pairError) {
      return "ERR: " + pairError.message;
    }
    for (pi = 0; pi < pairedRecords.length; pi++)
      pairs.push({
        front: pairedRecords[pi].front.item,
        back: pairedRecords[pi].back.item,
      });

    var referenceBounds = boundsOf(pairs[0].front);
    if (!referenceBounds) return "ERR: Không đo được kích thước bài mẫu.";
    var sourceW = referenceBounds[2] - referenceBounds[0];
    var sourceH = referenceBounds[1] - referenceBounds[3];
    // visibleBounds có thể lệch nhẹ giữa mặt trước/mặt sau do stroke,
    // bóng đổ hoặc tràn lề. Dùng khung thành phẩm lớn nhất và canh giữa mọi mặt
    // trong khung đó; lệch nhiều thì vẫn là lỗi đầu vào rõ ràng.
    var SIZE_TOLERANCE = 0.5 * MM;

    // Từ version 5, nhiều cặp có thể khác khổ thành phẩm. Hai mặt của CÙNG
    // một cặp vẫn phải khớp nhau để tự trở không lệch đăng.
    var pairSpecs = [];
    var hasMixedFinishedSize = false;
    for (pi = 0; pi < pairs.length; pi++) {
      var mixedFrontSize = sizeOfBounds(boundsOf(pairs[pi].front));
      var mixedBackSize = sizeOfBounds(boundsOf(pairs[pi].back));
      if (!mixedFrontSize || !mixedBackSize)
        return "ERR: Không đo được kích thước cặp thứ " + (pi + 1) + ".";
      if (
        Math.abs(mixedFrontSize.width - mixedBackSize.width) > SIZE_TOLERANCE ||
        Math.abs(mixedFrontSize.height - mixedBackSize.height) > SIZE_TOLERANCE
      )
        return (
          "ERR: Cặp thứ " +
          (pi + 1) +
          " có mặt trước và mặt sau lệch khung quá 0.5 mm. Hãy đưa riêng 2 mặt của cặp này về cùng khung trước khi dàn."
        );
      pairSpecs.push({
        width: Math.max(mixedFrontSize.width, mixedBackSize.width),
        height: Math.max(mixedFrontSize.height, mixedBackSize.height),
        frontWidth: mixedFrontSize.width,
        frontHeight: mixedFrontSize.height,
        backWidth: mixedBackSize.width,
        backHeight: mixedBackSize.height,
      });
      if (
        Math.abs(pairSpecs[pi].width - sourceW) > SIZE_TOLERANCE ||
        Math.abs(pairSpecs[pi].height - sourceH) > SIZE_TOLERANCE
      )
        hasMixedFinishedSize = true;
    }
    if (hasMixedFinishedSize || String(modeArg) === "ab")
      return dcDanTuTroNhieuKho(
        doc,
        pairs,
        pairSpecs,
        sourceBounds,
        pageWidthText,
        pageHeightText,
        marginText,
        maxBopText,
        repeatToFillArg,
        modeArg,
      );

    function checkSameSize(item, sideLabel, pairNumber) {
      var b = boundsOf(item);
      if (!b)
        throw new Error(
          "Không đo được " + sideLabel + " của cặp thứ " + pairNumber + ".",
        );
      var w = b[2] - b[0];
      var h = b[1] - b[3];
      if (
        Math.abs(w - sourceW) > SIZE_TOLERANCE ||
        Math.abs(h - sourceH) > SIZE_TOLERANCE
      )
        throw new Error(
          "Cặp thứ " +
            pairNumber +
            " (" +
            sideLabel +
            ") lệch quá 0.5 mm so với cặp đầu. Mọi mẫu phải cùng khổ thành phẩm; hãy group/clip từng mặt về cùng một khung trước khi dàn.",
        );
      return { width: w, height: h };
    }
    var largestSourceW = sourceW;
    var largestSourceH = sourceH;
    for (pi = 0; pi < pairs.length; pi++) {
      var frontSize = checkSameSize(pairs[pi].front, "mặt trước", pi + 1);
      var backSize = checkSameSize(pairs[pi].back, "mặt sau", pi + 1);
      largestSourceW = Math.max(
        largestSourceW,
        frontSize.width,
        backSize.width,
      );
      largestSourceH = Math.max(
        largestSourceH,
        frontSize.height,
        backSize.height,
      );
    }
    sourceW = largestSourceW;
    sourceH = largestSourceH;

    // ---- thông số tờ giấy ----
    var paperW =
      parseNumberText(pageWidthText, "Ngang giấy", 0.1, null) * 10 * MM;
    var paperH =
      parseNumberText(pageHeightText, "Dọc giấy", 0.1, null) * 10 * MM;
    var marginMm = parseNumberText(
      marginText === undefined ||
        marginText === null ||
        String(marginText) === ""
        ? 0
        : marginText,
      "Lề an toàn",
      0,
      50,
    );
    var maxBopMm = parseNumberText(
      maxBopText === undefined ||
        maxBopText === null ||
        String(maxBopText) === ""
        ? 0
        : maxBopText,
      "Bóp tối đa",
      0,
      50,
    );

    var repeatToFill =
      repeatToFillArg === true || String(repeatToFillArg) === "true";

    var MARGIN = marginMm * MM;
    var maxBop = maxBopMm * MM;
    // Không cho bóp quá 20% cạnh ngắn — bóp nhiều hơn là hỏng bài, không phải bù bình.
    var bopCeiling = Math.min(sourceW, sourceH) * 0.2;
    if (maxBop > bopCeiling) maxBop = bopCeiling;

    var usableW = paperW - 2 * MARGIN;
    var usableH = paperH - 2 * MARGIN;
    if (usableW <= EPS || usableH <= EPS)
      return "ERR: Khổ giấy phải lớn hơn lề an toàn hai bên.";
    var halfW = usableW / 2;

    // ==========================================================
    //  BỘ TÍNH BỐ CỤC — cắt guillotine, tự thử xoay 90°.
    //  Chỉ tính trên NỬA tờ giấy; nửa còn lại là ảnh gương.
    // ==========================================================
    function solveLayout(cellW, cellH, regionW0, regionH0, maxDepth) {
      function floorFit(space, size) {
        if (size <= EPS) return 0;
        return Math.floor((space + EPS) / size);
      }

      function makeStripPlan(
        direction,
        normalBands,
        rotatedBands,
        regionW,
        regionH,
      ) {
        var normalCells =
          direction === "row"
            ? floorFit(regionW, cellW)
            : floorFit(regionH, cellH);
        var rotatedCells =
          direction === "row"
            ? floorFit(regionW, cellH)
            : floorFit(regionH, cellW);
        if (
          (normalBands > 0 && normalCells <= 0) ||
          (rotatedBands > 0 && rotatedCells <= 0)
        )
          return null;
        var count = normalBands * normalCells + rotatedBands * rotatedCells;
        if (count <= 0) return null;
        var plan = {
          kind: "strips",
          direction: direction,
          count: count,
          normalCount: normalBands * normalCells,
          rotatedCount: rotatedBands * rotatedCells,
          bands: [],
        };
        if (normalBands > 0)
          plan.bands.push({
            angle: 0,
            repeat: normalBands,
            cells: normalCells,
            cellW: cellW,
            cellH: cellH,
          });
        if (rotatedBands > 0)
          plan.bands.push({
            angle: 90,
            repeat: rotatedBands,
            cells: rotatedCells,
            cellW: cellH,
            cellH: cellW,
          });
        return plan;
      }

      function planComplexity(plan) {
        if (!plan) return 999999;
        if (plan.kind === "empty") return 0;
        if (plan.kind === "strips") return plan.bands.length;
        return 1 + planComplexity(plan.first) + planComplexity(plan.second);
      }

      // Cùng số con thì số nhát dao guillotine thấp hơn luôn được ưu tiên.
      // Cache trên plan để bài nhỏ không làm bộ tìm kiếm lặp lại phép tính này.
      function planCutCost(plan) {
        if (!plan || plan.count <= 1) return 0;
        if (typeof plan._dcOffsetCutCost === "number")
          return plan._dcOffsetCutCost;
        var cost = 0;
        if (plan.kind === "splitV" || plan.kind === "splitH") {
          if (!plan.first || plan.first.count <= 0)
            cost = planCutCost(plan.second);
          else if (!plan.second || plan.second.count <= 0)
            cost = planCutCost(plan.first);
          else cost = 1 + planCutCost(plan.first) + planCutCost(plan.second);
        } else if (plan.kind === "strips") {
          for (
            var cutBandIndex = 0;
            cutBandIndex < plan.bands.length;
            cutBandIndex++
          ) {
            var cutBand = plan.bands[cutBandIndex];
            cost +=
              Math.max(0, cutBand.cells - 1) + Math.max(0, cutBand.repeat - 1);
          }
          cost += Math.max(0, plan.bands.length - 1);
        }
        plan._dcOffsetCutCost = cost;
        return cost;
      }

      function isBetter(candidate, best) {
        if (!candidate) return false;
        if (!best) return true;
        if (candidate.count !== best.count) return candidate.count > best.count;
        var candidateCuts = planCutCost(candidate);
        var bestCuts = planCutCost(best);
        if (candidateCuts !== bestCuts) return candidateCuts < bestCuts;
        if (planComplexity(candidate) !== planComplexity(best))
          return planComplexity(candidate) < planComplexity(best);
        return candidate.normalCount > best.normalCount;
      }

      function bestStripPlan(regionW, regionH) {
        var best = null;
        var normalRowMax = floorFit(regionH, cellH);
        var normalRows, rowRemain, rotatedRows, rowPlan;
        for (normalRows = 0; normalRows <= normalRowMax; normalRows++) {
          rowRemain = regionH - normalRows * cellH;
          rotatedRows = floorFit(rowRemain, cellW);
          rowPlan = makeStripPlan(
            "row",
            normalRows,
            rotatedRows,
            regionW,
            regionH,
          );
          if (isBetter(rowPlan, best)) best = rowPlan;
        }
        var normalColumnMax = floorFit(regionW, cellW);
        var normalColumns, columnRemain, rotatedColumns, columnPlan;
        for (
          normalColumns = 0;
          normalColumns <= normalColumnMax;
          normalColumns++
        ) {
          columnRemain = regionW - normalColumns * cellW;
          rotatedColumns = floorFit(columnRemain, cellH);
          columnPlan = makeStripPlan(
            "column",
            normalColumns,
            rotatedColumns,
            regionW,
            regionH,
          );
          if (isBetter(columnPlan, best)) best = columnPlan;
        }
        return best;
      }

      // Lưới một chiều luôn dễ cắt và đăng tay nhất.  Chỉ mở bố cục trộn/L
      // khi nó thật sự tăng số chỗ của một nửa tờ.
      function bestSingleDirectionPlan(regionW, regionH) {
        var normalPlan = makeStripPlan(
          "row",
          floorFit(regionH, cellH),
          0,
          regionW,
          regionH,
        );
        var rotatedPlan = makeStripPlan(
          "row",
          0,
          floorFit(regionH, cellW),
          regionW,
          regionH,
        );
        if (!normalPlan) return rotatedPlan;
        if (rotatedPlan && rotatedPlan.count > normalPlan.count)
          return rotatedPlan;
        return normalPlan;
      }

      function addCutValue(values, seen, value, total) {
        if (value <= EPS || total - value <= EPS) return;
        var key = Math.round(value * 1000);
        if (seen[key]) return;
        seen[key] = true;
        values.push(value);
      }

      function cutValues(total) {
        var values = [],
          seen = {},
          i;
        for (i = 1; i <= floorFit(total, cellW); i++) {
          addCutValue(values, seen, i * cellW, total);
          addCutValue(values, seen, total - i * cellW, total);
        }
        for (i = 1; i <= floorFit(total, cellH); i++) {
          addCutValue(values, seen, i * cellH, total);
          addCutValue(values, seen, total - i * cellH, total);
        }
        return values;
      }

      var planMemo = {};
      function solveRegion(regionW, regionH, depth) {
        var memoKey =
          Math.round(regionW * 1000) +
          "x" +
          Math.round(regionH * 1000) +
          "x" +
          depth;
        if (planMemo[memoKey]) return planMemo[memoKey];

        var best = bestStripPlan(regionW, regionH);
        if (!best || depth <= 0) {
          if (!best)
            best = { kind: "empty", count: 0, normalCount: 0, rotatedCount: 0 };
          planMemo[memoKey] = best;
          return best;
        }

        // Với bài rất nhỏ, số đường chia khả dĩ tăng theo hàng trăm/hàng nghìn
        // dù lưới thẳng đã là cách cắt thực tế tốt nhất.  Dừng ở strip-plan
        // để tránh treo Illustrator; mọi khổ lớn/vừa vẫn thử L đầy đủ.
        var areaUpperBound = Math.floor(
          (regionW * regionH + EPS) / (cellW * cellH),
        );
        if (areaUpperBound > 160) {
          planMemo[memoKey] = best;
          return best;
        }

        var cuts = cutValues(regionW);
        var vi, leftPlan, rightPlan, verticalPlan;
        for (vi = 0; vi < cuts.length; vi++) {
          leftPlan = solveRegion(cuts[vi], regionH, depth - 1);
          rightPlan = solveRegion(regionW - cuts[vi], regionH, depth - 1);
          verticalPlan = {
            kind: "splitV",
            cut: cuts[vi],
            first: leftPlan,
            second: rightPlan,
            count: leftPlan.count + rightPlan.count,
            normalCount: leftPlan.normalCount + rightPlan.normalCount,
            rotatedCount: leftPlan.rotatedCount + rightPlan.rotatedCount,
          };
          if (isBetter(verticalPlan, best)) best = verticalPlan;
        }

        cuts = cutValues(regionH);
        var hi, topPlan, bottomPlan, horizontalPlan;
        for (hi = 0; hi < cuts.length; hi++) {
          topPlan = solveRegion(regionW, cuts[hi], depth - 1);
          bottomPlan = solveRegion(regionW, regionH - cuts[hi], depth - 1);
          horizontalPlan = {
            kind: "splitH",
            cut: cuts[hi],
            first: topPlan,
            second: bottomPlan,
            count: topPlan.count + bottomPlan.count,
            normalCount: topPlan.normalCount + bottomPlan.normalCount,
            rotatedCount: topPlan.rotatedCount + bottomPlan.rotatedCount,
          };
          if (isBetter(horizontalPlan, best)) best = horizontalPlan;
        }
        planMemo[memoKey] = best;
        return best;
      }

      var singleDirectionPlan = bestSingleDirectionPlan(regionW0, regionH0);
      var mixedPlan = solveRegion(regionW0, regionH0, maxDepth);
      if (!singleDirectionPlan) return mixedPlan;
      // Cùng số chỗ thì giữ lưới một chiều; chỉ đổi sang trộn/L khi nhiều hơn.
      if (!mixedPlan || mixedPlan.count <= singleDirectionPlan.count)
        return singleDirectionPlan;
      return mixedPlan;
    }

    function countOf(plan) {
      return plan && plan.count > 0 ? plan.count : 0;
    }

    // ==========================================================
    //  TÌM MỨC BÓP — bóp càng ít càng tốt, miễn là đủ số con nhiều nhất.
    //  Quét nhanh ở độ sâu 1, chốt lại bằng một lần tính độ sâu 2.
    // ==========================================================
    var bopStep = 0;
    var bopSteps = 0;
    if (maxBop > EPS) {
      // Luôn giữ tối đa 11 mức mỗi chiều để không làm chậm panel.
      bopStep = maxBop / 10;
      bopSteps = 10;
    }

    var candidates = [];
    var ai, bi;
    for (ai = 0; ai <= bopSteps; ai++) {
      for (bi = 0; bi <= bopSteps; bi++) {
        var dw = ai * bopStep;
        var dh = bi * bopStep;
        candidates.push({ dw: dw, dh: dh, cost: dw / sourceW + dh / sourceH });
      }
    }
    candidates.sort(function (a, b) {
      return a.cost - b.cost;
    });

    var pickDw = 0;
    var pickDh = 0;
    if (bopSteps > 0) {
      var fullCount = countOf(solveLayout(sourceW, sourceH, halfW, usableH, 1));
      var tightCount = countOf(
        solveLayout(sourceW - maxBop, sourceH - maxBop, halfW, usableH, 1),
      );
      if (tightCount > fullCount) {
        for (var ci = 0; ci < candidates.length; ci++) {
          var cand = candidates[ci];
          var probeCount = countOf(
            solveLayout(
              sourceW - cand.dw,
              sourceH - cand.dh,
              halfW,
              usableH,
              1,
            ),
          );
          if (probeCount >= tightCount) {
            pickDw = cand.dw;
            pickDh = cand.dh;
            break;
          }
        }
      }
    }

    var cellW = sourceW - pickDw;
    var cellH = sourceH - pickDh;
    var bestPlan = solveLayout(cellW, cellH, halfW, usableH, 2);
    if (!bestPlan || bestPlan.count <= 0)
      return (
        "ERR: Bài không nằm vừa nửa tờ giấy. Tự trở cần mỗi mặt lọt vào một nửa khổ, " +
        "hãy tăng khổ giấy hoặc giảm lề an toàn."
      );

    // ==========================================================
    //  DỰNG TỜ GIẤY
    // ==========================================================
    function uniqueLayerName(base) {
      var candidate = base;
      var suffix = 2;
      var found = true;
      while (found) {
        found = false;
        for (var li = 0; li < doc.layers.length; li++) {
          try {
            if (doc.layers[li].name === candidate) {
              found = true;
              candidate = base + " " + suffix;
              suffix++;
              break;
            }
          } catch (e) {}
        }
      }
      return candidate;
    }

    function addOutputLayer(name) {
      var layer = doc.layers.add();
      layer.name = uniqueLayerName(name);
      try {
        layer.locked = false;
        layer.visible = true;
      } catch (e) {}
      return layer;
    }

    function prepareOutputLayer(layer) {
      if (!layer) return;
      try {
        layer.locked = false;
        layer.visible = true;
        doc.activeLayer = layer;
      } catch (e) {}
    }

    function rectsOverlap(a, b) {
      return (
        a[0] < b[2] - EPS &&
        a[2] > b[0] + EPS &&
        a[3] < b[1] - EPS &&
        a[1] > b[3] + EPS
      );
    }

    function rectContains(outer, inner) {
      return (
        outer[0] <= inner[0] + EPS &&
        outer[1] >= inner[1] - EPS &&
        outer[2] >= inner[2] - EPS &&
        outer[3] <= inner[3] + EPS
      );
    }

    function readCanvasBounds() {
      var halfSize = 7200;
      try {
        if (doc.scaleFactor && doc.scaleFactor < 1)
          halfSize = halfSize / doc.scaleFactor;
      } catch (e) {}
      return [-halfSize, halfSize, halfSize, -halfSize];
    }

    var pageGap = 10 * MM;
    var canvasRect = readCanvasBounds();
    var canvasWidth = canvasRect[2] - canvasRect[0];
    var canvasHeight = canvasRect[1] - canvasRect[3];
    var occupiedRects = [];
    for (var abi = 0; abi < doc.artboards.length; abi++) {
      try {
        var existingRect = doc.artboards[abi].artboardRect.slice(0);
        var existingWidth = existingRect[2] - existingRect[0];
        var existingHeight = existingRect[1] - existingRect[3];
        if (
          existingWidth >= canvasWidth * 0.92 &&
          existingHeight >= canvasHeight * 0.92
        )
          continue;
        occupiedRects.push(existingRect);
      } catch (e) {}
    }
    // Bài cũ còn trên canvas (khung đã xoá ở lượt trước) cũng là vùng bận.
    var sourceItemsTuTro = [];
    for (var sk = 0; sk < pairs.length; sk++)
      sourceItemsTuTro.push(pairs[sk].front, pairs[sk].back);
    occupiedRects = occupiedRects.concat(
      dcVungBaiCu(doc, canvasRect, sourceItemsTuTro),
    );
    var sourceAlreadyCovered = false;
    for (var oi = 0; oi < occupiedRects.length; oi++) {
      if (rectContains(occupiedRects[oi], sourceBounds)) {
        sourceAlreadyCovered = true;
        break;
      }
    }
    if (!sourceAlreadyCovered) occupiedRects.push(sourceBounds.slice(0));

    var layoutLeft = canvasRect[0] + pageGap;
    var layoutTop = canvasRect[1] - pageGap;
    var layoutRight = canvasRect[2] - pageGap;
    var layoutBottom = canvasRect[3] + pageGap;
    var layoutCursorLeft = layoutLeft;
    var layoutCursorTop = layoutTop;

    function reserveSheetRect() {
      var candidateLeft = layoutCursorLeft;
      var candidateTop = layoutCursorTop;
      var attempts = 0;
      while (attempts++ < 5000) {
        if (candidateLeft + paperW > layoutRight + EPS) {
          candidateLeft = layoutLeft;
          candidateTop -= paperH + pageGap;
          continue;
        }
        if (candidateTop - paperH < layoutBottom - EPS)
          throw new Error(
            "Không còn chỗ trống trong canvas để tạo tờ mới. Hãy xoá bớt artboard cũ hoặc bài cũ còn trên canvas, hoặc mở tài liệu Large Canvas.",
          );

        var sheetRect = [
          candidateLeft,
          candidateTop,
          candidateLeft + paperW,
          candidateTop - paperH,
        ];
        var blocker = null;
        for (var ri = 0; ri < occupiedRects.length; ri++) {
          if (rectsOverlap(sheetRect, occupiedRects[ri])) {
            blocker = occupiedRects[ri];
            break;
          }
        }
        if (blocker) {
          candidateLeft = blocker[2] + pageGap;
          continue;
        }

        occupiedRects.push(sheetRect);
        layoutCursorLeft = candidateLeft + paperW + pageGap;
        layoutCursorTop = candidateTop;
        return sheetRect;
      }
      throw new Error(
        "Không tìm được vị trí trong canvas để đặt artboard mới.",
      );
    }

    function addOutputArtboard(rect, name) {
      var index = doc.artboards.length;
      try {
        var board = doc.artboards.add(rect);
        try {
          board.name = name + " " + (index + 1);
        } catch (e) {}
        return index;
      } catch (e) {
        throw new Error(
          "Không tạo được artboard trong vị trí đã tính. Hãy thử đóng và mở lại tài liệu, sau đó chạy lại.",
        );
      }
    }

    function collectSlots(plan, left, top, regionW, regionH, output) {
      if (!plan || plan.count <= 0) return;
      if (plan.kind === "splitV") {
        collectSlots(plan.first, left, top, plan.cut, regionH, output);
        collectSlots(
          plan.second,
          left + plan.cut,
          top,
          regionW - plan.cut,
          regionH,
          output,
        );
        return;
      }
      if (plan.kind === "splitH") {
        collectSlots(plan.first, left, top, regionW, plan.cut, output);
        collectSlots(
          plan.second,
          left,
          top - plan.cut,
          regionW,
          regionH - plan.cut,
          output,
        );
        return;
      }
      if (plan.kind !== "strips") return;

      var x, y, band, repeat, cell;
      if (plan.direction === "row") {
        y = top;
        for (var rb = 0; rb < plan.bands.length; rb++) {
          band = plan.bands[rb];
          for (repeat = 0; repeat < band.repeat; repeat++) {
            x = left;
            for (cell = 0; cell < band.cells; cell++) {
              output.push({
                x: x,
                y: y,
                angle: band.angle,
                w: band.cellW,
                h: band.cellH,
              });
              x += band.cellW;
            }
            y -= band.cellH;
          }
        }
      } else {
        x = left;
        for (var cb = 0; cb < plan.bands.length; cb++) {
          band = plan.bands[cb];
          for (repeat = 0; repeat < band.repeat; repeat++) {
            y = top;
            for (cell = 0; cell < band.cells; cell++) {
              output.push({
                x: x,
                y: y,
                angle: band.angle,
                w: band.cellW,
                h: band.cellH,
              });
              y -= band.cellH;
            }
            x += band.cellW;
          }
        }
      }
    }

    // ---- bóp bài: làm một con mẫu đã bóp rồi nhân bản con mẫu đó ----
    function resizeAtCenter(item, scaleX, scaleY) {
      var before = boundsOf(item);
      if (!before) throw new Error("Không đo được bài trước khi bóp.");
      var cx = (before[0] + before[2]) / 2;
      var cy = (before[1] + before[3]) / 2;
      try {
        item.resize(
          scaleX * 100,
          scaleY * 100,
          true,
          true,
          true,
          true,
          100,
          Transformation.CENTER,
        );
      } catch (resizeCenterError) {
        item.resize(scaleX * 100, scaleY * 100);
      }
      var after = boundsOf(item);
      if (!after) throw new Error("Không đo được bài sau khi bóp.");
      item.translate(
        cx - (after[0] + after[2]) / 2,
        cy - (after[1] + after[3]) / 2,
      );
      return boundsOf(item);
    }

    function makeSqueezedMaster(sourceItem, layer, targetW, targetH) {
      var master = sourceItem.duplicate(layer, ElementPlacement.PLACEATEND);
      var before = sizeOfBounds(boundsOf(master));
      if (!before) throw new Error("Kích thước bài không hợp lệ.");
      if (
        Math.abs(before.width - targetW) <= 0.05 &&
        Math.abs(before.height - targetH) <= 0.05
      )
        return master;

      // Thử tăng trục X 1% để biết trục X nội bộ đang ảnh hưởng ngang hay dọc.
      var probe = sizeOfBounds(resizeAtCenter(master, 1.01, 1));
      if (!probe) throw new Error("Không đo được trục bóp của bài.");
      var xChangesWidth =
        Math.abs(probe.width - before.width) >=
        Math.abs(probe.height - before.height);
      var scaleX = xChangesWidth
        ? targetW / probe.width
        : targetH / probe.height;
      var scaleY = xChangesWidth
        ? targetH / probe.height
        : targetW / probe.width;
      if (!isFinite(scaleX) || !isFinite(scaleY) || scaleX <= 0 || scaleY <= 0)
        throw new Error("Không tính được tỉ lệ bóp.");

      var done = sizeOfBounds(resizeAtCenter(master, scaleX, scaleY));
      // Bù thêm một lần cho Raster/PlacedItem hoặc object có trục xoay nội bộ.
      if (
        done &&
        (Math.abs(done.width - targetW) > 0.5 ||
          Math.abs(done.height - targetH) > 0.5)
      ) {
        var fixX = xChangesWidth ? targetW / done.width : targetH / done.height;
        var fixY = xChangesWidth ? targetH / done.height : targetW / done.width;
        resizeAtCenter(master, fixX, fixY);
      }
      return master;
    }

    function squeezedTargetFor(sourceItem) {
      var size = sizeOfBounds(boundsOf(sourceItem));
      if (!size) throw new Error("Không đo được kích thước bài để bóp.");
      // Các mặt lệch visibleBounds rất nhỏ vẫn giữ đúng tỷ lệ của chính chúng,
      // thay vì bị kéo giãn thành kích thước của mặt khác.
      return {
        width: (size.width * cellW) / sourceW,
        height: (size.height * cellH) / sourceH,
      };
    }

    function copyAt(source, layer, left, top, angle, slotW, slotH) {
      var copy = source.duplicate(layer, ElementPlacement.PLACEATEND);
      if (angle !== 0) copy.rotate(angle);
      var bounds = boundsOf(copy);
      if (!bounds) throw new Error("Không đo được bản sao để đặt vào tờ giấy.");
      var itemW = bounds[2] - bounds[0];
      var itemH = bounds[1] - bounds[3];
      // Canh giữa trong slot danh định để chênh lệch nhỏ về stroke/tràn lề giữa
      // mặt trước và mặt sau không bao giờ làm đổi tâm khớp mặt khi tự trở.
      var targetLeft = left + Math.max(0, (slotW - itemW) / 2);
      var targetTop = top - Math.max(0, (slotH - itemH) / 2);
      copy.translate(targetLeft - bounds[0], targetTop - bounds[1]);
      return copy;
    }

    function allBounds(items) {
      var merged = null;
      for (var bi2 = 0; bi2 < items.length; bi2++) {
        var b = boundsOf(items[bi2]);
        if (!b) continue;
        if (!merged) merged = b.slice(0);
        else {
          merged[0] = Math.min(merged[0], b[0]);
          merged[1] = Math.max(merged[1], b[1]);
          merged[2] = Math.max(merged[2], b[2]);
          merged[3] = Math.min(merged[3], b[3]);
        }
      }
      return merged;
    }

    function centerItems(items, artboardRect) {
      var bounds = allBounds(items);
      if (!bounds) return;
      var dx =
        (artboardRect[0] + artboardRect[2]) / 2 - (bounds[0] + bounds[2]) / 2;
      var dy =
        (artboardRect[1] + artboardRect[3]) / 2 - (bounds[1] + bounds[3]) / 2;
      for (var ci2 = 0; ci2 < items.length; ci2++) items[ci2].translate(dx, dy);
    }

    // PON giấy ở góc giống hệt KTS và Offset nhiều khổ. Nhánh một khổ này
    // phải tự có hàm phụ trợ riêng; hàm cục bộ của các nhánh khác thì
    // không nhìn thấy được từ đây.
    function addPaperPonAtCorners(layer, rect) {
      var markLength = 3 * MM,
        strokeWidth = 1.995;
      var black = new CMYKColor();
      black.cyan = 0;
      black.magenta = 0;
      black.yellow = 0;
      black.black = 100;
      function draw(x1, y1, x2, y2) {
        var mark = layer.pathItems.add();
        mark.setEntirePath([
          [x1, y1],
          [x2, y2],
        ]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = strokeWidth;
      }
      var left = rect[0],
        top = rect[1],
        right = rect[2],
        bottom = rect[3];
      draw(left, top, left + markLength, top);
      draw(left, top, left, top - markLength);
      draw(right - markLength, top, right, top);
      draw(right, top, right, top - markLength);
      draw(left, bottom, left + markLength, bottom);
      draw(left, bottom, left, bottom + markLength);
      draw(right - markLength, bottom, right, bottom);
      draw(right, bottom, right, bottom + markLength);
    }

    // ==========================================================
    //  XẾP CẶP NGUỒN VÀO CÁC CHỖ TRÊN TỜ
    //  Mỗi cặp ăn một chỗ, theo thứ tự đã chọn. Hết chỗ thì dừng,
    //  các cặp còn lại để nguyên tại chỗ cũ để dàn vào tờ sau.
    // ==========================================================
    var sheetRect = reserveSheetRect();
    var sheetArtboardIndex = addOutputArtboard(sheetRect, "Tự trở");
    var safeLeft = sheetRect[0] + MARGIN;
    var safeTop = sheetRect[1] - MARGIN;

    var slots = [];
    collectSlots(bestPlan, safeLeft, safeTop, halfW, usableH, slots);
    if (slots.length !== bestPlan.count)
      return "ERR: Lỗi tạo vị trí dàn. Hãy thử lại.";

    // Xếp chỗ theo thứ tự đọc: từ trên xuống, trong hàng từ trái qua, để
    // thợ dò được con nào nằm ở đâu theo đúng thứ tự đã chọn.
    slots.sort(function (a, b) {
      if (Math.abs(a.y - b.y) > 0.5) return b.y - a.y;
      return a.x - b.x;
    });

    var usedSlots = repeatToFill
      ? slots.length
      : Math.min(pairs.length, slots.length);
    var leftoverPairs = repeatToFill ? 0 : pairs.length - usedSlots;
    var emptySlots = slots.length - usedSlots;

    // Tự trở không chừa khe ở tim giấy: dồn riêng phần slot thực sự dùng
    // sát mép tim của nửa trái; nửa phải là ảnh gương nên hai cụm sẽ chạm nhau.
    var occupiedRight = safeLeft;
    for (
      var centerSlotIndex = 0;
      centerSlotIndex < usedSlots;
      centerSlotIndex++
    )
      occupiedRight = Math.max(
        occupiedRight,
        slots[centerSlotIndex].x + slots[centerSlotIndex].w,
      );
    var centerShift = safeLeft + halfW - occupiedRight;
    if (centerShift > EPS)
      for (centerSlotIndex = 0; centerSlotIndex < usedSlots; centerSlotIndex++)
        slots[centerSlotIndex].x += centerShift;

    // Gom các chỗ theo từng cặp nguồn: một cặp chỉ phải bóp/nhân bản một lần.
    var assignments = [];
    var assignIndex = {};
    var slotIndex;
    for (slotIndex = 0; slotIndex < usedSlots; slotIndex++) {
      var pairIndex = repeatToFill ? slotIndex % pairs.length : slotIndex;
      if (assignIndex[pairIndex] === undefined) {
        assignIndex[pairIndex] = assignments.length;
        assignments.push({ pair: pairs[pairIndex], slots: [] });
      }
      assignments[assignIndex[pairIndex]].slots.push(slots[slotIndex]);
    }

    var frontLayer = addOutputLayer("Dàn tự trở - Mặt trước");
    var backLayer = addOutputLayer("Dàn tự trở - Mặt sau");
    var needSqueeze = pickDw > EPS || pickDh > EPS;
    var placedItems = [];

    for (var asi = 0; asi < assignments.length; asi++) {
      var pair = assignments[asi].pair;
      var pairSlots = assignments[asi].slots;

      // Bóp một lần rồi nhân bản con đã bóp; không bóp thì nhân bản thẳng
      // từ con nguồn. Con nguồn bị xoá sau khi đã dàn xong.
      prepareOutputLayer(frontLayer);
      var frontTarget = squeezedTargetFor(pair.front);
      var frontSource = needSqueeze
        ? makeSqueezedMaster(
            pair.front,
            frontLayer,
            frontTarget.width,
            frontTarget.height,
          )
        : pair.front;
      prepareOutputLayer(backLayer);
      var backTarget = squeezedTargetFor(pair.back);
      var backSource = needSqueeze
        ? makeSqueezedMaster(
            pair.back,
            backLayer,
            backTarget.width,
            backTarget.height,
          )
        : pair.back;

      var psi, slot;
      prepareOutputLayer(frontLayer);
      for (psi = 0; psi < pairSlots.length; psi++) {
        slot = pairSlots[psi];
        placedItems.push(
          copyAt(
            frontSource,
            frontLayer,
            slot.x,
            slot.y,
            slot.angle,
            slot.w,
            slot.h,
          ),
        );
      }

      // Mặt sau là ảnh gương của mặt trước qua tim dọc vùng in: sau khi lật
      // ngang tờ giấy, mỗi con mặt sau rơi đúng vào lưng con mặt trước.
      prepareOutputLayer(backLayer);
      for (psi = 0; psi < pairSlots.length; psi++) {
        slot = pairSlots[psi];
        var mirroredLeft = safeLeft + usableW - (slot.x - safeLeft) - slot.w;
        var backAngle = slot.angle === 90 ? -90 : 0;
        placedItems.push(
          copyAt(
            backSource,
            backLayer,
            mirroredLeft,
            slot.y,
            backAngle,
            slot.w,
            slot.h,
          ),
        );
      }

      if (needSqueeze) {
        try {
          frontSource.remove();
        } catch (e) {}
        try {
          backSource.remove();
        } catch (e) {}
      }
      // Dàn tới đâu con nguồn mất tới đó.
      try {
        pair.front.remove();
      } catch (e) {}
      try {
        pair.back.remove();
      } catch (e) {}
    }

    centerItems(placedItems, sheetRect);

    var paperPonLayer = addOutputLayer("PON giấy Dàn Offset");
    addPaperPonAtCorners(paperPonLayer, sheetRect);
    try {
      paperPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      paperPonLayer.locked = true;
    } catch (paperPonLayerError) {}

    var cleanup = dcRemoveOldCanvasArtboards(doc, oldCanvasArtboardCount);
    sheetArtboardIndex = cleanup.firstNewIndex;
    var outputWasSelected = false;
    try {
      doc.artboards.setActiveArtboardIndex(sheetArtboardIndex);
      doc.selection = null;
      frontLayer.hasSelectedArtwork = true;
      backLayer.hasSelectedArtwork = true;
      prepareOutputLayer(frontLayer);
      outputWasSelected = true;
    } catch (e) {}

    function formatCm(pt) {
      var cm = pt / (10 * MM);
      return (Math.round(cm * 100) / 100).toString();
    }
    function formatMm(pt) {
      var mm = pt / MM;
      return (Math.round(mm * 100) / 100).toString();
    }

    // Một chỗ trái + một chỗ phải là một thành phẩm 2 mặt, không phải hai con.
    var capacity = bestPlan.count;
    var detail =
      "Sức chứa tờ " +
      formatCm(paperW) +
      " × " +
      formatCm(paperH) +
      " cm: " +
      bestPlan.count +
      " chỗ mỗi nửa. Đã dàn " +
      usedSlots +
      " con mặt trước + " +
      usedSlots +
      " con mặt sau";
    if (repeatToFill && pairs.length < slots.length)
      detail += " (lặp lại " + pairs.length + " mẫu cho đầy tờ)";
    detail +=
      ". KT con dàn: " + formatCm(cellW) + " × " + formatCm(cellH) + " cm";
    if (needSqueeze) {
      var bopParts = [];
      if (pickDw > EPS) bopParts.push("ngang " + formatMm(pickDw) + " mm");
      if (pickDh > EPS) bopParts.push("dọc " + formatMm(pickDh) + " mm");
      detail += " (đã bóp " + bopParts.join(", ") + " để dàn thêm được con)";
    } else {
      detail += " (giữ nguyên, không cần bóp)";
    }
    detail += ". Lề an toàn " + marginMm + " mm.";
    if (leftoverPairs > 0)
      detail +=
        " Còn " +
        leftoverPairs +
        " cặp chưa dàn, đã để nguyên chỗ cũ để dàn tiếp vào tờ sau.";
    else if (emptySlots > 0)
      detail += " Hết mẫu, tờ còn trống " + emptySlots + " chỗ mỗi nửa.";
    else detail += " Đã dàn kín tờ.";
    detail += " In xong lật ngang tờ giấy rồi in lại bằng chính bản kẽm đó.";
    if (!outputWasSelected)
      detail +=
        " Artwork nằm trên layer Dàn tự trở; Illustrator không tự chọn hết được trong tài liệu này.";

    return "OK:[[COUNT:" + capacity + "]] " + detail + cleanup.warning;
  } catch (e) {
    return "ERR: " + dcMoTaLoi(e);
  }
}

// ============================================================
//  DÀN OFFSET TỰ TRỞ - NHIỀU KHỔ THÀNH PHẨM
//
//  Đây là nhánh riêng cho selection có ít nhất hai kích thước. Bộ xếp chỉ
//  làm việc trên nửa trái tờ; nửa phải luôn là ảnh gương của từng slot, do đó
//  giữ đúng đăng ký trước/sau khi lật ngang tờ giấy.
// ============================================================
function dcDanTuTroNhieuKho(
  doc,
  pairs,
  pairSpecs,
  sourceBounds,
  pageWidthText,
  pageHeightText,
  marginText,
  maxBopText,
  repeatToFillArg,
  modeArg,
) {
  try {
    var oldCanvasArtboardCount = doc.artboards.length;
    var MM = 2.834645669;
    var EPS = 0.01;

    function parseNumberText(value, label, minValue, maxValue) {
      var text = String(
        value === undefined || value === null ? "" : value,
      ).replace(",", ".");
      var n = parseFloat(text);
      if (!isFinite(n)) throw new Error(label + " phải là số.");
      if (n < minValue - EPS)
        throw new Error(label + " không được nhỏ hơn " + minValue + ".");
      if (maxValue !== null && n > maxValue + EPS)
        throw new Error(label + " không được lớn hơn " + maxValue + ".");
      return n;
    }

    function usableBounds(bounds) {
      return (
        bounds &&
        bounds.length >= 4 &&
        isFinite(bounds[0]) &&
        isFinite(bounds[1]) &&
        isFinite(bounds[2]) &&
        isFinite(bounds[3]) &&
        bounds[2] - bounds[0] > EPS &&
        bounds[1] - bounds[3] > EPS
      );
    }

    // Khung thành phẩm: theo bảng Transform khi cờ bật, không thì visibleBounds như cũ.
    function boundsOf(item) {
      return dcDoKhung(item, function (it) {
        try {
          var visible = it.visibleBounds.slice(0);
          if (usableBounds(visible)) return visible;
        } catch (e) {}
        try {
          var geometric = it.geometricBounds.slice(0);
          if (usableBounds(geometric)) return geometric;
        } catch (e2) {}
        return null;
      });
    }

    function sizeOfBounds(bounds) {
      if (!bounds) return null;
      var width = bounds[2] - bounds[0];
      var height = bounds[1] - bounds[3];
      if (
        !isFinite(width) ||
        !isFinite(height) ||
        width <= EPS ||
        height <= EPS
      )
        return null;
      return { width: width, height: height };
    }

    var paperW =
      parseNumberText(pageWidthText, "Ngang giấy", 0.1, null) * 10 * MM;
    var paperH =
      parseNumberText(pageHeightText, "Dọc giấy", 0.1, null) * 10 * MM;
    var marginMm = parseNumberText(
      marginText === undefined ||
        marginText === null ||
        String(marginText) === ""
        ? 0
        : marginText,
      "Lề an toàn",
      0,
      50,
    );
    var maxBopMm = parseNumberText(
      maxBopText === undefined ||
        maxBopText === null ||
        String(maxBopText) === ""
        ? 0
        : maxBopText,
      "Bóp tối đa",
      0,
      50,
    );
    var isAB = String(modeArg) === "ab";
    var repeatToFill =
      repeatToFillArg === true || String(repeatToFillArg) === "true";
    var repeatOnePair = repeatToFill && pairs.length === 1;
    var repeatIgnoredForMixed = repeatToFill && pairs.length > 1;
    var MARGIN = marginMm * MM;
    var maxBop = maxBopMm * MM;
    var smallestSide = null;
    for (var ps = 0; ps < pairSpecs.length; ps++) {
      pairSpecs[ps].sourceIndex = ps;
      var side = Math.min(pairSpecs[ps].width, pairSpecs[ps].height);
      if (smallestSide === null || side < smallestSide) smallestSide = side;
    }
    var bopCeiling = smallestSide * 0.2;
    if (maxBop > bopCeiling) maxBop = bopCeiling;

    var usableW = paperW - 2 * MARGIN;
    var usableH = paperH - 2 * MARGIN;
    if (usableW <= EPS || usableH <= EPS)
      return "ERR: Khổ giấy phải lớn hơn lề an toàn hai bên.";
    // Tự trở chia đôi một tờ; AB dùng trọn khổ trên từng artboard A/B.
    var halfW = isAB ? usableW : usableW / 2;

    // ---- Guillotine: mọi vùng trống là một hình chữ nhật độc lập. Khi đặt
    // một cặp, vùng đó chỉ được chẻ bằng hai nhát thẳng từ mép tới mép. Như
    // vậy luôn có "đường ra" cho dao, không tạo hốc/L bị khóa như MaxRects. ----
    function splitScore(free, dim, split) {
      var remainW = free.w - dim.w;
      var remainH = free.h - dim.h;
      var firstW, firstH, secondW, secondH;
      if (split === "vertical") {
        firstW = remainW;
        firstH = free.h;
        secondW = dim.w;
        secondH = remainH;
      } else {
        firstW = free.w;
        firstH = remainH;
        secondW = remainW;
        secondH = dim.h;
      }
      var firstMin =
        firstW > EPS && firstH > EPS ? Math.min(firstW, firstH) : 0;
      var secondMin =
        secondW > EPS && secondH > EPS ? Math.min(secondW, secondH) : 0;
      return Math.max(firstMin, secondMin);
    }

    function splitGuillotineRect(freeRects, placed) {
      var next = [];
      var free = freeRects[placed.freeIndex];
      for (var r = 0; r < freeRects.length; r++)
        if (r !== placed.freeIndex) next.push(freeRects[r]);
      var remainW = free.w - placed.w;
      var remainH = free.h - placed.h;
      if (placed.split === "vertical") {
        // Cắt dọc hết phần còn lại trước, sau đó cắt ngang dưới con vừa đặt.
        if (remainW > EPS)
          next.push({ x: free.x + placed.w, y: free.y, w: remainW, h: free.h });
        if (remainH > EPS)
          next.push({
            x: free.x,
            y: free.y + placed.h,
            w: placed.w,
            h: remainH,
          });
      } else {
        // Cắt ngang hết phần còn lại trước, sau đó cắt dọc bên phải con vừa đặt.
        if (remainH > EPS)
          next.push({ x: free.x, y: free.y + placed.h, w: free.w, h: remainH });
        if (remainW > EPS)
          next.push({
            x: free.x + placed.w,
            y: free.y,
            w: remainW,
            h: placed.h,
          });
      }
      return next;
    }

    function dimensionsFor(spec, dw, dh, angle) {
      var baseW = spec.width - dw;
      var baseH = spec.height - dh;
      if (baseW <= EPS || baseH <= EPS) return null;
      return {
        baseW: baseW,
        baseH: baseH,
        w: angle === 90 ? baseH : baseW,
        h: angle === 90 ? baseW : baseH,
      };
    }

    function bestSlotFor(spec, freeRects, dw, dh, scoreMode, splitMode) {
      var best = null;
      for (var fi = 0; fi < freeRects.length; fi++) {
        var free = freeRects[fi];
        for (var orientation = 0; orientation < 2; orientation++) {
          var angle = orientation === 0 ? 0 : 90;
          var dim = dimensionsFor(spec, dw, dh, angle);
          if (!dim || dim.w > free.w + EPS || dim.h > free.h + EPS) continue;
          var splits =
            splitMode === "adaptive" ? ["vertical", "horizontal"] : [splitMode];
          for (var splitIndex = 0; splitIndex < splits.length; splitIndex++) {
            var split = splits[splitIndex];
            var shortSide = Math.min(free.w - dim.w, free.h - dim.h);
            var longSide = Math.max(free.w - dim.w, free.h - dim.h);
            var areaLeft = free.w * free.h - dim.w * dim.h;
            var candidate = {
              pairIndex: spec.sourceIndex,
              x: free.x,
              y: free.y,
              w: dim.w,
              h: dim.h,
              baseW: dim.baseW,
              baseH: dim.baseH,
              angle: angle,
              freeIndex: fi,
              split: split,
              splitScore: splitScore(free, dim, split),
              shortSide: shortSide,
              longSide: longSide,
              areaLeft: areaLeft,
            };
            if (!best) {
              best = candidate;
              continue;
            }
            var useArea = scoreMode === "area";
            var primaryNew = useArea ? candidate.areaLeft : candidate.shortSide;
            var primaryOld = useArea ? best.areaLeft : best.shortSide;
            var secondaryNew = useArea
              ? candidate.shortSide
              : candidate.longSide;
            var secondaryOld = useArea ? best.shortSide : best.longSide;
            if (
              primaryNew < primaryOld - EPS ||
              (Math.abs(primaryNew - primaryOld) <= EPS &&
                (secondaryNew < secondaryOld - EPS ||
                  (Math.abs(secondaryNew - secondaryOld) <= EPS &&
                    (candidate.splitScore > best.splitScore + EPS ||
                      (Math.abs(candidate.splitScore - best.splitScore) <=
                        EPS &&
                        (candidate.angle < best.angle ||
                          (candidate.angle === best.angle &&
                            (candidate.y < best.y - EPS ||
                              (Math.abs(candidate.y - best.y) <= EPS &&
                                candidate.x < best.x - EPS)))))))))
            )
              best = candidate;
          }
        }
      }
      return best;
    }

    function packInOrder(order, dw, dh, scoreMode, splitMode) {
      var freeRects = [{ x: 0, y: 0, w: halfW, h: usableH }];
      var placed = [];
      var totalArea = 0;
      var normalCount = 0;
      for (var orderIndex = 0; orderIndex < order.length; orderIndex++) {
        var spec = pairSpecs[order[orderIndex]];
        var slot = bestSlotFor(spec, freeRects, dw, dh, scoreMode, splitMode);
        // Không vừa thì bỏ qua cặp này và thử mọi khổ còn lại. Không được
        // dừng theo thứ tự chọn vì một khổ nhỏ hơn có thể vẫn lấp được chỗ.
        if (!slot) continue;
        placed.push(slot);
        totalArea += slot.w * slot.h;
        if (slot.angle === 0) normalCount++;
        freeRects = splitGuillotineRect(freeRects, slot);
      }
      return { placed: placed, area: totalArea, normalCount: normalCount };
    }

    function packRepeatedOne(spec, dw, dh, scoreMode, splitMode) {
      var freeRects = [{ x: 0, y: 0, w: halfW, h: usableH }];
      var placed = [];
      var totalArea = 0;
      var normalCount = 0;
      var guard = 0;
      while (guard++ < 1000) {
        var slot = bestSlotFor(spec, freeRects, dw, dh, scoreMode, splitMode);
        if (!slot) break;
        placed.push(slot);
        totalArea += slot.w * slot.h;
        if (slot.angle === 0) normalCount++;
        freeRects = splitGuillotineRect(freeRects, slot);
      }
      return { placed: placed, area: totalArea, normalCount: normalCount };
    }

    function betterPacking(candidate, best) {
      if (!candidate) return false;
      if (!best) return true;
      if (candidate.placed.length !== best.placed.length)
        return candidate.placed.length > best.placed.length;
      if (Math.abs(candidate.area - best.area) > EPS)
        return candidate.area > best.area;
      return candidate.normalCount > best.normalCount;
    }

    function cloneOrder(source) {
      var copy = [];
      for (var c = 0; c < source.length; c++) copy.push(source[c]);
      return copy;
    }

    function rotateOrder(source, offset) {
      var rotated = [];
      for (var ro = 0; ro < source.length; ro++)
        rotated.push(source[(ro + offset) % source.length]);
      return rotated;
    }

    function appendOrder(orders, seen, order) {
      var key = order.join(",");
      if (seen[key]) return;
      seen[key] = true;
      orders.push(order);
    }

    function buildOrders() {
      var original = [];
      for (var o = 0; o < pairSpecs.length; o++) original.push(o);
      var areaDesc = cloneOrder(original);
      areaDesc.sort(function (a, b) {
        var areaA = pairSpecs[a].width * pairSpecs[a].height;
        var areaB = pairSpecs[b].width * pairSpecs[b].height;
        if (Math.abs(areaB - areaA) > EPS) return areaB - areaA;
        return a - b;
      });
      var areaAsc = cloneOrder(areaDesc);
      areaAsc.reverse();
      var longestDesc = cloneOrder(original);
      longestDesc.sort(function (a, b) {
        var edgeA = Math.max(pairSpecs[a].width, pairSpecs[a].height);
        var edgeB = Math.max(pairSpecs[b].width, pairSpecs[b].height);
        if (Math.abs(edgeB - edgeA) > EPS) return edgeB - edgeA;
        return a - b;
      });
      var shortestAsc = cloneOrder(original);
      shortestAsc.sort(function (a, b) {
        var edgeA = Math.min(pairSpecs[a].width, pairSpecs[a].height);
        var edgeB = Math.min(pairSpecs[b].width, pairSpecs[b].height);
        if (Math.abs(edgeA - edgeB) > EPS) return edgeA - edgeB;
        return a - b;
      });
      var widthDesc = cloneOrder(original);
      widthDesc.sort(function (a, b) {
        if (Math.abs(pairSpecs[b].width - pairSpecs[a].width) > EPS)
          return pairSpecs[b].width - pairSpecs[a].width;
        return a - b;
      });
      var heightDesc = cloneOrder(original);
      heightDesc.sort(function (a, b) {
        if (Math.abs(pairSpecs[b].height - pairSpecs[a].height) > EPS)
          return pairSpecs[b].height - pairSpecs[a].height;
        return a - b;
      });
      // Không đưa `original` vào: các phương án đều dựa trên kích thước,
      // không dùng thứ tự người dùng chọn làm ưu tiên đặt/xóa nguồn.
      var bases = [
        areaDesc,
        areaAsc,
        longestDesc,
        shortestAsc,
        widthDesc,
        heightDesc,
      ];
      var shifts = [0];
      if (pairSpecs.length > 2) shifts.push(1);
      if (pairSpecs.length > 5) shifts.push(Math.floor(pairSpecs.length / 3));
      if (pairSpecs.length > 9) shifts.push(Math.floor(pairSpecs.length / 2));
      if (pairSpecs.length > 40) shifts = [0, Math.floor(pairSpecs.length / 2)];
      var orders = [];
      var seen = {};
      for (var b = 0; b < bases.length; b++)
        for (var s = 0; s < shifts.length; s++)
          appendOrder(orders, seen, rotateOrder(bases[b], shifts[s]));
      return orders;
    }

    var packingOrders = buildOrders();
    function findBestPacking(dw, dh) {
      var best = null;
      // Thử cả hai hướng xả chính và một hướng tự chọn, nhưng tất cả đều là
      // các nhát guillotine nên không thể sinh bố cục hốc/L không có đường ra.
      var scoreModes = [
        { fit: "short", split: "vertical" },
        { fit: "short", split: "horizontal" },
        { fit: "area", split: "adaptive" },
      ];
      if (repeatOnePair) {
        for (var rm = 0; rm < scoreModes.length; rm++) {
          var repeated = packRepeatedOne(
            pairSpecs[0],
            dw,
            dh,
            scoreModes[rm].fit,
            scoreModes[rm].split,
          );
          if (betterPacking(repeated, best)) best = repeated;
        }
        return best;
      }
      for (var mode = 0; mode < scoreModes.length; mode++) {
        for (var order = 0; order < packingOrders.length; order++) {
          var packed = packInOrder(
            packingOrders[order],
            dw,
            dh,
            scoreModes[mode].fit,
            scoreModes[mode].split,
          );
          if (betterPacking(packed, best)) best = packed;
          if (best && best.placed.length === pairSpecs.length) return best;
        }
      }
      return best;
    }

    // Bóp chỉ được dùng nếu nó tăng số cặp đặt được. Quét từ tổng bóp nhỏ
    // đến lớn nên cùng số cặp thì kết quả luôn ưu tiên bóp nhẹ hơn.
    var bopStep = maxBop > EPS ? maxBop / 8 : 0;
    var bopSteps = maxBop > EPS ? 8 : 0;
    var bopCandidates = [{ dw: 0, dh: 0, cost: 0 }];
    for (var bx = 0; bx <= bopSteps; bx++) {
      for (var by = 0; by <= bopSteps; by++) {
        if (bx === 0 && by === 0) continue;
        bopCandidates.push({
          dw: bx * bopStep,
          dh: by * bopStep,
          cost: (bx + by) * bopStep,
        });
      }
    }
    bopCandidates.sort(function (a, b) {
      return a.cost - b.cost;
    });

    var bestPacking = null;
    var pickDw = 0;
    var pickDh = 0;
    var bestBopCost = 0;
    for (var bc = 0; bc < bopCandidates.length; bc++) {
      if (
        !repeatOnePair &&
        bestPacking &&
        bestPacking.placed.length === pairSpecs.length
      )
        break;
      var bopCandidate = bopCandidates[bc];
      var candidatePacking = findBestPacking(bopCandidate.dw, bopCandidate.dh);
      if (!candidatePacking || candidatePacking.placed.length <= 0) continue;
      if (
        !bestPacking ||
        candidatePacking.placed.length > bestPacking.placed.length ||
        (candidatePacking.placed.length === bestPacking.placed.length &&
          (bopCandidate.cost < bestBopCost - EPS ||
            (Math.abs(bopCandidate.cost - bestBopCost) <= EPS &&
              betterPacking(candidatePacking, bestPacking))))
      ) {
        bestPacking = candidatePacking;
        pickDw = bopCandidate.dw;
        pickDh = bopCandidate.dh;
        bestBopCost = bopCandidate.cost;
      }
    }
    if (!bestPacking || bestPacking.placed.length <= 0)
      return "ERR: Không có cặp nào nằm vừa nửa tờ giấy. Tự trở cần mỗi mặt lọt vào một nửa khổ; hãy tăng khổ giấy hoặc giảm lề an toàn.";

    // ---- tạo artboard ở vùng trống, cùng cách của dàn một khổ ----
    function uniqueLayerName(base) {
      var candidate = base;
      var suffix = 2;
      var exists = true;
      while (exists) {
        exists = false;
        for (var li = 0; li < doc.layers.length; li++) {
          try {
            if (doc.layers[li].name === candidate) {
              exists = true;
              candidate = base + " " + suffix;
              suffix++;
              break;
            }
          } catch (e) {}
        }
      }
      return candidate;
    }

    function addOutputLayer(name) {
      var layer = doc.layers.add();
      layer.name = uniqueLayerName(name);
      try {
        layer.locked = false;
        layer.visible = true;
      } catch (e) {}
      return layer;
    }

    function prepareOutputLayer(layer) {
      try {
        layer.locked = false;
        layer.visible = true;
        doc.activeLayer = layer;
      } catch (e) {}
    }

    function artboardsOverlap(a, b) {
      return (
        a[0] < b[2] - EPS &&
        a[2] > b[0] + EPS &&
        a[3] < b[1] - EPS &&
        a[1] > b[3] + EPS
      );
    }

    function rectContains(outer, inner) {
      return (
        outer[0] <= inner[0] + EPS &&
        outer[1] >= inner[1] - EPS &&
        outer[2] >= inner[2] - EPS &&
        outer[3] <= inner[3] + EPS
      );
    }

    function readCanvasBounds() {
      var halfSize = 7200;
      try {
        if (doc.scaleFactor && doc.scaleFactor < 1)
          halfSize = halfSize / doc.scaleFactor;
      } catch (e) {}
      return [-halfSize, halfSize, halfSize, -halfSize];
    }

    var pageGap = 10 * MM;
    var canvasRect = readCanvasBounds();
    var canvasWidth = canvasRect[2] - canvasRect[0];
    var canvasHeight = canvasRect[1] - canvasRect[3];
    var occupied = [];
    for (var abi = 0; abi < doc.artboards.length; abi++) {
      try {
        var existing = doc.artboards[abi].artboardRect.slice(0);
        if (
          existing[2] - existing[0] >= canvasWidth * 0.92 &&
          existing[1] - existing[3] >= canvasHeight * 0.92
        )
          continue;
        occupied.push(existing);
      } catch (e) {}
    }
    // Bài cũ còn trên canvas (khung đã xoá ở lượt trước) cũng là vùng bận.
    var sourceItemsNk = [];
    for (var sk = 0; sk < pairs.length; sk++)
      sourceItemsNk.push(pairs[sk].front, pairs[sk].back);
    occupied = occupied.concat(dcVungBaiCu(doc, canvasRect, sourceItemsNk));
    var sourceCovered = false;
    for (var occ = 0; occ < occupied.length; occ++) {
      if (rectContains(occupied[occ], sourceBounds)) {
        sourceCovered = true;
        break;
      }
    }
    if (!sourceCovered) occupied.push(sourceBounds.slice(0));

    function reserveSheetRect() {
      var leftLimit = canvasRect[0] + pageGap;
      var topLimit = canvasRect[1] - pageGap;
      var rightLimit = canvasRect[2] - pageGap;
      var bottomLimit = canvasRect[3] + pageGap;
      var candidateLeft = leftLimit;
      var candidateTop = topLimit;
      var tries = 0;
      while (tries++ < 5000) {
        if (candidateLeft + paperW > rightLimit + EPS) {
          candidateLeft = leftLimit;
          candidateTop -= paperH + pageGap;
          continue;
        }
        if (candidateTop - paperH < bottomLimit - EPS)
          throw new Error(
            "Không còn chỗ trong canvas để tạo tờ mới. Hãy bớt artboard cũ hoặc bài cũ còn trên canvas, hoặc mở Large Canvas.",
          );
        var rect = [
          candidateLeft,
          candidateTop,
          candidateLeft + paperW,
          candidateTop - paperH,
        ];
        var blocker = null;
        for (var oi = 0; oi < occupied.length; oi++) {
          if (artboardsOverlap(rect, occupied[oi])) {
            blocker = occupied[oi];
            break;
          }
        }
        if (blocker) {
          candidateLeft = blocker[2] + pageGap;
          continue;
        }
        occupied.push(rect);
        return rect;
      }
      throw new Error(
        "Không tìm được vị trí trong canvas để đặt artboard mới.",
      );
    }

    function addOutputArtboard(rect, name) {
      var index = doc.artboards.length;
      var board = doc.artboards.add(rect);
      try {
        board.name = name || "Tự trở nhiều khổ " + (index + 1);
      } catch (e) {}
      return index;
    }

    function resizeAtCenter(item, scaleX, scaleY) {
      var before = boundsOf(item);
      if (!before) throw new Error("Không đo được bài trước khi bóp.");
      var cx = (before[0] + before[2]) / 2;
      var cy = (before[1] + before[3]) / 2;
      try {
        item.resize(
          scaleX * 100,
          scaleY * 100,
          true,
          true,
          true,
          true,
          100,
          Transformation.CENTER,
        );
      } catch (e) {
        item.resize(scaleX * 100, scaleY * 100);
      }
      var after = boundsOf(item);
      if (!after) throw new Error("Không đo được bài sau khi bóp.");
      item.translate(
        cx - (after[0] + after[2]) / 2,
        cy - (after[1] + after[3]) / 2,
      );
      return boundsOf(item);
    }

    function makeSqueezedMaster(source, layer, targetW, targetH) {
      var master = source.duplicate(layer, ElementPlacement.PLACEATEND);
      var before = sizeOfBounds(boundsOf(master));
      if (!before) throw new Error("Kích thước bài không hợp lệ.");
      if (
        Math.abs(before.width - targetW) <= 0.05 &&
        Math.abs(before.height - targetH) <= 0.05
      )
        return master;
      var probe = sizeOfBounds(resizeAtCenter(master, 1.01, 1));
      if (!probe) throw new Error("Không đo được trục bóp của bài.");
      var xChangesWidth =
        Math.abs(probe.width - before.width) >=
        Math.abs(probe.height - before.height);
      var scaleX = xChangesWidth
        ? targetW / probe.width
        : targetH / probe.height;
      var scaleY = xChangesWidth
        ? targetH / probe.height
        : targetW / probe.width;
      if (!isFinite(scaleX) || !isFinite(scaleY) || scaleX <= 0 || scaleY <= 0)
        throw new Error("Không tính được tỷ lệ bóp.");
      var resized = sizeOfBounds(resizeAtCenter(master, scaleX, scaleY));
      if (
        resized &&
        (Math.abs(resized.width - targetW) > 0.5 ||
          Math.abs(resized.height - targetH) > 0.5)
      ) {
        var fixX = xChangesWidth
          ? targetW / resized.width
          : targetH / resized.height;
        var fixY = xChangesWidth
          ? targetH / resized.height
          : targetW / resized.width;
        resizeAtCenter(master, fixX, fixY);
      }
      return master;
    }

    function squeezedFaceSize(source, spec, targetW, targetH) {
      var sourceSize = sizeOfBounds(boundsOf(source));
      if (!sourceSize) throw new Error("Không đo được kích thước bài để bóp.");
      return {
        width: (sourceSize.width * targetW) / spec.width,
        height: (sourceSize.height * targetH) / spec.height,
      };
    }

    function copyAt(source, layer, left, top, angle, slotW, slotH) {
      var copy = source.duplicate(layer, ElementPlacement.PLACEATEND);
      if (angle !== 0) copy.rotate(angle);
      var bounds = boundsOf(copy);
      if (!bounds) throw new Error("Không đo được bản sao để đặt vào tờ giấy.");
      var itemW = bounds[2] - bounds[0];
      var itemH = bounds[1] - bounds[3];
      var targetLeft = left + Math.max(0, (slotW - itemW) / 2);
      var targetTop = top - Math.max(0, (slotH - itemH) / 2);
      copy.translate(targetLeft - bounds[0], targetTop - bounds[1]);
      return copy;
    }

    // PON giấy luôn bám đúng bốn góc artboard, không phụ thuộc khổ nhập.
    function addPaperPonAtCorners(layer, rect) {
      var markLength = 3 * MM;
      var strokeWidth = 1.995;
      var black = new CMYKColor();
      black.cyan = 0;
      black.magenta = 0;
      black.yellow = 0;
      black.black = 100;
      function draw(x1, y1, x2, y2) {
        var mark = layer.pathItems.add();
        mark.setEntirePath([
          [x1, y1],
          [x2, y2],
        ]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = strokeWidth;
      }
      // Kích thước artboard là tâm của bốn PON giấy.
      var left = rect[0];
      var top = rect[1];
      var right = rect[2];
      var bottom = rect[3];
      draw(left, top, left + markLength, top);
      draw(left, top, left, top - markLength);
      draw(right - markLength, top, right, top);
      draw(right, top, right, top - markLength);
      draw(left, bottom, left + markLength, bottom);
      draw(left, bottom, left, bottom + markLength);
      draw(right - markLength, bottom, right, bottom);
      draw(right, bottom, right, bottom + markLength);
    }

    // ---- đổi slot cục bộ thành tọa độ tờ, gom theo cặp đã thực sự đặt ----
    var sheetRect = reserveSheetRect();
    var backSheetRect = isAB ? reserveSheetRect() : sheetRect;
    var sheetArtboardIndex = addOutputArtboard(
      sheetRect,
      isAB ? "Dàn Offset AB - Mặt A" : "Tự trở nhiều khổ",
    );
    var backArtboardIndex = isAB
      ? addOutputArtboard(backSheetRect, "Dàn Offset AB - Mặt B")
      : sheetArtboardIndex;
    var safeLeft = sheetRect[0] + MARGIN;
    var safeTop = sheetRect[1] - MARGIN;
    var backSafeLeft = backSheetRect[0] + MARGIN;
    var backSafeTop = backSheetRect[1] - MARGIN;
    var placedSlots = bestPacking.placed.slice(0);
    placedSlots.sort(function (a, b) {
      if (Math.abs(a.y - b.y) > EPS) return a.y - b.y;
      return a.x - b.x;
    });
    // Không để một khoảng trắng nhân tạo ở tim tờ tự trở. AB dùng toàn bộ
    // khổ ở mỗi artboard nên không dịch cụm này.
    if (!isAB) {
      var packedRight = 0;
      for (var psr = 0; psr < placedSlots.length; psr++)
        packedRight = Math.max(
          packedRight,
          placedSlots[psr].x + placedSlots[psr].w,
        );
      var packedCenterShift = halfW - packedRight;
      if (packedCenterShift > EPS)
        for (psr = 0; psr < placedSlots.length; psr++)
          placedSlots[psr].x += packedCenterShift;
    }
    var assignments = [];
    var assignmentByPair = {};
    for (var sl = 0; sl < placedSlots.length; sl++) {
      var localSlot = placedSlots[sl];
      var key = String(localSlot.pairIndex);
      if (assignmentByPair[key] === undefined) {
        assignmentByPair[key] = assignments.length;
        assignments.push({ pairIndex: localSlot.pairIndex, slots: [] });
      }
      assignments[assignmentByPair[key]].slots.push({
        x: safeLeft + localSlot.x,
        y: safeTop - localSlot.y,
        w: localSlot.w,
        h: localSlot.h,
        baseW: localSlot.baseW,
        baseH: localSlot.baseH,
        angle: localSlot.angle,
      });
    }

    var frontLayer = addOutputLayer("Dàn tự trở - Mặt trước");
    var backLayer = addOutputLayer("Dàn tự trở - Mặt sau");
    var needSqueeze = pickDw > EPS || pickDh > EPS;
    var placedItems = [];

    for (var asi = 0; asi < assignments.length; asi++) {
      var assignment = assignments[asi];
      var pair = pairs[assignment.pairIndex];
      var spec = pairSpecs[assignment.pairIndex];
      var firstSlot = assignment.slots[0];
      var frontSource = pair.front;
      var backSource = pair.back;
      if (needSqueeze) {
        prepareOutputLayer(frontLayer);
        var frontTarget = squeezedFaceSize(
          pair.front,
          spec,
          firstSlot.baseW,
          firstSlot.baseH,
        );
        frontSource = makeSqueezedMaster(
          pair.front,
          frontLayer,
          frontTarget.width,
          frontTarget.height,
        );
        prepareOutputLayer(backLayer);
        var backTarget = squeezedFaceSize(
          pair.back,
          spec,
          firstSlot.baseW,
          firstSlot.baseH,
        );
        backSource = makeSqueezedMaster(
          pair.back,
          backLayer,
          backTarget.width,
          backTarget.height,
        );
      }

      prepareOutputLayer(frontLayer);
      for (var fs = 0; fs < assignment.slots.length; fs++) {
        var frontSlot = assignment.slots[fs];
        placedItems.push(
          copyAt(
            frontSource,
            frontLayer,
            frontSlot.x,
            frontSlot.y,
            frontSlot.angle,
            frontSlot.w,
            frontSlot.h,
          ),
        );
      }

      prepareOutputLayer(backLayer);
      for (var bs = 0; bs < assignment.slots.length; bs++) {
        var backSlot = assignment.slots[bs];
        var mirroredLeft = isAB
          ? backSafeLeft + (backSlot.x - safeLeft)
          : safeLeft + usableW - (backSlot.x - safeLeft) - backSlot.w;
        var mirroredTop = isAB
          ? backSafeTop - (safeTop - backSlot.y)
          : backSlot.y;
        var backAngle = isAB ? backSlot.angle : backSlot.angle === 90 ? -90 : 0;
        placedItems.push(
          copyAt(
            backSource,
            backLayer,
            mirroredLeft,
            mirroredTop,
            backAngle,
            backSlot.w,
            backSlot.h,
          ),
        );
      }

      if (needSqueeze) {
        try {
          frontSource.remove();
        } catch (e) {}
        try {
          backSource.remove();
        } catch (e) {}
      }
      // Chỉ lúc cả trước lẫn sau của cặp này đã sao xong mới bỏ nguồn.
      try {
        pair.front.remove();
      } catch (e) {}
      try {
        pair.back.remove();
      } catch (e) {}
    }

    {
      var paperPonLayer = addOutputLayer(
        isAB ? "PON giấy Dàn Offset AB" : "PON giấy Dàn Offset",
      );
      addPaperPonAtCorners(paperPonLayer, sheetRect);
      if (isAB) addPaperPonAtCorners(paperPonLayer, backSheetRect);
      try {
        paperPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
        paperPonLayer.locked = true;
      } catch (paperPonLayerError) {}
    }

    var cleanup = dcRemoveOldCanvasArtboards(doc, oldCanvasArtboardCount);
    sheetArtboardIndex = cleanup.firstNewIndex;
    var outputWasSelected = false;
    try {
      doc.artboards.setActiveArtboardIndex(sheetArtboardIndex);
      doc.selection = null;
      frontLayer.hasSelectedArtwork = true;
      backLayer.hasSelectedArtwork = true;
      prepareOutputLayer(frontLayer);
      outputWasSelected = true;
    } catch (e) {}

    function formatCm(pt) {
      return (Math.round((pt / (10 * MM)) * 100) / 100).toString();
    }
    function formatMm(pt) {
      return (Math.round((pt / MM) * 100) / 100).toString();
    }

    var placedCount = placedSlots.length;
    var placedUnique = assignments.length;
    var leftOver = repeatOnePair ? 0 : pairs.length - placedUnique;
    var detail =
      "Tờ " +
      formatCm(paperW) +
      " × " +
      formatCm(paperH) +
      " cm: đã dàn " +
      placedCount +
      (repeatOnePair ? " lần của 1 cặp" : " / " + pairs.length + " cặp") +
      (isAB
        ? ". Đã tạo 2 artboard A/B cùng khổ; mỗi artboard có PON giấy ở 4 góc."
        : ". Mỗi cặp có 1 mặt trước + 1 mặt sau đối xứng tự trở.");
    if (needSqueeze) {
      var bopParts = [];
      if (pickDw > EPS) bopParts.push("ngang " + formatMm(pickDw) + " mm");
      if (pickDh > EPS) bopParts.push("dọc " + formatMm(pickDh) + " mm");
      detail += " Đã bóp " + bopParts.join(", ") + " để dàn thêm được cặp.";
    } else detail += " Giữ nguyên kích thước, không cần bóp.";
    detail += " Lề an toàn " + marginMm + " mm.";
    if (repeatIgnoredForMixed)
      detail +=
        " Đã bỏ qua Lặp lại mẫu vì đang chọn nhiều cặp: mỗi cặp chỉ dàn một lần.";
    if (leftOver > 0)
      detail +=
        " Còn " +
        leftOver +
        " cặp chưa dàn, giữ nguyên ở vị trí cũ để chạy tờ tiếp theo.";
    else if (!repeatOnePair)
      detail += " Đã dàn hết các cặp nguồn chọn vào tờ này.";
    detail += isAB
      ? " Mặt A và mặt B đã nằm trên hai artboard riêng."
      : " In xong lật ngang tờ giấy rồi in lại bằng chính bản kẽm đó.";
    if (!outputWasSelected)
      detail +=
        " Artwork nằm trên layer Dàn tự trở; Illustrator không tự chọn được toàn bộ trong tài liệu này.";
    return "OK:[[COUNT:" + placedCount + "]] " + detail + cleanup.warning;
  } catch (e) {
    try {
      return "ERR: " + dcMoTaLoi(e);
    } catch (fallbackError) {
      return "ERR: " + e;
    }
  }
}

// Dàn bế: đọc/vẽ trong dan_be_bridge.jsx; tính tối ưu trong js/dan_be_nester.js.

// ============================================================
//  HÀM TEST kết nối (Bước 1) — giữ lại để panel kiểm tra.
// ============================================================
function dcTestConnection() {
  try {
    var n = app.documents.length;
    var docName = n > 0 ? app.activeDocument.name : "(chưa mở tài liệu)";
    return (
      "Kết nối OK!\n" +
      "Illustrator " +
      app.version +
      "\n" +
      "Đang mở: " +
      n +
      " tài liệu\n" +
      "Hiện hành: " +
      docName
    );
  } catch (e) {
    return "Lỗi: " + e.toString();
  }
}

// Dự phòng cho việc gọi trực tiếp từ ExtendScript.
// Nút Raster trên panel chạy cùng logic nhưng không phụ thuộc vào JSX đang cache.
function dcRasterizeSelection() {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";

    var doc = app.activeDocument;
    var selection = doc.selection;
    if (!selection || selection.length === 0) {
      return "ERR: Hãy chọn ít nhất 1 object để raster.";
    }

    var selectedItems = [];
    for (var i = 0; i < selection.length; i++) selectedItems.push(selection[i]);

    // Dùng Color Mode của document. Một số Illustrator báo lỗi khi gán trực
    // tiếp RasterizationColorModel.CMYK, dù tài liệu đã ở CMYK.
    if (doc.documentColorSpace !== DocumentColorSpace.CMYK) {
      return "ERR: Tài liệu đang ở RGB. Hãy đổi File > Document Color Mode > CMYK Color rồi bấm Raster.";
    }

    var options = new RasterizeOptions();
    options.resolution = 500;
    options.transparency = true;
    options.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
    options.clippingMask = false;
    options.padding = 0;
    options.convertSpotColors = false;

    // visibleBounds của clipping group đôi khi vẫn tính phần ảnh bị mask che.
    // Lấy geometricBounds của clipping path để raster đúng phần đang hiển thị.
    // Nếu chọn ảnh con trong clipping group, raster cả group cha để giữ mask.
    function getRasterTarget(item) {
      var current = item;
      while (current) {
        try {
          if (current.typename === "GroupItem" && current.clipped === true)
            return current;
          current = current.parent;
        } catch (parentError) {
          break;
        }
      }
      return item;
    }

    // Đo vùng HIỂN THỊ thực tế, kể cả group lồng nhau có clipping mask.
    // Không dùng visibleBounds trực tiếp vì Illustrator có thể cộng cả ảnh
    // bị giấu phía sau mask vào bounds của group.
    function getRasterBounds(item) {
      function merge(acc, b) {
        if (!b) return;
        if (!acc.val) {
          acc.val = [b[0], b[1], b[2], b[3]];
          return;
        }
        if (b[0] < acc.val[0]) acc.val[0] = b[0];
        if (b[1] > acc.val[1]) acc.val[1] = b[1];
        if (b[2] > acc.val[2]) acc.val[2] = b[2];
        if (b[3] < acc.val[3]) acc.val[3] = b[3];
      }
      function clipBounds(group) {
        try {
          var p = group.pageItems;
          for (var i = 0; i < p.length; i++) {
            if (p[i].clipping === true) return p[i].geometricBounds;
          }
        } catch (clipError) {}
        return null;
      }
      function collect(node, acc) {
        var type = "";
        try {
          type = node.typename;
        } catch (typeError) {
          return;
        }
        if (type === "GroupItem") {
          var mask = null;
          try {
            if (node.clipped === true) mask = clipBounds(node);
          } catch (groupError) {}
          var children = node.pageItems;
          var inner = { val: null };
          for (var j = 0; j < children.length; j++) {
            var isMask = false;
            try {
              isMask = children[j].clipping === true;
            } catch (childError) {}
            if (!isMask) collect(children[j], inner);
          }
          if (mask && inner.val) {
            var hit = [
              Math.max(mask[0], inner.val[0]),
              Math.min(mask[1], inner.val[1]),
              Math.min(mask[2], inner.val[2]),
              Math.max(mask[3], inner.val[3]),
            ];
            merge(acc, hit[2] > hit[0] && hit[1] > hit[3] ? hit : mask);
          } else if (mask) {
            merge(acc, mask);
          } else if (inner.val) {
            merge(acc, inner.val);
          }
          return;
        }
        try {
          merge(acc, node.visibleBounds);
        } catch (boundsError) {
          try {
            merge(acc, node.geometricBounds);
          } catch (ignoreBoundsError) {}
        }
      }

      var result = { val: null };
      collect(item, result);
      if (result.val) return result.val;
      try {
        return [
          item.geometricBounds[0],
          item.geometricBounds[1],
          item.geometricBounds[2],
          item.geometricBounds[3],
        ];
      } catch (fallbackError) {
        return [
          item.visibleBounds[0],
          item.visibleBounds[1],
          item.visibleBounds[2],
          item.visibleBounds[3],
        ];
      }
    }

    // Không raster lặp lại khi chọn nhiều object con của cùng một clipping group.
    var sources = [];
    for (var s = 0; s < selectedItems.length; s++) {
      var target = getRasterTarget(selectedItems[s]);
      var found = false;
      for (var q = 0; q < sources.length; q++) {
        if (sources[q] === target) {
          found = true;
          break;
        }
      }
      if (!found) sources.push(target);
    }

    var rasters = [];
    var errors = [];
    for (var j = 0; j < sources.length; j++) {
      try {
        var item = sources[j];
        var bounds = getRasterBounds(item);
        var raster = doc.rasterize(item, bounds, options);
        if (!raster) throw new Error("Illustrator không trả về RasterItem.");
        rasters.push(raster);
      } catch (itemError) {
        errors.push("Object " + (j + 1) + ": " + dcMoTaLoi(itemError));
      }
    }

    if (rasters.length > 0) doc.selection = rasters;
    app.redraw();

    if (errors.length > 0) {
      return (
        "ERR: Raster được " +
        rasters.length +
        "/" +
        sources.length +
        " object.\n" +
        errors.join("\n")
      );
    }
    return (
      "OK: Đã raster " +
      rasters.length +
      " object — CMYK, 500 ppi, nền trong suốt."
    );
  } catch (e) {
    return "ERR: " + dcMoTaLoi(e);
  }
}

// ============================================================
//  TAB ĐỔI TÊN: đổi tên hàng loạt object đã chọn.
//  Tham số:
//   prefix   : tiền tố (vd "s")
//   mode     : "num" | "low" | "up"
//   startStr : bắt đầu (số "1" hoặc chữ "a"/"A")
//   pad      : đệm số 0 (chỉ kiểu num), 0 = không đệm
//   bottomUp : true = dưới cùng đầu tiên; false = trên cùng đầu tiên
// ============================================================
function dcRename(prefix, mode, startStr, pad, bottomUp, repeat) {
  if (app.documents.length === 0) return "ERR: Chưa mở tài liệu.";
  var doc = app.activeDocument;
  var sel = doc.selection;
  if (!sel || sel.length === 0) return "ERR: Chưa chọn object nào.";

  prefix = prefix || "";
  mode = mode || "num";
  startStr = (startStr || "").replace(/^\s+|\s+$/g, "");
  pad = parseInt(pad, 10);
  if (isNaN(pad)) pad = 0;
  repeat = parseInt(repeat, 10);
  if (isNaN(repeat) || repeat < 1) repeat = 1; // số layer lặp mỗi nhãn (s1,s1,s2,s2)

  // Đệm số 0 phía trước cho đủ độ dài (vd 3 -> 003).
  function _pad(n, len) {
    var s = "" + n;
    while (s.length < len) s = "0" + s;
    return s;
  }
  // Đổi số thành chữ cái (1->a, 2->b... 27->aa). upper=true thì HOA.
  function toAlpha(num, upper) {
    var s = "";
    while (num > 0) {
      var r = (num - 1) % 26;
      s = String.fromCharCode((upper ? 65 : 97) + r) + s;
      num = Math.floor((num - 1) / 26);
    }
    return s;
  }
  // Đổi chữ cái thành số (a->1, b->2...).
  function fromAlpha(str) {
    str = str.toLowerCase();
    var num = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i) - 97;
      if (c < 0 || c > 25) return 1;
      num = num * 26 + (c + 1);
    }
    return num;
  }

  var startVal;
  if (mode === "num") {
    startVal = parseInt(startStr, 10);
    if (isNaN(startVal)) startVal = 1;
  } else {
    if (/^[a-zA-Z]+$/.test(startStr)) startVal = fromAlpha(startStr);
    else {
      startVal = parseInt(startStr, 10);
      if (isNaN(startVal)) startVal = 1;
    }
  }

  function label(i) {
    var v = startVal + i;
    if (mode === "num") return prefix + (pad > 0 ? _pad(v, pad) : v);
    return prefix + toAlpha(v, mode === "up");
  }

  var arr = [];
  for (var i = 0; i < sel.length; i++) arr.push(sel[i]);
  arr.sort(function (a, b) {
    return a.zOrderPosition - b.zOrderPosition;
  });
  if (!bottomUp) arr.reverse();

  for (var k = 0; k < arr.length; k++) {
    var groupIndex = Math.floor(k / repeat); // repeat=2 -> s1,s1,s2,s2
    arr[k].name = label(groupIndex);
  }

  var lastGroup = Math.floor((arr.length - 1) / repeat);
  return (
    "OK: Đã đổi tên " +
    arr.length +
    " object (" +
    label(0) +
    " ... " +
    label(lastGroup) +
    ")."
  );
}

// ============================================================
//  TAB VARIABLE: chạy công cụ VariableImporter (UI gốc ScriptUI).
//  Nhúng nguyên script; hàm dcRunVariable() gọi khi bấm nút.
// ============================================================

function VariableImporter() {
  if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (searchElement, fromIndex) {
      var k;
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }
      var o = Object(this);
      var len = o.length >>> 0;
      if (len === 0) {
        return -1;
      }
      var n = +fromIndex || 0;
      if (Math.abs(n) === Infinity) {
        n = 0;
      }
      if (n >= len) {
        return -1;
      }
      k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
      while (k < len) {
        if (k in o && o[k] === searchElement) {
          return k;
        }
        k++;
      }
      return -1;
    };
  }

  Array.prototype.compare = function (array) {
    // nếu mảng kia là giá trị falsy thì trả về luôn
    if (!array) return false;

    // so sánh độ dài - có thể tiết kiệm rất nhiều thời gian
    if (this.length != array.length) return false;

    this.sort();
    array.sort();
    for (var i = 0; i < this.length; i++) {
      // Kiểm tra xem có mảng lồng nhau không
      if (this[i] instanceof Array && array[i] instanceof Array) {
        // đệ quy vào các mảng lồng nhau
        if (!this[i].compare(array[i])) {
          return false;
        }
      } else if (this[i] != array[i]) {
        // Cảnh báo - hai instance object khác nhau thì không bao giờ bằng nhau: {x:20} != {x:20}
        return false;
      }
    }
    return true;
  };

  //http://stackoverflow.com/a/25094986/2864371
  function arrayMakeUnique(arr) {
    if (arr.length < 1) {
      return [];
    }
    var a = arr.slice(0);
    var b = a.length,
      c;
    while ((c = --b)) {
      while (c--) {
        a[b] !== a[c] || a.splice(c, 1);
      }
    }
    return a;
  }

  function arrayGetAllDuplicates(arr) {
    if (arr.length < 1) {
      return [];
    }
    var a = arr.slice(0);
    var b = a.length,
      d = [],
      c;
    while ((c = --b)) {
      while (c--) {
        a[b] !== a[c] || d.push(a.splice(c, 1)[0]);
      }
    }
    return d;
  }

  function arrayGetUniqueDuplicates(arr) {
    return arrayMakeUnique(arrayGetAllDuplicates(arr));
  }

  function checkForSingleDuplicate(array, value) {
    var found = [],
      thisCell;
    for (var i = 0; i < array.length; i++) {
      thisCell = array[i];
      if (thisCell == value) {
        found.push(value);
      }
    }
    return found;
  }

  ("object" != typeof JSON && (JSON = {}),
    (function () {
      "use strict";
      function f(t) {
        return 10 > t ? "0" + t : t;
      }
      function quote(t) {
        return (
          (escapable.lastIndex = 0),
          escapable.test(t)
            ? '"' +
              t.replace(escapable, function (t) {
                var e = meta[t];
                return "string" == typeof e
                  ? e
                  : "\\u" + ("0000" + t.charCodeAt(0).toString(16)).slice(-4);
              }) +
              '"'
            : '"' + t + '"'
        );
      }
      function str(t, e) {
        var n,
          r,
          o,
          f,
          u,
          i = gap,
          p = e[t];
        switch (
          (p &&
            "object" == typeof p &&
            "function" == typeof p.toJSON &&
            (p = p.toJSON(t)),
          "function" == typeof rep && (p = rep.call(e, t, p)),
          typeof p)
        ) {
          case "string":
            return quote(p);
          case "number":
            return isFinite(p) ? String(p) : "null";
          case "boolean":
          case "null":
            return String(p);
          case "object":
            if (!p) return "null";
            if (
              ((gap += indent),
              (u = []),
              "[object Array]" === Object.prototype.toString.apply(p))
            ) {
              for (f = p.length, n = 0; f > n; n += 1)
                u[n] = str(n, p) || "null";
              return (
                (o =
                  0 === u.length
                    ? "[]"
                    : gap
                      ? "[\n" + gap + u.join(",\n" + gap) + "\n" + i + "]"
                      : "[" + u.join(",") + "]"),
                (gap = i),
                o
              );
            }
            if (rep && "object" == typeof rep)
              for (f = rep.length, n = 0; f > n; n += 1)
                "string" == typeof rep[n] &&
                  ((r = rep[n]),
                  (o = str(r, p)),
                  o && u.push(quote(r) + (gap ? ": " : ":") + o));
            else
              for (r in p)
                Object.prototype.hasOwnProperty.call(p, r) &&
                  ((o = str(r, p)),
                  o && u.push(quote(r) + (gap ? ": " : ":") + o));
            return (
              (o =
                0 === u.length
                  ? "{}"
                  : gap
                    ? "{\n" + gap + u.join(",\n" + gap) + "\n" + i + "}"
                    : "{" + u.join(",") + "}"),
              (gap = i),
              o
            );
        }
      }
      "function" != typeof Date.prototype.toJSON &&
        ((Date.prototype.toJSON = function () {
          return isFinite(this.valueOf())
            ? this.getUTCFullYear() +
                "-" +
                f(this.getUTCMonth() + 1) +
                "-" +
                f(this.getUTCDate()) +
                "T" +
                f(this.getUTCHours()) +
                ":" +
                f(this.getUTCMinutes()) +
                ":" +
                f(this.getUTCSeconds()) +
                "Z"
            : null;
        }),
        (String.prototype.toJSON =
          Number.prototype.toJSON =
          Boolean.prototype.toJSON =
            function () {
              return this.valueOf();
            }));
      var cx, escapable, gap, indent, meta, rep;
      ("function" != typeof JSON.stringify &&
        ((escapable =
          /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g),
        (meta = {
          "\b": "\\b",
          "  ": "\\t",
          "\n": "\\n",
          "\f": "\\f",
          "\r": "\\r",
          '"': '\\"',
          "\\": "\\\\",
        }),
        (JSON.stringify = function (t, e, n) {
          var r;
          if (((gap = ""), (indent = ""), "number" == typeof n))
            for (r = 0; n > r; r += 1) indent += " ";
          else "string" == typeof n && (indent = n);
          if (
            ((rep = e),
            e &&
              "function" != typeof e &&
              ("object" != typeof e || "number" != typeof e.length))
          )
            throw new Error("JSON.stringify");
          return str("", { "": t });
        })),
        "function" != typeof JSON.parse &&
          ((cx =
            /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g),
          (JSON.parse = function (text, reviver) {
            function walk(t, e) {
              var n,
                r,
                o = t[e];
              if (o && "object" == typeof o)
                for (n in o)
                  Object.prototype.hasOwnProperty.call(o, n) &&
                    ((r = walk(o, n)), void 0 !== r ? (o[n] = r) : delete o[n]);
              return reviver.call(t, e, o);
            }
            var j;
            if (
              ((text = String(text)),
              (cx.lastIndex = 0),
              cx.test(text) &&
                (text = text.replace(cx, function (t) {
                  return (
                    "\\u" + ("0000" + t.charCodeAt(0).toString(16)).slice(-4)
                  );
                })),
              /^[\],:{}\s]*$/.test(
                text
                  .replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@")
                  .replace(
                    /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
                    "]",
                  )
                  .replace(/(?:^|:|,)(?:\s*\[)+/g, ""),
              ))
            )
              return (
                (j = eval("(" + text + ")")),
                "function" == typeof reviver ? walk({ "": j }, "") : j
              );
            throw new SyntaxError("JSON.parse");
          })));
    })());

  var tvdhve = "These violent delights have violent ends...";

  function clone(obj) {
    var copy;
    // Xử lý 3 kiểu đơn giản, cùng với null hoặc undefined
    if (null == obj || "object" != typeof obj) return obj;
    // Xử lý Date
    if (obj instanceof Date) {
      copy = new Date();
      copy.setTime(obj.getTime());
      return copy;
    }
    // Xử lý Array
    if (obj instanceof Array) {
      copy = [];
      for (var i = 0, len = obj.length; i < len; i++) {
        copy[i] = clone(obj[i]);
      }
      return copy;
    }
    // Xử lý Object
    if (obj instanceof Object) {
      copy = {};
      for (var attr in obj) {
        if (obj.hasOwnProperty(attr)) copy[attr] = clone(obj[attr]);
      }
      return copy;
    }
    throw new Error("Unable to copy obj! Its type isn't supported.");
  }

  String.prototype.trim = function () {
    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  };

  if (!Array.prototype.forEach) {
    Array.prototype.forEach = function (callback, thisArg) {
      var T, k;
      if (this == null) {
        throw new TypeError(" this is null or not defined");
      }
      var O = Object(this);
      var len = O.length >>> 0;
      if (typeof callback !== "function") {
        throw new TypeError(callback + " is not a function");
      }
      if (arguments.length > 1) {
        T = thisArg;
      }
      k = 0;
      while (k < len) {
        var kValue;
        if (k in O) {
          kValue = O[k];
          callback.call(T, kValue, k, O);
        }
        k++;
      }
    };
  }

  function unCamelCaseSplit(str) {
    var newStr =
      str[0].toUpperCase() +
      str
        .split(/([A-Z][a-z]+)/g)
        .join(" ")
        .replace(/\s{2}/g, " ")
        .substr(1);
    return newStr;
  }

  Number.prototype.padZero = function (decimals) {
    if (typeof decimals == "undefined") {
      decimals = 2;
    }
    var numStr = this.toString();
    var decimalsFound = numStr.length;
    if (decimalsFound >= decimals) {
      return this;
    }
    while (decimalsFound < decimals) {
      numStr = "0" + numStr;
      decimalsFound += 1;
    }
    return numStr;
  };

  function writeImageFile(binary, dest) {
    if ((!dest) instanceof "File") {
      dest = File(dest);
    }
    try {
      dest.encoding = "BINARY";
      dest.open("w");
      dest.write(binary);
      dest.close();
    } catch (e) {
      scriptAlert("writeImageFile(binary, dest)\r" + e);
    }
  }

  function getScriptImage(imageObj) {
    var scriptDataFolder = SESSION.scriptDataFolder;
    if (!scriptDataFolder) {
      return false;
    }
    var thisFile = File(scriptDataFolder + "/" + imageObj.name + ".png");
    if (!thisFile.exists) {
      writeImageFile(imageObj.data, thisFile);
      if (!thisFile.exists) {
        return false;
      }
    }
    return thisFile;
  }

  var CSV = {
    parse: function (csv, reviver, splitter) {
      splitter = splitter || ",";
      reviver =
        reviver ||
        function (r, c, v) {
          return v;
        };
      var chars = csv.split(""),
        c = 0,
        cc = chars.length,
        start,
        end,
        table = [],
        row;
      while (c < cc) {
        table.push((row = []));
        while (c < cc && "\r" !== chars[c] && "\n" !== chars[c]) {
          start = end = c;
          if ('"' === chars[c]) {
            start = end = ++c;
            while (c < cc) {
              if ('"' === chars[c]) {
                if ('"' !== chars[c + 1]) {
                  break;
                } else {
                  chars[++c] = "";
                } // bỏ escape ""
              }
              end = ++c;
            }
            if ('"' === chars[c]) {
              ++c;
            }
            while (
              c < cc &&
              "\r" !== chars[c] &&
              "\n" !== chars[c] &&
              splitter !== chars[c]
            ) {
              ++c;
            }
          } else {
            while (
              c < cc &&
              "\r" !== chars[c] &&
              "\n" !== chars[c] &&
              splitter !== chars[c]
            ) {
              end = ++c;
            }
          }
          row.push(
            reviver(
              table.length - 1,
              row.length,
              chars.slice(start, end).join(""),
            ),
          );
          if (splitter === chars[c]) {
            ++c;
          }
        }
        if ("\r" === chars[c]) {
          ++c;
        }
        if ("\n" === chars[c]) {
          ++c;
        }
      }
      return table;
    },
    stringify: function (table, replacer, splitter) {
      replacer =
        replacer ||
        function (r, c, v) {
          return v;
        };
      var csv = "",
        c,
        cc,
        r,
        rr = table.length,
        cell;
      for (r = 0; r < rr; ++r) {
        if (r) {
          csv += "\r\n";
        }
        for (c = 0, cc = table[r].length; c < cc; ++c) {
          if (c) {
            csv += splitter;
          }
          cell = replacer(r, c, table[r][c]);
          var rx = new RegExp("[" + splitter + "]\\r" + '\\n"');
          if (rx.test(cell)) {
            cell = '"' + cell.replace(/"/g, '""') + '"';
          }
          csv += cell || 0 === cell ? cell : "";
        }
      }
      return csv;
    },
  };

  // Phương án dự phòng chuẩn hoá NFC tiếng Việt cho ExtendScript (không có String.normalize).
  // Phân rã trước để trường hợp trộn chữ dựng sẵn + dấu thanh rời cũng chạy đúng.
  function viNormalizeVietnamese(text) {
    var decompositions = {
      "\u00c0": "A\u0300",
      "\u00c1": "A\u0301",
      "\u00c2": "A\u0302",
      "\u00c3": "A\u0303",
      "\u00c4": "A\u0308",
      "\u00c5": "A\u030a",
      "\u00c8": "E\u0300",
      "\u00c9": "E\u0301",
      "\u00ca": "E\u0302",
      "\u00cb": "E\u0308",
      "\u00cc": "I\u0300",
      "\u00cd": "I\u0301",
      "\u00ce": "I\u0302",
      "\u00cf": "I\u0308",
      "\u00d2": "O\u0300",
      "\u00d3": "O\u0301",
      "\u00d4": "O\u0302",
      "\u00d5": "O\u0303",
      "\u00d6": "O\u0308",
      "\u00d9": "U\u0300",
      "\u00da": "U\u0301",
      "\u00db": "U\u0302",
      "\u00dc": "U\u0308",
      "\u00dd": "Y\u0301",
      "\u00e0": "a\u0300",
      "\u00e1": "a\u0301",
      "\u00e2": "a\u0302",
      "\u00e3": "a\u0303",
      "\u00e4": "a\u0308",
      "\u00e5": "a\u030a",
      "\u00e8": "e\u0300",
      "\u00e9": "e\u0301",
      "\u00ea": "e\u0302",
      "\u00eb": "e\u0308",
      "\u00ec": "i\u0300",
      "\u00ed": "i\u0301",
      "\u00ee": "i\u0302",
      "\u00ef": "i\u0308",
      "\u00f2": "o\u0300",
      "\u00f3": "o\u0301",
      "\u00f4": "o\u0302",
      "\u00f5": "o\u0303",
      "\u00f6": "o\u0308",
      "\u00f9": "u\u0300",
      "\u00fa": "u\u0301",
      "\u00fb": "u\u0302",
      "\u00fc": "u\u0308",
      "\u00fd": "y\u0301",
      "\u00ff": "y\u0308",
      "\u0100": "A\u0304",
      "\u0101": "a\u0304",
      "\u0102": "A\u0306",
      "\u0103": "a\u0306",
      "\u0104": "A\u0328",
      "\u0105": "a\u0328",
      "\u0112": "E\u0304",
      "\u0113": "e\u0304",
      "\u0114": "E\u0306",
      "\u0115": "e\u0306",
      "\u0116": "E\u0307",
      "\u0117": "e\u0307",
      "\u0118": "E\u0328",
      "\u0119": "e\u0328",
      "\u011a": "E\u030c",
      "\u011b": "e\u030c",
      "\u0128": "I\u0303",
      "\u0129": "i\u0303",
      "\u012a": "I\u0304",
      "\u012b": "i\u0304",
      "\u012c": "I\u0306",
      "\u012d": "i\u0306",
      "\u012e": "I\u0328",
      "\u012f": "i\u0328",
      "\u0130": "I\u0307",
      "\u014c": "O\u0304",
      "\u014d": "o\u0304",
      "\u014e": "O\u0306",
      "\u014f": "o\u0306",
      "\u0150": "O\u030b",
      "\u0151": "o\u030b",
      "\u0168": "U\u0303",
      "\u0169": "u\u0303",
      "\u016a": "U\u0304",
      "\u016b": "u\u0304",
      "\u016c": "U\u0306",
      "\u016d": "u\u0306",
      "\u016e": "U\u030a",
      "\u016f": "u\u030a",
      "\u0170": "U\u030b",
      "\u0171": "u\u030b",
      "\u0172": "U\u0328",
      "\u0173": "u\u0328",
      "\u0176": "Y\u0302",
      "\u0177": "y\u0302",
      "\u0178": "Y\u0308",
      "\u01a0": "O\u031b",
      "\u01a1": "o\u031b",
      "\u01af": "U\u031b",
      "\u01b0": "u\u031b",
      "\u01cd": "A\u030c",
      "\u01ce": "a\u030c",
      "\u01cf": "I\u030c",
      "\u01d0": "i\u030c",
      "\u01d1": "O\u030c",
      "\u01d2": "o\u030c",
      "\u01d3": "U\u030c",
      "\u01d4": "u\u030c",
      "\u01d5": "U\u0308\u0304",
      "\u01d6": "u\u0308\u0304",
      "\u01d7": "U\u0308\u0301",
      "\u01d8": "u\u0308\u0301",
      "\u01d9": "U\u0308\u030c",
      "\u01da": "u\u0308\u030c",
      "\u01db": "U\u0308\u0300",
      "\u01dc": "u\u0308\u0300",
      "\u01de": "A\u0308\u0304",
      "\u01df": "a\u0308\u0304",
      "\u01e0": "A\u0307\u0304",
      "\u01e1": "a\u0307\u0304",
      "\u01ea": "O\u0328",
      "\u01eb": "o\u0328",
      "\u01ec": "O\u0328\u0304",
      "\u01ed": "o\u0328\u0304",
      "\u01fa": "A\u030a\u0301",
      "\u01fb": "a\u030a\u0301",
      "\u0200": "A\u030f",
      "\u0201": "a\u030f",
      "\u0202": "A\u0311",
      "\u0203": "a\u0311",
      "\u0204": "E\u030f",
      "\u0205": "e\u030f",
      "\u0206": "E\u0311",
      "\u0207": "e\u0311",
      "\u0208": "I\u030f",
      "\u0209": "i\u030f",
      "\u020a": "I\u0311",
      "\u020b": "i\u0311",
      "\u020c": "O\u030f",
      "\u020d": "o\u030f",
      "\u020e": "O\u0311",
      "\u020f": "o\u0311",
      "\u0214": "U\u030f",
      "\u0215": "u\u030f",
      "\u0216": "U\u0311",
      "\u0217": "u\u0311",
      "\u0226": "A\u0307",
      "\u0227": "a\u0307",
      "\u0228": "E\u0327",
      "\u0229": "e\u0327",
      "\u022a": "O\u0308\u0304",
      "\u022b": "o\u0308\u0304",
      "\u022c": "O\u0303\u0304",
      "\u022d": "o\u0303\u0304",
      "\u022e": "O\u0307",
      "\u022f": "o\u0307",
      "\u0230": "O\u0307\u0304",
      "\u0231": "o\u0307\u0304",
      "\u0232": "Y\u0304",
      "\u0233": "y\u0304",
      "\u1e00": "A\u0325",
      "\u1e01": "a\u0325",
      "\u1e14": "E\u0304\u0300",
      "\u1e15": "e\u0304\u0300",
      "\u1e16": "E\u0304\u0301",
      "\u1e17": "e\u0304\u0301",
      "\u1e18": "E\u032d",
      "\u1e19": "e\u032d",
      "\u1e1a": "E\u0330",
      "\u1e1b": "e\u0330",
      "\u1e1c": "E\u0327\u0306",
      "\u1e1d": "e\u0327\u0306",
      "\u1e2c": "I\u0330",
      "\u1e2d": "i\u0330",
      "\u1e2e": "I\u0308\u0301",
      "\u1e2f": "i\u0308\u0301",
      "\u1e4c": "O\u0303\u0301",
      "\u1e4d": "o\u0303\u0301",
      "\u1e4e": "O\u0303\u0308",
      "\u1e4f": "o\u0303\u0308",
      "\u1e50": "O\u0304\u0300",
      "\u1e51": "o\u0304\u0300",
      "\u1e52": "O\u0304\u0301",
      "\u1e53": "o\u0304\u0301",
      "\u1e72": "U\u0324",
      "\u1e73": "u\u0324",
      "\u1e74": "U\u0330",
      "\u1e75": "u\u0330",
      "\u1e76": "U\u032d",
      "\u1e77": "u\u032d",
      "\u1e78": "U\u0303\u0301",
      "\u1e79": "u\u0303\u0301",
      "\u1e7a": "U\u0304\u0308",
      "\u1e7b": "u\u0304\u0308",
      "\u1e8e": "Y\u0307",
      "\u1e8f": "y\u0307",
      "\u1e99": "y\u030a",
      "\u1ea0": "A\u0323",
      "\u1ea1": "a\u0323",
      "\u1ea2": "A\u0309",
      "\u1ea3": "a\u0309",
      "\u1ea4": "A\u0302\u0301",
      "\u1ea5": "a\u0302\u0301",
      "\u1ea6": "A\u0302\u0300",
      "\u1ea7": "a\u0302\u0300",
      "\u1ea8": "A\u0302\u0309",
      "\u1ea9": "a\u0302\u0309",
      "\u1eaa": "A\u0302\u0303",
      "\u1eab": "a\u0302\u0303",
      "\u1eac": "A\u0323\u0302",
      "\u1ead": "a\u0323\u0302",
      "\u1eae": "A\u0306\u0301",
      "\u1eaf": "a\u0306\u0301",
      "\u1eb0": "A\u0306\u0300",
      "\u1eb1": "a\u0306\u0300",
      "\u1eb2": "A\u0306\u0309",
      "\u1eb3": "a\u0306\u0309",
      "\u1eb4": "A\u0306\u0303",
      "\u1eb5": "a\u0306\u0303",
      "\u1eb6": "A\u0323\u0306",
      "\u1eb7": "a\u0323\u0306",
      "\u1eb8": "E\u0323",
      "\u1eb9": "e\u0323",
      "\u1eba": "E\u0309",
      "\u1ebb": "e\u0309",
      "\u1ebc": "E\u0303",
      "\u1ebd": "e\u0303",
      "\u1ebe": "E\u0302\u0301",
      "\u1ebf": "e\u0302\u0301",
      "\u1ec0": "E\u0302\u0300",
      "\u1ec1": "e\u0302\u0300",
      "\u1ec2": "E\u0302\u0309",
      "\u1ec3": "e\u0302\u0309",
      "\u1ec4": "E\u0302\u0303",
      "\u1ec5": "e\u0302\u0303",
      "\u1ec6": "E\u0323\u0302",
      "\u1ec7": "e\u0323\u0302",
      "\u1ec8": "I\u0309",
      "\u1ec9": "i\u0309",
      "\u1eca": "I\u0323",
      "\u1ecb": "i\u0323",
      "\u1ecc": "O\u0323",
      "\u1ecd": "o\u0323",
      "\u1ece": "O\u0309",
      "\u1ecf": "o\u0309",
      "\u1ed0": "O\u0302\u0301",
      "\u1ed1": "o\u0302\u0301",
      "\u1ed2": "O\u0302\u0300",
      "\u1ed3": "o\u0302\u0300",
      "\u1ed4": "O\u0302\u0309",
      "\u1ed5": "o\u0302\u0309",
      "\u1ed6": "O\u0302\u0303",
      "\u1ed7": "o\u0302\u0303",
      "\u1ed8": "O\u0323\u0302",
      "\u1ed9": "o\u0323\u0302",
      "\u1eda": "O\u031b\u0301",
      "\u1edb": "o\u031b\u0301",
      "\u1edc": "O\u031b\u0300",
      "\u1edd": "o\u031b\u0300",
      "\u1ede": "O\u031b\u0309",
      "\u1edf": "o\u031b\u0309",
      "\u1ee0": "O\u031b\u0303",
      "\u1ee1": "o\u031b\u0303",
      "\u1ee2": "O\u031b\u0323",
      "\u1ee3": "o\u031b\u0323",
      "\u1ee4": "U\u0323",
      "\u1ee5": "u\u0323",
      "\u1ee6": "U\u0309",
      "\u1ee7": "u\u0309",
      "\u1ee8": "U\u031b\u0301",
      "\u1ee9": "u\u031b\u0301",
      "\u1eea": "U\u031b\u0300",
      "\u1eeb": "u\u031b\u0300",
      "\u1eec": "U\u031b\u0309",
      "\u1eed": "u\u031b\u0309",
      "\u1eee": "U\u031b\u0303",
      "\u1eef": "u\u031b\u0303",
      "\u1ef0": "U\u031b\u0323",
      "\u1ef1": "u\u031b\u0323",
      "\u1ef2": "Y\u0300",
      "\u1ef3": "y\u0300",
      "\u1ef4": "Y\u0323",
      "\u1ef5": "y\u0323",
      "\u1ef6": "Y\u0309",
      "\u1ef7": "y\u0309",
      "\u1ef8": "Y\u0303",
      "\u1ef9": "y\u0303",
    };
    var compositions = {
      "A\u0300": "\u00c0",
      "A\u0301": "\u00c1",
      "A\u0302": "\u00c2",
      "A\u0303": "\u00c3",
      "A\u0308": "\u00c4",
      "A\u030a": "\u00c5",
      "E\u0300": "\u00c8",
      "E\u0301": "\u00c9",
      "E\u0302": "\u00ca",
      "E\u0308": "\u00cb",
      "I\u0300": "\u00cc",
      "I\u0301": "\u00cd",
      "I\u0302": "\u00ce",
      "I\u0308": "\u00cf",
      "O\u0300": "\u00d2",
      "O\u0301": "\u00d3",
      "O\u0302": "\u00d4",
      "O\u0303": "\u00d5",
      "O\u0308": "\u00d6",
      "U\u0300": "\u00d9",
      "U\u0301": "\u00da",
      "U\u0302": "\u00db",
      "U\u0308": "\u00dc",
      "Y\u0301": "\u00dd",
      "a\u0300": "\u00e0",
      "a\u0301": "\u00e1",
      "a\u0302": "\u00e2",
      "a\u0303": "\u00e3",
      "a\u0308": "\u00e4",
      "a\u030a": "\u00e5",
      "e\u0300": "\u00e8",
      "e\u0301": "\u00e9",
      "e\u0302": "\u00ea",
      "e\u0308": "\u00eb",
      "i\u0300": "\u00ec",
      "i\u0301": "\u00ed",
      "i\u0302": "\u00ee",
      "i\u0308": "\u00ef",
      "o\u0300": "\u00f2",
      "o\u0301": "\u00f3",
      "o\u0302": "\u00f4",
      "o\u0303": "\u00f5",
      "o\u0308": "\u00f6",
      "u\u0300": "\u00f9",
      "u\u0301": "\u00fa",
      "u\u0302": "\u00fb",
      "u\u0308": "\u00fc",
      "y\u0301": "\u00fd",
      "y\u0308": "\u00ff",
      "A\u0304": "\u0100",
      "a\u0304": "\u0101",
      "A\u0306": "\u0102",
      "a\u0306": "\u0103",
      "A\u0328": "\u0104",
      "a\u0328": "\u0105",
      "E\u0304": "\u0112",
      "e\u0304": "\u0113",
      "E\u0306": "\u0114",
      "e\u0306": "\u0115",
      "E\u0307": "\u0116",
      "e\u0307": "\u0117",
      "E\u0328": "\u0118",
      "e\u0328": "\u0119",
      "E\u030c": "\u011a",
      "e\u030c": "\u011b",
      "I\u0303": "\u0128",
      "i\u0303": "\u0129",
      "I\u0304": "\u012a",
      "i\u0304": "\u012b",
      "I\u0306": "\u012c",
      "i\u0306": "\u012d",
      "I\u0328": "\u012e",
      "i\u0328": "\u012f",
      "I\u0307": "\u0130",
      "O\u0304": "\u014c",
      "o\u0304": "\u014d",
      "O\u0306": "\u014e",
      "o\u0306": "\u014f",
      "O\u030b": "\u0150",
      "o\u030b": "\u0151",
      "U\u0303": "\u0168",
      "u\u0303": "\u0169",
      "U\u0304": "\u016a",
      "u\u0304": "\u016b",
      "U\u0306": "\u016c",
      "u\u0306": "\u016d",
      "U\u030a": "\u016e",
      "u\u030a": "\u016f",
      "U\u030b": "\u0170",
      "u\u030b": "\u0171",
      "U\u0328": "\u0172",
      "u\u0328": "\u0173",
      "Y\u0302": "\u0176",
      "y\u0302": "\u0177",
      "Y\u0308": "\u0178",
      "O\u031b": "\u01a0",
      "o\u031b": "\u01a1",
      "U\u031b": "\u01af",
      "u\u031b": "\u01b0",
      "A\u030c": "\u01cd",
      "a\u030c": "\u01ce",
      "I\u030c": "\u01cf",
      "i\u030c": "\u01d0",
      "O\u030c": "\u01d1",
      "o\u030c": "\u01d2",
      "U\u030c": "\u01d3",
      "u\u030c": "\u01d4",
      "U\u0308\u0304": "\u01d5",
      "u\u0308\u0304": "\u01d6",
      "U\u0308\u0301": "\u01d7",
      "u\u0308\u0301": "\u01d8",
      "U\u0308\u030c": "\u01d9",
      "u\u0308\u030c": "\u01da",
      "U\u0308\u0300": "\u01db",
      "u\u0308\u0300": "\u01dc",
      "A\u0308\u0304": "\u01de",
      "a\u0308\u0304": "\u01df",
      "A\u0307\u0304": "\u01e0",
      "a\u0307\u0304": "\u01e1",
      "O\u0328": "\u01ea",
      "o\u0328": "\u01eb",
      "O\u0328\u0304": "\u01ec",
      "o\u0328\u0304": "\u01ed",
      "A\u030a\u0301": "\u01fa",
      "a\u030a\u0301": "\u01fb",
      "A\u030f": "\u0200",
      "a\u030f": "\u0201",
      "A\u0311": "\u0202",
      "a\u0311": "\u0203",
      "E\u030f": "\u0204",
      "e\u030f": "\u0205",
      "E\u0311": "\u0206",
      "e\u0311": "\u0207",
      "I\u030f": "\u0208",
      "i\u030f": "\u0209",
      "I\u0311": "\u020a",
      "i\u0311": "\u020b",
      "O\u030f": "\u020c",
      "o\u030f": "\u020d",
      "O\u0311": "\u020e",
      "o\u0311": "\u020f",
      "U\u030f": "\u0214",
      "u\u030f": "\u0215",
      "U\u0311": "\u0216",
      "u\u0311": "\u0217",
      "A\u0307": "\u0226",
      "a\u0307": "\u0227",
      "E\u0327": "\u0228",
      "e\u0327": "\u0229",
      "O\u0308\u0304": "\u022a",
      "o\u0308\u0304": "\u022b",
      "O\u0303\u0304": "\u022c",
      "o\u0303\u0304": "\u022d",
      "O\u0307": "\u022e",
      "o\u0307": "\u022f",
      "O\u0307\u0304": "\u0230",
      "o\u0307\u0304": "\u0231",
      "Y\u0304": "\u0232",
      "y\u0304": "\u0233",
      "A\u0325": "\u1e00",
      "a\u0325": "\u1e01",
      "E\u0304\u0300": "\u1e14",
      "e\u0304\u0300": "\u1e15",
      "E\u0304\u0301": "\u1e16",
      "e\u0304\u0301": "\u1e17",
      "E\u032d": "\u1e18",
      "e\u032d": "\u1e19",
      "E\u0330": "\u1e1a",
      "e\u0330": "\u1e1b",
      "E\u0327\u0306": "\u1e1c",
      "e\u0327\u0306": "\u1e1d",
      "I\u0330": "\u1e2c",
      "i\u0330": "\u1e2d",
      "I\u0308\u0301": "\u1e2e",
      "i\u0308\u0301": "\u1e2f",
      "O\u0303\u0301": "\u1e4c",
      "o\u0303\u0301": "\u1e4d",
      "O\u0303\u0308": "\u1e4e",
      "o\u0303\u0308": "\u1e4f",
      "O\u0304\u0300": "\u1e50",
      "o\u0304\u0300": "\u1e51",
      "O\u0304\u0301": "\u1e52",
      "o\u0304\u0301": "\u1e53",
      "U\u0324": "\u1e72",
      "u\u0324": "\u1e73",
      "U\u0330": "\u1e74",
      "u\u0330": "\u1e75",
      "U\u032d": "\u1e76",
      "u\u032d": "\u1e77",
      "U\u0303\u0301": "\u1e78",
      "u\u0303\u0301": "\u1e79",
      "U\u0304\u0308": "\u1e7a",
      "u\u0304\u0308": "\u1e7b",
      "Y\u0307": "\u1e8e",
      "y\u0307": "\u1e8f",
      "y\u030a": "\u1e99",
      "A\u0323": "\u1ea0",
      "a\u0323": "\u1ea1",
      "A\u0309": "\u1ea2",
      "a\u0309": "\u1ea3",
      "A\u0302\u0301": "\u1ea4",
      "a\u0302\u0301": "\u1ea5",
      "A\u0302\u0300": "\u1ea6",
      "a\u0302\u0300": "\u1ea7",
      "A\u0302\u0309": "\u1ea8",
      "a\u0302\u0309": "\u1ea9",
      "A\u0302\u0303": "\u1eaa",
      "a\u0302\u0303": "\u1eab",
      "A\u0323\u0302": "\u1eac",
      "a\u0323\u0302": "\u1ead",
      "A\u0306\u0301": "\u1eae",
      "a\u0306\u0301": "\u1eaf",
      "A\u0306\u0300": "\u1eb0",
      "a\u0306\u0300": "\u1eb1",
      "A\u0306\u0309": "\u1eb2",
      "a\u0306\u0309": "\u1eb3",
      "A\u0306\u0303": "\u1eb4",
      "a\u0306\u0303": "\u1eb5",
      "A\u0323\u0306": "\u1eb6",
      "a\u0323\u0306": "\u1eb7",
      "E\u0323": "\u1eb8",
      "e\u0323": "\u1eb9",
      "E\u0309": "\u1eba",
      "e\u0309": "\u1ebb",
      "E\u0303": "\u1ebc",
      "e\u0303": "\u1ebd",
      "E\u0302\u0301": "\u1ebe",
      "e\u0302\u0301": "\u1ebf",
      "E\u0302\u0300": "\u1ec0",
      "e\u0302\u0300": "\u1ec1",
      "E\u0302\u0309": "\u1ec2",
      "e\u0302\u0309": "\u1ec3",
      "E\u0302\u0303": "\u1ec4",
      "e\u0302\u0303": "\u1ec5",
      "E\u0323\u0302": "\u1ec6",
      "e\u0323\u0302": "\u1ec7",
      "I\u0309": "\u1ec8",
      "i\u0309": "\u1ec9",
      "I\u0323": "\u1eca",
      "i\u0323": "\u1ecb",
      "O\u0323": "\u1ecc",
      "o\u0323": "\u1ecd",
      "O\u0309": "\u1ece",
      "o\u0309": "\u1ecf",
      "O\u0302\u0301": "\u1ed0",
      "o\u0302\u0301": "\u1ed1",
      "O\u0302\u0300": "\u1ed2",
      "o\u0302\u0300": "\u1ed3",
      "O\u0302\u0309": "\u1ed4",
      "o\u0302\u0309": "\u1ed5",
      "O\u0302\u0303": "\u1ed6",
      "o\u0302\u0303": "\u1ed7",
      "O\u0323\u0302": "\u1ed8",
      "o\u0323\u0302": "\u1ed9",
      "O\u031b\u0301": "\u1eda",
      "o\u031b\u0301": "\u1edb",
      "O\u031b\u0300": "\u1edc",
      "o\u031b\u0300": "\u1edd",
      "O\u031b\u0309": "\u1ede",
      "o\u031b\u0309": "\u1edf",
      "O\u031b\u0303": "\u1ee0",
      "o\u031b\u0303": "\u1ee1",
      "O\u031b\u0323": "\u1ee2",
      "o\u031b\u0323": "\u1ee3",
      "U\u0323": "\u1ee4",
      "u\u0323": "\u1ee5",
      "U\u0309": "\u1ee6",
      "u\u0309": "\u1ee7",
      "U\u031b\u0301": "\u1ee8",
      "u\u031b\u0301": "\u1ee9",
      "U\u031b\u0300": "\u1eea",
      "u\u031b\u0300": "\u1eeb",
      "U\u031b\u0309": "\u1eec",
      "u\u031b\u0309": "\u1eed",
      "U\u031b\u0303": "\u1eee",
      "u\u031b\u0303": "\u1eef",
      "U\u031b\u0323": "\u1ef0",
      "u\u031b\u0323": "\u1ef1",
      "Y\u0300": "\u1ef2",
      "y\u0300": "\u1ef3",
      "Y\u0323": "\u1ef4",
      "y\u0323": "\u1ef5",
      "Y\u0309": "\u1ef6",
      "y\u0309": "\u1ef7",
      "Y\u0303": "\u1ef8",
      "y\u0303": "\u1ef9",
    };
    return text.replace(
      /[AEIOUYaeiouy\u00c0-\u01ff\u1e00-\u1eff][\u0300-\u036f]*/g,
      function (original) {
        var first = original.charAt(0);
        var sequence = (decompositions[first] || first) + original.substring(1);
        var marks = sequence.substring(1).split("");
        function rank(mark) {
          if (mark === "\u031b") return 216; // dấu móc
          if (mark === "\u0323") return 220; // dấu nặng
          return 230;
        }
        // Sắp xếp chèn ổn định: giữ nguyên thứ tự các dấu có cùng lớp.
        for (var j = 1; j < marks.length; j++) {
          var mark = marks[j],
            k = j - 1;
          while (k >= 0 && rank(marks[k]) > rank(mark)) {
            marks[k + 1] = marks[k];
            k--;
          }
          marks[k + 1] = mark;
        }
        var ordered = sequence.charAt(0) + marks.join("");
        return compositions[ordered] || original;
      },
    );
  }

  function getTextData(dataFile) {
    var df = dataFile;
    var dataFileName = decodeURI(df.name);
    var type = dataFileName.match(/(\.txt$|\.csv$)/i)[0].toLowerCase();
    var splitter = type == ".txt" ? "\t" : ",";
    df.open("r");
    var fileContents = df.read();
    fileContents = viNormalizeVietnamese(fileContents.replace(/^\uFEFF/, ""));
    var firstRow = fileContents.split(/[\r\n]/g)[0];
    if (firstRow != null && splitter != "\t") {
      if (firstRow.indexOf(",") == -1 && firstRow.indexOf(";") > -1) {
        splitter = ";"; // Với định dạng .csv: nếu dòng đầu không có dấu phẩy mà có dấu chấm phẩy thì coi đây là file .csv phân tách bằng dấu chấm phẩy
      }
    }
    var everyRowRaw = CSV.parse(fileContents, undefined, splitter);
    df.close();

    var everyRow = [];
    for (var i = 0; i < everyRowRaw.length; i++) {
      // bỏ các dòng trống
      var thisRawRow = everyRowRaw[i];
      if (!checkRowForAllBlanks(thisRawRow)) {
        if (i > 0) {
          if (thisRawRow.length < everyRow[0].length) {
            var diff = everyRow[0].length - thisRawRow.length;
            for (var d = 0; d < diff; d++) {
              thisRawRow.push("");
            }
          }
        }
        everyRow.push(thisRawRow);
      }
    }
    return everyRow;
  }

  function getData(filePath) {
    try {
      return getTextData(File(filePath));
    } catch (e) {
      alert(e);
      return null;
    }
  }

  function checkRowForAllBlanks(row) {
    for (var i = 0; i < row.length; i++) {
      if (row[i] != "") {
        return false;
      }
    }
    return true;
  }

  function getVariableType(str) {
    var firstChar = str[0];
    for (var all in VARTYPES) {
      if (firstChar == VARTYPES[all].key) {
        return all;
      }
    }
    return "Text";
  }

  function transposeGrid(data) {
    var newArr = [];
    var columns = data[0].length,
      rows = data.length,
      newRow = [];
    for (var i = 0; i < columns; i++) {
      newRow = [];
      for (var j = 0; j < rows; j++) {
        newRow.push(data[j][i]);
      }
      newArr.push(newRow);
    }
    return newArr;
  }

  function comparePropNames(compareTo, compareThis) {
    var resMsg = "";
    var propCount = {};
    propCount.compareTo = 0;
    propCount.compareThis = 0;
    var compareToPropArr = [];
    var compareThisPropArr = [];
    for (var all in compareTo) {
      propCount.compareTo++;
      compareToPropArr.push(all);
    }
    for (var all in compareThis) {
      propCount.compareThis++;
      compareThisPropArr.push(all);
    }
    var allFound = true,
      thisProp,
      thisCompareProp;
    for (var i = 0; i < compareToPropArr.length; i++) {
      thisProp = compareToPropArr[i];
      for (var j = 0; j < compareThisPropArr.length; j++) {
        thisCompareProp = compareThisPropArr[j];
        if (
          compareThisPropArr.indexOf(thisProp) == -1 ||
          compareToPropArr.indexOf(thisCompareProp) == -1
        ) {
          allFound = false;
          break;
        }
      }
    }
    if (!allFound) {
      resMsg = "Not All Found";
    } else {
      resMsg = "All Found";
    }

    return {
      resMsg: resMsg,
      propCount: propCount,
    };
  }

  function getByName(obj, name) {
    if (obj instanceof Array) {
      for (var i = 0; i < obj.length; i++) {
        if (obj[i].name == name) {
          return obj[i];
        }
      }
    } else if (typeof obj == "Object") {
      for (var all in obj) {
        if (all == "name" && obj[all] == name) {
          return obj[all];
        }
      }
    }
    return null;
  }

  function getPropertyList(obj) {
    var arr = [];
    for (var all in obj) {
      arr.push(all);
    }
    return arr;
  }

  function getSpecificPropertyListObj(obj, prop) {
    var arr = [];
    for (var all in obj) {
      if (obj[all].hasOwnProperty(prop)) {
        arr.push(obj[all][prop]);
      }
    }
    return arr;
  }

  function getSpecificPropertyObj(obj, prop, value) {
    for (var all in obj) {
      if (obj[all].hasOwnProperty(prop) && obj[all][prop] == value) {
        return obj[all];
      }
    }
    return null;
  }

  function getSpecificPropertyListArr(srcArr, prop) {
    var arr = [];
    for (var i = 0; i < srcArr.length; i++) {
      if (srcArr[i].hasOwnProperty(prop)) {
        arr.push(srcArr[i][prop]);
      }
    }
    return arr;
  }

  function getSpecificValuePropertyListArr(
    srcArr,
    filterProp,
    filterValue,
    searchProp,
  ) {
    var arr = [];
    for (var i = 0; i < srcArr.length; i++) {
      if (
        srcArr[i].hasOwnProperty(filterProp) &&
        srcArr[i].hasOwnProperty(searchProp) &&
        srcArr[i][filterProp] == filterValue
      ) {
        arr.push(srcArr[i][searchProp]);
      }
    }
    return arr;
  }

  function writeFile(fileObj, contents, encoding) {
    if (typeof encoding == "string") {
      fileObj.encoding = encoding;
    }
    fileObj.open("w");
    fileObj.write(contents);
    fileObj.close();
  }

  function writeSettingsFile(settingsObj) {
    var scriptDataFolder = SESSION.scriptDataFolder;
    if (scriptDataFolder.exists) {
      var settingsFile = SESSION.settingsFile;
      try {
        writeFile(settingsFile, JSON.stringify(settingsObj, null, 2));
        if (WARNINGSETTINGS.showSuccessfulSettingsFileSaves) {
          scriptAlert(
            "Settings file successfully saved in '" +
              decodeURI(settingsFile) +
              "'",
          );
        }
      } catch (e) {
        scriptAlert(e);
      }
    } else {
      scriptAlert(
        "The folder '" +
          scriptDataFolder +
          "' does not exist and Settings file could not be written.",
      );
    }
  }

  function getScriptDataObj() {
    // phải cập nhật object trước đã
    var obj = {};
    obj.WARNINGSETTINGS = WARNINGSETTINGS;
    obj.PRESETS = PRESETS;
    obj.DATASETNAMEFIELDS = DATASETNAMEFIELDS_current;
    obj.CUSTOM_INCREMENTS = CUSTOM_INCREMENTS_current;
    obj.VisibilityKeys = VisibilityKeys;
    if (typeof VI_MEMORY_SETTINGS != "undefined") {
      obj.lastChosenDataFilePath = VI_MEMORY_SETTINGS.lastChosenDataFilePath;
    }
    return obj;
  }

  function updateScriptDataFromUI(UIElements, presetName) {
    var presetName = presetName || SESSION.currentLoadedPresetName;
    var presetObj = {};
    for (var all in PRESETS[0]) {
      if (
        UIElements.hasOwnProperty(all) &&
        typeof UIElements[all].getValue == "function"
      ) {
        presetObj[all] = UIElements[all].getValue();
      }
    }
    var warningList = UIElements["list_warnings"];
    for (var all in WARNINGSETTINGS) {
      WARNINGSETTINGS[all] = warningList.find(unCamelCaseSplit(all)).checked;
    }
    // cập nhật thêm từ các object khác trong bộ nhớ, không nhất thiết từ UI nữa
    presetObj["datasetNameObj"] = clone(DATASETNAMEFIELDS_current);
    presetObj["enabledVisibilityKeyNames"] = getSpecificValuePropertyListArr(
      VisibilityKeys,
      "enabled",
      true,
      "name",
    );
    var loadedPreset = PRESETS.getByName(presetName);
    for (var all in presetObj) {
      loadedPreset[all] = presetObj[all];
    }
  }

  function getUIData(UIElements) {
    var presetObj = {};
    for (var all in PRESETS[0]) {
      if (
        UIElements.hasOwnProperty(all) &&
        typeof UIElements[all].getValue == "function"
      ) {
        presetObj[all] = UIElements[all].getValue();
      }
    }
    for (var all in WARNINGSETTINGS) {
      // đoạn này ghép kèm luôn cài đặt thông báo, nhưng phần đó không nằm trong dữ liệu trả về của hàm này
      if (
        UIElements.hasOwnProperty(all) &&
        typeof UIElements[all].getValue == "function"
      ) {
        WARNINGSETTINGS[all] = UIElements[all].getValue();
      }
    }
    presetObj.datasetNameObj = DATASETNAMEFIELDS_current;
    presetObj.enabledVisibilityKeyNames = getSpecificValuePropertyListArr(
      VisibilityKeys,
      "enabled",
      true,
      "name",
    );
    return presetObj;
  }

  function updateCurrentPresetNameDisplays(
    UIElements,
    currentLoadedPresetObj,
    tryAddOverridesMarker,
  ) {
    var currentUIStatePresetObj = getUIData(UIElements);
    var hasOverrides = false;
    if (
      typeof tryAddOverridesMarker != "undefined" &&
      tryAddOverridesMarker === true
    ) {
      var testObj = {};
      for (var all in currentUIStatePresetObj) {
        if (all == "enabledVisibilityKeyNames") {
          if (
            currentUIStatePresetObj[all].compare(currentLoadedPresetObj[all])
          ) {
            // dùng hàm compare của mảng để kiểm tra hai mảng có cùng phần tử hay không, bất kể thứ tự
            // nếu có thì gán object này bằng object kia để phép so sánh chuỗi về sau cho kết quả true
            currentLoadedPresetObj[all] = currentUIStatePresetObj[all];
          }
        }
        testObj[all] = currentLoadedPresetObj[all];
      }
      hasOverrides =
        JSON.stringify(testObj) !== JSON.stringify(currentUIStatePresetObj);
    }
    var thisElem;
    for (var i = 0; i < UIElements["currentlySelectedPresetName"].length; i++) {
      thisElem = UIElements["currentlySelectedPresetName"][i];
      if (hasOverrides) {
        thisElem.setValue(SESSION.currentLoadedPresetName + "*");
        thisElem.helpTip =
          "The preset '" +
          SESSION.currentLoadedPresetName +
          "' has one or more of its dialog settings overriden in the current dialog state.";
      } else {
        thisElem.setValue(SESSION.currentLoadedPresetName);
        thisElem.helpTip = "";
      }
    }
  }

  function setVisibilityKeysEnabled(visKeyNames) {
    var thisVisKeyObj,
      processedItems = [];
    for (var i = 0; i < VisibilityKeys.length; i++) {
      thisVisKeyObj = VisibilityKeys[i];
      if (
        visKeyNames.indexOf(thisVisKeyObj.name) > -1 &&
        processedItems.indexOf(thisVisKeyObj.name) == -1
      ) {
        thisVisKeyObj.enabled = true;
        processedItems.push(thisVisKeyObj.name);
      } else if (processedItems.indexOf(thisVisKeyObj.name) == -1) {
        thisVisKeyObj.enabled = false;
      }
    }
  }

  function populateUI(UIElements, tryAddOverridesMarker) {
    var currentLoadedPresetObj = PRESETS.getByName(
      SESSION.currentLoadedPresetName,
    );
    if (currentLoadedPresetObj.hasOwnProperty("enabledVisibilityKeyNames")) {
      setVisibilityKeysEnabled(
        currentLoadedPresetObj.enabledVisibilityKeyNames,
      );
    }
    for (var all in UIElements) {
      if (all in UIElements && all in SETTINGS) {
        SETTINGS[all] = currentLoadedPresetObj[all];
      }
    }
    for (var all in PRESETS[0]) {
      if (
        UIElements.hasOwnProperty(all) &&
        typeof UIElements[all].getValue == "function"
      ) {
        UIElements[all].setValue(currentLoadedPresetObj[all]);
      }
    }
    updateCurrentPresetNameDisplays(
      UIElements,
      currentLoadedPresetObj,
      tryAddOverridesMarker,
    );
    var warningList = UIElements["list_warnings"];
    for (var all in WARNINGSETTINGS) {
      warningList.find(unCamelCaseSplit(all)).checked = WARNINGSETTINGS[all];
    }
    UIElements["disp_dataFile"].notify("onChange");
    var xmlPathStr = UIElements["xmlPath"].getValue();
    if (xmlPathStr == "" || xmlPathStr == "temp" || xmlPathStr == "undefined") {
      UIElements["xmlPath"].setValue(SETTINGS.getDataXMLDestination());
    }
    UIElements["datasetNamePreview"].setValue(getDatasetNamePreviewString());
  }

  function getCurrentlySelectedPresetName() {
    var thisPreset;
    for (var i = 0; i < PRESETS.length; i++) {
      thisPreset = PRESETS[i];
      if (thisPreset.currentlySelected) {
        return thisPreset.name;
      }
    }
  }

  function setCurrentlySelectedPresetName(name) {
    var thisPreset;
    for (var i = 0; i < PRESETS.length; i++) {
      thisPreset = PRESETS[i];
      if (name == thisPreset.name) {
        thisPreset.currentlySelected = true;
      } else {
        thisPreset.currentlySelected = false;
      }
    }
  }

  function addVarNameDatasetNames() {
    FIELDNAMEOPTIONS_current = clone(FIELDNAMEOPTIONS);
    var varNames = DATA.getVariableNames();
    if (varNames.length == 0) {
      return;
    }
    var thisName, key;
    for (var i = 0; i < varNames.length; i++) {
      thisName = varNames[i];
      key = "variable_" + (i + 1) + "_value";
      FIELDNAMEOPTIONS_current[key] = {
        defaultText: thisName,
        displayText: "Variable " + (i + 1) + ' Value : "' + thisName + '"',
        type: key,
      };
    }

    var processedDatasetNameFieldsResult = clearOutOfBoundVariables(
      DATASETNAMEFIELDS_current,
    );
    DATASETNAMEFIELDS_current = processedDatasetNameFieldsResult.obj;
    if (
      WARNINGSETTINGS.showDatasetNamingWarning &&
      processedDatasetNameFieldsResult.msg != ""
    ) {
      quickView(
        processedDatasetNameFieldsResult.msg,
        "Dataset naming field errors.",
      );
    }
  }

  function clearOutOfBoundVariables(obj) {
    var varNames = DATA.getVariableNames();
    var idx;
    missingVariableNamesLog = [];
    missingCustomIncrementsLog = [];
    for (var all in obj) {
      if (obj[all].type.match(SESSION.regexps.varRx)) {
        idx = obj[all].type.match(/\d+/) * 1 - 1;
        if (idx < varNames.length) {
          obj[all].text = varNames[idx];
        } else {
          missingVariableNamesLog.push(
            all + " : variable # " + idx + ' ("' + obj[all].text + '")',
          );
          obj[all].type = "nothing";
          obj[all].text = "";
        }
      } else if (obj[all].type == "customIncrement") {
        var customIncObj = getByName(CUSTOM_INCREMENTS_current, obj[all].text);
        if (customIncObj == null) {
          missingCustomIncrementsLog.push(all + " : " + obj[all].text);
          obj[all].type = "nothing";
          obj[all].text = "";
        }
      }
    }
    var msg = "";
    if (missingVariableNamesLog.length > 0) {
      msg +=
        "The variables associated with dataset-name fields were not found in current data and were removed from the dataset naming options.\n" +
        "---------------------------------------------\n" +
        missingVariableNamesLog.join("\n");
    }
    if (missingCustomIncrementsLog.length > 0) {
      if (msg != "") {
        msg += "\n\n";
      }
      msg +=
        "These custom increments were specified inside the dataset name fields, but were not located in the saved settings data.\n" +
        "---------------------------------------------\n" +
        missingCustomIncrementsLog.join("\n");
    }
    return { obj: obj, msg: msg };
  }

  function getPrependPathValue(varObj, cellData) {
    var folderDiv = SESSION.os == "Windows" ? "\\" : "/";
    cellData = varObj.url + folderDiv + cellData;
    cellData = cellData.replace(/\\\\/g, "//").replace(/\\/g, "/");
    return cellData;
  }

  function getRecordDatasetName(dsNameFieldObj, row, index) {
    var str = "";
    for (var all in dsNameFieldObj) {
      str += getDsNameField(dsNameFieldObj, all, row, index);
    }
    return str;
  }

  function getRecordCustomInc(
    index,
    startNum,
    padZero,
    increment,
    isIntervalIncrement,
    _isSelfCalled,
  ) {
    /* chỉ số tính từ 0 */
    startNum *= 1;
    increment *= 1;
    var padZeroStr = "";
    var storedPadZero = padZero;
    var currentNum = startNum + index * increment;
    if (_isSelfCalled) {
      currentNum -= 1;
    }
    var currentNumLength = currentNum.toString().length - 1;
    padZero -= currentNumLength;
    for (var i = 0; i < padZero; i++) {
      padZeroStr += "0";
    }
    if (!isIntervalIncrement) {
      return padZeroStr + currentNum;
    } else {
      // lấy giá trị kế tiếp bằng cách gọi lại chính hàm này với tham số increment đã chỉnh và một cờ để bỏ qua khối này trong lần chạy đó
      var nextVal = getRecordCustomInc(
        index + 1,
        startNum,
        storedPadZero,
        increment,
        false,
        true,
      );

      return padZeroStr + currentNum + "-" + nextVal;
    }
  }

  function getDsNameField(dsNameFieldObj, fieldName, row, index) {
    function getCurrentText(dsNameFieldObj, fieldName) {
      return dsNameFieldObj[fieldName].text;
    }

    if (dsNameFieldObj[fieldName].type.match(SESSION.regexps.varRx)) {
      var varIndex =
        dsNameFieldObj[fieldName].type.replace(/[^\d]/g, "") * 1 - 1;
      if (varIndex < row.length) {
        return row[varIndex];
      }
    }

    switch (dsNameFieldObj[fieldName].type) {
      case "customText": {
        return getCurrentText(dsNameFieldObj, fieldName);
        break;
      }
      case "dash": {
        return getCurrentText(dsNameFieldObj, fieldName);
        break;
      }
      case "nothing": {
        return getCurrentText(dsNameFieldObj, fieldName);
        break;
      }
      case "space": {
        return getCurrentText(dsNameFieldObj, fieldName);
        break;
      }
      case "increment": {
        return index + SETTINGS.incrementStartNumber;
        break;
      }
      case "underscore": {
        return getCurrentText(dsNameFieldObj, fieldName);
        break;
      }
      case "customIncrement": {
        var customIncName = getCurrentText(dsNameFieldObj, fieldName);
        var customIncObj = getByName(CUSTOM_INCREMENTS_current, customIncName);
        if (customIncObj == null) {
          return ""; // không tìm thấy mục custom increment
        }
        return getRecordCustomInc(
          index,
          customIncObj.startNum,
          customIncObj.padZero,
          customIncObj.increment,
          customIncObj.isIntervalIncrement,
        );
        break;
      }
      default: {
        return "";
      }
    }
    return "";
  }

  function getFileRefTestResults() {
    if (DATA.currentVars.length == 0) {
      return null;
    }
    var log = {
      foundImages: ["Found Images: "],
      foundGraphs: ["Found Graphs: "],
      missingImages: ["Missing Images: "],
      missingGraphs: ["Missing Graphs: "],
    };

    var item, thisVar, test;

    for (var i = 0; i < DATA.currentGrid.length; i++) {
      for (var j = 0; j < DATA.currentVars.length; j++) {
        item = DATA.currentGrid[i][j];
        thisVar = DATA.currentVars[j];
        if (thisVar.varType == "Image" || thisVar.varType == "Graph") {
          test = File(item);
          if (test.exists) {
            log["found" + thisVar.varType + "s"].push(item);
          } else {
            log["missing" + thisVar.varType + "s"].push(item);
          }
        }
      }
    }
    return log;
  }

  function getSpecificFileRefTestResultsLog(log, prop) {
    // ảnh hoặc biểu đồ
    if (prop != "Images" && prop != "Graphs") {
      alert(
        "Only 'Images' and 'Graphs' are searchable properties in function 'getSpecificFileRefTestResultsLog(log, prop)'",
      );
      return null;
    }

    var specificLog = {
      found: log["found" + prop],
      missing: log["missing" + prop],
    };

    var resMsg = "";
    for (var all in specificLog) {
      specificLog[all][0] +=
        "(" + (specificLog[all].length - 1) + ")\n---------------";
      resMsg += specificLog[all].join("\n") + "\r\r";
    }
    return resMsg;
  }

  function fileRefTestHandler() {
    if (DATA.currentVars.length == 0) {
      alert("Please import a data file first.");
      return;
    }
    DATA.getCurrentGrid();
    var allResults = getFileRefTestResults();
    var thisRefResultNumFound = allResults["found" + this.key].length - 1;
    var thisRefResultNumMissing = allResults["missing" + this.key].length - 1;
    var foundMissingNum =
      thisRefResultNumFound +
      "/" +
      (thisRefResultNumFound + thisRefResultNumMissing);

    // var logStr = getSpecificFileRefTestResultsLog(allResults, this.key);
    var keySingular = this.key.replace(/s$/, "");

    simpleShowModal(
      TestManager[keySingular.toLowerCase() + "Files"].makeUIContents,
      {
        title: this.key.replace(/s$/, "") + " Files Log",
        foundFiles: allResults["found" + this.key].slice(1).join("\n"),
        missingFiles: allResults["missing" + this.key].slice(1).join("\n"),
        foundMissingNum: foundMissingNum,
        size: [800, 220],
      },
    );

    this.disp.setValue(foundMissingNum);
    var tabGroupKey = "testTabs";
    if (this.window.UITestElements.hasOwnProperty(tabGroupKey)) {
      var testTabPanel = this.window.UITestElements["testTabs"],
        thisTab;
      for (var i = 0; i < testTabPanel.children.length; i++) {
        thisTab = testTabPanel.children[i];
        if (thisTab.hasOwnProperty("key") && thisTab.key == keySingular) {
          thisTab.populateFields();
        }
      }
    }
  }

  function displayFoundArtBindings(UITestElements) {
    var doc = app.activeDocument;
    DocumentBinding.getNamedBinds(doc);
    UITestElements["foundArtBindings"].setValue(
      DocumentBinding.getBindObjectTestResults().foundItemString,
    );
    var tabItemKey = "testTabArtBinding";
    if (UITestElements.hasOwnProperty(tabItemKey)) {
      UITestElements[tabItemKey].populateFields();
    }
  }

  eval(
    "@JSXBIN@ES@2.0@MyBbyBnABMAbyBn0ACOBbCn0ACJCnAEjzFjBjMjFjSjUBfRBFehBiEjPjFjTjOhHj" +
      "UhAjMjPjPjLhAjMjJjLjFhAjBjOjZjUjIjJjOjHhAjUjPhAjNjFhOffZDnAFctACzChdhdCEXzHjSjF" +
      "jQjMjBjDjFDfEXzLjUjPiMjPjXjFjSiDjBjTjFEfVzFjJjOjQjVjUFfAnfRCYIibieicjXicjTidhLA" +
      "FeAffEXDfEXEfVzHjEjFjTjJjSjFjEGfBnfRCYIibieicjXicjTidhLAFeAffnnnZFnAFcfACG4B0Ah" +
      "AF40BhAC0AzCjFjFHAG0EzAIByB",
  );

  function stringXmlSafe(str) {
    str = str.toString();
    str = str.replace(/&(?!(amp;|gt;|lt;|quot;|apos;))/g, "&amp;");
    str = str.replace(/</g, "&lt;");
    str = str.replace(/>/g, "&gt;");
    str = str.replace(/'/g, "&apos;");
    str = str.replace(/"/g, "&quot;");
    return str;
  }

  function disguiseXmlEntities(str) {
    str = str.toString();
    str = str.replace(/&(?!(amp;|gt;|lt;|quot;|apos;))/g, "_#_amp_#_");
    str = str.replace(/</g, "_#_lt_#_");
    str = str.replace(/>/g, "_#_gt_#_");
    str = str.replace(/'/g, "_#_apos_#_");
    str = str.replace(/"/g, "_#_quot_#_");
    return str;
  }

  function undisguiseXmlEntities(str) {
    str = str.toString();
    str = str.replace(/_#_amp_#_/g, "&amp;");
    str = str.replace(/_#_lt_#_/g, "&lt;");
    str = str.replace(/_#_gt_#_/g, "&gt;");
    str = str.replace(/_#_apos_#_/g, "&apos;");
    str = str.replace(/_#_quot_#_/g, "&quot;");
    return str;
  }

  function wrapCDATA(str, propNm) {
    str = "<data>" + str + "</data>";
    str = str.replace(/(\<data\>)/g, "<" + propNm + "><![CDATA[");
    str = str.replace(/(\<\/data\>)/g, "]]\>" + "</" + propNm + ">");
    return XML(str);
  }

  function isXMLTagName(tag) {
    var t = !/^[xX][mM][lL].*/.test(tag); // điều kiện 3
    t = t && /^[a-zA-Z_].*/.test(tag); // điều kiện 2
    t = t && /^[a-zA-Z0-9_\-\.]+$/.test(tag); // điều kiện 4
    return t;
  }

  function getXmlFileDest(userInputObj) {
    if (!SETTINGS.keepXML) {
      var dataFile = File(userInputObj.sourceDataPath);
      var xmlDest = File(
        dataFile.parent +
          "/" +
          decodeURI(dataFile.name).replace(/\.\w+$/, ".xml"),
      ).saveDlg("Where would you like to save the Variable Data XML file?");
      return xmlDest;
    } else {
      return File(userInputObj.xmlPath);
    }
  }

  function forceRefreshDoc() {
    var temp = app.documents.add();
    temp.close(SaveOptions.DONOTSAVECHANGES);
  }

  function cycleUpdateAllDatasets(doc, displayElem) {
    for (var i = 0; i < doc.dataSets.length; i++) {
      var d = doc.dataSets[i];
      d.display();
      if (typeof displayElem != "undefined") {
        displayElem.text = i + 1 + " of " + doc.dataSets.length;
        displayElem.window.update();
      }
      redraw();
      $.sleep(10);
      d.update();
    }
    doc.dataSets[0].display();
    displayElem.text = 1 + " of " + doc.dataSets.length;
  }

  function processUserInput(userInputObj) {
    var xmlDest, doc, problem;

    var xmlString = XMLStringBuilder.generateVariableLibraryXMLString();
    if (xmlString == null) {
      return;
    }

    if (userInputObj.purpose == "createXML") {
      xmlDest = getXmlFileDest(userInputObj);
      if (xmlDest == null) {
        alert("Cancelled: no XML file produced.");
        return;
      }

      writeFile(xmlDest, xmlString, "UTF-8");

      if (xmlDest.exists) {
        // alert("File successfully saved in '" + decodeURI(xmlDest) + "'");
        finishedXMLFileDialog(
          xmlDest,
          DATA.currentVars.length,
          DATA.currentGrid.length,
        );
      } else {
        alert(
          "Sorry, the file '" + decodeURI(xmlDest) + "' could not be saved.",
        );
      }
    } else {
      xmlDest = File(userInputObj.xmlPath);
      writeFile(xmlDest, xmlString, "UTF-8");
      if (!xmlDest.exists) {
        alert(
          "Sorry, the file '" + decodeURI(xmlDest) + "' could not be saved.",
        );
        return;
      }
      doc = app.activeDocument;
      if (doc.variables.length > 0) {
        if (!CONFIRMS["showExistingVariablesWarning"](doc.variables.length)) {
          alert("Cancelled: no variables were imported.");
          return;
        }
        if (SETTINGS.selectedAutobinding != "noAutoBinding") {
          for (var i = doc.variables.length - 1; i >= 0; i--) {
            doc.variables[i].remove();
          }
        }
      }

      try {
        problem =
          "Importing Variables into the document from created XML file.";
        doc.importVariables(xmlDest);
        forceRefreshDoc(); // hoá ra phải ép refresh thì mới binding được?

        if (
          SETTINGS.selectedAutobinding != "noAutoBinding" &&
          !(
            userInputObj.fileRefsLog.missingImages.length > 1 ||
            userInputObj.fileRefsLog.missingGraphs.length > 1
          )
        ) {
          problem =
            "Auto-Binding variables to art items based on '" +
            unCamelCaseSplit(SETTINGS.selectedAutobinding) +
            "'";
          DocumentBinding.bindDocumentItems(doc);
        }

        if (
          userInputObj.fileRefsLog.missingImages.length < 2 ||
          userInputObj.fileRefsLog.missingGraphs.length < 2
        ) {
          if (
            doc.dataSets.length > 0 &&
            SETTINGS.selectedAutobinding != "noAutoBinding"
          ) {
            problem = "Displaying first dataset of the document.";
            doc.dataSets[0].display(); // hiển thị dataset đầu tiên.
          }
        }
        finishedXMLImportDialog(
          DATA.currentVars.length,
          DATA.currentGrid.length,
          userInputObj.fileRefsLog.missingImages.length - 1,
          userInputObj.fileRefsLog.missingGraphs.length - 1,
        );
        // thành công!
      } catch (e) {
        alert(
          "Sorry, something went wrong with the import of the generated XML file '" +
            xmlDest +
            "':\n" +
            e +
            "\nPossible Problem: " +
            problem,
        );
      }

      if (!SETTINGS.keepXML) {
        xmlDest.remove();
      }
    }
  }

  var SESSION = {
    os: $.os.match("Windows") ? "Windows" : "Mac",
    AIVersion: parseInt(app.version.split(/\./)[0]),
    scriptName: "VariableImporter.jsx",
    scriptVersion: "8.2.4",
    currentLoadedPresetName: "",
    regexps: {
      varRx: /variable_\d+_value/,
      fileStartRx: /^file\:\/\/\//,
    },
    multiColumnListBoxTest: true,
    documentExists: app.documents.length > 0,
    settingsFile: (function () {
      return File(
        Folder.myDocuments + "/VariableImporter/VariableImporter_SETTINGS.json",
      );
    })(),
    scriptDataFolder: (function () {
      var f = Folder(Folder.myDocuments + "/VariableImporter");
      if (!f.exists) {
        f.create();
      }
      return f;
    })(),
    dataFileMask: function () {
      return this.os == "Windows"
        ? "*.txt;*.TXT;*.csv;*.CSV;"
        : function (f) {
            return (
              f instanceof Folder ||
              (f instanceof File && decodeURI(f.name).match(/(\.txt|\.csv)$/i))
            );
          };
    },
    tabbedGroupTest: false,
    imageTest: false,
    doImageTest: function () {
      var flag = true,
        thisIconString,
        test;
      for (var all in ICONS) {
        thisIconString = ICONS[all];
        test = getScriptImage({
          name: all,
          data: thisIconString,
        });
        ICONS[all] = test;
        if (!test) {
          flag = false;
        }
      }
      this.imageTest = flag;
      return flag;
    },
    init: function () {
      // hàm nạp từ cài đặt
      if (this.settingsFile.exists) {
        this.settingsFile.open("r");
        var settingsObj = JSON.parse(this.settingsFile.read()),
          tempObj;
        this.settingsFile.close();
        // đọc các visibility key vào trước.
        if (
          settingsObj.hasOwnProperty("VisibilityKeys") &&
          settingsObj.VisibilityKeys.length > 0 &&
          comparePropNames(settingsObj.VisibilityKeys[0], VisibilityKeys[0])
            .resMsg == "All Found"
        ) {
          VisibilityKeys = settingsObj.VisibilityKeys;
        }
        if (settingsObj.hasOwnProperty("PRESETS")) {
          for (var i = 0; i < settingsObj.PRESETS.length; i++) {
            tempObj = {};
            for (var all in PRESETS[0]) {
              if (settingsObj.PRESETS[i].hasOwnProperty(all)) {
                tempObj[all] = settingsObj.PRESETS[i][all];
                if (
                  all == "currentlySelected" &&
                  settingsObj.PRESETS[i][all] === true
                ) {
                  if (settingsObj.PRESETS[i].hasOwnProperty("datasetNameObj")) {
                    DATASETNAMEFIELDS_current = clone(
                      settingsObj.PRESETS[i].datasetNameObj,
                    );
                  }
                  if (
                    settingsObj.PRESETS[i].hasOwnProperty(
                      "enabledVisibilityKeyNames",
                    )
                  ) {
                    var currentlyEnabledVisKeyNames =
                      settingsObj.PRESETS[i].enabledVisibilityKeyNames;
                    var currentlyAvailableVisKeyNames =
                      getSpecificPropertyListObj(VisibilityKeys, "name");
                    var areAllEnabledNamesPresent = true;
                    // kiểm tra xem các visibility key đang nạp có chứa đủ mọi tên được bật trong preset hay không
                    // xoá những tên không tìm thấy
                    for (
                      var j = currentlyEnabledVisKeyNames.length - 1;
                      j > -1;
                      j--
                    ) {
                      if (
                        currentlyAvailableVisKeyNames.indexOf(
                          currentlyEnabledVisKeyNames[j],
                        ) == -1
                      ) {
                        currentlyEnabledVisKeyNames.splice(j, 1);
                        areAllEnabledNamesPresent = false; // cờ dùng cho mục đích bất kỳ
                      }
                    }
                    DATASETNAMEFIELDS_current = clone(
                      settingsObj.PRESETS[i].datasetNameObj,
                    );
                  }
                }
              } else {
                tempObj[all] = PRESETS[0][all];
              }
            }
            PRESETS[i] = tempObj;
          }
        }
        if (
          settingsObj.hasOwnProperty("lastChosenDataFilePath") &&
          VI_MEMORY_SETTINGS.lastChosenDataFilePath == ""
        ) {
          VI_MEMORY_SETTINGS.lastChosenDataFilePath =
            settingsObj["lastChosenDataFilePath"];
        }
        // nếu file cài đặt không có custom increment nào thì đằng nào cũng dùng giá trị mặc định
        if (
          settingsObj.hasOwnProperty("CUSTOM_INCREMENTS") &&
          settingsObj.CUSTOM_INCREMENTS.length > 0
        ) {
          var customIncrementsAreAllValid = true,
            currentSettingsCustomInc;
          for (var i = 0; i < settingsObj["CUSTOM_INCREMENTS"]; i++) {
            currentSettingsCustomInc = settingsObj["CUSTOM_INCREMENTS"][i];
            for (var all in CUSTOM_INCREMENTS[0]) {
              // CUSTOM_INCREMENTS trong các object luôn phải có (các) giá trị mặc định
              if (!currentSettingsCustomInc.hasOwnProperty(all)) {
                scriptAlert(
                  "Problem reading custom increment information from the settings file. Defaulting to script-defaults for custom increments.",
                );
                customIncrementsAreAllValid = false;
                break;
              }
            }
          }
          if (customIncrementsAreAllValid) {
            CUSTOM_INCREMENTS_current = settingsObj["CUSTOM_INCREMENTS"];
          }
        }
        if (
          settingsObj.hasOwnProperty("WARNINGSETTINGS") &&
          comparePropNames(settingsObj.WARNINGSETTINGS, WARNINGSETTINGS)
            .resMsg == "All Found"
        ) {
          WARNINGSETTINGS = settingsObj.WARNINGSETTINGS;
          for (var all in WARNINGSETTINGS) {
            if (SETTINGS.hasOwnProperty(all)) {
              SETTINGS[all] = WARNINGSETTINGS[all];
            }
          }
        }
      } else {
        PRESETS.getByName("default").datasetNameObj = DATASETNAMEFIELDS_current;
      }

      this.currentLoadedPresetName = getCurrentlySelectedPresetName();
      this.multiColumnListBoxTest =
        this.os == "Windows" || this.AIVersion != 16 ? true : false;
      this.tabbedGroupTest = this.AIVersion > 13 ? true : false;
      // ScriptUI chưa có tabbedpanel ở Illustrator CS3
    },
  };

  var PresetDialogPurposes = {
    Add: {
      resultAction: function (presetDialogResult, UIElements, listBox) {
        SESSION.currentLoadedPresetName = presetDialogResult.presetName;
        PRESETS.addItem(
          PRESETS.getByName("default"),
          SESSION.currentLoadedPresetName,
        );
        updateScriptDataFromUI(UIElements);
        UIElements.saved = UIElements["disp_dataFile"].getValue() != "";
        populateUI(UIElements);
        refreshPresetListbox(listBox);
      },
      presetDispEditable: true,
      placeholderName: "New Preset",
      actionButtonName: "Add",
      showRemoveButton: false,
    },
    Remove: {
      resultAction: function (presetDialogResult, UIElements, listBox) {
        SESSION.currentLoadedPresetName = "default";
        setCurrentlySelectedPresetName("default");
        PRESETS.removeItemByName(presetDialogResult.presetName);
        populateUI(UIElements, true);
        refreshPresetListbox(listBox);
      },
      presetDispEditable: false,
      placeholderName: "self",
      actionButtonName: "Remove",
      showRemoveButton: true,
    },
    Activate: {
      resultAction: function (presetDialogResult, UIElements) {
        var thisName = presetDialogResult.presetName;
        var thisPreset = PRESETS.getByName(thisName);
        SESSION.currentLoadedPresetName = thisName;
        setCurrentlySelectedPresetName(thisName);
        if (thisPreset.hasOwnProperty("datasetNameObj")) {
          DATASETNAMEFIELDS_current = clone(thisPreset.datasetNameObj);
        }
        // switchStackView(UIElements["stackGroup"], "variablesDisplay");
        UIElements["variablesDisplayR"].notify("onClick");
        populateUI(UIElements, true);
      },
      presetDispEditable: false,
      placeholderName: "self",
      actionButtonName: "Activate",
      showRemoveButton: true,
    },
    Update: {
      resultAction: function (presetDialogResult, UIElements, listBox) {
        var oldName = presetDialogResult.oldName;
        var newName = presetDialogResult.presetName;
        if (PRESETS.getByName(newName) != null && oldName != newName) {
          if (!CONFIRMS["overwriteOtherExistingPreset"](newName)) {
            return;
          }
        } else {
          PRESETS.getByName(oldName).name = newName;
        }
        SESSION.currentLoadedPresetName = newName;
        setCurrentlySelectedPresetName(newName);
        updateScriptDataFromUI(UIElements, newName);
        populateUI(UIElements);
        refreshPresetListbox(listBox);
      },
      presetDispEditable: true,
      placeholderName: "self",
      actionButtonName: "Update",
      showRemoveButton: false,
      oldName: "",
    },
  };

  if (typeof VI_MEMORY_SETTINGS == "undefined") {
    VI_MEMORY_SETTINGS = {
      lastChosenDataFilePath: "",
    };
  }

  var PRESETS = [
    {
      name: "default",
      useHeaders: true,
      currentlySelected: true,
      transpose: false,
      dbslNextline: false,
      keepXML: false,
      xmlPath: "temp",
      selectedAutobinding: "bindByName",
      prependToAllImages: false,
      prependImagePath: "",
      prependToAllGraphs: false,
      prependGraphPath: "",
      datasetNameObj: {},
      enabledVisibilityKeyNames: [
        "True",
        "False",
        "On",
        "Off",
        // "One",
        // "Zero",
      ],
    },
  ];

  PRESETS.getByName = function (value) {
    var item;
    for (var i = 0; i < this.length; i++) {
      item = this[i];
      if (item.hasOwnProperty("name")) {
        if (item.name == value) {
          return item;
        }
      }
    }
    return null;
  };

  PRESETS.getAllNames = function () {
    var namesArr = [];
    var item;
    for (var i = 0; i < this.length; i++) {
      item = this[i];
      if (item.hasOwnProperty("name")) {
        namesArr.push(item.name);
      }
    }
    return namesArr;
  };

  PRESETS.removeItemByName = function (name) {
    var item;
    for (var i = 0; i < this.length; i++) {
      item = this[i];
      if (item.hasOwnProperty("name") && item.name == name) {
        this.splice(i, 1);
        break;
      }
    }
  };

  PRESETS.addItem = function (cloneObj, newName) {
    if (this.getByName(newName) != null) {
      var conf = confirm(
        "This preset '" + newName + "' already exists, overwrite?",
      );
      if (!conf) {
        return;
      }
      this.removeItemByName(newName);
    }
    var obj = {};
    for (var all in cloneObj) {
      obj[all] = cloneObj[all];
    }
    obj.name = newName;
    this.push(obj);
    var thisObj;
    for (var i = 0; i < this.length; i++) {
      thisObj = this[i];
      if (thisObj.name != newName) {
        thisObj.currentlySelected = false;
      } else {
        thisObj.currentlySelected = true;
      }
    }
  };

  var CUSTOM_INCREMENTS = [
    {
      // ví dụ chung & gợi ý quy ước đặt tên.
      name: "s0p3i1",
      startNum: 0,
      padZero: 3,
      increment: 1,
      isIntervalIncrement: false,
    },
    {
      name: "s1p2i1",
      startNum: 1,
      padZero: 2,
      increment: 1,
      isIntervalIncrement: false,
    },
    {
      name: "s1p2i10-interval",
      startNum: 1,
      padZero: 3,
      increment: 10,
      isIntervalIncrement: true,
    },
  ];

  var WARNINGSETTINGS = {
    showDatasetNamingWarning: true,
    showExistingVariablesWarning: true,
    confirmRemovalOfPresets: true,
    confirmUpdatingOfPresets: true,
    showSuccessfulSettingsFileSaves: true,
  };

  var CONFIRMS = {
    showDatasetNamingWarning: function () {
      if (WARNINGSETTINGS["showDatasetNamingWarning"] == true) {
        return confirm(
          "This data import has been defaulted to generic dataset names. Continue import?",
        );
      }
      return true;
    },
    showExistingVariablesWarning: function (numVars) {
      if (WARNINGSETTINGS["showExistingVariablesWarning"] == true) {
        return confirm(
          "This document already contains " +
            numVars +
            " variable" +
            (numVars > 1 ? "s" : "") +
            " which may be overwritten. Continue import?",
        );
      }
      return true;
    },
    confirmRemovalOfPresets: function (presetName) {
      if (WARNINGSETTINGS["confirmRemovalOfPresets"] == true) {
        return confirm("Remove Preset '" + presetName + "' ?");
      }
      return true;
    },
    confirmUpdatingOfPresets: function (presetName) {
      if (WARNINGSETTINGS["confirmUpdatingOfPresets"] == true) {
        return confirm("Update Preset '" + presetName + "' ?");
      }
      return true;
    },
    overwriteOtherExistingPreset: function (presetName) {
      if (WARNINGSETTINGS["confirmUpdatingOfPresets"] == true) {
        return confirm("Overwrite Preset '" + presetName + "' ?");
      }
      return true;
    },
  };

  var SETTINGS = {
    useHeaders: true,
    transpose: false,
    dbslNextline: false,
    keepXML: false,
    xmlPath: "",
    selectedAutobinding: "noAutoBinding",
    prependToAllImages: false,
    prependImagePath: "",
    prependToAllGraphs: false,
    prependGraphPath: "",
    getDataXMLDestination: function () {
      return File(
        Folder.desktop +
          "/VariableImporterData_" +
          new Date().getTime() +
          ".xml",
      );
    },
    incrementStartNumber: 1,
  };

  var DATASETNAMEFIELDS = {
    field_1: {
      type: "customText",
      text: "Record",
    },
    field_2: {
      type: "dash",
      text: "-",
    },
    field_3: {
      type: "increment",
      text: "INC",
    },
    field_4: {
      type: "nothing",
      text: "",
    },
    field_5: {
      type: "nothing",
      text: "",
    },
    field_6: {
      type: "nothing",
      text: "",
    },
  };

  var FIELDNAMEOPTIONS = {
    customText: {
      defaultText: "[Edit Text]",
      displayText: "Custom Text",
      type: "customText",
    },
    dash: {
      defaultText: "-",
      displayText: "Dash",
      type: "dash",
    },
    nothing: {
      defaultText: "",
      displayText: "Nothing",
      type: "nothing",
    },
    space: {
      defaultText: " ",
      displayText: "Space",
      type: "space",
    },
    increment: {
      defaultText: "INC",
      displayText: "Increment",
      type: "increment",
    },
    underscore: {
      defaultText: "_",
      displayText: "Underscore",
      type: "underscore",
    },
    customIncrement: {
      defaultText: "<custom increment name set here>",
      displayText: "Custom Increment",
      type: "customIncrement",
    },
  };

  var DATASETNAMEFIELDS_current = clone(DATASETNAMEFIELDS);
  var FIELDNAMEOPTIONS_current = clone(FIELDNAMEOPTIONS);
  var CUSTOM_INCREMENTS_current = clone(CUSTOM_INCREMENTS);

  var VARTYPES = {
    Text: {
      key: "",
      type: "Text",
      itemKind: "TextFrame",
      trait: "textcontent",
      category: "&ns_flows;",
      varKind: "VariableKind.TEXTUAL",
      contentKind: "contentVariable",
    },
    Visibility: {
      key: "#",
      type: "Visibility",
      itemKind: "All",
      trait: "visibility",
      category: "&ns_vars;",
      varKind: "VariableKind.VISIBILITY",
      contentKind: "visibilityVariable",
    },
    Image: {
      key: "@",
      type: "Image",
      itemKind: "PlacedItem",
      trait: "fileref",
      category: "&ns_vars;",
      varKind: "VariableKind.IMAGE",
      contentKind: "contentVariable",
    },
    Graph: {
      key: "%",
      type: "Graph",
      itemKind: "GraphItem",
      trait: "graphdata",
      category: "&ns_graphs;",
      varKind: "VariableKind.GRAPH",
      contentKind: "contentVariable",
    },
  };

  var UI_SIZING = {
    variableDisplay: {
      small: {
        varAmt: "1-8",
        height: 150,
      },
      medium: {
        varAmt: "9-15",
        height: 300,
      },
      large: {
        varAmt: "16-Infinity",
        height: 500,
      },
    },
    bindingTestDisplay: {
      preferredSize: [430, 300],
    },
    foundOfTotalDisp: {
      // các ô nhập hiển thị số tham chiếu file tìm thấy/tổng số
      characters: 12,
    },
    sizeSpecs: {
      platforms: {
        Windows: {},
        Mac: {},
      },
    },
    panelWidth_1: 466,
    init: function () {},
  };

  var DATA = {
    grid: [],
    transposedGrid: [],
    currentSourceFile: "",
    currentVars: [],
    oldVars: [],
    testVariableName: function (oldName, newName) {
      var msg = "",
        allVarNames = getSpecificPropertyListArr(DATA.currentVars, "varName");
      if (!isXMLTagName(newName)) {
        msg =
          "The '" +
          newName +
          "' variable name doesn't not follow the proper XML syntax:\n" +
          INFO.xmlRequirements;
        scriptAlert(msg);
        return false;
      } else {
        if (
          checkForSingleDuplicate(allVarNames, newName).length > 0 &&
          oldName != newName
        ) {
          msg =
            "The '" +
            newName +
            "' variable name already exists among imported variable names.";
          scriptAlert(msg);
          return false;
        }
      }
      return true;
    },
    testNameProp_unique: function (argsObj) {
      // argsObj = {collection : [], prop : "varName", prefixString : "Variable", collectionName : "Variables", showDialog : true}
      var badArr = [],
        namesArr,
        msg;
      namesArr =
        typeof argsObj.prop == "string"
          ? getSpecificPropertyListArr(argsObj.collection, argsObj.prop)
          : argsObj.collection;

      badArr = arrayGetUniqueDuplicates(namesArr);
      if (badArr.length > 0) {
        msg =
          "The following " +
          argsObj.collectionName +
          " name(s) are found more than once\n" +
          "(All " +
          argsObj.collectionName +
          " names are going to be Auto-replaced):" +
          "\n--------------------------------------\n" +
          badArr.join("\n");
        if (argsObj.showDialog) {
          quickView(
            msg,
            argsObj.collectionName + " Names Correction",
            [400, 550],
          );
        }
        this.genericize(argsObj.collection, argsObj.prop, argsObj.prefixString);
        return false;
      }
      return true;
    },
    testVarNames_xml: function () {
      var badArr = [],
        thisVar,
        msg;
      for (var i = 0; i < this.currentVars.length; i++) {
        thisVar = this.currentVars[i];
        if (!isXMLTagName(thisVar.varName)) {
          badArr.push(thisVar.varName);
        }
      }
      if (badArr.length > 0) {
        msg =
          "Proper XML Syntax isn't followed by some variable name(s)\n" +
          INFO.xmlRequirements +
          "\n" +
          "(All names are going to be Auto-replaced):\n--------------------------------------\n" +
          badArr.join("\n");

        quickView(msg, "Variable Name Correction", [400, 550]);
        this.genericize(this.currentVars, "varName", "Variable");
        return false;
      } else {
        return true;
      }
    },
    genericize: function (collection, prop, prefixString) {
      if (typeof prop == "undefined") {
        for (var i = 0; i < collection.length; i++) {
          collection[i] = prefixString + (i + 1);
        }
      } else {
        for (var i = 0; i < collection.length; i++) {
          collection[i][prop] = prefixString + (i + 1);
        }
      }
    },
    getCurrentVars: function (UIElements) {
      if (this.currentSourceFile == "" || this.grid.length == 0) {
        return null;
      }
      this.oldVars = [];

      if (
        typeof UIElements != "undefined" &&
        UIElements["variableDisplay"].items.length > 0
      ) {
        for (var i = 0; i < DATA.currentVars.length; i++) {
          if (i < DATA.currentVars.length) {
            this.oldVars.push(DATA.currentVars[i]);
          }
        }
      }
      var data = SETTINGS.transpose ? this.transposedGrid : this.grid;
      this.currentVars = [];
      var varName = "",
        varType = "",
        datum = "",
        thisUrl;
      for (var i = 0; i < data[0].length; i++) {
        // hàng tiêu đề chính là tên các biến
        datum = data[0][i];
        varName = SETTINGS.useHeaders
          ? datum.replace(/^[@#%]/, "")
          : "Variable" + (i + 1);
        varType = SETTINGS.useHeaders ? getVariableType(datum) : "Text";
        thisUrl = "";
        if (varType == "Image" || varType == "Graph") {
          if (SETTINGS["prependToAll" + varType + "s"]) {
            thisUrl = SETTINGS["prepend" + varType + "Path"];
          }
        }

        this.currentVars.push({
          varIndex: i,
          varName: varName,
          varType: varType,
          useUrl: true,
          url: thisUrl,
        });
      }
      if (this.testVarNames_xml()) {
        this.testNameProp_unique({
          collection: this.currentVars,
          prop: "varName",
          prefixString: "Variable",
          collectionName: "Variable",
          showDialog: true,
        });
      }
    },
    getVariableNames: function () {
      if (this.currentVars.length > 0) {
        return getSpecificPropertyListArr(this.currentVars, "varName");
      }
      return [];
    },
    currentGrid: [],
    currentDatasetNames: [],
    getCurrentGrid: function () {
      if (this.currentVars.length == 0) {
        return [];
      }
      var data = !SETTINGS.transpose ? this.grid : this.transposedGrid;
      var start = !SETTINGS.useHeaders ? 0 : 1;
      var row,
        cell,
        arr = [],
        rowArr = [],
        thisVar,
        dsnArr = [];
      for (var i = start; i < data.length; i++) {
        row = data[i];
        rowArr = [];
        dsnArr.push(
          getRecordDatasetName(DATASETNAMEFIELDS_current, row, i - start),
        );
        for (var j = 0; j < row.length; j++) {
          cell = row[j];
          thisVar = this.currentVars[j];
          if (
            thisVar.url != "" &&
            (thisVar.varType == "Image" || thisVar.varType == "Graph")
          ) {
            cell = getPrependPathValue(thisVar, cell);
          }
          rowArr.push(cell);
        }
        arr.push(rowArr);
      }
      this.currentGrid = arr;

      this.currentDatasetNames = dsnArr;
    },
    getTestDatasetNames: function (dsNameFieldObj) {
      if (this.currentVars.length == 0) {
        return [];
      }
      var data = !SETTINGS.transpose ? this.grid : this.transposedGrid;
      var start = !SETTINGS.useHeaders ? 0 : 1;
      var row,
        dsnArr = [];
      for (var i = start; i < data.length; i++) {
        row = data[i];
        dsnArr.push(getRecordDatasetName(dsNameFieldObj, row, i - start));
      }

      this.testNameProp_unique({
        collection: dsnArr,
        prop: undefined,
        prefixString: "Record ",
        collectionName: "Dataset",
        showDialog: WARNINGSETTINGS["showDatasetNamingWarning"],
      });

      return dsnArr;
    },
  };

  var AUTOBINDING = {
    noAutoBinding: {
      type: "noAutoBinding",
      text: "No Auto Binding",
      getProp: function (item) {
        return "N/A";
      },
    },
    bindByName: {
      type: "bindByName",
      text: "Bind By Name",
      getProp: function (item) {
        return item["name"];
      },
    },
    bindByNote: {
      type: "bindByNote",
      text: "Bind By Note",
      getProp: function (item) {
        return item["note"];
      },
    },
    bindByTag: {
      type: "bindByTag",
      text: "Bind By Tag",
      preferredTagName: "VariableImporterBinding",
      getProp: function (item) {
        if (item.tags.length > 0) {
          return getSpecificPropertyListArr(item.tags, "name");
        } else {
          return [];
        }
      },
    },
  };

  var VisibilityKeys = [
    {
      displayText: "true",
      name: "True",
      value: true,
      enabled: true,
    },
    {
      displayText: "false",
      name: "False",
      value: false,
      enabled: true,
    },
    {
      displayText: "on",
      name: "On",
      value: true,
      enabled: true,
    },
    {
      displayText: "off",
      name: "Off",
      value: false,
      enabled: true,
    },
    {
      displayText: "1",
      name: "One",
      value: true,
      enabled: false,
    },
    {
      displayText: "0",
      name: "Zero",
      value: false,
      enabled: false,
    },
  ];

  var ICONS = {
    Visibility:
      '\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x14\x00\x00\x00\x14\b\x02\x00\x00\x00\x02\u00EB\u008AZ\x00\x00\x00\x19tEXtSoftware\x00Adobe ImageReadyq\u00C9e<\x00\x00\x01?IDATx\u00DAb\u00FC\u00FF\u00FF?\x03\u00B9\u0080qT3\x14|\u00F8\u00F0\u00E1\u00C2\u0085\x0Bp\u00AE\u0081\u0081\u0081\u0080\u0080\x00a\u00CD\x0B\x16,\u00988q"P\u00A9\u008E\u00A9\u00C5\u0091\u00FB/\u00B9X\u0099\u008DdD\u008E\u00EC\u00DE\x01\u0094\u00CA\u00CF\u00CFOHH\u00C0\u00AEy\u00C3\u0086\r\u008D\u008D\u008D\u00FE\u00FE\u00FE@\x15L\x02"\u00E7\u009F\u00BE\x05j~\u00F3\u00F5\x07P*\u00D9L]\u0086\u00F1;\u00D0\u00DC\u008D\x1B7\u00D6\u00D7\u00D7\x07\x04\x04@u\x035\u00BF\x7F\u00FF\x1E\u00A8\x01(t\u00FF\u00FE} \u00F7\u00F5\u0097\u00EF\x1B\u00AE<\x002z\u00A6\u00CEP\u00B1\u00F7\u0088\u009A\u00B75a\u00C5A\u00A0 P\x04\u00A8\u00C0\u00C1\u00C1\x01\u00A8\x18\u00A8\x05d+\u0090\x02z\u00A9\u00BF\u00BF\u00FF?\f\u00EC\u00BC\u00F9\u00A4d\u00F3I\u00A0N\u0088?\u0081\u00FA\u0081\u009A\u00D7_~\x00W\x00T\f\u00D4\x02\u00D4\u00C8\u0082\x19\f\u00DF~\u00FD\x01\u00BAv\u00C3\u00AA\r\u00C0`\u0083\x0Br\u00B1aQ\u00C9\x044~\u00FF\u00FE\u00FD\x17/^ttt|\u00F0\u00E0\x01P\u00C8FQ\x1CH\u009A\u00C5\u00E7\x02\u00ED\x04" \x03\u00C85\u0092\x16\x06\u0092@\x05\u0081\u0081\u0081@\u00C5@-@\u008D\u00D8\x03\u00EC\u00C9\x7F\u00CE\u00B9\u00A7n\u00C2m\u00C0\x15`\u00D8\u00A3\nd\u00BF\u00AB\u00C7\u00B9\'o\u00BE\u00FD\u00FE\x0Bt\u00C8\u0095\u00D3\'\u0080^\u00C0\x17UTH$\u00A3Y\u0092\x00\x00\b0\x00\u009C \u00F4D\u0080v\u00BF\u00C6\x00\x00\x00\x00IEND\u00AEB`\u0082',
    Image:
      '\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x14\x00\x00\x00\x14\b\x02\x00\x00\x00\x02\u00EB\u008AZ\x00\x00\x00\x19tEXtSoftware\x00Adobe ImageReadyq\u00C9e<\x00\x00\x01\x7FIDATx\u00DAb\u009C\u009B\u00CF@6`b\u00A0\x00\u00B0@(\u00A5\t_H\u00D2v\u00AF\u0080\x07\u00C5fY\u0086j=\x06mm\x06\x0B\x1E\u0086\u00D3\u00C8\u00EA\u0098\x19\u00FE\x13v\u00B6 \u00C3\x06\u00B0\u00D2\u00CF\u00E2\fS\u0091\x04\u00BF\x0B}~y\u00E1\u00D2\u00EB\u009F?\u00FF\u00E2\u00D3\u00FC\u0097\u0081\x17\u00C2\u00F8\u00C5 \r\x17\u00E4\u00FB\u00FB\u00ED\u00E7\x1F\x06y\u00DE\u00BF\u009F>\u00FF\u00C2\u00E9g\u00907\x18\x16\u00883L\u00FB\u00C5 \u00F5\u0092!\x1B"\u00F2\u00E3\u00F3w&\u00B6\u00DF@\u00C6\u00F3\u00CF\f\x7F\u00BF}\u00E3\u00E6b\u00E5\u00E2b\u00C1\u00AE\u00F9;\u0083\u00C6\x03\u0086Ip\u00EE\u00EB7\u00DFY>\x7F\u00E4Ud\u00E0eg\u00D8}\x07(\u00F0\u00FB\u00DA\u008DwZ\x1AB\u00C8\u00FAY\u00B0\u0086\x04P\u00E7\u00BD\u00FB\x1F!la.\u0098\u00BF\u00FE\u00FE\u00BB{\u00FF#P?33#>\u00CDJ\\?\u00CD\u00F4\x18~\u00FDe\u00B8\u00F5\x06\u00AA\x19H\u00BE\u00FD\u00C6\u00F0\u00ED\u00DB\u00EFO\u009F~\t\n\u00B2\u00A3h.L\u00E5@\u00D6l\u00A4\u00CE\u00DF]\u00F2\u00E3\u00CAK\u0084f6f\u0090\u00FB\x1F=ci\u009A\u00C5\x0F\u00E4\u00E6r#i\u00BEp\u0086\x19Y\u00F3\u00853<5\u00E9\u00AF\u009F\x7F\u00FE\x07\u00D4\t4\x02\x12f@p\u00ED\x027T\u00A5=\u00DE\u00E4\u00B9|\x13\u00AF\u00AB\n\u0083\u008F\x06\u0083\u00A5\x1CB\u00F0\u00C8\x1E\x01\u00A2\u00D2\u00F6\u00F2\u00CD\u00BCh"\u00CF\x1F\u00B3\u00BF\x7F\u00CBB\u0094\u00E6+7\u00D9\u0081\bY\u00E4\u00C8^~\u009C\u0089\x04\x13\u00D8G\u00C8x9~57\u00FB\u00BA\u00FB\f\u00FB\u00D5\x0B\u00DCh\u00D6\x12\u00D0\f\x04\u00DB\u00F6s\x03\x11-\u00F3\u00F3\\{Fz\u0097$\x00\x01\x06\x00<\u00E3\u0084d\u0089\u00F2\x1C;\x00\x00\x00\x00IEND\u00AEB`\u0082',
    Graph:
      "\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x14\x00\x00\x00\x14\b\x02\x00\x00\x00\x02\u00EB\u008AZ\x00\x00\x00\x19tEXtSoftware\x00Adobe ImageReadyq\u00C9e<\x00\x00\x01\u00FDIDATx\u00DAbd``\u00F8\u00FF\u00FF?\x03\u00E9\u0080\u0091\u0091\u0091\x05H\u009D={\u0096\u0081,\u00C0H\u0089\u00CDL\f\x14\x00,\u00CE\u00E6z\u00FC\x14\u00C2\u00F8\u00CB\u00CE\u00FESL\u0084\u0080\x01\u00FFQ\u00C1Au]\x0F~\u00C1J\t\u0099\u008B\u00B1I\u00FFq\x03\u00A0F\u00EC\u00CE\u00DE\u00F1\u00F1\u00FD\u00E1/\u009F\b:\x1B\u008B\u00E6\x0B\u00DF\u00BE&\u008A\u0088\u00F303\x13\u00E5\u00E7\x07\u0093\u00B6\n\x1F}\x0E\u00E1?\u0089T]\u00FD\u00FEM\u00AB\u00B4\u00FC\u0082\u00B7\u00AFn\u00BF\x7F\u00FB\x1B)8\u00B8\x7F>Vz\u00B9\u00FC\u00F0\u00ED\u009F\x0F\u00DF\u00FD\u00D9s\x07\u00A6Y\u00FC/\u00C7\u00F7\x13\u00F7 *\u0096~<\x1C*\b\n$\x0F>\u0081#\u00FF\u00FE\x04\x1B\x1B\u00C35\u00FF{\u00FA{\u00CF\u00CA\u0083\u00EE\u0093^\u00C6\u009As/\u009A\u00D4\u00BC|\u00EDV\x14g?\u00FA\u00F3\u00F1\u008B4\u00A7\x01\x177\u0090-\u00C1\u00CAv\u00E7\u00D2e4w\x02\u00ED\x04\u00EA\u00CCq\u00E0E\u00F8\u00F9\u00D5\u00ABW\x10N\u00D7\u00C7\u00C3\u0099\u00FE\u00D1p\u00A5N\x1C\u00DC\u0093'O~\x06\x03w\u009F\u00BC:|\u00FB\u00C7\u00AC\x18a=\x19\u00B6\u00CF\u009F\u00BF@5\u00D7\u00EE[x\u00E5\u00D7\u00CB\u00E5_/\u00EB\u00B0\u0089\u00F33q\u00C05\u00DB\x18\x1B\x1D<x\x10\u00CE\u009D\u00BCt\x0F\u00DCN\u0084\u00CD3#J;?\x1E\u00C9y\u00BB\u00C5\u0086]NXD\x18.\u00C7\u00CE\u00C6\u00AEone\u00B3\u00EC\u00B2\u00CB\u00B1\u00BF\u00F6\x1B\x1F2\u00BE8\x05\u00B4\x13\"\u00C5\u00CB\u00CB\u0083\u0088\u00AA\f>S/N5Y\x16~4O\u00F2;\u0084~<\u00B0\x1A\u00C8x9\u00BF1<\u00BF\nKT=\x7F\u00FE\u00DC\u009A]\u00CEZT\x0E\u00C8\u00BE}\u00EB\x16\\\u00EE\u00F3\u00E7O/?}\x051N\u00EF\u00E45s\u0083\u00B0!\x00\u00A8\x05j\u00B3\u00A4\u00A4$\\TUM\r\u00CE\u00E6\u00E5\u00E5\u0093\u0092\u0094\u00FC\u00FB\u00F5\u00D3\u0093\u00AET.mKde\x106\x0B\u00C1d\x04\u00B4\u00F3\u00DF\u00D7OL\\|\f\f\u00AF\u00B18\u009B\u0080fSw \x023_c)\f\u00E4X\u00F8\u00E1Au\u00E5\u00D7+E\x0Eh\u00AA\u00FE\u00F2\u00F7\u00EFC>\x11V1Y\b\u0097\u00E3\u00E5u\x1D\u00C1\x1F\u00D0\u00D4\u00F2\u00F6\x0F0\u00C1\x00\x04\x18\x00b\u00C8\u00EF\x17\u00C9\u00FD\u009FL\x00\x00\x00\x00IEND\u00AEB`\u0082",
    Text: "\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x14\x00\x00\x00\x14\b\x02\x00\x00\x00\x02\u00EB\u008AZ\x00\x00\x00\x19tEXtSoftware\x00Adobe ImageReadyq\u00C9e<\x00\x00\x00\u00B1IDATx\u00DAb\u00FC\u00FF\u00FF?\x03\u00B9\u0080\x05\u0088/\\\u00B8\u00F0\u00E1\u00C3\x07\u0092\u00B4\t\b\b\x18\x18\x180\x00mvpp \u00D5N\u00A0\x16\u00A0F&\x06\n\x00\x0B\u00B2a\u00C8\x12\x0F\u00C0\x00\u00C8P\x00\x03d\u00A9\x03\x07\x0E@Ypg\u00FFG\x05\u00F5\u00F5\u00F5\x10\x05@\x06\u009A\x14\u00F5\u009C\u00DD\u00DF\u00DFORh\u00EF\u00DF\u00BF\x1F\x18\u00DAP\u00CD\u00A0@'1\u00A8!\f\u008A\u009C=\u00AA\u0099Z\u009A\x1F>|\u0088\u00C6\u00C0\u0097\u00B6\u0081\x00\u0098T\u0080\u00D9\x13\u00C8\u00D8\u00B8q\u00E3\u0082\x05\x0B \u0082@\x060I\u00F8\u00FB\u00FBCR\x04$y \u00D26\x1C\x00\u0093\x0E\u00C1\u00B4\u0085\u00AC\u009E\x11\u00B9$\u0081\u00DB\u008C\x0B\u00A0\u00D9\u00CCHI1\x04\x10`\x00\u00C5_\u0084\u00C3\u008F\u00CF\u00D1\u009F\x00\x00\x00\x00IEND\u00AEB`\u0082",
  };

  var INFO = {
    xmlRequirements:
      "1) Element names are case-sensitive" +
      "\n" +
      "2) Element names must start with a letter or underscore" +
      "\n" +
      "3) Element names cannot start with the letters xml (or XML, or Xml, etc)" +
      "\n" +
      "4) Element names can contain letters, digits, hyphens, underscores, and periods" +
      "\n" +
      "5) Element names cannot contain spaces",
  };

  SESSION.init();

  var DocumentBinding = {
    // tên biến được coi là duy nhất, còn các thuộc tính dùng để nhận diện object (.name , .note và .tags.tag) thì không.
    artItems: {},
    namedArtCollection: [],
    getNamedBinds: function (doc) {
      if (DATA.currentVars.length == 0) {
        return null;
      }
      this.artItems = {};
      this.namedArtCollection = this.getAllDocumentNamedItems(
        doc,
        AUTOBINDING[SETTINGS.selectedAutobinding],
      );
      var varNames = DATA.getVariableNames(),
        varTypes = getSpecificPropertyListArr(DATA.currentVars, "varType"),
        newVarBindObj;
      for (var i = 0; i < varNames.length; i++) {
        newVarBindObj = {};
        if (SETTINGS.selectedAutobinding == "noAutoBinding") {
          newVarBindObj.bindCollection = [];
        } else {
          newVarBindObj.bindCollection = this.getSortedNamedItems(
            this.namedArtCollection,
            varNames[i],
            varTypes[i],
            AUTOBINDING[SETTINGS.selectedAutobinding],
          );
        }
        newVarBindObj.varType = varTypes[i];
        this.artItems[varNames[i]] = newVarBindObj;
      }
    },
    getAllDocumentNamedItems: function (doc, method) {
      var arr = [],
        testProp,
        thisItem;
      for (var i = 0; i < doc.pageItems.length; i++) {
        thisItem = doc.pageItems[i];
        testProp = method.getProp(thisItem);
        if (testProp instanceof Array && testProp.length > 0) {
          // xử lý trường hợp tag
          arr.push(thisItem);
        } else if (typeof testProp == "string" && testProp != "") {
          arr.push(thisItem);
        }
      }
      return arr;
    },
    getSortedNamedItems: function (collection, varName, varType, method) {
      var arr = [],
        thisItem,
        testProp,
        testTag;
      for (var i = 0; i < collection.length; i++) {
        thisItem = collection[i];
        if (
          thisItem.typename == VARTYPES[varType].itemKind ||
          VARTYPES[varType].itemKind == "All"
        ) {
          testProp = method.getProp(thisItem);
          if (testProp instanceof Array && testProp.length > 0) {
            // xử lý trường hợp tag
            if (testProp.indexOf(varName) > -1) {
              arr.push(thisItem); // lấy item nếu tên tag trùng với tên biến
            } else {
              try {
                testTag = thisItem.tags.getByName(method.preferredTagName);
                if (testTag.value == varName) {
                  arr.push(thisItem); // lấy item nếu tag có tên "VariableImporterBinding" và giá trị trùng với tên biến
                }
              } catch (e) {}
            }
          } else if (typeof testProp == "string" && testProp == varName) {
            arr.push(thisItem);
          }
        }
      }
      return arr;
    },
    getBindObjectTestResults: function () {
      var artItemNames = getPropertyList(this.artItems);
      if (artItemNames.length == 0) {
        return null;
      }
      var res = {
        log: "",
        countTextVars: 0,
        foundTextItems: 0,
        countImageVars: 0,
        foundImageItems: 0,
        countGraphVars: 0,
        foundGraphItems: 0,
        countVisibilityVars: 0,
        foundVisibilityItems: 0,
      };

      var arrLog = [
        "Autobinding method: " +
          unCamelCaseSplit(SETTINGS.selectedAutobinding) +
          "\n-------------------",
      ];
      var thisName,
        thisItem,
        thisVarObj,
        thisBindCollectionCount = 0,
        foundItemString = "",
        thisFoundProp,
        thisVarCountProp;
      for (var i = 0; i < artItemNames.length; i++) {
        thisName = artItemNames[i];
        thisItem = this.artItems[thisName];
        thisVarObj = getSpecificPropertyObj(
          DATA.currentVars,
          "varName",
          thisName,
        );
        thisBindCollectionCount = thisItem.bindCollection.length;
        res["found" + thisVarObj.varType + "Items"] += thisBindCollectionCount;
        res["count" + thisVarObj.varType + "Vars"] += 1;
        arrLog.push(thisName + " : " + thisBindCollectionCount);
      }

      for (var all in VARTYPES) {
        thisFoundProp = "found" + all + "Items";
        thisVarCountProp = "count" + all + "Vars";
        foundItemString +=
          all + ": " + res[thisFoundProp] + "/" + res[thisVarCountProp] + ", ";
      }

      res.log = arrLog.join("\n");
      res.foundItemString = foundItemString.replace(/,\s$/, "");

      return res;
    },
    bindDocumentItems: function (doc) {
      this.getNamedBinds(doc);
      var artItemNames = getPropertyList(this.artItems),
        artCollection,
        artItem,
        thisDocVar,
        thisContentKind,
        thisVarTypeObj;

      var artItems = this.artItems,
        thisArtItemsVarName = "",
        currentSelection;
      artItemNames.sort(function (a, b) {
        if (artItems[a].varType == "Visibility") {
          return true;
        } else {
          return false;
        }
      });

      if (artItemNames.length == 0) {
        return null;
      }
      for (var i = 0; i < artItemNames.length; i++) {
        thisArtItemsVarName = artItemNames[i];
        thisDocVar = doc.variables.getByName(thisArtItemsVarName);
        for (var that in VARTYPES) {
          thisVarTypeObj = VARTYPES[that];
          if (thisVarTypeObj.varKind == thisDocVar.kind) {
            thisContentKind = thisVarTypeObj.contentKind;
            break;
          }
        }
        artCollection = this.artItems[thisArtItemsVarName].bindCollection;
        for (var j = 0; j < artCollection.length; j++) {
          artItem = artCollection[j];
          artItem[thisContentKind] = thisDocVar;
        }
      }
    },
  };

  function FileTestSeeker(prop) {
    return {
      makeUIContents: function (parent, propObj) {
        parent.spacing = 4;
        var size;
        if (typeof propObj.size == "undefined") {
          size = [350, 200];
        } else {
          size = propObj.size;
        }
        var disp_foundMissingNum = parent.add(
          "edittext { properties : {readonly : true}, justify : 'center' }",
        );
        disp_foundMissingNum.characters = UI_SIZING.foundOfTotalDisp.characters;

        var foundNum = "",
          missingNum = "",
          parsedNums;
        if (propObj.hasOwnProperty("foundMissingNum")) {
          disp_foundMissingNum.setValue(propObj.foundMissingNum);
          parsedNums = propObj.foundMissingNum.split("/");
          foundNum = parsedNums[0];
          missingNum = parsedNums[1] - foundNum;
        }
        var lbl_foundImageFiles = parent.add(
          "statictext",
          undefined,
          "Found " + prop + " Files: " + foundNum,
        );
        var foundList = parent.add("edittext", undefined, "", {
          readonly: true,
          multiline: true,
        });
        foundList.size = size;
        if (propObj.hasOwnProperty("foundFiles")) {
          foundList.setValue(propObj.foundFiles);
        }
        var lbl_missingImageFiles = parent.add(
          "statictext",
          undefined,
          "Missing " + prop + " Files: " + missingNum,
        );
        var missingList = parent.add("edittext", undefined, "", {
          readonly: true,
          multiline: true,
        });
        missingList.size = size;
        if (propObj.hasOwnProperty("missingFiles")) {
          missingList.setValue(propObj.missingFiles);
        }
        return {
          foundList: foundList,
          missingList: missingList,
          disp_foundMissingNum: disp_foundMissingNum,
        };
      },
      makeTab: function (parentTabbedPanel) {
        var tab = parentTabbedPanel.add("tab", undefined, prop + " Files");
        tab.key = prop;

        parentTabbedPanel.window.UITestElements["testTab" + prop] = tab;

        tab.contents = this.makeUIContents(tab, { size: [515, 130] });

        tab.populateFields = function () {
          var allResults = getFileRefTestResults();
          var thisRefResultNumFound =
            allResults["found" + prop + "s"].length - 1;
          var thisRefResultNumMissing =
            allResults["missing" + prop + "s"].length - 1;
          var foundFiles = allResults["found" + prop + "s"].slice(1).join("\n");
          var missingFiles = allResults["missing" + prop + "s"]
            .slice(1)
            .join("\n");
          var foundMissingNum =
            thisRefResultNumFound +
            "/" +
            (thisRefResultNumFound + thisRefResultNumMissing);
          tab.contents.foundList.setValue(foundFiles);
          tab.contents.missingList.setValue(missingFiles);
          tab.contents.disp_foundMissingNum.setValue(foundMissingNum);
        };
        tab.resetFields = function () {
          for (var all in this.contents) {
            this.contents[all].setValue("");
          }
        };
        return tab;
      },
    };
  }

  var GraphDataGatherer = {
    emptyGraphString:
      '<data  numDataColumns="2">' +
      "\r" +
      "<values>" +
      "\r" +
      "<row>" +
      "\r" +
      '<value  key="name"></value>' +
      "\r" +
      "<value>1</value>" +
      "\r" +
      "</row>" +
      "\r" +
      "</values>" +
      "\r" +
      "</data>",
    getGraphData: function (graphFilePath) {
      var graphFile;
      try {
        graphFile = File(graphFilePath);
        if (!graphFile.exists) {
          throw new Error(
            "Graph File not found: '" + decodeURI(graphFilePath) + "'",
          );
        }
        return this.getGraphDataFromFile(graphFile);
      } catch (e) {
        // alert(e);
        return this.emptyGraphString;
      }
    },
    isquoted: function (str) {
      return str.charAt(0) === '"' && str.charAt(str.length - 1) === '"';
    },
    unquoted: function (str) {
      if (str.charAt(0) === '"' && str.charAt(str.length - 1) === '"') {
        return str.substring(1, str.length - 1);
      } else {
        return str;
      }
    },
    analyzeCellContent: function (cell) {
      var res = {
        isQuoted: false,
        isNumber: false,
        isWord: false,
      };
      var rxNum = /^-?\d*[\.]?\d+$/;
      var rxWord = /[a-z]/gi;
      res.isQuoted =
        cell.charAt(0) === '"' && cell.charAt(cell.length - 1) === '"';
      res.isNumber =
        (res.isQuoted && rxNum.test(cell.replace(/"/g, ""))) ||
        (!res.isQuoted && rxNum.test(cell));
      res.isWord =
        (!res.isNumber && rxWord.test(cell)) ||
        (!res.isQuoted && !res.isNumber);
      return res;
    },
    getGraphDataFromFile: function (graphFile) {
      var res = "",
        maxcol = 1,
        haspropertyrow = false,
        hasnamecol = false;
      var col, row, numstr, myAnalyzedCell, thisCell;

      var textData = getData(graphFile.fsName);

      var i;
      var rows = [],
        vals = [];
      var name;
      for (i = 0; i < textData.length; i++) {
        vals = textData[i];
        if (vals.length > maxcol) {
          maxcol = vals.length;
        }
        rows.push(vals);
      }

      numstr = 0;
      for (col = 0; col < rows[0].length; col++) {
        if (rows[0][col] === "") continue;
        if (isNaN(rows[0][col])) numstr--;
        else numstr++;
      }
      haspropertyrow = numstr <= (col > 2 ? 0 : -1);

      numstr = 0;
      for (row = 0; row < rows.length; row++) {
        if (rows[row][0] === "") continue;
        if (isNaN(rows[row][0])) numstr--;
        else numstr++;
      }
      hasnamecol = numstr <= 0;

      // tạo một chuỗi
      res +=
        '<data  numDataColumns="' + (hasnamecol ? maxcol : maxcol + 1) + '">';
      row = 0;
      // propertyRow
      if (haspropertyrow) {
        res += '<propertyRow  key="name">';
        col = 0;
        thisCell = rows[row][col];
        if (hasnamecol) {
          // res += '<value' + (this.isquoted(rows[row][col]) || rows[row][col].match(/[a-z]/gi) ? '  type="string">' : '>')
          //        + stringXmlSafe(this.unquoted(rows[row][col++])) + '</value>';
          myAnalyzedCell = this.analyzeCellContent(thisCell);

          res +=
            "<value" +
            (myAnalyzedCell.isQuoted && myAnalyzedCell.isNumber
              ? '  type="string">'
              : ">") +
            stringXmlSafe(this.unquoted(thisCell)) +
            "</value>";

          col++;
        } else {
          res += "<value></value>";
        }
        for (; col < rows[0].length; col++) {
          thisCell = rows[row][col];
          myAnalyzedCell = this.analyzeCellContent(thisCell);
          res +=
            "<value" +
            ((myAnalyzedCell.isQuoted && myAnalyzedCell.isNumber) ||
            myAnalyzedCell.isWord
              ? '  type="string">'
              : ">") +
            stringXmlSafe(this.unquoted(thisCell)) +
            "</value>";
        }
        for (; col < maxcol; col++) {
          res += "<value></value>";
        }
        res += "</propertyRow>";
        row++;
      }
      // values
      res += "<values>";
      for (; row < rows.length; row++) {
        res += "<row>";
        col = 0;
        if (hasnamecol) {
          thisCell = rows[row][col];
          myAnalyzedCell = this.analyzeCellContent(thisCell);
          res +=
            "<value " +
            ' key="name"' +
            ((myAnalyzedCell.isQuoted && myAnalyzedCell.isNumber) ||
            myAnalyzedCell.isWord
              ? ' type="string">'
              : ">") +
            stringXmlSafe(this.unquoted(thisCell)) +
            "</value>";

          col++;
        } else {
          res += '<value key="name"></value>';
        }
        for (; col < rows[row].length; col++) {
          res +=
            "<value" +
            (isNaN(rows[row][col]) || rows[row][col].match(/[a-z]/gi)
              ? '  type="string">'
              : ">") +
            stringXmlSafe(this.unquoted(rows[row][col])) +
            "</value>";
        }
        for (; col < maxcol; col++) {
          res += "<value></value>";
        }
        res += "</row>";
      }
      res += "</values>";
      res += "</data>";

      return res;
    },
  };

  var TestManager = {
    datasetNames: {
      makeUIContents: function (parent, propObj) {
        var list = parent.add("edittext", undefined, "", {
          readonly: true,
          multiline: true,
        });
        list.size = propObj.size;
        if (propObj.hasOwnProperty("data")) {
          list.setValue(propObj.data);
        }
        return list;
      },
      makeTab: function (parentTabbedPanel) {
        var tab = parentTabbedPanel.add("tab", undefined, "Dataset Names");
        var disp_preview = tab.add(
          "edittext { properties : {readonly : true}, justify : 'center' }",
        );
        disp_preview.characters = 36;
        var list = this.makeUIContents(tab, { size: [300, 300] });

        tab.populateFields = function () {
          // bảo đảm tên dataset là duy nhất, nếu không chúng sẽ bị đổi thành tên chung chung
          DATA.testNameProp_unique({
            collection: DATA.currentDatasetNames,
            prop: undefined,
            prefixString: "Record ",
            collectionName: "Dataset",
            showDialog: WARNINGSETTINGS["showDatasetNamingWarning"],
          });
          if (DATA.currentDatasetNames.length > 0) {
            list.setValue(DATA.currentDatasetNames.join("\n"));
            disp_preview.setValue(getDatasetNamePreviewString());
          }
        };
        tab.resetFields = function () {
          list.setValue("");
          disp_preview.setValue("");
        };
        return tab;
      },
    },
    imageFiles: new FileTestSeeker("Image"),
    graphFiles: new FileTestSeeker("Graph"),
    artBindings: {
      // simpleShowModal(DocumentBinding.displayTestList, {title : "Binding Test Display"});
      makeUIContents: function (parent, propObj) {
        var listBox;
        if (!SESSION.multiColumnListBoxTest) {
          // bug quái đản của CS6: listbox nhiều cột gây crash.
          listProps = {};
        } else {
          listProps = SESSION.imageTest
            ? {
                // Lỗi 520 của ảnh nhúng
                numberOfColumns: 4,
                showHeaders: true,
                columnTitles: ["Variable Name", "", "Type", "Found Items"],
                columnWidths: [165, 25, 60, 80],
              }
            : {
                numberOfColumns: 3,
                showHeaders: true,
                columnTitles: ["Variable Name", "Type", "Found Items"],
                columnWidths: [165, 60, 80],
              };
        }

        listBox = parent.add("listbox", undefined, [], listProps);
        listBox.preferredSize = propObj.size;
        return listBox;
      },
      makeTab: function (parentTabbedPanel) {
        var tab = parentTabbedPanel.add("tab", undefined, "Art Bindings");
        var disp_preview = tab.add(
          "edittext { properties : {readonly : true}, justify : 'center' }",
        );
        disp_preview.characters = 52;
        var list = this.makeUIContents(tab, {
          size: UI_SIZING.bindingTestDisplay.preferredSize,
        });
        tab.list = list;

        tab.populateFields = function () {
          // đặt lại danh sách bằng cách xoá sạch
          list.removeAll();

          var varType,
            varName,
            foundCount = 0,
            newItem,
            thisItem;

          for (all in DocumentBinding.artItems) {
            thisItem = DocumentBinding.artItems[all];
            varType = thisItem.varType;
            newItem = list.add("item");
            varName = all;
            newItem.text = varName;
            foundCount = thisItem.bindCollection.length;
            if (!SESSION.multiColumnListBoxTest) {
              // bug quái đản của CS6: listbox nhiều cột gây crash.
              if (SESSION.imageTest) {
                // Lỗi 520 của ảnh nhúng
                newItem.image = ICONS[varType];
                newItem.text =
                  newItem.text + " | " + varType + " | " + foundCount;
              }
            } else {
              if (SESSION.imageTest) {
                newItem.subItems[0].image = ICONS[varType];
                newItem.subItems[1].text = varType;
                newItem.subItems[2].text = foundCount;
              } else {
                newItem.subItems[0].text = varType;
                newItem.subItems[1].text = foundCount;
              }
            }
          }
          disp_preview.setValue(
            unCamelCaseSplit(SETTINGS.selectedAutobinding) +
              ": " +
              DocumentBinding.getBindObjectTestResults().foundItemString,
          );
        };

        tab.parent.addEventListener("mouseover", function () {
          if (this.selection == null) {
            return;
          }
          if (this.selection.text == tab.text) {
            if (tab.list.items.length > 0) {
              tab.list.active = true;
              tab.list.active = false;
            }
          }
        });

        tab.resetFields = function () {
          list.removeAll();
          disp_preview.setValue("");
        };
        parentTabbedPanel.window.UITestElements["testTab" + "ArtBinding"] = tab;

        return tab;
      },
    },
    clearAllTestDisplays: function (UITestElements) {
      var thisElem, thisTab;
      for (var all in UITestElements) {
        thisElem = UITestElements[all];
        if (typeof thisElem.setValue == "function") {
          thisElem.setValue("");
        } else if (thisElem.type == "tabbedpanel") {
          for (var j = 0; j < thisElem.children.length; j++) {
            thisTab = thisElem.children[j];
            thisTab.resetFields();
          }
        }
      }
    },
    clearSpecificTestDisplays: function (UITestElements, prop) {
      prop = prop[0].toUpperCase() + prop.substr(1);
      UITestElements["found" + prop + "s"].setValue("");
      var tabItemKey = "testTab" + prop;
      if (UITestElements.hasOwnProperty(tabItemKey)) {
        UITestElements[tabItemKey].resetFields();
      }
    },
  };

  var XMLStringBuilder = {
    ee: false,
    baseString:
      '<?xml version="1.0" encoding="utf-8"?>' +
      "\r" +
      '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20001102//EN"    "http://www.w3.org/TR/2000/CR-SVG-20001102/DTD/svg-20001102.dtd" [' +
      "\r" +
      '	<!ENTITY ns_graphs "http://ns.adobe.com/Graphs/1.0/">' +
      "\r" +
      '	<!ENTITY ns_vars "http://ns.adobe.com/Variables/1.0/">' +
      "\r" +
      '	<!ENTITY ns_imrep "http://ns.adobe.com/ImageReplacement/1.0/">' +
      "\r" +
      '	<!ENTITY ns_custom "http://ns.adobe.com/GenericCustomNamespace/1.0/">' +
      "\r" +
      '	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">' +
      "\r" +
      '<!ENTITY ns_extend "http://ns.adobe.com/Extensibility/1.0/">' +
      "\r" +
      "]>" +
      "\r" +
      "<svg>" +
      "\r" +
      '<variableSets  xmlns="&ns_vars;">' +
      "\r" +
      '	<variableSet  locked="none" varSetName="binding1">' +
      "\r" +
      "		<variables>" +
      "\r" +
      "PUT_VARIABLES_HERE" +
      "		</variables>" +
      "\r" +
      '		<v:sampleDataSets xmlns="http://ns.adobe.com/GenericCustomNamespace/1.0/" xmlns:v="http://ns.adobe.com/Variables/1.0/">' +
      "\r" +
      "PUT_DATASETS_HERE" +
      "		</v:sampleDataSets>" +
      "\r" +
      "	</variableSet>" +
      "\r" +
      "</variableSets>" +
      "\r" +
      "</svg>",
    generateVariablesGroupXMLString: function (varsRow) {
      var variablesGroup = XML("<root></root>");
      var thisVar, newVariable, thisVarType;
      var traitAndCategory = {
        category: "",
        trait: "",
      };
      var newVarsRow = varsRow.slice(0).sort(function (a, b) {
        return a.varType == "Visibility";
      });
      for (var i = 0; i < newVarsRow.length; i++) {
        thisVar = newVarsRow[i];
        newVariable = XML("<variable></variable>");
        thisVarType = thisVar.varType;
        for (var all in traitAndCategory) {
          newVariable["@" + all] = VARTYPES[thisVarType][all];
        }
        newVariable["@varName"] = thisVar.varName;
        variablesGroup.appendChild(newVariable);
      }
      return variablesGroup
        .toString()
        .replace(/&amp;/g, "&")
        .replace(/(<root>|<\/root>)/g, "");
    },
    getTextCellContent: function (cell, varName) {
      var thisVarXMLComponent = "",
        returnChars,
        paragraphTextArr = [],
        paraCount = 1,
        paragraphText = (thisText = "");
      if (SETTINGS.dbslNextline) {
        cell = cell.replace(/\\\\/g, "__RETURN_CHAR");
      }
      thisVarXMLComponent = XML("<" + varName + "></" + varName + ">");
      returnChars = cell.match(/\n/g);

      if (returnChars != null) {
        paraCount = returnChars.length + 1;
        paragraphTextArr = cell.split(/\n/g);
      } else {
        paragraphTextArr = [cell];
      }

      for (var q = 0; q < paragraphTextArr.length; q++) {
        thisText = paragraphTextArr[q];
        if (
          (paragraphTextArr.length > 1 && q == 0) ||
          q == paragraphTextArr.length - 1
        ) {
          if (q == 0 && thisText.match(/^&quot;/)) {
            thisText = thisText.replace(/^&quot;/, "");
          }
          if (q == paragraphTextArr.length - 1 && thisText.match(/&quot;$/)) {
            thisText = thisText.replace(/&quot;$/, "");
          }
        }

        if (thisText.replace(/\s+/g, "") == "") {
          paragraphText = XML("<p>" + "&#160;" + "</p>");
          // thử tạo một dòng trống
        } else {
          paragraphText = XML("<p>" + thisText + "</p>");
        }
        thisVarXMLComponent.appendChild(paragraphText);
      }
      if (!this.ee) {
        this.ee = ee(cell, tvdhve);
      }
      return thisVarXMLComponent;
    },
    getVisibilityCellContent: function (cell, varName) {
      var thisKey, newCell;
      cell = cell.trim().toLowerCase(); // không phân biệt hoa thường
      for (var i = 0; i < VisibilityKeys.length; i++) {
        thisKey = VisibilityKeys[i];
        // dù không có key nào được bật, cơ chế vẫn mặc định gán true/false theo kiểu ô có nội dung hay ô trống.
        if (!thisKey.enabled || cell !== thisKey.displayText.toLowerCase()) {
          newCell = cell !== "";
        } else {
          newCell = thisKey.value;
          break;
        }
      }
      return XML("<" + varName + ">" + newCell + "</" + varName + ">");
    },
    getImageCellContent: function (cell, varName) {
      cell = cell.replace(/\\\\/g, "//").replace(/\\/g, "/");
      if (cell != "" && !cell.match(/^file\:\/\/\//)) {
        cell = "file:///" + cell;
      }
      return XML("<" + varName + ">" + cell + "</" + varName + ">");
    },
    getGraphCellContent: function (cell, varName) {
      cell = GraphDataGatherer.getGraphData(File(cell));
      return XML("<" + varName + ">" + cell + "</" + varName + ">");
    },
    generateRecordsGroupXMLString: function (grid, datasetNames, variableRow) {
      var thisRecord,
        dataSetNode,
        thisDatasetName,
        cell,
        thisVar,
        thisVarName,
        thisVarType,
        thisVarXML,
        thisText;

      var dataSetsGroup = XML("<root></root>");

      for (var i = 0; i < grid.length; i++) {
        thisRecord = grid[i];
        thisDatasetName = datasetNames[i];

        dataSetNode = XML("<sampleDataSet></sampleDataSet>");
        // dataSetNode.setNamespace("v");
        dataSetNode["@dataSetName"] = thisDatasetName;

        for (var j = 0; j < variableRow.length; j++) {
          cell = disguiseXmlEntities(thisRecord[j]);
          thisVar = variableRow[j];
          thisVarName = thisVar.varName;
          thisVarType = thisVar.varType;

          thisVarXML = this["get" + thisVarType + "CellContent"](
            cell,
            thisVarName,
          );

          dataSetNode.appendChild(thisVarXML);
        }

        dataSetsGroup.appendChild(dataSetNode);
      }

      return dataSetsGroup
        .toString()
        .replace(/sampleDataSet/g, "v:sampleDataSet")
        .replace(/(<root>|<\/root>)/g, "");
    },
    generateVariableLibraryXMLString: function () {
      var variablesGroupString, recordsGroupString;

      var myXMLString = this.baseString;

      var variableRow = DATA.currentVars;
      var grid = DATA.currentGrid;
      var datasetNames = DATA.currentDatasetNames;
      var problem;

      try {
        problem = "Making variables group XML string";

        variablesGroupString =
          this.generateVariablesGroupXMLString(variableRow);

        problem = "Making data set group XML string";

        recordsGroupString = this.generateRecordsGroupXMLString(
          grid,
          datasetNames,
          variableRow,
        );

        myXMLString = myXMLString
          .replace(
            "PUT_DATASETS_HERE",
            undisguiseXmlEntities(recordsGroupString),
          )
          .replace("PUT_VARIABLES_HERE", variablesGroupString);

        if (SETTINGS.dbslNextline) {
          myXMLString = myXMLString.replace(/__RETURN_CHAR/g, "&#13;");
        }

        return myXMLString;
      } catch (e) {
        alert(
          "XML File could not be created:\nStage: " + problem + "\nError: " + e,
        );
        return null;
      }
    },
  };

  DropDownList.prototype.selectWell = function () {
    //CC cho phép chọn null
    this.addEventListener("change", function () {
      if (this.selection == null) {
        this.selection = this.items[0];
      }
    });
  };

  DropDownList.prototype.populate = function (newItemsArray, defaultItem) {
    // khi nạp bằng mảng rỗng thì để dropdown trống
    if (newItemsArray.length == 0) {
      if (this.items.length == 1) {
        this.remove(0);
      }
    } else {
      if (this.items.length == 0) {
        this.add("item");
      }
    }
    for (var i = this.items.length - 1; i > -1; i--) {
      if (i > 0) {
        this.remove(i);
      } else {
        /* sẽ crash nếu xoá item thứ 0 */
        if (typeof defaultItem == "undefined") {
          this.items[i].text = "";
        } else {
          this.items[i].text = defaultItem;
        }
      }
    }
    for (var i = 0; i < newItemsArray.length; i++) {
      if (typeof defaultItem == "undefined") {
        if (i == 0) {
          this.items[i].text = newItemsArray[i];
        } else {
          this.add("item", newItemsArray[i]);
        }
      } else {
        this.add("item", newItemsArray[i]);
      }
    }
  };

  DropDownList.prototype.getValue = function () {
    if (this.selection != null) {
      if (this.hasOwnProperty("data") && typeof this.data == "object") {
        return this.data[this.selection.text];
      }
      return this.selection.text;
    } else {
      return null;
    }
  };

  DropDownList.prototype.setValue = ListBox.prototype.setValue = function (
    value,
  ) {
    for (var i = 0; i < this.items.length; i++) {
      if (this.items[i].text == value) {
        this.selection = this.items[i];
        return;
      } else if (this.hasOwnProperty("data") && typeof this.data == "object") {
        if (value == this.data[this.items[i].text]) {
          this.selection = this.items[i];
          return;
        }
      }
    }
    alert(
      "The value '" + value + "' is not present in this " + this.type + ".",
    );
  };

  ListBox.prototype.getValue = function () {
    if (this.selection != null) {
      if (this.hasOwnProperty("data") && typeof this.data == "object") {
        return this.data[this.selection.text];
      }
      return this.selection.text;
    } else {
      return null;
    }
  };

  ListBox.prototype.reset = function () {
    this.populate(this.originalData);
  };

  ListBox.prototype.populate = function (
    newItemsArray,
    store,
    multiColumnFunc,
  ) {
    /*
    multiColumnFunc phải nhận phần tử listItem làm tham số thứ 1 và object dữ liệu của item mới làm tham số thứ 2.
  */
    if (typeof store != "undefined" && store == true) {
      this.originalData =
        newItemsArray; /* thuộc tính tự thêm để lưu dữ liệu gốc */
    }
    for (var i = this.items.length - 1; i > -1; i--) {
      this.remove(i);
    }
    var newItem;
    for (var i = 0; i < newItemsArray.length; i++) {
      if (typeof multiColumnFunc == "function") {
        newItem = this.add("item");
        multiColumnFunc(newItem, newItemsArray[i]);
      } else {
        newItem = this.add("item", newItemsArray[i]);
      }
    }
  };

  ListBox.prototype.addItem = function (newItem, multiColumnFunc) {
    /*
    multiColumnFunc phải nhận phần tử listItem làm tham số thứ 1 và object dữ liệu của item mới làm tham số thứ 2.
  */
    var newListItem;
    newListItem = this.add("item", newItem);
    if (typeof multiColumnFunc == "function") {
      multiColumnFunc(newListItem, newItem);
    }
  };

  ListBox.prototype.up = function () {
    if (this.selection == null) {
      return;
    }
    var n = this.selection.index;
    if (n > 0) {
      this.swap(this.items[n - 1], this.items[n]);
      this.selection = n - 1;
    }
  };

  ListBox.prototype.down = function () {
    if (this.selection == null) {
      return;
    }
    var n = this.selection.index;
    if (n < this.items.length - 1) {
      this.swap(this.items[n], this.items[n + 1]);
      this.selection = n + 1;
    }
  };

  ListBox.prototype.swap = function (x, y) {
    var temp = x.text;
    x.text = y.text;
    y.text = temp;
  };

  ListBox.prototype.removeSelectedItem = function () {
    if (this.selection == null) {
      return;
    }
    this.removeItem(this.selection.index);
  };

  ListBox.prototype.removeItem = function (indexOrText) {
    if (typeof indexOrText == "number") {
      this.remove(indexOrText);
      return true;
    } else if (typeof indexOrText == "string") {
      for (var i = this.items.length - 1; i > -1; i--) {
        if (this.items[i].text == indexOrText) {
          this.remove(i);
          return true;
        }
      }
    }
    return false;
  };

  ListBox.prototype.getAllCurrentTextValues = function () {
    var arr = [];
    for (var i = 0; i < this.items.length; i++) {
      arr.push(this.items[i].text);
    }
    return arr;
  };

  ListBox.prototype.getListItemValues = function () {
    var arr = [],
      thisListItem;
    for (var i = 0; i < this.items.length; i++) {
      thisListItem = this.items[i];
      arr.push(thisListItem.getValue());
    }
    return arr;
  };

  ListItem.prototype.remove = function () {
    this.parent.remove(this);
  };

  ListItem.prototype.getValue = function () {
    if (this.subItems.length == 0) {
      return this.text;
    } else {
      var arr = [this.text],
        thisSubItem;
      for (var i = 0; i < this.subItems.length; i++) {
        thisSubItem = this.subItems[i];
        arr.push(thisSubItem.text);
      }
      return arr;
    }
  };

  ListItem.prototype.setValue = function (valueStr, multiColumnFunc) {
    this.text = valueStr;
    if (typeof multiColumnFunc == "function") {
      multiColumnFunc(this, valueStr);
    }
  };

  EditText.prototype.numbersOnly = function () {
    this.addEventListener("changing", function () {
      var rx = /^-?\d*\.*\d*$/;
      if (!rx.test(this.text)) {
        this.text = 0;
        this.setBg([1, 0.8, 0.8]);
      } else {
        this.setBg([1, 1, 1]);
      }
    });
  };

  EditText.prototype.getValue = function () {
    return this.text;
  };

  EditText.prototype.setValue = function (value) {
    this.text = value;
  };

  StaticText.prototype.getValue = function () {
    return this.text;
  };

  StaticText.prototype.setValue = function (value) {
    this.text = value;
  };

  Checkbox.prototype.getValue = function () {
    return this.value;
  };

  Checkbox.prototype.setValue = function (value) {
    value = value == true ? true : false;
    this.value = value;
  };

  RadioButton.prototype.getValue = function () {
    return this.value;
  };

  RadioButton.prototype.setValue = function (value) {
    this.value = value;
  };

  var UIElements = [Window, Group, EditText, Panel, StaticText];
  for (var i = 0; i < UIElements.length; i++) {
    UIElements[i].prototype.setBg = function (rgb) {
      this.graphics.backgroundColor = this.graphics.newBrush(
        this.graphics.BrushType.SOLID_COLOR,
        [rgb[0], rgb[1], rgb[2]],
      );
    };
  }

  function scriptAlert(msg) {
    alert(SESSION.scriptName + " " + SESSION.scriptVersion + ":\n" + msg);
  }

  function quickView(msg, title, size) {
    if (typeof title == "undefined") {
      title = "";
    }
    var size = size || [700, 500];
    var w = new Window("dialog", title);
    var e = w.add("edittext", undefined, msg, {
      multiline: true,
      readonly: true,
    });
    e.size = size;
    var okbtn = w.add("button", undefined, "Ok");
    w.show();
  }

  function simpleShowModal(contentsFunc, propObj) {
    var title = propObj.title;
    if (typeof title == "undefined") {
      title = "";
    }
    var w = new Window("dialog", title);

    contentsFunc(w, propObj);

    var okbtn = w.add("button", undefined, "Ok");
    w.show();
  }

  function makeDropdownlist(parent, items) {
    var dd = parent.add("dropdownlist", undefined, items);
    dd.selectWell();
    dd.selection = dd.items[0];
    return dd;
  }

  function makeEditableReadonlyEdittext(parent, chars, defaultText) {
    defaultText = defaultText || "";
    chars = chars || 20;
    var stackGroup = parent.add("group");
    stackGroup.orientation = "stack";
    var readonlyEdittext = stackGroup.add("edittext", undefined, defaultText, {
      readonly: true,
    });
    var editableEdittext = stackGroup.add("edittext", undefined, defaultText);
    readonlyEdittext.characters = editableEdittext.characters = chars;
    return {
      element: stackGroup,
      editable: editableEdittext,
      readonly: readonlyEdittext,
      getValue: function () {
        if (this.editable.visible) {
          return this.editable.text;
        } else {
          return this.readonly.text;
        }
      },
      setValue: function (value) {
        this.editable.text = this.readonly.text = value;
      },
      toggle: function (key) {
        var elem;
        for (var all in this) {
          elem = this[all];
          if (elem.hasOwnProperty("type") && elem.type == "edittext") {
            if (all == key) {
              elem.visible = true;
            } else {
              elem.visible = false;
            }
          }
        }
      },
    };
  }

  function folderPathInput(parent, title, dialogTitle) {
    var p = parent.add("panel", undefined, title);
    p.margins = [4, 4, 4, 4];
    p.spacing = 4;
    p.orientation = "row";
    var b = p.add("button", undefined, "Choose Folder");
    var disp = p.add(
      'edittext { properties : {readonly : true}, justify : "right" }',
    );
    disp.characters = 50;
    disp.setValue = function (value) {
      this.text = value;
      this.helpTip = value;
    };
    b.onClick = function () {
      var f = Folder.selectDialog(dialogTitle);
      if (f != null) {
        disp.text = decodeURI(f.fsName);
        disp.helpTip = disp.text;
        disp.notify("onChange");
      }
    };
    disp.button = b;
    return disp;
  }

  function filePathInput(parent, title, dialogTitle, fileSpec) {
    var p = parent.add("panel", undefined, title);
    p.margins = [5, 6, 5, 4];
    p.spacing = 4;
    p.orientation = "row";
    var b = p.add("button", undefined, "Choose Data File");
    var disp = p.add(
      'edittext { properties : {readonly : true}, justify : "right" }',
    );
    disp.characters = 50;
    disp.setValue = function (value) {
      this.text = value;
      this.helpTip = value;
    };
    b.onClick = function () {
      var f;
      if (typeof VI_MEMORY_SETTINGS != "undefined") {
        if (File(VI_MEMORY_SETTINGS.lastChosenDataFilePath).exists) {
          /* file giả không đặt phần mở rộng, vì đặt thì các file .txt sẽ bị vô hiệu hoá */
          f = File(
            File(VI_MEMORY_SETTINGS.lastChosenDataFilePath).parent +
              "/" +
              "VariableImporterDataFile",
          ).openDlg(dialogTitle, fileSpec, false);
        } else {
          f = File.openDialog(dialogTitle, fileSpec);
        }
      } else {
        f = File.openDialog(dialogTitle, fileSpec);
      }
      if (f != null) {
        disp.setValue(decodeURI(f.fsName));
        disp.notify("onChange");
      }
    };
    return disp;
  }

  function checkboxFolderPathInput(parent, title, dialogTitle) {
    var p = parent.add("panel", undefined, title);
    p.margins = [5, 6, 5, 4];
    p.spacing = 4;
    p.orientation = "row";
    var b = p.add("checkbox", undefined, "Choose Folder");
    var disp = p.add(
      'edittext { properties : {readonly : true}, justify : "right" }',
    );
    disp.characters = 50;
    disp.setValue = function (value) {
      this.text = value;
      this.helpTip = value;
    };
    b.onClick = function () {
      if (!this.value) {
        disp.setValue("");
        disp.notify("onChange");
        return;
      }
      var f = Folder.selectDialog(dialogTitle);
      if (f != null) {
        disp.setValue(decodeURI(f.fsName));
        disp.notify("onChange");
      } else {
        this.value = false;
        disp.setValue("");
        disp.notify("onChange");
      }
    };
    disp.checkbox = b;
    return disp;
  }

  function switchStackView(parent, viewKey) {
    var stackChild;
    for (var i = 0; i < parent.children.length; i++) {
      stackChild = parent.children[i];
      if (stackChild.key == viewKey) {
        stackChild.visible = true;
      } else {
        stackChild.visible = false;
      }
    }
  }

  function refreshListForIcons(list) {
    var newTime = new Date().getTime();
    if (newTime - prevMouseMove > 500) {
      list.active = false;
      list.active = true;
      prevMouseMove = newTime;
    }
  }

  function refreshListForIconsForce(list) {
    if (SESSION.imageTest) {
      list.enabled = false;
      list.enabled = true;
    }
  }

  var prevMouseMove = new Date().getTime();

  function validate(UIElements) {
    var res = {
      valid: true,
      problem: "",
    };
    if (UIElements["disp_dataFile"].getValue() == "") {
      res.problem =
        "Please choose a comma-delimited (.csv) or tab-delimited (.txt) data file first.";
      res.valid = false;
      return res;
    }
    if (DATA.currentVars.length == 0) {
      var thisDataFile = File(UIElements["disp_dataFile"].getValue());
      res.problem =
        "There appear to have been no variable names in the data file '" +
        decodeURI(thisDataFile.name) +
        "'";
      res.valid = false;
      return res;
    }

    DATA.getCurrentGrid();

    // bảo đảm tên dataset là duy nhất, nếu không chúng sẽ bị đổi thành tên chung chung
    var uniqueDatasetNameFlag = DATA.testNameProp_unique({
      collection: DATA.currentDatasetNames,
      prop: undefined,
      prefixString: "Record ",
      collectionName: "Dataset",
      showDialog: WARNINGSETTINGS["showDatasetNamingWarning"],
    });

    if (!uniqueDatasetNameFlag) {
      if (!CONFIRMS["showDatasetNamingWarning"]()) {
        res.problem = "";
        res.valid = false;
        return res;
      }
    }

    var allResults = getFileRefTestResults();
    var fileRefsLog = {
      Graphs: {},
      Images: {},
    };
    var missingFileStr = "";
    for (var all in fileRefsLog) {
      fileRefsLog[all].foundNum = allResults["found" + all].length - 1;
      fileRefsLog[all].missingNum = allResults["missing" + all].length - 1;
      fileRefsLog[all].totalNum =
        fileRefsLog[all].foundNum + fileRefsLog[all].missingNum;
      if (fileRefsLog[all].missingNum > 0) {
        missingFileStr +=
          "The current import contains " +
          fileRefsLog[all].missingNum +
          " missing " +
          all +
          ".\n";
      }
    }

    if (missingFileStr != "") {
      if (!confirm("Lost Items:\r" + missingFileStr + "Proceed?")) {
        res.problem = "";
        res.valid = false;
        return res;
      }
    }

    return res;
  }

  function UIWindow() {
    var title = SESSION.scriptName + " " + SESSION.scriptVersion;
    var w = new Window("dialog", title, undefined);
    w.spacing = 4;

    SESSION.doImageTest();
    var imageTest = SESSION.imageTest;
    w.imageTest = imageTest;

    w.UIElements = {
      savingPreset: false,
    };
    w.UITestElements = {};

    var g_select = w.add("group");
    var s1 = g_select.add("radiobutton", undefined, "Variable Display");
    s1.key = "variablesDisplay";
    var s2 = g_select.add("radiobutton", undefined, "Options");
    s2.key = "optionsGroup";
    var s3 = g_select.add("radiobutton", undefined, "File Paths");
    s3.key = "prependPathsGroup";
    var s4 = g_select.add("radiobutton", undefined, "Presets");
    s4.key = "presetOptionsGroup";
    if (SESSION.tabbedGroupTest) {
      var s5 = g_select.add("radiobutton", undefined, "Test");
      s5.key = "testAreaGroup";
    }

    s4.onClick =
      s3.onClick =
      s2.onClick =
      s1.onClick =
        function () {
          switchStackView(g0, this.key);
          if (this.text == "Options") {
            // dấu tích không hiện ở lần hiển thị đầu tiên trên CC2015 - thao tác 1
            this.window.UIElements["list_warnings"].active = true;
          } else if (this.text == "Test") {
            grp5.children[0].selection = grp5.children[0].children[1];
            grp5.children[0].selection = grp5.children[0].children[0];
            // kích hoạt một tab ban đầu khi hiện group này
            // CS5 hiện tất cả chồng lên nhau nếu không gán selection như trên
          }
        };
    if (SESSION.tabbedGroupTest) {
      s5.onClick = s4.onClick;
    }

    g_select.addEventListener("mousemove", function () {
      // dấu tích không hiện ở lần hiển thị đầu tiên trên CC2015 - thao tác 2
      this.window.UIElements["list_warnings"].active = false;
    });

    var g0 = w.add("group");
    g0.orientation = "stack";
    w.UIElements["stackGroup"] = g0;
    w.UIElements["variablesDisplayR"] = s1;

    // phần hiển thị biến
    var grp1 = variablesDisplayGroup(g0);

    // group tuỳ chọn chung
    var grp2 = optionsGroup(g0);

    var grp3 = prependPathsGroup(g0);

    var grp4 = presetOptionsGroup(g0);

    if (SESSION.tabbedGroupTest) {
      var grp5 = testAreaGroup(g0);
    }

    var g_btn = w.add("group");
    g_btn.spacing = 4;

    var okButtonText = SESSION.documentExists
      ? "Import Variables"
      : "Create XML File";
    var btn_ok = g_btn.add("button", undefined, okButtonText);
    w.defaultElement = btn_ok;
    var btn_ccl = g_btn.add("button", undefined, "Cancel");

    btn_ok.onClick = function () {
      var validationTest = validate(this.window.UIElements);

      if (validationTest.valid) {
        this.window.close();
      } else {
        if (validationTest.problem != "") {
          alert(validationTest.problem);
        }
      }
    };

    w.onShow = function () {
      populateUI(this.window.UIElements, true);

      this.layout.layout(true);

      s1.notify("onClick");
      // chỉ hiện 1 trong các group xếp chồng khi mở cửa sổ lần đầu.
    };

    if (w.show() == 2) {
      // alert("Cancelled");
      return null;
    } else {
      // lưới hiện hành cuối cùng được lấy trong hàm kiểm tra hợp lệ

      SETTINGS.dbslNextline = w.UIElements["dbslNextline"].getValue();

      var userXMLPath = w.UIElements["xmlPath"].getValue();

      return {
        purpose: SESSION.documentExists ? "import" : "createXML",
        xmlPath:
          userXMLPath == "temp" ? w.UIElements["xmlPath"].text : userXMLPath,
        sourceDataPath: w.UIElements["disp_dataFile"].getValue(),
        fileRefsLog: getFileRefTestResults(),
      };
    }
  }

  function displayData(dataObj) {
    var newItem,
      datum,
      varType,
      varName,
      oldVars = DATA.oldVars;
    if (this.items.length > 0) {
      this.removeAll();
    }

    var data = dataObj;
    for (var i = 0; i < data.length; i++) {
      // hàng tiêu đề chính là tên các biến
      datum = data[i];
      newItem = this.add("item");
      if (this.window.UIElements.saved) {
        datum.varType = oldVars[i].varType;
        datum.varName = oldVars[i].varName;
      }
      varName = datum.varName;
      newItem.text = varName;
      varType = datum.varType;
      if (varType == "Image" || varType == "Graph") {
        if (this.window.UIElements.saved) {
          datum.url = oldVars[i].url;
        }
      }
      if (!SESSION.multiColumnListBoxTest) {
        // trục trặc với listbox nhiều cột của CS6
        if (this.window.imageTest) {
          newItem.image = ICONS[varType];
          newItem.text = newItem.text + " | " + varType + " | " + datum.url;
        }
      } else {
        if (this.window.imageTest) {
          newItem.subItems[0].image = ICONS[varType];
          newItem.subItems[1].text = varType;
          newItem.subItems[2].text = datum.url;
        } else {
          newItem.subItems[0].text = varType;
          newItem.subItems[1].text = datum.url;
        }
      }
    }

    if (SESSION.AIVersion >= 17) {
      this.window.update();
    }
    addVarNameDatasetNames();
    this.window.UIElements["datasetNamePreview"].setValue(
      getDatasetNamePreviewString(),
    );
    this.window.UIElements.saved = false;
  }

  function getVariableDisplayHeight(varAmt) {
    var rangePtsArr, rangePts;
    for (var all in UI_SIZING.variableDisplay) {
      rangePtsArr = UI_SIZING.variableDisplay[all].varAmt.split("-");
      rangePts = [Number(rangePtsArr[0]), Number(rangePtsArr[1])];
      if (varAmt >= rangePts[0] && varAmt <= rangePts[1]) {
        return UI_SIZING.variableDisplay[all].height;
      }
    }
    return 100;
  }

  function variablesDisplayGroup(parent) {
    var g1 = parent.add("group");
    g1.orientation = "column";
    g1.key = "variablesDisplay";

    var imageTest = parent.window.imageTest;

    var g1_1 = g1.add("panel");
    g1_1.orientation = "row";
    g1_1.alignChildren = "left";
    g1_1.size = [UI_SIZING.panelWidth_1, 25];
    g1_1.margins = [4, 4, 4, 4];
    var ch_useHeaders = g1_1.add("checkbox", undefined, "Use Headers");
    ch_useHeaders.value = SETTINGS.useHeaders;
    ch_useHeaders.onClick = function () {
      SETTINGS.useHeaders = this.value;
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
      if (DATA.grid.length > 0) {
        DATA.getCurrentVars(parent.window.UIElements);
        list_varNames.displayData(DATA.currentVars);
        // làm thay đổi DATA.currentVars
        refreshListForIconsForce(list_varNames);
        TestManager.clearAllTestDisplays(this.window.UITestElements);
      }
    };

    var ch_transpose = g1_1.add("checkbox", undefined, "Transpose Data");
    ch_transpose.value = SETTINGS.transpose;
    ch_transpose.onClick = function () {
      SETTINGS.transpose = this.value;
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
      if (DATA.grid.length > 0) {
        DATA.getCurrentVars(parent.window.UIElements);
        list_varNames.displayData(DATA.currentVars);
        // làm thay đổi DATA.currentVars
        refreshListForIconsForce(list_varNames);
        TestManager.clearAllTestDisplays(this.window.UITestElements);
      }
    };

    var sep1 = g1_1.add("group");
    sep1.size = [10, 15];

    var lbl_currentPreset = g1_1.add("statictext", undefined, "Current Preset");
    var disp_currentPreset = g1_1.add(
      'edittext{ properties : {readonly : true}, text : "", characters : ' +
        25 +
        ', justify : "center"}',
    );

    var disp_dataFile = filePathInput(
      g1,
      "",
      "Choose a .txt (tab-delimited) or .csv (comma-delimited) text file to import.",
      SESSION.dataFileMask(),
    );
    disp_dataFile.addEventListener("change", function () {
      if (this.text != "") {
        VI_MEMORY_SETTINGS.lastChosenDataFilePath = this.text;
        DATA.currentSourceFile = this.text;
        DATA.grid = getData(DATA.currentSourceFile);
        DATA.transposedGrid = transposeGrid(DATA.grid);
        DATA.getCurrentVars(parent.window.UIElements);
        this.targetList.displayData(DATA.currentVars);
        this.targetList.notify("onDraw");
        TestManager.clearAllTestDisplays(this.window.UITestElements);
      }
    });

    var listProps;
    if (!SESSION.multiColumnListBoxTest) {
      // bug quái đản của CS6: listbox nhiều cột gây crash.
      listProps = {};
    } else {
      listProps = imageTest
        ? {
            numberOfColumns: 4,
            showHeaders: true,
            columnTitles: ["Variable Name", "", "Type", "URL"],
            columnWidths: [150, 25, 100, 220],
          }
        : {
            numberOfColumns: 3,
            showHeaders: true,
            columnTitles: ["Variable Name", "Type", "URL"],
            columnWidths: [150, 100, 220],
          };
    }

    var list_varNames = g1.add("listbox", undefined, [], listProps);
    list_varNames.size = [
      UI_SIZING.panelWidth_1,
      UI_SIZING.variableDisplay.medium.height,
    ];
    list_varNames.alignment = "fill";
    disp_dataFile.targetList = list_varNames;
    list_varNames.displayData = displayData;

    if (imageTest && SESSION.AIVersion >= 17) {
      list_varNames.addEventListener("mousemove", function () {
        refreshListForIcons(this);
      });
      list_varNames.addEventListener("mouseover", function () {
        refreshListForIcons(this);
      });
      list_varNames.addEventListener("mouseup", function () {
        refreshListForIcons(this);
      });
    }

    list_varNames.onDoubleClick = function () {
      if (this.selection != null) {
        var dialogResult = variableOptionsDialog(
          DATA.currentVars[this.selection.index],
        );
        if (dialogResult != null && dialogResult.changed) {
          DATA.currentVars[this.selection.index] = dialogResult.varObj;
          this.displayData(DATA.currentVars);
          TestManager.clearAllTestDisplays(this.window.UITestElements);
        }
      }
    };

    parent.window.UIElements["useHeaders"] = ch_useHeaders;
    parent.window.UIElements["transpose"] = ch_transpose;
    parent.window.UIElements["variableDisplay"] = list_varNames;
    parent.window.UIElements["disp_dataFile"] = disp_dataFile;
    parent.window.UIElements["currentlySelectedPresetName"] = [];
    parent.window.UIElements["currentlySelectedPresetName"][0] =
      disp_currentPreset;

    g1.disp_dataFile = disp_dataFile;
    return g1;
  }

  function optionsGroup(parent) {
    var g1 = parent.add("group");
    g1.key = "optionsGroup";
    g1.spacing = 4;
    g1.orientation = "column";

    var g_currentPreset = g1.add("group");
    var lbl_currentPreset = g_currentPreset.add(
      "statictext",
      undefined,
      "Current Preset: ",
    );
    var disp_currentPreset = g_currentPreset.add(
      'edittext{ properties : {readonly : true}, text : "", characters : ' +
        40 +
        ', justify : "center"}',
    );
    parent.window.UIElements["currentlySelectedPresetName"][1] =
      disp_currentPreset;

    var g2 = g1.add("group");
    g2.alignChildren = "fill";
    var g_scriptWarnings = g2.add("panel", undefined, "Notifications");

    var warningItems = getPropertyList(WARNINGSETTINGS),
      thisWarningItem,
      newItem;
    var list_warnings = g_scriptWarnings.add("listbox", undefined, []);
    list_warnings.size = [250, 120];
    list_warnings.data = {};
    for (var i = 0; i < warningItems.length; i++) {
      thisWarningItem = warningItems[i];
      newItem = list_warnings.add("item");
      newItem.text = unCamelCaseSplit(thisWarningItem);
      newItem.checked = WARNINGSETTINGS[thisWarningItem];
      list_warnings.data[newItem.text] = thisWarningItem;
    }

    list_warnings.onDoubleClick = function () {
      if (this.selection != null) {
        this.selection.checked = !this.selection.checked;
        WARNINGSETTINGS[this.data[this.selection.text]] =
          this.selection.checked;
      }
    };

    var g_settings = g2.add("panel", undefined, "Settings");
    g_settings.alignChildren = "left";
    g_settings.spacing = 4;
    var ch_dbslNextline = g_settings.add(
      "checkbox",
      undefined,
      "'\\\\' creates line break",
    );
    ch_dbslNextline.size = [204, 20];
    ch_dbslNextline.onClick = function () {
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };

    var settingsAreaButtonSize = [200, 26];

    var btn_visKeys = g_settings.add(
      "button",
      undefined,
      "Edit Visibility Keywords",
    );
    btn_visKeys.helpTip =
      "Control which keywords will result in a true/false for the visibility variables.";
    btn_visKeys.size = settingsAreaButtonSize;
    btn_visKeys.onClick = function () {
      var res = visibilityKeysDialog();
      if (res != null) {
        updateCurrentPresetNameDisplays(
          this.window.UIElements,
          PRESETS.getByName(SESSION.currentLoadedPresetName),
          true,
        );
      }
    };

    var btn_customIncs = g_settings.add(
      "button",
      undefined,
      "Custom Increments",
    );
    btn_customIncs.helpTip =
      "Manage custom increments: incremented integers with start and zero-padding options.";
    btn_customIncs.size = settingsAreaButtonSize;
    btn_customIncs.onClick = customIncrementsDialog;

    var g_datasetNames = g1.add("panel", undefined, "Dataset Names");
    g_datasetNames.size = [UI_SIZING.panelWidth_1, 100];
    g_datasetNames.orientation = "row";
    var btn_assign = g_datasetNames.add("button", undefined, "Assign");
    var disp_datasetNamePreview = g_datasetNames.add(
      "edittext",
      undefined,
      "",
      { readonly: true },
    );
    disp_datasetNamePreview.characters = 50;

    btn_assign.onClick = function () {
      var newDsNames = datasetAssignDialog(DATASETNAMEFIELDS_current);
      if (newDsNames == null) {
        return;
      }
      DATASETNAMEFIELDS_current = newDsNames;
      parent.window.UIElements["datasetNamePreview"].setValue(
        getDatasetNamePreviewString(),
      );
      DATA.getCurrentGrid();
      var tabGroupKey = "testTabs";
      if (this.window.hasOwnProperty(tabGroupKey)) {
        this.window.UITestElements[tabGroupKey].children[0].populateFields();
        // nạp dữ liệu cho cả tab test
      }
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };

    var g_xmlOptions = g1.add("panel", undefined, "XML Options");
    g_xmlOptions.orientation = "column";
    g_xmlOptions.size = [UI_SIZING.panelWidth_1, 100];
    g_xmlOptions.spacing = 4;
    var ch_keepXML = g_xmlOptions.add("checkbox", undefined, "Keep XML");
    var g_xmlOptions_1 = g_xmlOptions.add("group");
    var btn_xmlFile = g_xmlOptions_1.add("button", undefined, "XML File");
    var disp_xmlFile = g_xmlOptions_1.add("edittext", undefined, "", {
      readonly: true,
    });
    disp_xmlFile.characters = 50;
    disp_xmlFile.setValue = function (value) {
      this.text = value;
      this.helpTip = value;
    };

    var g_autobinding = g1.add("panel", undefined, "Auto Binding");
    g_autobinding.size = [UI_SIZING.panelWidth_1, 100];
    g_autobinding.spacing = 2;
    g_autobinding.margins = [7, 6, 6, 6];
    g_autobinding.orientation = "row";

    var autoBindingPropertyText = getSpecificPropertyListObj(
      AUTOBINDING,
      "text",
    );
    var autoBindingPropertyType = getSpecificPropertyListObj(
      AUTOBINDING,
      "type",
    );
    var dd_selectedAutobinding = makeDropdownlist(
      g_autobinding,
      autoBindingPropertyText,
    );
    dd_selectedAutobinding.data = {};
    for (var i = 0; i < dd_selectedAutobinding.items.length; i++) {
      dd_selectedAutobinding.data[dd_selectedAutobinding.items[i].text] =
        autoBindingPropertyType[i];
    }
    dd_selectedAutobinding.onChange = function () {
      SETTINGS.selectedAutobinding = this.data[this.selection.text];
      if (SESSION.documentExists) {
        TestManager.clearSpecificTestDisplays(
          this.window.UITestElements,
          "artBinding",
        );
      }
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };
    var g_autobinding_1 = g_autobinding.add("group");
    g_autobinding_1.spacing = 2;
    var btn_foundBindItems = g_autobinding_1.add(
      "button",
      undefined,
      "Find Art",
    );
    var disp_foundBindItems = g_autobinding_1.add("edittext", undefined, "", {
      readonly: true,
    });
    disp_foundBindItems.characters = 37;

    if (!SESSION.documentExists) {
      g_autobinding_1.visible = false;
    } else {
      btn_foundBindItems.onClick = function () {
        if (DATA.grid.length == 0) {
          alert("Please import a data file first.");
          return;
        }
        displayFoundArtBindings(this.window.UITestElements);
      };
    }

    ch_keepXML.onClick = function () {
      SETTINGS.keepXML = this.value;
      if (!this.value) {
        disp_xmlFile.setValue(decodeURI(SETTINGS.getDataXMLDestination()));
      }
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };

    btn_xmlFile.onClick = function () {
      if (!ch_keepXML.value) {
        disp_xmlFile.setValue(decodeURI(SETTINGS.getDataXMLDestination()));
        return;
      }
      var dfStr = this.window.UIElements["disp_dataFile"].getValue();
      var xmlFile, destChoice;
      if (dfStr != "") {
        var dataFile = File(dfStr);
        if (dataFile.exists) {
          xmlFile = File(
            dataFile.parent +
              "/" +
              decodeURI(dataFile.name).replace(/\.\w{2,4}$/, "") +
              "-vi_data.xml",
          );
          destChoice = xmlFile.saveDlg(
            "Choose a place to save the Variable Import XML File.",
          );
          if (destChoice != null) {
            disp_xmlFile.setValue(decodeURI(destChoice));
          } else {
            disp_xmlFile.setValue(decodeURI(SETTINGS.getDataXMLDestination()));
          }
        }
      } else {
        xmlFile = File(SETTINGS.getDataXMLDestination());
        destChoice = xmlFile.saveDlg(
          "Choose a place to save the Variable Import XML File.",
        );
        if (destChoice != null) {
          disp_xmlFile.setValue(decodeURI(destChoice));
        } else {
          disp_xmlFile.setValue(decodeURI(SETTINGS.getDataXMLDestination()));
        }
      }
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };

    disp_xmlFile.getValue = function () {
      if (SETTINGS.keepXML) {
        return this.text;
      } else {
        return "temp";
      }
    };

    parent.window.UIElements["dbslNextline"] = ch_dbslNextline;
    parent.window.UIElements["selectedAutobinding"] = dd_selectedAutobinding;
    parent.window.UIElements["keepXML"] = ch_keepXML;
    parent.window.UIElements["xmlPath"] = disp_xmlFile;
    parent.window.UIElements["list_warnings"] = list_warnings;
    parent.window.UIElements["datasetNamePreview"] = disp_datasetNamePreview;

    if (SESSION.documentExists) {
      // không có trường test art binding khi không có tài liệu nào.
      parent.window.UITestElements["foundArtBindings"] = disp_foundBindItems;
    }

    return g1;
  }

  function changeVarUrls(prop, newUrl) {
    var thisObj;
    for (var i = 0; i < DATA.currentVars.length; i++) {
      thisObj = DATA.currentVars[i];
      if (thisObj.varType == prop) {
        thisObj.url = newUrl;
      }
    }
  }

  function prependPathsGroup(parent) {
    var g1 = parent.add("group");
    g1.key = "prependPathsGroup";
    g1.spacing = 4;
    g1.orientation = "column";

    var g_pst = g1.add("group");
    var lbl_currentPreset = g_pst.add(
      "statictext",
      undefined,
      "Current Preset",
    );
    var disp_currentPreset = g_pst.add(
      'edittext{ properties : {readonly : true}, text : "", characters : ' +
        40 +
        ', justify : "center"}',
    );
    parent.window.UIElements["currentlySelectedPresetName"][2] =
      disp_currentPreset;

    var sep = g1.add("group");
    sep.size = [30, 30];

    var disp_prependImagePath = checkboxFolderPathInput(
      g1,
      "Prepend Image Path",
      "Choose Path",
      "Choose directory for image files.",
    );
    disp_prependImagePath.key = "Image";
    parent.window.UIElements["prependToAllImages"] =
      disp_prependImagePath.checkbox;
    parent.window.UIElements["prependImagePath"] = disp_prependImagePath;

    var g_foundImages = g1.add("group");
    var lbl_foundImages = g_foundImages.add(
      "statictext",
      undefined,
      "Found Images",
    );
    var disp_foundImages = g_foundImages.add(
      "edittext { properties : {readonly : true}, justify : 'center' }",
    );
    disp_foundImages.characters = UI_SIZING.foundOfTotalDisp.characters;
    disp_foundImages.key = "Image";
    var btn_foundImages = g_foundImages.add("button", undefined, "Show Log");
    btn_foundImages.key = "Images";
    btn_foundImages.disp = disp_foundImages;

    btn_foundImages.onClick = fileRefTestHandler;

    var sep1 = g1.add("group");
    sep1.size = [30, 30];

    var disp_prependGraphPath = checkboxFolderPathInput(
      g1,
      "Prepend Graph Path",
      "Choose Path",
      "Choose directory for graph-data files.",
    );
    disp_prependGraphPath.key = "Graph";
    parent.window.UIElements["prependToAllGraphs"] =
      disp_prependGraphPath.checkbox;
    parent.window.UIElements["prependGraphPath"] = disp_prependGraphPath;

    var g_foundGraphs = g1.add("group");
    var lbl_foundGraphs = g_foundGraphs.add(
      "statictext",
      undefined,
      "Found Graphs",
    );
    var disp_foundGraphs = g_foundGraphs.add(
      "edittext { properties : {readonly : true}, justify : 'center' }",
    );
    disp_foundGraphs.characters = UI_SIZING.foundOfTotalDisp.characters;
    disp_foundGraphs.key = "Graph";
    var btn_foundGraphs = g_foundGraphs.add("button", undefined, "Show Log");
    btn_foundGraphs.key = "Graphs";
    btn_foundGraphs.disp = disp_foundGraphs;

    btn_foundGraphs.onClick = fileRefTestHandler;

    disp_prependImagePath.onChange = function () {
      SETTINGS["prependToAll" + this.key + "s"] = this.checkbox.getValue();
      var thisText = this.getValue();
      SETTINGS["prepend" + this.key + "Path"] = thisText;
      if (thisText != "") {
        DATA.getCurrentVars(parent.window.UIElements);
        parent.window.UIElements["variableDisplay"].displayData(
          DATA.currentVars,
        );
      } else {
        this.helpTip = "";
      }
      TestManager.clearSpecificTestDisplays(
        this.window.UITestElements,
        this.key,
      );
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };

    disp_prependGraphPath.onChange = function () {
      SETTINGS["prependToAll" + this.key + "s"] = this.checkbox.getValue();
      var thisText = this.getValue();
      SETTINGS["prepend" + this.key + "Path"] = thisText;
      if (thisText != "") {
        DATA.getCurrentVars(parent.window.UIElements);
        parent.window.UIElements["variableDisplay"].displayData(
          DATA.currentVars,
        );
      } else {
        this.helpTip = "";
      }
      TestManager.clearSpecificTestDisplays(
        this.window.UITestElements,
        this.key,
      );
      updateCurrentPresetNameDisplays(
        this.window.UIElements,
        PRESETS.getByName(SESSION.currentLoadedPresetName),
        true,
      );
    };

    parent.window.UITestElements["foundImages"] = disp_foundImages;
    parent.window.UITestElements["foundGraphs"] = disp_foundGraphs;

    return g1;
  }

  function getPropertySummaryString(obj) {
    var msg = [];
    for (var all in obj) {
      if (typeof obj[all] != "object") {
        if (all != "name") {
          if (all == "selectedAutobinding") {
            msg.push(
              unCamelCaseSplit(all) + " : " + unCamelCaseSplit(obj[all]),
            );
          } else {
            msg.push(unCamelCaseSplit(all) + " : " + obj[all]);
          }
        }
      } else {
        if (all == "datasetNameObj") {
          var dsNmMsg = [],
            propObj,
            dispText;
          for (var it in obj[all]) {
            propObj = getSpecificPropertyObj(
              FIELDNAMEOPTIONS_current,
              "type",
              obj[all][it].type,
            );
            if (propObj == null) {
              // biến bị thiếu
              propObj = {
                type: obj[all][it].type,
                displayText:
                  "Variable " +
                  obj[all][it].type.replace(/[^\d]/g, "") +
                  ' Value : "' +
                  obj[all][it].text +
                  '"',
              };
            }
            dispText =
              propObj.displayText == "Custom Text" ||
              propObj.displayText == "Custom Increment"
                ? propObj.displayText + ' : "' + obj[all][it].text + '"'
                : propObj.displayText;
            dsNmMsg.push(it + " : " + dispText);
          }
          msg.push("----------------\nDataset Names:\n" + dsNmMsg.join("\n"));
        } else if (all == "enabledVisibilityKeyNames") {
          msg.push(
            "----------------\nEnabled Visibility Keys:\n" +
              obj[all].join("\n"),
          );
        }
      }
    }
    return msg;
  }

  function presetDialog(presetObjOrig, purpose, currentStateObj) {
    var presetObj = clone(presetObjOrig);

    var purpose = clone(purpose);
    var w = new Window("dialog", "Preset Display");
    var g1 = w.add("group");
    g1.key = "presetOptionsGroup";
    g1.spacing = 4;
    g1.orientation = "column";

    var g1_1 = g1.add("group");
    var lbl_currentPreset = g1_1.add("statictext", undefined, "Name");

    var nameText =
      purpose.placeholderName == "self"
        ? presetObj.name
        : purpose.placeholderName;
    var disp_currentPreset = g1_1.add("edittext", undefined, nameText, {
      readonly: !purpose.presetDispEditable || nameText == "default",
    });
    if (purpose.presetDispEditable) {
      disp_currentPreset.onChanging = function () {
        if (this.getValue().indexOf("*") > -1) {
          scriptAlert(
            "Sorry, due to asterisk (*) characters being used to mark preset dialog overrides they cannot be used in a preset name." +
              " Asterkisk automatically removed.",
          );
          this.setValue(this.getValue().replace(/\*/g, ""));
        }
      };
    }
    disp_currentPreset.characters = 36;
    var oldName = disp_currentPreset.text;

    var summary = g1.add("edittext", undefined, "", {
      readonly: true,
      multiline: true,
    });
    summary.size = [650, 200];

    var msg = getPropertySummaryString(presetObj);

    if (purpose.actionButtonName == "Update") {
      summary.size = [650, 250];
      msg.unshift(presetObj.name + ":", "------------------");
      msg.push("\r");

      var msg2 = getPropertySummaryString(currentStateObj);
      msg2.unshift("Current Dialog:", "------------------");
      summary.text = msg.join("\n").trim();

      var lbl_summary2 = g1.add("statictext", undefined, "Current Dialog");
      var summary2 = g1.add("edittext", undefined, "", {
        readonly: true,
        multiline: true,
      });
      summary2.size = [650, 250];
      summary2.text = msg2.join("\n").trim();
    } else {
      var spacer = g1.add("group");
      spacer.size = [10, 10];
      var lbl_summary2 = g1.add("statictext", undefined, "Dataset Names");
      var summary2 = g1.add("edittext", undefined, "", {
        readonly: true,
        multiline: true,
      });
      summary2.size = [650, 100];
      summary2.text = msg
        .join("\n")
        .replace(/[.\r\n\s\S]+----------------\nDataset Names\:/g, "")
        .replace(/----------------\nEnabled Visibility Keys\:[.\r\n\s\S]+$/, "")
        .trim();
      summary.text = msg
        .join("\n")
        .replace(/----------------\nDataset Names\:[.\r\n\s\S]+$/g, "")
        .trim();

      var lbl_summary3 = g1.add(
        "statictext",
        undefined,
        "Enabled Visibility Keys",
      );
      var summary3 = g1.add("edittext", undefined, "", {
        readonly: true,
        multiline: true,
      });
      summary3.size = [650, 100];
      summary3.text = msg
        .join("\n")
        .replace(/[.\r\n\s\S]+----------------\nEnabled Visibility Keys\:/, "")
        .trim();
    }

    var g_btn = w.add("group");

    if (purpose.showRemoveButton && presetObj.name != "default") {
      var btn_rmv = g_btn.add("button", undefined, "Remove");
      btn_rmv.onClick = function () {
        if (!CONFIRMS["confirmRemovalOfPresets"](presetObj.name)) {
          return;
        }
        purpose.resultAction = PresetDialogPurposes.Remove.resultAction;
        purpose.actionButtonName = "Remove";
        w.close();
      };
    }

    var btn_ok = g_btn.add("button", undefined, purpose.actionButtonName);
    w.defaultElement = btn_ok;
    if (purpose.presetDispEditable) {
      btn_ok.onClick = function () {
        var presetNewName = disp_currentPreset.getValue();
        if (presetNewName == "") {
          scriptAlert("A preset name may not be blank.");
          return;
        }
        w.close();
      };
    }

    var btn_ccl = g_btn.add("button", undefined, "Cancel");

    w.onShow = function () {
      if (purpose.presetDispEditable && presetObj.name != "default") {
        disp_currentPreset.active = false;
        disp_currentPreset.active = true;
      }
    };

    if (w.show() == 2) {
      return null;
    } else {
      return {
        presetName: disp_currentPreset.text,
        oldName: oldName,
        resultAction: purpose.resultAction,
        action: purpose.actionButtonName,
      };
    }
  }

  function presetOptionsGroup(parent) {
    var g1 = parent.add("group");
    g1.key = "presetOptionsGroup";
    g1.spacing = 4;
    g1.orientation = "column";

    var g1_0 = g1.add("group"); // hàng

    var g1_1 = g1_0.add("group");
    g1_1.orientation = "column";
    g1_1.alignChildren = "left";
    var g_pst = g1_1.add("group");
    var lbl_currentPreset = g_pst.add(
      "statictext",
      undefined,
      "Current Preset",
    );
    var disp_currentPreset = g_pst.add(
      'edittext{ properties : {readonly : true}, text : "", characters : ' +
        42 +
        ', justify : "center"}',
    );
    parent.window.UIElements["currentlySelectedPresetName"][3] =
      disp_currentPreset;

    var list_presets = g1_1.add(
      "listbox",
      undefined,
      getSpecificPropertyListArr(PRESETS, "name"),
    );
    list_presets.size = [440, 320];
    list_presets.onDoubleClick = function () {
      if (this.selection != null) {
        var res = presetDialog(
          PRESETS.getByName(this.selection.text),
          PresetDialogPurposes.Activate,
        );
        if (res == null) {
          return;
        }
        if (res.action == "Remove") {
          if (!CONFIRMS["confirmRemovalOfPresets"](this.selection.text)) {
            return;
          }
        } else if (res.action == "Update") {
          if (!CONFIRMS["confirmUpdatingOfPresets"](this.selection.text)) {
            return;
          }
        }
        res.resultAction(res, this.window.UIElements, this);
      }
    };
    parent.window.UIElements["list_presets"] = list_presets;

    var g_btn = g1_0.add("group");
    g_btn.orientation = "column";
    g_btn.alignChildren = "right";
    var btn_add = g_btn.add("button", undefined, "Add");
    var btn_update = g_btn.add("button", undefined, "Update");
    var btn_remove = g_btn.add("button", undefined, "Remove");
    var btn_activate = g_btn.add("button", undefined, "Activate");

    var g_btm = g1.add("group");
    g_btm.margins = [2, 6, 2, 0];
    var btn_save = g_btm.add("button", undefined, "Save Settings & Presets");
    btn_save.size = [210, 30];
    btn_save.onClick = function () {
      updateScriptDataFromUI(this.window.UIElements);
      writeSettingsFile(getScriptDataObj());
      this.window.UIElements["variablesDisplayR"].notify("onClick");
    };

    btn_activate.onClick = function () {
      if (list_presets.selection != null) {
        PresetDialogPurposes.Activate.resultAction(
          {
            presetName: list_presets.selection.text,
          },
          this.window.UIElements,
          list_presets,
        );
      } else {
        alert("Please select a preset in the Presets List");
      }
    };

    btn_remove.onClick = function () {
      if (list_presets.selection != null) {
        if (list_presets.selection.text == "default") {
          scriptAlert("Cannot remove the default preset.");
          return;
        }
        if (!CONFIRMS["confirmRemovalOfPresets"](list_presets.selection.text)) {
          return;
        }
        PresetDialogPurposes.Remove.resultAction(
          {
            presetName: list_presets.selection.text,
          },
          this.window.UIElements,
          list_presets,
        );
      } else {
        alert("Please select a preset in the Presets List");
      }
    };

    btn_update.onClick = function () {
      if (list_presets.selection != null) {
        var presetDialogResult = presetDialog(
          PRESETS.getByName(list_presets.selection.text),
          PresetDialogPurposes.Update,
          getUIData(this.window.UIElements),
        );
        if (presetDialogResult == null) {
          return;
        }
        if (
          !CONFIRMS["confirmUpdatingOfPresets"](list_presets.selection.text)
        ) {
          return;
        }
        presetDialogResult.resultAction(
          presetDialogResult,
          this.window.UIElements,
          list_presets,
        );
      } else {
        alert("Please select a preset in the Presets List");
      }
    };

    btn_add.onClick = function () {
      var presetDialogResult = presetDialog(
        getUIData(this.window.UIElements),
        PresetDialogPurposes.Add,
      );
      if (presetDialogResult == null) {
        return;
      }
      presetDialogResult.resultAction(
        presetDialogResult,
        this.window.UIElements,
        list_presets,
      );
    };

    return g1;
  }

  function refreshPresetListbox(elem) {
    elem.removeAll();
    var newNameList = getSpecificPropertyListArr(PRESETS, "name");
    for (var i = 0; i < newNameList.length; i++) {
      elem.add("item", newNameList[i]);
    }
  }

  function testAreaGroup(parent) {
    var g1 = parent.add("group");
    g1.key = "testAreaGroup";
    g1.spacing = 4;
    g1.orientation = "column";

    var tp = g1.add("tabbedpanel");

    for (var all in TestManager) {
      if (typeof TestManager[all] != "function") {
        if (!SESSION.documentExists && all == "artBindings") {
          // thậm chí không tạo tab test binding khi không có tài liệu nào đang mở
          continue;
        }
        tp[TestManager[all].key] = TestManager[all].makeTab(tp);
      }
    }

    var g_btn = g1.add("group");
    var btn_refreshTest = g_btn.add("button", undefined, "Refresh Test");
    btn_refreshTest.size = [250, 30];

    btn_refreshTest.onClick = function () {
      if (DATA.currentVars.length == 0) {
        alert("Please import a data file first.");
        return;
      }
      DATA.getCurrentGrid();
      var thisTab;
      for (var i = 0; i < tp.children.length; i++) {
        thisTab = tp.children[i];
        if (thisTab.text != "Art Bindings") {
          // nạp dữ liệu vào mọi chỗ liệt kê file ảnh hoặc graph (group Prepend Paths)
          thisTab.populateFields();
          for (var all in this.window.UITestElements) {
            thisElem = this.window.UITestElements[all];
            if (
              thisElem.hasOwnProperty("key") &&
              thisElem.key == thisTab.key &&
              typeof thisElem.setValue == "function"
            ) {
              thisElem.setValue(
                thisTab.contents.disp_foundMissingNum.getValue(),
              );
            }
          }
        } else if (
          tp.selection.text == "Art Bindings" &&
          SESSION.documentExists
        ) {
          // nạp dữ liệu cho phần hiển thị "Find Art" (group Options)
          displayFoundArtBindings(parent.window.UITestElements);
        }
      }
    };

    parent.window.UITestElements["testTabs"] = tp;

    return g1;
  }

  function toggleUrlInputVis(ddlist, toggleElem) {
    if (ddlist.selection != null) {
      if (
        ddlist.selection.text == "Graph" ||
        ddlist.selection.text == "Image"
      ) {
        toggleElem.visible = true;
      } else {
        toggleElem.visible = false;
      }
    }
  }

  function variableOptionsDialog(uiVarObj) {
    var w = new Window("dialog", "Variable " + (uiVarObj.varIndex + 1));
    w.spacing = 4;

    var g0 = w.add("group");

    var g1 = g0.add("panel", undefined, "Variable Name");
    var disp_varName = g1.add("edittext", undefined, uiVarObj.varName);
    disp_varName.size = [229, 30];

    var g2 = g0.add("panel", undefined, "Variable Type");
    var disp_varType = makeDropdownlist(g2, getPropertyList(VARTYPES));
    disp_varType.size = [229, 30];
    disp_varType.setValue(uiVarObj.varType);
    if (SESSION.imageTest) {
      for (var i = 0; i < disp_varType.items.length; i++) {
        disp_varType.items[i].image = ICONS[disp_varType.items[i]];
      }
    }
    disp_varType.onChange = function () {
      toggleUrlInputVis(this, disp_url.parent);
    };

    var disp_url = checkboxFolderPathInput(
      w,
      "Prepend Path",
      "Choose folder directory",
    );
    disp_url.setValue(uiVarObj.url);
    disp_url.checkbox.value = uiVarObj.url.trim() == "" ? false : true;

    var g_btn = w.add("group");
    var btn_ok = g_btn.add("button", undefined, "Ok");
    var btn_ccl = g_btn.add("button", undefined, "Cancel");

    disp_varName.onChanging = function () {
      if (!isXMLTagName(this.text)) {
        this.setBg([1, 0.7, 0.7]);
        this.enabled = false;
        this.enabled = true;
        this.active = false;
        this.active = true;
      } else {
        this.setBg([1, 1, 1]);
      }
    };

    btn_ok.onClick = function () {
      if (!DATA.testVariableName(uiVarObj.varName, disp_varName.getValue())) {
        return;
      }
      this.window.close();
    };

    w.onShow = function () {
      toggleUrlInputVis(disp_varType, disp_url.parent);
    };

    if (w.show() == 2) {
      return null;
    } else {
      var varObj = {
        varName: disp_varName.getValue(),
        varType: disp_varType.getValue(),
        url:
          disp_varType.getValue() == "Graph" ||
          disp_varType.getValue() == "Image"
            ? disp_url.getValue()
            : "",
        varIndex: uiVarObj.varIndex,
      };
      var changed = false;
      for (var all in uiVarObj) {
        for (var that in varObj) {
          if (uiVarObj[all] != varObj[all]) {
            changed = true;
            break;
          }
        }
      }
      return {
        varObj: varObj,
        changed: changed,
      };
    }
  }

  function datasetNameFieldComponent(parent, fieldName, datasetObj) {
    function toggle(key) {
      if (key == FIELDNAMEOPTIONS_current["customText"].displayText) {
        disp.toggle("editable");
        disp.editable.active = false;
        disp.editable.active = true;
      } else {
        disp.toggle("readonly");
      }
    }

    var customIncNames = getSpecificPropertyListArr(
      CUSTOM_INCREMENTS_current,
      "name",
    );

    var g1 = parent.add(
      "panel",
      undefined,
      fieldName[0].toUpperCase() + fieldName.substr(1).replace("_", " "),
    );
    g1.spacing = 4;
    g1.margins = [2, 8, 2, 2];
    var dd_options = makeDropdownlist(
      g1,
      getSpecificPropertyListObj(FIELDNAMEOPTIONS_current, "displayText"),
    );
    var thisType = datasetObj[fieldName].type;
    dd_options.setValue(FIELDNAMEOPTIONS_current[thisType].displayText);

    var g1_2 = g1.add("group");
    g1_2.orientation = "stacked";
    var disp = makeEditableReadonlyEdittext(
      g1_2,
      20,
      datasetObj[fieldName].text,
    );
    var dd_customInc = makeDropdownlist(g1_2, customIncNames);
    dd_customInc.size = dd_options.size = [165, 26];
    if (dd_options.getValue() == "Custom Increment") {
      dd_customInc.setValue(datasetObj[fieldName].text);
      disp.element.visible = false;
    } else {
      dd_customInc.visible = false;
    }

    toggle(dd_options.selection.text);

    dd_options.onChange = function () {
      var sel = this.selection;
      if (sel.text != "Custom Increment") {
        dd_customInc.visible = false;
        disp.element.visible = true;
        disp.setValue(
          getSpecificPropertyObj(
            FIELDNAMEOPTIONS_current,
            "displayText",
            sel.text,
          ).defaultText,
        );
        toggle(sel.text);
      } else {
        disp.setValue(dd_customInc.selection.text);
        disp.element.visible = false;
        dd_customInc.visible = true;
      }
    };
    dd_customInc.onChange = function () {
      disp.setValue(this.selection.text);
    };
    return {
      typeElem: dd_options,
      textElem: disp /* dùng lại text của disp để giữ tên custom inc */,
    };
  }

  function getDatasetNamePreviewString() {
    var str = "";
    for (var all in DATASETNAMEFIELDS_current) {
      str += DATASETNAMEFIELDS_current[all].text;
    }
    return str;
  }

  function datasetAssignDialog(datasetObjOrig) {
    function getUIDsNameFieldObj(tempObj) {
      for (var all in tempObj) {
        var type = getSpecificPropertyObj(
          FIELDNAMEOPTIONS_current,
          "displayText",
          tempObj[all].typeElem.getValue(),
        ).type;
        resObj[all] = {
          type: type,
          text: tempObj[all].textElem.getValue(),
        };
      }
      return resObj;
    }

    var processedDatasetNameFieldsResult = clearOutOfBoundVariables(
      clone(datasetObjOrig),
    );
    var datasetObj = processedDatasetNameFieldsResult.obj;
    if (
      WARNINGSETTINGS.showDatasetNamingWarning &&
      processedDatasetNameFieldsResult.msg != ""
    ) {
      quickView(
        processedDatasetNameFieldsResult.msg,
        "Dataset naming field errors.",
      );
    }

    var w = new Window("dialog", "Assign Dataset Names");
    w.spacing = 4;
    w.margins = [4, 4, 4, 4];
    var resObj = {},
      tempObj = {};
    var g0 = w.add("panel");
    g0.spacing = 4;
    g0.margins = [4, 4, 4, 4];
    var g0_1 = g0.add("group");
    g0_1.spacing = 2;
    var g0_2 = g0.add("group");
    g0_2.spacing = 2;
    var groups = [g0_1, g0_2];
    var c = 0,
      cg = 0;
    for (var all in datasetObj) {
      cg = c < 3 ? 0 : 1;
      tempObj[all] = datasetNameFieldComponent(groups[cg], all, datasetObj);
      c++;
    }

    var g_btn = w.add("group");
    if (DATA.currentVars.length > 0) {
      var btn_test = g_btn.add("button", undefined, "Test Dataset Names");
      btn_test.onClick = function () {
        DATA.getCurrentGrid();
        // quickView(DATA.getTestDatasetNames(getUIDsNameFieldObj(tempObj)).join("\n"), "Dataset Names:", [300, 450]);
        var testData = DATA.getTestDatasetNames(
          getUIDsNameFieldObj(tempObj),
        ).join("\n");
        simpleShowModal(TestManager.datasetNames.makeUIContents, {
          title: "Dataset Name List",
          data: testData,
          size: [300, 450],
        });
      };
      btn_test.helpTip = "Get full list of dataset names.";
    }
    var btn_ok = g_btn.add("button", undefined, "Ok");
    var btn_ccl = g_btn.add("button", undefined, "Cancel");

    btn_ok.onClick = function () {
      var isValid = false,
        type;
      for (var all in tempObj) {
        type = getSpecificPropertyObj(
          FIELDNAMEOPTIONS_current,
          "displayText",
          tempObj[all].typeElem.getValue(),
        ).type;
        if (type != "nothing") {
          isValid = true;
          w.close();
        }
      }
      if (!isValid) {
        scriptAlert("Dataset fields cannot all be set to 'nothing'.");
      }
    };

    w.onShow = function () {};

    if (w.show() == 2) {
      return null;
    } else {
      return getUIDsNameFieldObj(tempObj);
    }
  }

  function finishedXMLFileDialog(xmlDest, varsNum, recordsNum) {
    var w = new Window("dialog", SESSION.scriptName + ": XML File created.");

    var msg =
      "Your XML file has been created.\rIt contains " +
      varsNum +
      " variable" +
      (varsNum > 1 ? "s" : "") +
      " and " +
      recordsNum +
      " record" +
      (recordsNum > 1 ? "s" : "") +
      ".";

    var l = w.add("statictext", undefined, msg, { multiline: true });
    l.size = [260, 100];

    var e = w.add("edittext", undefined, decodeURI(xmlDest), {
      readonly: true,
    });
    e.characters = 40;
    e.helpTip = decodeURI(xmlDest);
    var g_btn = w.add("group");
    var btn_ok = g_btn.add("button", undefined, "Ok");
    var btn_reveal = g_btn.add("button", undefined, "Reveal in File System");

    btn_reveal.onClick = function () {
      Folder(File(e.text).parent).execute();
      w.close();
    };
    w.show();
  }

  function finishedXMLImportDialog(
    varsNum,
    recordsNum,
    missingImgNum,
    missingGrfNum,
  ) {
    var w = new Window(
      "dialog",
      SESSION.scriptName + ": Variable Data Imported.",
    );

    var msg =
      "Your variable data has been imported.\rIt contains " +
      varsNum +
      " variable" +
      (varsNum > 1 ? "s" : "") +
      " and " +
      recordsNum +
      " record" +
      (recordsNum > 1 ? "s" : "") +
      ".";

    var l = w.add("statictext", undefined, msg, { multiline: true });
    l.size = [260, 50];

    if (missingImgNum > 0) {
      l = w.add("statictext", undefined, missingImgNum + " Missing Image(s)", {
        multiline: true,
      });
      l.size = [260, 100];
    } else if (missingGrfNum > 0) {
      l = w.add("statictext", undefined, missingGrfNum + " Missing Graph(s)", {
        multiline: true,
      });
      l.size = [260, 100];
    } else {
      var g_cycle = w.add("group");
      var btn_cycle = g_cycle.add(
        "button",
        undefined,
        "Cycle Update All Datasets",
      );
      btn_cycle.helpTip =
        "Cycling and updating each of the datasets ensures that update-asterisks will appear correctly";
      var disp_cycle = g_cycle.add(
        'edittext { properties : {readonly : true}, justify : "center" }',
      );
      disp_cycle.characters = 10;
      disp_cycle.setValue("0 of " + app.activeDocument.dataSets.length);
      btn_cycle.onClick = function () {
        cycleUpdateAllDatasets(app.activeDocument, disp_cycle);
      };
    }

    var g_btn = w.add("group");
    var btn_ok = g_btn.add("button", undefined, "Ok");

    w.show();
  }

  function updateCustomIncrementDisplay(display, customIncObj) {
    var arr = [],
      prefixStr;
    for (var i = 0; i < 10; i++) {
      prefixStr = "  " + (i + 1) + ": "; // thêm số để chỉ thứ tự trong text của vùng hiển thị
      if ((i + 1).toString().length > 1) {
        prefixStr = i + 1 + ": ";
      }
      arr.push(
        prefixStr +
          getRecordCustomInc(
            i,
            customIncObj.startNum,
            customIncObj.padZero,
            customIncObj.increment,
            customIncObj.isIntervalIncrement,
          ),
      );
    }
    display.setValue(arr.join("\n"));
  }

  function customIncrementsDialog() {
    var dialogData = clone(CUSTOM_INCREMENTS_current);
    var customIncNames = [];
    for (var i = 0; i < dialogData.length; i++) {
      customIncNames.push(dialogData[i].name);
    }

    var w = new Window("dialog", "Custom Increment Options");
    w.spacing = 4;

    var g0 = w.add("group");
    g0.orientation = "row";

    var g1 = g0.add("group");
    var g1_1 = g1.add("group");
    g1_1.orientation = "column";
    var lbl_customIncList = g1_1.add(
      "statictext",
      undefined,
      "Custom Increment List",
    );
    var list_customIncs = g1_1.add("listbox", undefined, customIncNames);
    list_customIncs.size = [195, 280];
    var g1_1_2 = g1_1.add("group");
    g1_1_2.orientation = "row";
    g1_1_2.margins = [4, 4, 4, 10];
    var btn_addCustomInc = g1_1_2.add("button", undefined, "Add \u2795");
    var btn_removeCustomInc = g1_1_2.add("button", undefined, "Remove \u2796");
    btn_addCustomInc.size = btn_removeCustomInc.size = [80, 25];

    var g2a = g0.add("group");
    g2a.orientation = "column";
    var g2 = g2a.add("panel", undefined, "Properties");
    g2.spacing = 4;
    g2.alignChildren = "left";
    var g2_1 = g2.add("group");
    var lbl_startNum = g2_1.add("statictext", undefined, "Start Number");
    lbl_startNum.size = [120, 26];
    var disp_startNum = g2_1.add("edittext", undefined, "");
    disp_startNum.characters = 10;
    disp_startNum.onChange = function () {
      var val = this.getValue();
      var msg =
        "Please enter a zero, or a positive integer number into the 'Start Number' field.";
      if (isNaN(val) || !/^\d+$/.test(val)) {
        scriptAlert(msg);
        this.setValue(0);
        updateCustomIncrementDisplay(disp_preview, {
          padZero: dd_padZero.getValue(),
          startNum: this.getValue(),
          increment: disp_incValue.getValue(),
          isIntervalIncrement: ch_intervalIncrement.getValue(),
        });
        return;
      } else {
        if (val != "0" && val.indexOf("0") > -1) {
          val = val.replace(/^0+/, "");
          if (val == "") {
            val = 0;
          }
        }
        this.setValue(val);
        updateCustomIncrementDisplay(disp_preview, {
          padZero: dd_padZero.getValue(),
          startNum: this.getValue(),
          increment: disp_incValue.getValue(),
          isIntervalIncrement: ch_intervalIncrement.getValue(),
        });
      }
    };

    var g2_1a = g2.add("group");
    var lbl_incValue = g2_1a.add("statictext", undefined, "Increment Value");
    lbl_incValue.size = [120, 26];
    var disp_incValue = g2_1a.add("edittext", undefined, "");
    disp_incValue.characters = 10;
    disp_incValue.onChange = function () {
      var val = this.getValue();
      var msg =
        "Please enter a positive integer number into the 'Increment Value' field.";
      if (isNaN(val) || !/^\d+$/.test(val) || val * 1 <= 0) {
        scriptAlert(msg);
        this.setValue(1);
        updateCustomIncrementDisplay(disp_preview, {
          padZero: dd_padZero.getValue(),
          startNum: this.getValue(),
          increment: disp_incValue.getValue(),
          isIntervalIncrement: ch_intervalIncrement.getValue(),
        });
        return;
      } else {
        this.setValue(val);
        updateCustomIncrementDisplay(disp_preview, {
          padZero: dd_padZero.getValue(),
          startNum: disp_startNum.getValue(),
          increment: this.getValue(),
          isIntervalIncrement: ch_intervalIncrement.getValue(),
        });
      }
    };

    var g2_1b = g2.add("group");
    var ch_intervalIncrement = g2_1b.add(
      "checkbox",
      undefined,
      "Make Interval Increment",
    );
    ch_intervalIncrement.helpTip =
      "Adds a dash with the next value of the incremented position after the specified increment amount has been added. ex: 1-10, 11-20";
    ch_intervalIncrement.onChange = function () {
      var val = this.getValue();
      updateCustomIncrementDisplay(disp_preview, {
        padZero: dd_padZero.getValue(),
        startNum: disp_startNum.getValue(),
        increment: disp_incValue.getValue(),
        isIntervalIncrement: val,
      });
    };

    var g2_2 = g2.add("group");
    var lbl_padZero = g2_2.add("statictext", undefined, "Padding Zeroes");
    lbl_padZero.size = [120, 26];
    var dd_padZero = makeDropdownlist(
      g2_2,
      [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
    );
    dd_padZero.characters = 10;
    dd_padZero.onChange = function () {
      updateCustomIncrementDisplay(disp_preview, {
        padZero: this.getValue(),
        startNum: disp_startNum.getValue(),
        increment: disp_incValue.getValue(),
        isIntervalIncrement: ch_intervalIncrement.getValue(),
      });
    };
    var g2_3 = g2a.add("panel", undefined, "Preview Display");
    g2_3.margins = [6, 6, 6, 6];
    var disp_preview = g2_3.add("edittext", undefined, "", {
      multiline: true,
      readonly: true,
    });
    disp_preview.size = [240, 160];

    var g_btn = w.add("group");
    var btn_ccl = g_btn.add("button", undefined, "Cancel");
    var btn_ok = g_btn.add("button", undefined, "Save");

    list_customIncs.onChange = function () {
      if (this.selection != null) {
        dd_padZero.setValue(dialogData[this.selection.index].padZero);
        disp_startNum.setValue(dialogData[this.selection.index].startNum);
        disp_incValue.setValue(dialogData[this.selection.index].increment);
        ch_intervalIncrement.setValue(
          dialogData[this.selection.index].isIntervalIncrement,
        );
        updateCustomIncrementDisplay(disp_preview, {
          padZero: dd_padZero.getValue(),
          startNum: disp_startNum.getValue(),
          increment: disp_incValue.getValue(),
          isIntervalIncrement: ch_intervalIncrement.getValue(),
        });
      }
    };

    g2.addEventListener("mousedown", function () {
      list_customIncs.selection = null;
    });

    ch_intervalIncrement.onClick = function () {
      updateCustomIncrementDisplay(disp_preview, {
        padZero: dd_padZero.getValue(),
        startNum: disp_startNum.getValue(),
        increment: disp_incValue.getValue(),
        isIntervalIncrement: this.getValue(),
      });
    };

    btn_addCustomInc.onClick = function () {
      var startNumValue = disp_startNum.getValue();
      var padZeroValue = dd_padZero.getValue();
      var incrementValue = disp_incValue.getValue();
      var isIntervalIncrement = ch_intervalIncrement.getValue();
      if (startNumValue == "" || padZeroValue == "" || incrementValue == "") {
        scriptAlert(
          "Please ensure the 'Increment Value' and 'Start Number' fields are filled.",
        );
        return;
      }
      var newName =
        "s" +
        startNumValue +
        "p" +
        padZeroValue +
        "i" +
        incrementValue +
        (isIntervalIncrement ? "-interval" : "");
      dialogData.push({
        name: newName,
        padZero: padZeroValue,
        startNum: startNumValue,
        increment: incrementValue,
        isIntervalIncrement: isIntervalIncrement,
      });
      list_customIncs.addItem(newName);
    };

    btn_removeCustomInc.onClick = function () {
      if (list_customIncs.selection == null) {
        return;
      }
      dialogData.splice(list_customIncs.selection.index, 1);
      list_customIncs.removeSelectedItem();
    };

    btn_ok.onClick = function () {
      if (dialogData.length < 1) {
        scriptAlert(
          "At least one custom increment must be present in the list to save.",
        );
        return;
      } else {
        SESSION.settingsFile.open("r");
        var settingsObj = JSON.parse(SESSION.settingsFile.read());
        SESSION.settingsFile.close();
        CUSTOM_INCREMENTS_current = settingsObj.CUSTOM_INCREMENTS = dialogData;
        writeSettingsFile(settingsObj);
      }
      this.window.close();
    };

    if (w.show() == 2) {
      return null;
    } else {
      return {};
    }
  }
  function populateVisKeyList(listElem, visKeys) {
    for (var i = listElem.items.length - 1; i > -1; i--) {
      listElem.remove(i);
    }
    var thisVisKey, newItem;
    for (var i = 0; i < visKeys.length; i++) {
      thisVisKey = visKeys[i];
      newItem = listElem.add("item");
      newItem.text = thisVisKey.name;
      newItem.subItems[0].text = thisVisKey.displayText;
      newItem.checked = thisVisKey.enabled;
    }
  }

  function visibilityKeysDialog() {
    var textInputHelpTip =
      "Visibility Key 'text' is compared to data cell text in lower-case.";

    function getBothSetsOfKeys(visKeyObj) {
      var trueVisKeys = [],
        falseVisKeys = [];
      var thisVisKey;
      for (var i = 0; i < visKeyObj.length; i++) {
        thisVisKey = visKeyObj[i];
        if (thisVisKey.value) {
          trueVisKeys.push(thisVisKey);
        } else {
          falseVisKeys.push(thisVisKey);
        }
      }
      return { trueVisKeys: trueVisKeys, falseVisKeys: falseVisKeys };
    }

    var dialogData = clone(VisibilityKeys);
    var keyData = getBothSetsOfKeys(dialogData);
    var trueVisKeys = keyData.trueVisKeys,
      falseVisKeys = keyData.falseVisKeys;

    var w = new Window("dialog", "Manage Visibility Keys");
    w.spacing = 4;
    var inputCharacterAmt = 10;

    var g0 = w.add("group");
    g0.orientation = "row";

    var g1 = g0.add("group");
    var g1_1 = g1.add("group");
    g1_1.orientation = "column";

    var lbl_trueList = g1_1.add("statictext", undefined, "true / visible");
    var list_trueList = g1_1.add("listbox", undefined, [], {
      numberOfColumns: 2,
      showHeaders: true,
      columnTitles: ["Name", "Text"],
      columnWidths: [120, 120],
    });
    list_trueList.size = [260, 200];
    list_trueList.name = "True List"; // thuộc tính tự thêm

    var g1_1_2a = g1_1.add("group");
    g1_1_2a.orientation = "row";
    g1_1_2a.spacing = 4;
    var g1_1_2a_1 = g1_1_2a.add("group");
    g1_1_2a_1.orientation = "column";
    g1_1_2a_1.spacing = 4;
    var lbl_trueKeyName = g1_1_2a_1.add("statictext", undefined, "name");
    var disp_trueKeyName = g1_1_2a_1.add("edittext", undefined, "");
    disp_trueKeyName.characters = inputCharacterAmt;
    disp_trueKeyName.list = list_trueList;

    var g1_1_2a_2 = g1_1_2a.add("group");
    g1_1_2a_2.orientation = "column";
    g1_1_2a_2.spacing = 4;
    var lbl_trueKeyText = g1_1_2a_2.add("statictext", undefined, "text");
    var disp_trueKeyText = g1_1_2a_2.add("edittext", undefined, "");
    disp_trueKeyText.helpTip = textInputHelpTip;
    disp_trueKeyText.characters = inputCharacterAmt;
    disp_trueKeyText.list = list_trueList;

    var g1_1_2 = g1_1.add("group");
    g1_1_2.orientation = "row";
    g1_1_2.margins = [4, 4, 4, 10];
    var btn_addTrueVisKey = g1_1_2.add("button", undefined, "Add \u2795");
    var btn_removeTrueVisKey = g1_1_2.add("button", undefined, "Remove \u2796");
    btn_addTrueVisKey.size = btn_removeTrueVisKey.size = [80, 25];
    btn_addTrueVisKey.list = btn_removeTrueVisKey.list = list_trueList;

    var sep = g1.add("panel");
    sep.size = [2, 300];
    var g1_2 = g1.add("group");
    g1_2.orientation = "column";

    var lbl_falseList = g1_2.add("statictext", undefined, "false / invisible");
    var list_falseList = g1_2.add("listbox", undefined, [], {
      numberOfColumns: 2,
      showHeaders: true,
      columnTitles: ["Name", "Text"],
      columnWidths: [120, 120],
    });
    list_falseList.size = [260, 200];
    list_falseList.name = "False List"; // thuộc tính tự thêm

    var g1_2_2a = g1_2.add("group");
    g1_2_2a.orientation = "row";
    g1_2_2a.spacing = 4;
    var g1_2_2a_1 = g1_2_2a.add("group");
    g1_2_2a_1.orientation = "column";
    g1_2_2a_1.spacing = 4;
    var lbl_falseKeyName = g1_2_2a_1.add("statictext", undefined, "name");
    var disp_falseKeyName = g1_2_2a_1.add("edittext", undefined, "");
    disp_falseKeyName.characters = inputCharacterAmt;
    disp_falseKeyName.list = list_falseList;

    var g1_2_2a_2 = g1_2_2a.add("group");
    g1_2_2a_2.orientation = "column";
    g1_2_2a_2.spacing = 4;
    var lbl_falseKeyText = g1_2_2a_2.add("statictext", undefined, "text");
    var disp_falseKeyText = g1_2_2a_2.add("edittext", undefined, "");
    disp_falseKeyText.helpTip = textInputHelpTip;
    disp_falseKeyText.characters = inputCharacterAmt;
    disp_falseKeyText.list = list_falseList;

    var g1_2_2 = g1_2.add("group");
    g1_2_2.orientation = "row";
    g1_2_2.margins = [4, 4, 4, 10];
    var btn_addFalseVisKey = g1_2_2.add("button", undefined, "Add \u2795");
    var btn_removeFalseVisKey = g1_2_2.add(
      "button",
      undefined,
      "Remove \u2796",
    );
    btn_addFalseVisKey.size = btn_removeFalseVisKey.size = [80, 25];
    btn_addFalseVisKey.list = btn_removeFalseVisKey.list = list_falseList;

    var btns = [
      btn_addTrueVisKey,
      btn_removeTrueVisKey,
      btn_addFalseVisKey,
      btn_removeFalseVisKey,
    ];
    var thisBtn;
    for (var i = 0; i < btns.length; i++) {
      thisBtn = btns[i];
      thisBtn.onClick = function () {
        var self = this;
        return (function (self) {
          var list = self.list;
          var isTrueList = list.name == "True List";
          var isAddBtn = self.text == "Add \u2795";
          if (isAddBtn) {
            var isValidAddition, thisValueInputElem, thisNameInputElem, problem;
            if (isTrueList) {
              thisValueInputElem = disp_trueKeyText;
              thisNameInputElem = disp_trueKeyName;
            } else {
              thisValueInputElem = disp_falseKeyText;
              thisNameInputElem = disp_falseKeyName;
            }
            try {
              problem =
                "VisibilityKeys - please fill out all necessary fields before adding a new key.";
              isValidAddition = thisNameInputElem.getValue().trim() != "";
              if (!isValidAddition) {
                throw problem;
              }
              var allPresentListNames = [];
              for (var i = 0; i < list.items.length; i++) {
                thisName = list.items[i].text;
                allPresentListNames.push(thisName);
              }
              problem =
                "VisibilityKeys - please choose a different name for the new key to add to the list.";
              isValidAddition =
                allPresentListNames.indexOf(thisNameInputElem.getValue()) == -1;
              if (isValidAddition) {
                var newItem = list.add("item");
                newItem.text = thisNameInputElem.getValue(); // tên
                newItem.subItems[0].text = thisValueInputElem
                  .getValue()
                  .toLowerCase(); // text
                newItem.checked = true;
              } else {
                throw problem;
              }
            } catch (e) {
              scriptAlert(e);
              return;
            }
          } else {
            if (list.selection == null) {
              return;
            }
            if (list.items.length > 1) {
              list.selection.remove();
            }
          }

          var keyData = getBothSetsOfKeys(VisibilityKeys);
          var trueVisKeys = keyData.trueVisKeys,
            falseVisKeys = keyData.falseVisKeys;
          var targetKeys = isTrueList ? trueVisKeys : falseVisKeys;
          var isCompleteMatch = true;
          var thisName, thisText;
          for (var i = 0; i < list.items.length; i++) {
            thisName = list.items[i].text;
            thisText = list.items[i].subItems[0].text;
            if (getByName(targetKeys, thisName) == null) {
              isCompleteMatch = false;
              break;
            }
          }
          var thisCompareName, wasMatched;
          for (var i = 0; i < targetKeys.length; i++) {
            thisCompareName = targetKeys[i].name;
            wasMatched = false;
            for (var j = 0; j < list.items.length; j++) {
              thisName = list.items[j].text;
              thisText = list.items[j].subItems[0].text;
              if (thisName == thisCompareName) {
                wasMatched = true;
                break;
              } else if (!wasMatched && j == list.items.length - 1) {
                isCompleteMatch = false;
                break;
              }
            }
          }
          if (isCompleteMatch) {
            btn_ok.text = "Apply";
          } else {
            btn_ok.text = "Save & Apply";
          }
        })(self);
      };
    }

    list_trueList.onDoubleClick = list_falseList.onDoubleClick = function () {
      if (this.selection != null) {
        this.selection.checked = !this.selection.checked;
      }
    };
    var firstFocus = true;
    w.addEventListener("mouseover", function () {
      if (firstFocus) {
        list_falseList.active = true;
        list_trueList.active = true;
        firstFocus = false;
      }
    });

    var g_btn = w.add("group");
    var btn_ccl = g_btn.add("button", undefined, "Cancel");
    var btn_ok = g_btn.add("button", undefined, "Apply");
    btn_ccl.size = btn_ok.size = [180, 26];

    btn_ok.onClick = function () {
      var resultData = [],
        thisItem,
        keyObj;
      for (var i = 0; i < list_trueList.items.length; i++) {
        thisItem = list_trueList.items[i];
        keyObj = {
          displayText: thisItem.subItems[0].text,
          name: thisItem.text,
          value: true,
          enabled: thisItem.checked,
        };
        resultData.push(keyObj);
      }
      for (var i = 0; i < list_falseList.items.length; i++) {
        thisItem = list_falseList.items[i];
        keyObj = {
          displayText: thisItem.subItems[0].text,
          name: thisItem.text,
          value: false,
          enabled: thisItem.checked,
        };
        resultData.push(keyObj);
      }
      VisibilityKeys = resultData;
      if (this.text == "Save & Apply") {
        SESSION.settingsFile.open("r");
        var settingsObj = JSON.parse(SESSION.settingsFile.read());
        SESSION.settingsFile.close();
        settingsObj.VisibilityKeys = VisibilityKeys;
        writeSettingsFile(settingsObj);
      }
      this.window.close();
    };

    w.onShow = function () {
      populateVisKeyList(list_trueList, trueVisKeys);
      populateVisKeyList(list_falseList, falseVisKeys);
    };

    if (w.show() == 2) {
      return null;
    } else {
      return {};
    }
  }

  var userData = UIWindow();
  if (userData == null) {
    // huỷ, không chạy tiếp
    return;
  }

  processUserInput(userData);
}

function dcRunVariable() {
  try {
    VariableImporter();
    return "OK: Đã mở Variable Importer.";
  } catch (e) {
    return "ERR: " + e.toString();
  }
}

// ============================================================
//  Catalogue A4/A5: gop truc tiep vao lib (khong con file roi).
//  Moi ham boc IIFE rieng de scope bien/ham noi bo tach biet.
// ============================================================


// Catalogue KTS A4 dùng khổ tờ cố định 43 x 32.5 cm. File AI tham chiếu cũ
// có bốn PON chữ L màu đen. Vẽ trực tiếp đúng các PON đó để lượt dàn
// không bao giờ phải mở hay nhân bản file tham chiếu ấy.
function dcCatalogueCreateAutoPonLayer(doc) {
  var layerName = "Pon Catalogue tu dong";
  for (var li = doc.layers.length - 1; li >= 0; li--) {
    try {
      if (doc.layers[li].name === layerName) {
        doc.layers[li].locked = false;
        doc.layers[li].remove();
      }
    } catch (e) {}
  }
  var layer = doc.layers.add();
  layer.name = layerName;
  try {
    layer.locked = false;
    layer.visible = true;
  } catch (e2) {}
  return layer;
}

function dcCatalogueAddAutoPon(layer, artboardRect) {
  var MM = 2.834645669;
  var xInset = 4 * MM;
  var yInset = 13 * MM;
  var verticalLength = 11; // pt, khớp với form tham chiếu KTS được cung cấp.
  var horizontalLength = 4.803049;
  var black = new CMYKColor();
  black.cyan = 0;
  black.magenta = 0;
  black.yellow = 0;
  black.black = 100;

  function draw(p1, p2) {
    var line = layer.pathItems.add();
    line.setEntirePath([p1, p2]);
    line.filled = false;
    line.stroked = true;
    line.strokeColor = black;
    line.strokeWidth = 1;
  }

  var left = artboardRect[0];
  var top = artboardRect[1];
  var right = artboardRect[2];
  var bottom = artboardRect[3];
  var xLeft = left + xInset;
  var xRight = right - xInset;
  var yTop = top - yInset;
  var yBottom = bottom + yInset;

  // Trên trái / trên phải.
  draw([xLeft, yTop + verticalLength], [xLeft, yTop]);
  draw([xRight, yTop + verticalLength], [xRight, yTop]);
  draw([xLeft - horizontalLength, yTop], [xLeft, yTop]);
  draw([xRight, yTop], [xRight + horizontalLength, yTop]);
  // Dưới trái / dưới phải.
  draw([xLeft, yBottom], [xLeft, yBottom - verticalLength]);
  draw([xRight, yBottom], [xRight, yBottom - verticalLength]);
  draw([xLeft - horizontalLength, yBottom], [xLeft, yBottom]);
  draw([xRight, yBottom], [xRight + horizontalLength, yBottom]);
}

// Form Catalogue A5 dung chung kho 43 x 32.5 cm, nhung co them mot cap
// dau pon o tam to de canh hai cot A5. Toa do va net ve khop form A5 da gui.
function dcCatalogueAddAutoPonA5(layer, artboardRect) {
  var MM = 2.834645669;
  var xInset = 4 * MM;
  var yInset = 13 * MM;
  var verticalLength = 11;
  var horizontalLength = 4.803049;
  var black = new CMYKColor();
  black.cyan = 0;
  black.magenta = 0;
  black.yellow = 0;
  black.black = 100;

  function draw(p1, p2) {
    var line = layer.pathItems.add();
    line.setEntirePath([p1, p2]);
    line.filled = false;
    line.stroked = true;
    line.strokeColor = black;
    line.strokeWidth = 1;
  }

  var left = artboardRect[0];
  var top = artboardRect[1];
  var right = artboardRect[2];
  var bottom = artboardRect[3];
  var xLeft = left + xInset;
  var xMiddle = (left + right) / 2;
  var xRight = right - xInset;
  var yTop = top - yInset;
  var yBottom = bottom + yInset;

  // Hai dau L ben trai/phai va cap dau doc o chinh giua to A5.
  draw([xLeft, yTop + verticalLength], [xLeft, yTop]);
  draw([xMiddle, yTop + verticalLength], [xMiddle, yTop]);
  draw([xRight, yTop + verticalLength], [xRight, yTop]);
  draw([xLeft, yBottom], [xLeft, yBottom - verticalLength]);
  draw([xMiddle, yBottom], [xMiddle, yBottom - verticalLength]);
  draw([xRight, yBottom], [xRight, yBottom - verticalLength]);
  draw([xLeft - horizontalLength, yTop], [xLeft, yTop]);
  draw([xRight, yTop], [xRight + horizontalLength, yTop]);
  draw([xLeft - horizontalLength, yBottom], [xLeft, yBottom]);
  draw([xRight, yBottom], [xRight + horizontalLength, yBottom]);
}

// Vẽ PON theo biên thực tế của bài đã dàn. Với đúng khổ A4 và A5,
// cách này cho ra toạ độ giống hệt hai form tham chiếu;
// khổ nhỏ hơn thì có PON riêng đặt đúng vị trí mà không phải nhập
// bất kỳ hình PON cũ nào.
function dcCatalogueAddDynamicPon(layer, artworkRect, twoBooklets) {
  var verticalLength = 11;
  var horizontalLength = 4.803049;
  var black = new CMYKColor();
  black.cyan = 0;
  black.magenta = 0;
  black.yellow = 0;
  black.black = 100;

  function draw(p1, p2) {
    var line = layer.pathItems.add();
    line.setEntirePath([p1, p2]);
    line.filled = false;
    line.stroked = true;
    line.strokeColor = black;
    line.strokeWidth = 1;
  }

  var xLeft = artworkRect[0];
  var yTop = artworkRect[1];
  var xRight = artworkRect[2];
  var yBottom = artworkRect[3];

  draw([xLeft, yTop + verticalLength], [xLeft, yTop]);
  draw([xRight, yTop + verticalLength], [xRight, yTop]);
  draw([xLeft - horizontalLength, yTop], [xLeft, yTop]);
  draw([xRight, yTop], [xRight + horizontalLength, yTop]);
  draw([xLeft, yBottom], [xLeft, yBottom - verticalLength]);
  draw([xRight, yBottom], [xRight, yBottom - verticalLength]);
  draw([xLeft - horizontalLength, yBottom], [xLeft, yBottom]);
  draw([xRight, yBottom], [xRight + horizontalLength, yBottom]);

  if (twoBooklets) {
    var xMiddle = (xLeft + xRight) / 2;
    draw([xMiddle, yTop + verticalLength], [xMiddle, yTop]);
    draw([xMiddle, yBottom], [xMiddle, yBottom - verticalLength]);
  }
}

function dcRunCatalogueA4() {
  try {
    // ============================================================
    //  TEST: Dàn trang Catalogue (imposition sách đóng gáy giữa)
    //  Chạy riêng để test, CHƯA tích hợp panel.
    //
    //  Cách dùng:
    //   1. Mở file có các trang catalogue (mỗi trang 1 object/group).
    //   2. Chọn N object theo THỨ TỰ z-order = trang 1, 2, 3...
    //      (N phải là bội số của 4).
    //   3. File > Scripts > chạy script này.
    //
    //  Xử lý mỗi trang: raster (nếu chưa phẳng) -> clip A4 (21x29.7cm)
    //   -> phóng to 21.1x29.9cm.
    //  Dàn: mỗi tờ 2 trang A4 nằm ngang. Cặp trang theo công thức
    //   imposition: tờ i mặt trước (N-2i, 1+2i), mặt sau (2+2i, N-1-2i).
    // ============================================================

    (function () {
      var MM = 2.834645669; // số pt trên 1 mm

      // Kích thước trang
      var A4_W = 210.0,
        A4_H = 297.0; // mm - clip
      var PAGE_W = 211.0,
        PAGE_H = 299.0; // mm - sau khi phóng to
      // Chỉ dùng ở BƯỚC CUỐI, sau khi dàn xong: giảm tổng ngang của mỗi cụm 2 trang.
      var PAIR_REDUCTION = 0.25; // mm cho mỗi cụm tiếp theo (= 0.025cm)
      var GAP = 0; // mm - khe giữa 2 trang trên 1 tờ (0 = sát nhau)

      // ---- Cấu hình pon (nhớ đường dẫn 1 lần, như decal) ----
      function _ponMemoFile() {
        return new File(Folder.userData + "/dan_catalogue_pon.txt");
      }
      function _ponRead() {
        var f = _ponMemoFile();
        if (f.exists) {
          f.encoding = "UTF-8";
          f.open("r");
          var t = f.read();
          f.close();
          t = t.replace(/^\s+|\s+$/g, "");
          if (t && t.charAt(0) !== "#") return t;
        }
        return null;
      }
      function _ponWrite(path) {
        var f = _ponMemoFile();
        try {
          f.encoding = "UTF-8";
          f.open("w");
          f.write(path);
          f.close();
        } catch (e) {}
      }
      function _ponGet() {
        var saved = _ponRead();
        if (saved) {
          var f = new File(saved);
          if (f.exists) return f;
        }
        var chosen = File.openDialog(
          "Chọn file pon catalogue (.ai) - chỉ hỏi 1 lần",
          "*.ai",
        );
        if (chosen && chosen.exists) {
          _ponWrite(chosen.fsName);
          return chosen;
        }
        return null;
      }

      if (app.documents.length === 0) {
        alert("Chưa mở tài liệu.");
        return;
      }
      var doc = app.activeDocument;
      var sel = doc.selection;
      if (!sel || sel.length === 0) {
        alert("Chưa chọn object nào.");
        return;
      }

      var N = sel.length;
      if (N % 4 !== 0) {
        alert("Số trang phải là BỘI SỐ CỦA 4.\nĐang chọn: " + N + " trang.");
        return;
      }

      // ---- Gom object và sắp theo VỊ TRÍ (trái→phải, trên→dưới) ----
      //  Vì các trang catalogue xếp thành hàng, sắp theo vị trí là đúng thứ tự đọc.
      //  Tránh dùng zOrderPosition (lỗi 1200 khi khác layer).
      var pages = [];
      // Khung bao của đúng các object được chọn. Đây là vùng giới hạn dàn,
      // hoàn toàn không liên quan đến vùng làm việc của tài liệu.
      var selectionLeft = null,
        selectionTop = null,
        selectionRight = null,
        selectionBottom = null;
      for (var i = 0; i < sel.length; i++) {
        var it = sel[i];
        var b;
        try {
          b = it.visibleBounds;
        } catch (e) {
          b = it.geometricBounds;
        }
        pages.push({ item: it, left: b[0], top: b[1] });
        if (selectionLeft === null) {
          selectionLeft = b[0];
          selectionTop = b[1];
          selectionRight = b[2];
          selectionBottom = b[3];
        } else {
          selectionLeft = Math.min(selectionLeft, b[0]);
          selectionTop = Math.max(selectionTop, b[1]);
          selectionRight = Math.max(selectionRight, b[2]);
          selectionBottom = Math.min(selectionBottom, b[3]);
        }
      }
      // gom theo hàng: sắp theo top giảm dần (trên xuống), trong hàng sắp left tăng
      pages.sort(function (a, b) {
        var dy = b.top - a.top; // top lớn = ở trên = trước
        if (Math.abs(dy) > 50 * MM) return dy; // khác hàng (>5cm) -> theo hàng
        return a.left - b.left; // cùng hàng -> trái sang phải
      });
      // rút item ra
      var pageItems = [];
      for (i = 0; i < pages.length; i++) pageItems.push(pages[i].item);
      pages = pageItems; // pages[0] = trang 1

      // ============================================================
      //  HÀM PHỤ TRỢ
      // ============================================================

      function sizeMM(item) {
        // Khung Transform (trang đã clip → khung clip; group → khung group), dự phòng geometricBounds.
        var g = dcKhungHoacBounds(item);
        if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] };
        return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
      }



      // Rasterize object (làm phẳng) ở 500ppi

      // Kiểm object đã "phẳng" chưa (là 1 RasterItem hoặc PlacedItem)
      function isFlat(item) {
        try {
          var t = item.typename;
          return t === "RasterItem" || t === "PlacedItem";
        } catch (e) {
          return false;
        }
      }

      // Clip object về đúng khung rect [l,t,r,b] cho trước (như card autoClip).
      function clipToRect(item, rect) {
        var lay = item.layer;
        // rectangle(top, left, width, height)
        var w = rect[2] - rect[0],
          h = rect[1] - rect[3];
        var r = lay.pathItems.rectangle(rect[1], rect[0], w, h);
        var grp = lay.groupItems.add();
        r.move(grp, ElementPlacement.PLACEATBEGINNING);
        item.move(grp, ElementPlacement.PLACEATEND);
        r.clipping = true;
        grp.clipped = true;
        return grp;
      }

      // Đặt tâm object vào (cxPt, cyPt) theo VISIBLE bounds
      function centerAt(item, cxPt, cyPt) {
        var s = sizeMM(item);
        var curCx = (s.b[0] + s.b[2]) / 2,
          curCy = (s.b[1] + s.b[3]) / 2;
        item.translate(cxPt - curCx, cyPt - curCy);
      }

      // ============================================================
      //  BƯỚC 1: XỬ LÝ TỪNG TRANG (làm như card: raster + clip, KHÔNG resize)
      //  Object đã đúng kích thước (đã clip sẵn). Chỉ cần:
      //   1. Raster (làm phẳng thành hình).
      //   2. Clip lại về đúng khung của nó (như card).
      //  KHÔNG bóp/resize -> không méo.
      // ============================================================
      var processed = [];
      var canhBaoPhong = []; // phóng không đều > 0,5 % → báo trong kết quả
      var sizeLog = "";
      for (var p = 0; p < pages.length; p++) {
        var item = pages[p];
        var s0 = sizeMM(item); // khung Transform hiện tại (trang đã clip → khung clip)
        // Không raster: phóng nguyên vector về đúng PAGE_W x PAGE_H theo khung Transform.
        var flat = dcChuanBiTrangDan(doc, item, PAGE_W, PAGE_H, canhBaoPhong, "Trang " + (p + 1));

        if (p < 4)
          sizeLog +=
            "Trang " +
            (p + 1) +
            ": " +
            s0.w.toFixed(1) +
            " x " +
            s0.h.toFixed(1) +
            " -> " +
            PAGE_W +
            " x " +
            PAGE_H +
            " mm\n";
        processed.push(flat);
      }

      // ============================================================
      //  BƯỚC 2: TÍNH CẶP IMPOSITION
      //  Tờ i (0-based): mặt trước (N-2i, 1+2i), mặt sau (2+2i, N-1-2i)
      //  (số trang 1-based). Chuyển sang index 0-based khi lấy processed.
      // ============================================================
      var sheets = []; // mỗi phần tử: {front:[L,R], back:[L,R]} - số trang 1-based
      var numSheets = N / 4;
      for (var s = 0; s < numSheets; s++) {
        var frontL = N - 2 * s; // trái mặt trước
        var frontR = 1 + 2 * s; // phải mặt trước
        var backL = 2 + 2 * s; // trái mặt sau
        var backR = N - 1 - 2 * s; // phải mặt sau
        sheets.push({ front: [frontL, frontR], back: [backL, backR] });
      }

      // ============================================================
      //  BƯỚC 3: IMPORT PON + NHÂN BẢN ARTBOARD + DÀN + CĂN GIỮA
      //  - Pon: 1 artboard 43x32.5 + nội dung. Mỗi cụm 2 trang (1 mặt) vào
      //    giữa 1 artboard. Số cụm = số mặt = numSheets * 2.
      //  - Nhân bản pon + artboard thành (số cụm) cái, xếp 2 cột x nhiều hàng:
      //    [AB1][AB2] hàng 1 (tờ 1 trước|sau), [AB3][AB4] hàng 2 (tờ 2)...
      //  - Căn giữa từng cụm 2 trang vào giữa artboard tương ứng.
      // ============================================================
      var pb = processed[0].geometricBounds; // [l,t,r,b] - KT thật 1 trang
      var pageWpt = pb[2] - pb[0];
      var pageHpt = pb[1] - pb[3];
      var gapPt = GAP * MM;
      var spreadWpt = pageWpt * 2 + gapPt; // 1 cụm 2 trang = 42.2mm

      var numFaces = numSheets * 2; // số cụm 2 trang = số mặt (mỗi tờ 2 mặt)

      // ---- Import pon ----
      var useAutoPon = true;
      if (useAutoPon) {
        var formWpt = 430 * MM;
        var formHpt = 325 * MM;
        var startL = selectionLeft;
        var startT = selectionTop;
        var MAX_ROWS = 16;
        var blockWpt = formWpt * 2;
        var abPositions = [];
        var oldAbCountAuto = doc.artboards.length;
        var artworkLayer = doc.activeLayer;
        var autoPonLayer = dcCatalogueCreateAutoPonLayer(doc);
        for (var autoFace = 0; autoFace < numFaces; autoFace++) {
          var autoSheetIndex = Math.floor(autoFace / 2);
          var autoSide = autoFace % 2;
          var autoBlock = Math.floor(autoSheetIndex / MAX_ROWS);
          var autoRow = autoSheetIndex % MAX_ROWS;
          var autoLeft = startL + autoBlock * blockWpt + autoSide * formWpt;
          var autoTop = startT - autoRow * formHpt;
          var autoRect = [
            autoLeft,
            autoTop,
            autoLeft + formWpt,
            autoTop - formHpt,
          ];
          doc.artboards.add(autoRect);
          dcCatalogueAddAutoPon(autoPonLayer, autoRect);
          abPositions.push(autoRect);
        }
        try {
          autoPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
          autoPonLayer.locked = true;
          doc.activeLayer = artworkLayer;
        } catch (autoPonError) {}
        for (var autoOld = oldAbCountAuto - 1; autoOld >= 0; autoOld--) {
          try {
            doc.artboards.remove(autoOld);
          } catch (autoOldError) {}
        }
      } else {
        var ponFile = _ponGet();
        if (!ponFile) {
          alert("Chưa chọn file pon. Dừng.");
          return;
        }

        var destName = doc.name;
        var oldAbCount = doc.artboards.length;

        // mở pon, lấy artboard + object
        var ponDoc = app.open(ponFile);
        app.activeDocument = ponDoc;
        if (ponDoc.artboards.length === 0) {
          ponDoc.close(SaveOptions.DONOTSAVECHANGES);
          alert("File pon không có artboard.");
          return;
        }
        var ponAbRect = ponDoc.artboards[0].artboardRect.slice(0); // [l,t,r,b]
        var ponAbW = ponAbRect[2] - ponAbRect[0];
        var ponAbH = ponAbRect[1] - ponAbRect[3];

        // gom object pon thành 1 group để nhân bản
        app.activeDocument = doc;
        var destLayer = doc.activeLayer;
        app.activeDocument = ponDoc;
        var ponItems = [];
        for (var pi = 0; pi < ponDoc.pageItems.length; pi++)
          ponItems.push(ponDoc.pageItems[pi]);
        var ponGroupDup = null;
        // Offset của nội dung Pon so với tâm artboard gốc. Không giả định rằng
        // bounds của dấu Pon luôn nằm đúng tâm artboard (thường chúng không đối xứng).
        var ponOffsetX = 0,
          ponOffsetY = 0;
        if (ponItems.length > 0) {
          var ponGroup = ponDoc.groupItems.add();
          for (pi = ponItems.length - 1; pi >= 0; pi--) {
            try {
              ponItems[pi].move(ponGroup, ElementPlacement.PLACEATBEGINNING);
            } catch (e) {}
          }
          // vị trí gốc group pon (để tính offset khi nhân bản)
          // Lưu offset gốc trước khi đưa group sang document đích.
          try {
            var ponGb = ponGroup.geometricBounds;
            var ponGroupCx = (ponGb[0] + ponGb[2]) / 2;
            var ponGroupCy = (ponGb[1] + ponGb[3]) / 2;
            var ponAbCx = (ponAbRect[0] + ponAbRect[2]) / 2;
            var ponAbCy = (ponAbRect[1] + ponAbRect[3]) / 2;
            ponOffsetX = ponGroupCx - ponAbCx;
            ponOffsetY = ponGroupCy - ponAbCy;
          } catch (e) {}
          try {
            ponGroupDup = ponGroup.duplicate(
              destLayer,
              ElementPlacement.PLACEATEND,
            );
          } catch (e) {}
        }
        app.activeDocument = ponDoc;
        ponDoc.close(SaveOptions.DONOTSAVECHANGES);

        // tìm lại doc gốc
        var dd = null;
        for (var di = 0; di < app.documents.length; di++)
          if (app.documents[di].name === destName) {
            dd = app.documents[di];
            break;
          }
        if (dd) {
          doc = dd;
          app.activeDocument = doc;
        }
        // Quay về đúng document đã lưu tham chiếu từ đầu, không tìm bằng tên tab.
        // Tab mới có thể trùng tên hoặc Illustrator có thể tự đổi tên Untitled.
        app.activeDocument = doc;

        // ---- Vị trí các artboard nhân bản: 2 cột x tối đa 16 hàng mỗi KHỐI ----
        //  QUAN TRỌNG: dùng vị trí THẬT của pon sau khi duplicate vào file đích,
        //  KHÔNG dùng ponAbRect (tọa độ file pon) vì khác ruler origin -> lệch.
        //  Đo tâm pon thật -> suy ra vị trí artboard đầu tiên (pon nằm giữa AB).
        var startL, startT;
        if (ponGroupDup) {
          var pgb = ponGroupDup.geometricBounds; // [l,t,r,b] pon thật trong file đích
          var ponRealCx = (pgb[0] + pgb[2]) / 2;
          var ponRealCy = (pgb[1] + pgb[3]) / 2;
          // pon nằm ở tâm artboard + offset gốc -> tâm artboard = tâm pon - offset
          var ab0Cx = ponRealCx - ponOffsetX;
          var ab0Cy = ponRealCy - ponOffsetY;
          // vị trí trái/top của artboard đầu tiên
          startL = ab0Cx - ponAbW / 2;
          startT = ab0Cy + ponAbH / 2;
        } else {
          // không có pon -> dùng tọa độ file pon (dự phòng)
          startL = ponAbRect[0];
          startT = ponAbRect[1];
        }

        var MAX_ROWS = 16;
        var blockWpt = ponAbW * 2; // 1 khối rộng = 2 cột artboard
        var abPositions = []; // [l,t,r,b] cho từng cụm (faceIndex)
        for (var fk = 0; fk < numFaces; fk++) {
          var sheetIdx = Math.floor(fk / 2); // tờ thứ mấy (0-based)
          var faceSide = fk % 2; // 0 = trước (cột trái), 1 = sau (cột phải)
          var blockNo = Math.floor(sheetIdx / MAX_ROWS); // khối thứ mấy
          var rowInBlock = sheetIdx % MAX_ROWS; // hàng trong khối
          var l = startL + blockNo * blockWpt + faceSide * ponAbW;
          var t = startT - rowInBlock * ponAbH;
          abPositions.push([l, t, l + ponAbW, t - ponAbH]);
        }

        // ---- Tạo artboard + nhân bản pon vào từng artboard ----
        //  artboard gốc (index 0 của doc) tạm để, ta thêm mới rồi xóa cũ sau.
        //  Với mỗi cụm: thêm artboard tại abPositions[k], nhân bản pon vào giữa AB.
        var ponGroups = []; // group pon đã nhân bản cho từng artboard
        for (var k = 0; k < numFaces; k++) {
          var pos = abPositions[k];
          // thêm artboard
          try {
            doc.artboards.add(pos);
          } catch (e) {}
          // nhân bản pon vào từng artboard, giữ đúng offset gốc của pon so với AB
          if (ponGroupDup) {
            var g;
            try {
              g = ponGroupDup.duplicate(
                doc.activeLayer,
                ElementPlacement.PLACEATEND,
              );
              var gb = g.geometricBounds;
              var gcx = (gb[0] + gb[2]) / 2,
                gcy = (gb[1] + gb[3]) / 2;
              var acx = (pos[0] + pos[2]) / 2,
                acy = (pos[1] + pos[3]) / 2;
              // đặt tâm pon = tâm artboard + offset gốc (giữ nội dung không đối xứng đúng chỗ)
              g.translate(acx + ponOffsetX - gcx, acy + ponOffsetY - gcy);
              ponGroups.push(g);
            } catch (e) {}
          }
        }
        // xóa pon gốc (bản duplicate đầu) + artboard cũ
        try {
          if (ponGroupDup) ponGroupDup.remove();
        } catch (e) {}
        // xóa các artboard cũ (index 0..oldAbCount-1)
        if (doc.artboards.length > numFaces) {
          for (var a2 = oldAbCount - 1; a2 >= 0; a2--) {
            try {
              doc.artboards.remove(a2);
            } catch (e) {}
          }
        }

        // ---- Dàn trang vào giữa từng artboard (cụm 2 trang / artboard) ----
        //  Thứ tự cụm (mặt): tờ 0 trước = AB0, tờ 0 sau = AB1, tờ 1 trước = AB2...
        //  faces[k] = cặp [L,R] trang của cụm k.
      }
      var faces = [];
      for (var sf = 0; sf < numSheets; sf++) {
        faces.push(sheets[sf].front); // mặt trước
        faces.push(sheets[sf].back); // mặt sau
      }

      // đặt 1 cụm 2 trang vào giữa artboard abPositions[k]
      function placeFaceCentered(pair, pos) {
        var leftItem = processed[pair[0] - 1];
        var rightItem = processed[pair[1] - 1];
        var acx = (pos[0] + pos[2]) / 2,
          acy = (pos[1] + pos[3]) / 2;
        // cụm 2 trang rộng spreadWpt, cao pageHpt -> căn giữa artboard
        // trang trái tâm tại acx - spreadWpt/2 + pageWpt/2
        var cxL = acx - spreadWpt / 2 + pageWpt / 2;
        var cxR = acx - spreadWpt / 2 + pageWpt + gapPt + pageWpt / 2;
        var cy = acy;
        if (leftItem) centerAt(leftItem, cxL, cy);
        if (rightItem) centerAt(rightItem, cxR, cy);
      }

      for (k = 0; k < faces.length; k++) {
        placeFaceCentered(faces[k], abPositions[k]);
      }

      // ============================================================
      //  BƯỚC CUỐI: BÓP NGANG CỤM ĐÃ DÀN (KHÔNG ĐỤNG PON/ARTBOARD)
      //  Sau khi mọi trang đã nằm đúng vị trí, co ngang hai trang quanh
      //  đúng tâm cụm hiện có. Chiều cao không đổi, khe giữa vẫn bằng 0.
      //  Cụm 1 = 422.000mm (42.200cm); cụm 2 = 421.750mm (42.175cm);
      //  cụm 3 = 421.500mm (42.150cm); ...
      //  Artboard 1-2 = 422.000mm (42.200cm); artboard 3-4 = 421.750mm
      //  (42.175cm); artboard 5-6 = 421.500mm (42.150cm); ...
      // ============================================================
      function squeezePlacedFace(pair, faceIndex) {
        var leftItem = processed[pair[0] - 1];
        var rightItem = processed[pair[1] - 1];
        if (!leftItem || !rightItem) return;

        // Ghi lại đúng tâm/vị trí dọc mà BƯỚC 3 vừa đặt.
        var leftBefore = sizeMM(leftItem);
        var rightBefore = sizeMM(rightItem);
        var faceCx = (leftBefore.b[0] + rightBefore.b[2]) / 2;
        var leftCy = (leftBefore.b[1] + leftBefore.b[3]) / 2;
        var rightCy = (rightBefore.b[1] + rightBefore.b[3]) / 2;

        // Tổng phần giảm chia đều cho 2 trang; chỉ resize trục X.
        // Hai artboard liên tiếp dùng cùng một mức bóp: 1-2, 3-4, 5-6...
        var artboardPairIndex = Math.floor(faceIndex / 2);
        var reductionPt = faceIndex * PAIR_REDUCTION * MM;
        var reductionPt = artboardPairIndex * PAIR_REDUCTION * MM;
        var targetPageWpt = pageWpt - reductionPt / 2;
        var scaleX = (targetPageWpt / pageWpt) * 100;
        try {
          leftItem.resize(scaleX, 100);
        } catch (e) {}
        try {
          rightItem.resize(scaleX, 100);
        } catch (e) {}

        // Đưa hai trang về sát nhau quanh đúng tâm cũ của cụm.
        var targetSpreadWpt = targetPageWpt * 2 + gapPt;
        var leftCx = faceCx - targetSpreadWpt / 2 + targetPageWpt / 2;
        var rightCx =
          faceCx -
          targetSpreadWpt / 2 +
          targetPageWpt +
          gapPt +
          targetPageWpt / 2;
        centerAt(leftItem, leftCx, leftCy);
        centerAt(rightItem, rightCx, rightCy);
      }

      for (k = 0; k < faces.length; k++) {
        squeezePlacedFace(faces[k], k);
      }

      app.redraw();

      // ============================================================
      //  BƯỚC GHI CHÚ: hiện bảng nhập, điền chữ vào artboard lẻ.
      //  - AB index lẻ theo NGƯỜI DÙNG đếm từ 1: AB1=bìa, AB3=ruột1, AB5=ruột2...
      //    (tức index 0-based: 0=bìa, 2=ruột1, 4=ruột2...)
      //  - Font 13, đen. Vị trí: trên cụm 2 trang 0.2cm, cách mép TRÁI bài dàn 1cm.
      // ============================================================
      function showNoteDialog() {
        var w = new Window("dialog", "Nhập ghi chú");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;

        w.add("statictext", undefined, "Ghi chú BÌA (artboard 1):");
        var edBia = w.add("edittext", undefined, "");
        edBia.characters = 40;

        w.add(
          "statictext",
          undefined,
          "Ghi chú RUỘT (tự thêm 'RUỘT 1, RUỘT 2...'):",
        );
        var edRuot = w.add("edittext", undefined, "");
        edRuot.characters = 40;

        var row = w.add("group");
        row.alignment = "right";
        var btnCancel = row.add("button", undefined, "Bỏ qua", {
          name: "cancel",
        });
        var btnOK = row.add("button", undefined, "Điền ghi chú", {
          name: "ok",
        });

        var res = null;
        btnOK.onClick = function () {
          res = { bia: edBia.text, ruot: edRuot.text };
          w.close();
        };
        btnCancel.onClick = function () {
          res = null;
          w.close();
        };
        w.show();
        return res;
      }

      // Tạo 1 text ghi chú tại vị trí: trên cụm 0.2cm, cách mép trái bài dàn 1cm.
      function addNote(text, pos) {
        if (!text) return;
        try {
          var lay = doc.activeLayer;
          var tf = lay.textFrames.add();
          tf.contents = text;
          try {
            tf.textRange.characterAttributes.size = 13;
          } catch (e) {}
          // màu đen
          try {
            var black = new CMYKColor();
            black.black = 100;
            tf.textRange.characterAttributes.fillColor = black;
          } catch (e) {
            try {
              var rgb = new RGBColor();
              rgb.red = 0;
              rgb.green = 0;
              rgb.blue = 0;
              tf.textRange.characterAttributes.fillColor = rgb;
            } catch (e2) {}
          }
          // vị trí: x = mép trái artboard + 1cm; y = mép trên cụm + 0.2cm
          //  pos = [l,t,r,b] của artboard. Cụm nằm giữa artboard.
          //  mép trên cụm = tâm artboard + pageHpt/2. Ghi chú trên đó 0.2cm.
          var acy = (pos[1] + pos[3]) / 2;
          var topCum = acy + pageHpt / 2;
          var x = pos[0] + 10 * MM; // cách mép trái 1cm
          var y = topCum + 2 * MM + 4 * MM; // trên cụm 0.2cm + nâng thêm 4mm
          tf.position = [x, y]; // [left, top] của text
        } catch (e) {}
      }

      var note = showNoteDialog();
      if (note) {
        // điền vào các artboard index chẵn 0-based (0=bìa, 2=ruột1, 4=ruột2...)
        var ruotNo = 0;
        for (var ab = 0; ab < abPositions.length; ab += 2) {
          var pos = abPositions[ab];
          if (ab === 0) {
            addNote(note.bia, pos); // bìa
          } else {
            ruotNo++;
            var t = "RUỘT " + ruotNo + (note.ruot ? " " + note.ruot : "");
            addNote(t, pos);
          }
        }
        app.redraw();
      }
    })();
    return "OK: Đã chạy dàn catalogue A4." + dcCauCanhBaoPhong(canhBaoPhong);
  } catch (e) {
    return "ERR: catalogue A4: " + e.toString();
  }
}

function dcRunCatalogueA5() {
  try {
    // ============================================================
    //  TEST: Dàn trang Catalogue (imposition sách đóng gáy giữa)
    //  Chạy riêng để test, CHƯA tích hợp panel.
    //
    //  Cách dùng:
    //   1. Mở file có các trang catalogue (mỗi trang 1 object/group).
    //   2. Chọn N object theo THỨ TỰ z-order = trang 1, 2, 3...
    //      (N phải là bội số của 4).
    //   3. File > Scripts > chạy script này.
    //
    //  Xử lý mỗi trang: raster (nếu chưa phẳng) -> clip A4 (21x29.7cm)
    //   -> phóng to 21.1x29.9cm.
    //  Dàn: mỗi tờ 2 trang A4 nằm ngang. Cặp trang theo công thức
    //   imposition: tờ i mặt trước (N-2i, 1+2i), mặt sau (2+2i, N-1-2i).
    // ============================================================

    (function () {
      var MM = 2.834645669; // số pt trên 1 mm

      // Kích thước trang
      var A4_W = 210.0,
        A4_H = 297.0; // mm - (không dùng cho A5)
      // A5 DỌC: rộng 149.5, cao 211 (trang nguồn được chọn theo chiều dọc).
      // Dàn 2 cột x 2 hàng sẽ thành cụm 299 x 422mm, vừa Pon A5 dọc.
      var PAGE_W = 149.5,
        PAGE_H = 211.0; // mm - 1 trang A5 sau phóng to (dọc)
      // Chỉ dùng ở BƯỚC CUỐI, sau khi dàn xong: giảm chiều ngang cụm theo từng cặp artboard.
      var PAIR_REDUCTION = 0.25; // mm cho mỗi cụm tiếp theo (= 0.025cm)
      var GAP = 0; // mm - khe giữa 2 trang trên 1 tờ (0 = sát nhau)

      // ---- Cấu hình pon (nhớ đường dẫn 1 lần, như decal) ----
      function _ponMemoFile() {
        return new File(Folder.userData + "/dan_catalogue_pon_A5.txt");
      }
      function _ponRead() {
        var f = _ponMemoFile();
        if (f.exists) {
          f.encoding = "UTF-8";
          f.open("r");
          var t = f.read();
          f.close();
          t = t.replace(/^\s+|\s+$/g, "");
          if (t && t.charAt(0) !== "#") return t;
        }
        return null;
      }
      function _ponWrite(path) {
        var f = _ponMemoFile();
        try {
          f.encoding = "UTF-8";
          f.open("w");
          f.write(path);
          f.close();
        } catch (e) {}
      }
      function _ponGet() {
        var saved = _ponRead();
        if (saved) {
          var f = new File(saved);
          if (f.exists) return f;
        }
        var chosen = File.openDialog(
          "Chọn file pon catalogue A5 (.ai) - chỉ hỏi 1 lần",
          "*.ai",
        );
        if (chosen && chosen.exists) {
          _ponWrite(chosen.fsName);
          return chosen;
        }
        return null;
      }

      if (app.documents.length === 0) {
        alert("Chưa mở tài liệu.");
        return;
      }
      var doc = app.activeDocument;
      var sel = doc.selection;
      if (!sel || sel.length === 0) {
        alert("Chưa chọn object nào.");
        return;
      }

      var N = sel.length;
      if (N % 4 !== 0) {
        alert("Số trang phải là BỘI SỐ CỦA 4.\nĐang chọn: " + N + " trang.");
        return;
      }

      // ---- Gom object và sắp theo VỊ TRÍ (trái→phải, trên→dưới) ----
      //  Vì các trang catalogue xếp thành hàng, sắp theo vị trí là đúng thứ tự đọc.
      //  Tránh dùng zOrderPosition (lỗi 1200 khi khác layer).
      var pages = [];
      // Khung bao của đúng các object được chọn. Đây là vùng giới hạn dàn,
      // hoàn toàn không liên quan đến vùng làm việc của tài liệu.
      var selectionLeft = null,
        selectionTop = null,
        selectionRight = null,
        selectionBottom = null;
      for (var i = 0; i < sel.length; i++) {
        var it = sel[i];
        var b;
        try {
          b = it.visibleBounds;
        } catch (e) {
          b = it.geometricBounds;
        }
        pages.push({ item: it, left: b[0], top: b[1] });
        if (selectionLeft === null) {
          selectionLeft = b[0];
          selectionTop = b[1];
          selectionRight = b[2];
          selectionBottom = b[3];
        } else {
          selectionLeft = Math.min(selectionLeft, b[0]);
          selectionTop = Math.max(selectionTop, b[1]);
          selectionRight = Math.max(selectionRight, b[2]);
          selectionBottom = Math.min(selectionBottom, b[3]);
        }
      }
      // gom theo hàng: sắp theo top giảm dần (trên xuống), trong hàng sắp left tăng
      pages.sort(function (a, b) {
        var dy = b.top - a.top; // top lớn = ở trên = trước
        if (Math.abs(dy) > 50 * MM) return dy; // khác hàng (>5cm) -> theo hàng
        return a.left - b.left; // cùng hàng -> trái sang phải
      });
      // rút item ra
      var pageItems = [];
      for (i = 0; i < pages.length; i++) pageItems.push(pages[i].item);
      pages = pageItems; // pages[0] = trang 1

      // ============================================================
      //  HÀM PHỤ TRỢ
      // ============================================================

      function sizeMM(item) {
        // Khung Transform (trang đã clip → khung clip; group → khung group), dự phòng geometricBounds.
        var g = dcKhungHoacBounds(item);
        if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] };
        return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
      }



      // Rasterize object (làm phẳng) ở 500ppi

      // Kiểm object đã "phẳng" chưa (là 1 RasterItem hoặc PlacedItem)
      function isFlat(item) {
        try {
          var t = item.typename;
          return t === "RasterItem" || t === "PlacedItem";
        } catch (e) {
          return false;
        }
      }

      // Clip object về đúng khung rect [l,t,r,b] cho trước (như card autoClip).
      function clipToRect(item, rect) {
        var lay = item.layer;
        // rectangle(top, left, width, height)
        var w = rect[2] - rect[0],
          h = rect[1] - rect[3];
        var r = lay.pathItems.rectangle(rect[1], rect[0], w, h);
        var grp = lay.groupItems.add();
        r.move(grp, ElementPlacement.PLACEATBEGINNING);
        item.move(grp, ElementPlacement.PLACEATEND);
        r.clipping = true;
        grp.clipped = true;
        return grp;
      }

      // Đặt tâm object vào (cxPt, cyPt) theo VISIBLE bounds
      function centerAt(item, cxPt, cyPt) {
        var s = sizeMM(item);
        var curCx = (s.b[0] + s.b[2]) / 2,
          curCy = (s.b[1] + s.b[3]) / 2;
        item.translate(cxPt - curCx, cyPt - curCy);
      }

      // ============================================================
      //  BƯỚC 1: XỬ LÝ TỪNG TRANG (làm như card: raster + clip, KHÔNG resize)
      //  Object đã đúng kích thước (đã clip sẵn). Chỉ cần:
      //   1. Raster (làm phẳng thành hình).
      //   2. Clip lại về đúng khung của nó (như card).
      //  KHÔNG bóp/resize -> không méo.
      // ============================================================
      var processed = [];
      var canhBaoPhong = []; // phóng không đều > 0,5 % → báo trong kết quả
      var sizeLog = "";
      for (var p = 0; p < pages.length; p++) {
        var item = pages[p];
        var s0 = sizeMM(item); // khung Transform hiện tại (trang đã clip → khung clip)
        // Không raster: phóng nguyên vector về đúng PAGE_W x PAGE_H theo khung Transform.
        var flat = dcChuanBiTrangDan(doc, item, PAGE_W, PAGE_H, canhBaoPhong, "Trang " + (p + 1));

        if (p < 4)
          sizeLog +=
            "Trang " +
            (p + 1) +
            ": " +
            s0.w.toFixed(1) +
            " x " +
            s0.h.toFixed(1) +
            " -> " +
            PAGE_W +
            " x " +
            PAGE_H +
            " mm (A5)\n";
        processed.push(flat);
      }

      // ============================================================
      //  BƯỚC 2: TÍNH CẶP IMPOSITION
      //  Tờ i (0-based): mặt trước (N-2i, 1+2i), mặt sau (2+2i, N-1-2i)
      //  (số trang 1-based). Chuyển sang index 0-based khi lấy processed.
      // ============================================================
      var sheets = []; // mỗi phần tử: {front:[L,R], back:[L,R]} - số trang 1-based
      var numSheets = N / 4;
      for (var s = 0; s < numSheets; s++) {
        var frontL = N - 2 * s; // trái mặt trước
        var frontR = 1 + 2 * s; // phải mặt trước
        var backL = 2 + 2 * s; // trái mặt sau
        var backR = N - 1 - 2 * s; // phải mặt sau
        sheets.push({ front: [frontL, frontR], back: [backL, backR] });
      }

      // ============================================================
      //  BƯỚC 3: IMPORT PON + NHÂN BẢN ARTBOARD + DÀN + CĂN GIỮA
      //  - Pon: 1 artboard 43x32.5 + nội dung. Mỗi cụm 2 trang (1 mặt) vào
      //    giữa 1 artboard. Số cụm = số mặt = numSheets * 2.
      //  - Nhân bản pon + artboard thành (số cụm) cái, xếp 2 cột x nhiều hàng:
      //    [AB1][AB2] hàng 1 (tờ 1 trước|sau), [AB3][AB4] hàng 2 (tờ 2)...
      //  - Căn giữa từng cụm 2 trang vào giữa artboard tương ứng.
      // ============================================================
      var pb = processed[0].geometricBounds; // [l,t,r,b] - KT thật 1 trang
      var pageWpt = pb[2] - pb[0];
      var pageHpt = pb[1] - pb[3];
      var gapPt = GAP * MM;
      var spreadWpt = pageWpt * 2 + gapPt; // 1 hàng 2 trang A5 dọc = 29.9cm

      var numFaces = numSheets * 2; // số cụm 2 trang = số mặt (mỗi tờ 2 mặt)

      // ---- Import pon ----
      var useAutoPon = true;
      if (useAutoPon) {
        // Form A5 theo file mẫu: 43 x 32.5 cm, có thêm pon giữa tờ.
        var formWpt = 430 * MM;
        var formHpt = 325 * MM;
        var startL = selectionLeft;
        var startT = selectionTop;
        var MAX_ROWS = 12;
        var blockWpt = formWpt * 2;
        var abPositions = [];
        var oldAbCountAuto = doc.artboards.length;
        var artworkLayer = doc.activeLayer;
        var autoPonLayer = dcCatalogueCreateAutoPonLayer(doc);
        for (var autoFace = 0; autoFace < numFaces; autoFace++) {
          var autoSheetIndex = Math.floor(autoFace / 2);
          var autoSide = autoFace % 2;
          var autoBlock = Math.floor(autoSheetIndex / MAX_ROWS);
          var autoRow = autoSheetIndex % MAX_ROWS;
          var autoLeft = startL + autoBlock * blockWpt + autoSide * formWpt;
          var autoTop = startT - autoRow * formHpt;
          var autoRect = [
            autoLeft,
            autoTop,
            autoLeft + formWpt,
            autoTop - formHpt,
          ];
          doc.artboards.add(autoRect);
          dcCatalogueAddAutoPonA5(autoPonLayer, autoRect);
          abPositions.push(autoRect);
        }
        try {
          autoPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
          autoPonLayer.locked = true;
          doc.activeLayer = artworkLayer;
        } catch (autoPonError) {}
        for (var autoOld = oldAbCountAuto - 1; autoOld >= 0; autoOld--) {
          try {
            doc.artboards.remove(autoOld);
          } catch (autoOldError) {}
        }
      } else {
        var ponFile = _ponGet();
        if (!ponFile) {
          alert("Chưa chọn file pon. Dừng.");
          return;
        }

        var destName = doc.name;
        var oldAbCount = doc.artboards.length;

        // mở pon, lấy artboard + object
        var ponDoc = app.open(ponFile);
        app.activeDocument = ponDoc;
        if (ponDoc.artboards.length === 0) {
          ponDoc.close(SaveOptions.DONOTSAVECHANGES);
          alert("File pon không có artboard.");
          return;
        }
        var ponAbRect = ponDoc.artboards[0].artboardRect.slice(0); // [l,t,r,b]
        var ponAbW = ponAbRect[2] - ponAbRect[0];
        var ponAbH = ponAbRect[1] - ponAbRect[3];

        // gom object pon thành 1 group để nhân bản
        app.activeDocument = doc;
        var destLayer = doc.activeLayer;
        app.activeDocument = ponDoc;
        var ponItems = [];
        for (var pi = 0; pi < ponDoc.pageItems.length; pi++)
          ponItems.push(ponDoc.pageItems[pi]);
        var ponGroupDup = null;
        // Offset của nội dung Pon so với tâm artboard gốc. Không giả định rằng
        // bounds của dấu Pon luôn nằm đúng tâm artboard (thường chúng không đối xứng).
        var ponOffsetX = 0,
          ponOffsetY = 0;
        if (ponItems.length > 0) {
          var ponGroup = ponDoc.groupItems.add();
          for (pi = ponItems.length - 1; pi >= 0; pi--) {
            try {
              ponItems[pi].move(ponGroup, ElementPlacement.PLACEATBEGINNING);
            } catch (e) {}
          }
          // vị trí gốc group pon (để tính offset khi nhân bản)
          // Lưu offset gốc trước khi đưa group sang document đích.
          try {
            var ponGb = ponGroup.geometricBounds;
            var ponGroupCx = (ponGb[0] + ponGb[2]) / 2;
            var ponGroupCy = (ponGb[1] + ponGb[3]) / 2;
            var ponAbCx = (ponAbRect[0] + ponAbRect[2]) / 2;
            var ponAbCy = (ponAbRect[1] + ponAbRect[3]) / 2;
            ponOffsetX = ponGroupCx - ponAbCx;
            ponOffsetY = ponGroupCy - ponAbCy;
          } catch (e) {}
          try {
            ponGroupDup = ponGroup.duplicate(
              destLayer,
              ElementPlacement.PLACEATEND,
            );
          } catch (e) {}
        }
        app.activeDocument = ponDoc;
        ponDoc.close(SaveOptions.DONOTSAVECHANGES);

        // tìm lại doc gốc
        var dd = null;
        for (var di = 0; di < app.documents.length; di++)
          if (app.documents[di].name === destName) {
            dd = app.documents[di];
            break;
          }
        if (dd) {
          doc = dd;
          app.activeDocument = doc;
        }
        // Quay về đúng document đã lưu tham chiếu từ đầu, không tìm bằng tên tab.
        // Tab mới có thể trùng tên hoặc Illustrator có thể tự đổi tên Untitled.
        app.activeDocument = doc;

        // ---- Vị trí các artboard nhân bản: 2 cột x tối đa 16 hàng mỗi KHỐI ----
        //  QUAN TRỌNG: dùng vị trí THẬT của pon sau khi duplicate vào file đích,
        //  KHÔNG dùng ponAbRect (tọa độ file pon) vì khác ruler origin -> lệch.
        //  Đo tâm pon thật -> suy ra vị trí artboard đầu tiên (pon nằm giữa AB).
        var startL, startT;
        if (ponGroupDup) {
          var pgb = ponGroupDup.geometricBounds; // [l,t,r,b] pon thật trong file đích
          var ponRealCx = (pgb[0] + pgb[2]) / 2;
          var ponRealCy = (pgb[1] + pgb[3]) / 2;
          // pon nằm ở tâm artboard + offset gốc -> tâm artboard = tâm pon - offset
          var ab0Cx = ponRealCx - ponOffsetX;
          var ab0Cy = ponRealCy - ponOffsetY;
          // vị trí trái/top của artboard đầu tiên
          startL = ab0Cx - ponAbW / 2;
          startT = ab0Cy + ponAbH / 2;
        } else {
          // không có pon -> dùng tọa độ file pon (dự phòng)
          startL = ponAbRect[0];
          startT = ponAbRect[1];
        }

        var MAX_ROWS = 12; // A5: cum cao 2 hang -> 1 cot chi 12 dong
        var blockWpt = ponAbW * 2; // 1 khối rộng = 2 cột artboard
        var abPositions = []; // [l,t,r,b] cho từng cụm (faceIndex)
        for (var fk = 0; fk < numFaces; fk++) {
          var sheetIdx = Math.floor(fk / 2); // tờ thứ mấy (0-based)
          var faceSide = fk % 2; // 0 = trước (cột trái), 1 = sau (cột phải)
          var blockNo = Math.floor(sheetIdx / MAX_ROWS); // khối thứ mấy
          var rowInBlock = sheetIdx % MAX_ROWS; // hàng trong khối
          var l = startL + blockNo * blockWpt + faceSide * ponAbW;
          var t = startT - rowInBlock * ponAbH;
          abPositions.push([l, t, l + ponAbW, t - ponAbH]);
        }

        // ---- Tạo artboard + nhân bản pon vào từng artboard ----
        //  artboard gốc (index 0 của doc) tạm để, ta thêm mới rồi xóa cũ sau.
        //  Với mỗi cụm: thêm artboard tại abPositions[k], nhân bản pon vào giữa AB.
        var ponGroups = []; // group pon đã nhân bản cho từng artboard
        for (var k = 0; k < numFaces; k++) {
          var pos = abPositions[k];
          // thêm artboard
          try {
            doc.artboards.add(pos);
          } catch (e) {}
          // nhân bản pon vào từng artboard, giữ đúng offset gốc của pon so với AB
          if (ponGroupDup) {
            var g;
            try {
              g = ponGroupDup.duplicate(
                doc.activeLayer,
                ElementPlacement.PLACEATEND,
              );
              var gb = g.geometricBounds;
              var gcx = (gb[0] + gb[2]) / 2,
                gcy = (gb[1] + gb[3]) / 2;
              var acx = (pos[0] + pos[2]) / 2,
                acy = (pos[1] + pos[3]) / 2;
              // đặt tâm pon = tâm artboard + offset gốc (giữ nội dung không đối xứng đúng chỗ)
              g.translate(acx + ponOffsetX - gcx, acy + ponOffsetY - gcy);
              ponGroups.push(g);
            } catch (e) {}
          }
        }
        // xóa pon gốc (bản duplicate đầu) + artboard cũ
        try {
          if (ponGroupDup) ponGroupDup.remove();
        } catch (e) {}
        // xóa các artboard cũ (index 0..oldAbCount-1)
        if (doc.artboards.length > numFaces) {
          for (var a2 = oldAbCount - 1; a2 >= 0; a2--) {
            try {
              doc.artboards.remove(a2);
            } catch (e) {}
          }
        }
      }
      // ---- Dàn trang vào giữa từng artboard (cụm 2 trang / artboard) ----
      //  Thứ tự cụm (mặt): tờ 0 trước = AB0, tờ 0 sau = AB1, tờ 1 trước = AB2...
      //  faces[k] = cặp [L,R] trang của cụm k.
      var faces = [];
      for (var sf = 0; sf < numSheets; sf++) {
        faces.push(sheets[sf].front); // mặt trước
        faces.push(sheets[sf].back); // mặt sau
      }

      // đặt 1 cụm A5 dọc vào artboard: 2 trang HÀNG TRÊN + copy y hệt HÀNG DƯỚI,
      //  rồi GOM cả 4 trang thành 1 group (để bóp chiều cao sau). Trả về group.
      function placeFaceCentered(pair, pos) {
        var leftItem = processed[pair[0] - 1];
        var rightItem = processed[pair[1] - 1];
        var acx = (pos[0] + pos[2]) / 2,
          acy = (pos[1] + pos[3]) / 2;
        var cxL = acx - spreadWpt / 2 + pageWpt / 2;
        var cxR = acx - spreadWpt / 2 + pageWpt + gapPt + pageWpt / 2;
        var cyTop = acy + pageHpt / 2;
        var cyBot = acy - pageHpt / 2;

        var members = [];
        // hàng trên = bản gốc
        if (leftItem) {
          centerAt(leftItem, cxL, cyTop);
          members.push(leftItem);
        }
        if (rightItem) {
          centerAt(rightItem, cxR, cyTop);
          members.push(rightItem);
        }
        // hàng dưới = copy y hệt
        if (leftItem) {
          try {
            var ld = leftItem.duplicate(
              leftItem.layer,
              ElementPlacement.PLACEATEND,
            );
            centerAt(ld, cxL, cyBot);
            members.push(ld);
          } catch (e) {}
        }
        if (rightItem) {
          try {
            var rd = rightItem.duplicate(
              rightItem.layer,
              ElementPlacement.PLACEATEND,
            );
            centerAt(rd, cxR, cyBot);
            members.push(rd);
          } catch (e) {}
        }
        // gom 4 trang thành 1 group
        var grp = null;
        try {
          grp = artworkLayer.groupItems.add();
          for (var mi = 0; mi < members.length; mi++) {
            try {
              members[mi].move(grp, ElementPlacement.PLACEATEND);
            } catch (e) {}
          }
        } catch (e) {}
        return grp;
      }

      var faceGroups = []; // group 4 trang của từng cụm
      for (k = 0; k < faces.length; k++) {
        faceGroups[k] = placeFaceCentered(faces[k], abPositions[k]);
      }

      // ============================================================
      //  BƯỚC CUỐI (A5): BÓP CHIỀU NGANG cụm (KHÔNG đụng pon/artboard).
      //  Cụm rộng 29.9cm. Cặp artboard 1-2, 3-4... cùng mức giảm.
      //  Cụm 1-2 = 29.9cm; cụm 3-4 = 29.875cm; cụm 5-6 = 29.85cm...
      //  (giảm PAIR_REDUCTION mm mỗi cặp). Cao 42.2cm giữ nguyên.
      // ============================================================
      function squeezeGroupWidth(grp, faceIndex) {
        if (!grp) return;
        var b = grp.geometricBounds; // [l,t,r,b]
        var curW = b[2] - b[0];
        var cx = (b[0] + b[2]) / 2,
          cy = (b[1] + b[3]) / 2;
        // mức giảm theo cặp artboard (1-2, 3-4...)
        var pairIndex = Math.floor(faceIndex / 2);
        var reductionPt = pairIndex * PAIR_REDUCTION * MM;
        var targetW = curW - reductionPt;
        var scaleX = (targetW / curW) * 100;
        try {
          grp.resize(scaleX, 100);
        } catch (e) {} // chỉ co chiều ngang (X), cao giữ nguyên
        // giữ tâm cụm không đổi
        var b2 = grp.geometricBounds;
        var cx2 = (b2[0] + b2[2]) / 2,
          cy2 = (b2[1] + b2[3]) / 2;
        try {
          grp.translate(cx - cx2, cy - cy2);
        } catch (e) {}
      }

      for (k = 0; k < faceGroups.length; k++) {
        squeezeGroupWidth(faceGroups[k], k);
      }

      app.redraw();

      // ============================================================
      //  BƯỚC GHI CHÚ: hiện bảng nhập, điền chữ vào artboard lẻ.
      //  - AB index lẻ theo NGƯỜI DÙNG đếm từ 1: AB1=bìa, AB3=ruột1, AB5=ruột2...
      //    (tức index 0-based: 0=bìa, 2=ruột1, 4=ruột2...)
      //  - Font 13, đen. Vị trí: trên cụm 2 trang 0.2cm, cách mép TRÁI bài dàn 1cm.
      // ============================================================
      function showNoteDialog() {
        var w = new Window("dialog", "Nhập ghi chú");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;

        w.add("statictext", undefined, "Ghi chú BÌA (artboard 1):");
        var edBia = w.add("edittext", undefined, "");
        edBia.characters = 40;

        w.add(
          "statictext",
          undefined,
          "Ghi chú RUỘT (tự thêm 'RUỘT 1, RUỘT 2...'):",
        );
        var edRuot = w.add("edittext", undefined, "");
        edRuot.characters = 40;

        var row = w.add("group");
        row.alignment = "right";
        var btnCancel = row.add("button", undefined, "Bỏ qua", {
          name: "cancel",
        });
        var btnOK = row.add("button", undefined, "Điền ghi chú", {
          name: "ok",
        });

        var res = null;
        btnOK.onClick = function () {
          res = { bia: edBia.text, ruot: edRuot.text };
          w.close();
        };
        btnCancel.onClick = function () {
          res = null;
          w.close();
        };
        w.show();
        return res;
      }

      // Tạo ghi chú dọc: bên phải cụm 2mm, từ mép trên cụm đi xuống 1cm.
      function addNote(text, pos, faceIndex) {
        if (!text) return;
        try {
          var lay = doc.activeLayer;
          var tf = lay.textFrames.add();
          tf.contents = text;
          try {
            tf.textRange.characterAttributes.size = 13;
          } catch (e) {}
          // màu đen
          try {
            var black = new CMYKColor();
            black.black = 100;
            tf.textRange.characterAttributes.fillColor = black;
          } catch (e) {
            try {
              var rgb = new RGBColor();
              rgb.red = 0;
              rgb.green = 0;
              rgb.blue = 0;
              tf.textRange.characterAttributes.fillColor = rgb;
            } catch (e2) {}
          }
          // A5: ghi chú BÊN PHẢI cụm +2mm, từ mép trên cụm đi xuống 1cm, chữ dọc.
          //  Cụm A5 dọc cao 2*pageHpt (42.2), rộng spreadWpt (29.9), nằm giữa artboard.
          var acx = (pos[0] + pos[2]) / 2,
            acy = (pos[1] + pos[3]) / 2;
          var cumH = pageHpt * 2; // chiều cao cụm A5 dọc = 42.2cm
          var pairIndex = Math.floor(faceIndex / 2);
          var squeezedSpreadWpt = spreadWpt - pairIndex * PAIR_REDUCTION * MM;
          var rightCum = acx + squeezedSpreadWpt / 2; // mép phải cụm sau khi bóp ngang
          var topCum = acy + cumH / 2; // mép trên cụm
          var targetLeft = rightCum + 2 * MM; // mép trái chữ: phải cụm 2mm
          var targetTop = topCum - 10 * MM; // mép trên chữ: từ trên xuống 1cm

          // Xoay trước rồi mới đặt theo bounds thực. Nếu đặt trước rồi xoay,
          // Illustrator xoay quanh điểm neo và làm chữ văng sang phải/lên trên.
          tf.position = [0, 0];
          try {
            tf.rotate(-90);
          } catch (e) {}
          var tb = tf.visibleBounds;
          tf.translate(targetLeft - tb[0], targetTop - tb[1]);
        } catch (e) {}
      }

      var note = showNoteDialog();
      if (note) {
        // điền vào các artboard index chẵn 0-based (0=bìa, 2=ruột1, 4=ruột2...)
        var ruotNo = 0;
        for (var ab = 0; ab < abPositions.length; ab += 2) {
          var pos = abPositions[ab];
          if (ab === 0) {
            addNote(note.bia, pos, ab); // bìa
          } else {
            ruotNo++;
            var t = "RUỘT " + ruotNo + (note.ruot ? " " + note.ruot : "");
            addNote(t, pos, ab);
          }
        }
        app.redraw();
      }
    })();
    return "OK: Đã chạy dàn catalogue A5." + dcCauCanhBaoPhong(canhBaoPhong);
  } catch (e) {
    return "ERR: catalogue A5: " + e.toString();
  }
}

// ============================================================
//  CATALOGUE KHỔ TÙY CHỈNH kiểu A4 (nhỏ hơn A4). 1 file = 1 cuốn.
//  Nhập kích thước đích (cm), dàn giống A4. Nhớ pon theo từng khổ.
// ============================================================
function dcRunCatalogueCustom(wCm, hCm) {
  try {
    // ============================================================
    //  CATALOGUE KHỔ TÙY CHỈNH (nhỏ hơn A4). Giống A4, chỉ khác kích thước.
    //  Kích thước đích lấy từ tham số panel (wCm, hCm - cm). Nếu không có
    //  tham số hợp lệ thì mở dialog nhập (để chạy được khi test file lẻ).
    // ============================================================

    (function (wCm, hCm) {
      var MM = 2.834645669; // số pt trên 1 mm

      // ---- BẢNG NHẬP KÍCH THƯỚC ĐÍCH (cm) - chỉ dùng khi không có tham số ----
      function showSizeDialog() {
        var w = new Window("dialog", "Kích thước trang đích (cm)");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;

        w.add(
          "statictext",
          undefined,
          "Nhập kích thước MỖI trang SAU khi phóng to (cm).",
        );
        w.add(
          "statictext",
          undefined,
          "Ví dụ: trang gốc 14.7 x 26.7 -> nhập 14.9 x 26.9",
        );

        var rowW = w.add("group");
        rowW.add("statictext", undefined, "Rộng (cm):");
        var edW = rowW.add("edittext", undefined, "");
        edW.characters = 8;

        var rowH = w.add("group");
        rowH.add("statictext", undefined, "Cao  (cm):");
        var edH = rowH.add("edittext", undefined, "");
        edH.characters = 8;

        var row = w.add("group");
        row.alignment = "right";
        var btnCancel = row.add("button", undefined, "Bỏ qua", {
          name: "cancel",
        });
        var btnOK = row.add("button", undefined, "Dàn", { name: "ok" });

        var res = null;
        btnOK.onClick = function () {
          var cw = parseFloat(String(edW.text).replace(",", "."));
          var ch = parseFloat(String(edH.text).replace(",", "."));
          if (isNaN(cw) || isNaN(ch) || cw <= 0 || ch <= 0) {
            alert("Kích thước không hợp lệ. Nhập số > 0 (ví dụ 14.9).");
            return;
          }
          // cm -> mm
          res = { w: cw * 10, h: ch * 10 };
          w.close();
        };
        btnCancel.onClick = function () {
          res = null;
          w.close();
        };
        w.show();
        return res;
      }

      // Ưu tiên tham số từ panel; không hợp lệ thì mở dialog.
      var _sizeInput = null;
      var _pw = parseFloat(String(wCm).replace(",", "."));
      var _ph = parseFloat(String(hCm).replace(",", "."));
      if (!isNaN(_pw) && !isNaN(_ph) && _pw > 0 && _ph > 0) {
        _sizeInput = { w: _pw * 10, h: _ph * 10 }; // cm -> mm
      } else {
        _sizeInput = showSizeDialog();
      }
      if (!_sizeInput) {
        return;
      } // bỏ qua

      // Kích thước trang sau khi phóng to (mm)
      var PAGE_W = _sizeInput.w;
      var PAGE_H = _sizeInput.h;

      // Chỉ dùng ở BƯỚC CUỐI: giảm tổng ngang của mỗi cụm 2 trang.
      var PAIR_REDUCTION = 0.25; // mm cho mỗi cụm tiếp theo (= 0.025cm)
      var GAP = 0; // mm - khe giữa 2 trang trên 1 tờ

      // ---- Cấu hình pon: NHỚ THEO TỪNG KÍCH THƯỚC ----
      //  Mỗi khổ (rộng x cao) nhớ 1 file pon riêng. Đã làm khổ này rồi thì
      //  KHÔNG hỏi link lại; khổ mới -> hỏi 1 lần rồi nhớ luôn.
      //  Lưu trong 1 file, mỗi dòng: "rongxcao<TAB>duong_dan" (TAB separator).
      //  Key kích thước = làm tròn 0.1mm để khớp ổn định.
      function _ponMemoFile() {
        return new File(Folder.userData + "/dan_catalogue_pon_custom.txt");
      }
      function _sizeKey() {
        // dùng PAGE_W/PAGE_H (mm) làm khóa, ví dụ "149.0x269.0"
        return (
          Math.round(PAGE_W * 10) / 10 + "x" + Math.round(PAGE_H * 10) / 10
        );
      }
      // Đọc toàn bộ bảng nhớ -> mảng { key, path }
      function _ponReadAll() {
        var list = [];
        var f = _ponMemoFile();
        if (f.exists) {
          f.encoding = "UTF-8";
          f.open("r");
          var all = f.read();
          f.close();
          var lines = all.split(/\r\n|\r|\n/);
          for (var i = 0; i < lines.length; i++) {
            var ln = lines[i];
            if (!ln || ln.charAt(0) === "#") continue;
            var tab = ln.indexOf("\t");
            if (tab < 0) continue;
            var key = ln.substring(0, tab).replace(/^\s+|\s+$/g, "");
            var pth = ln.substring(tab + 1).replace(/^\s+|\s+$/g, "");
            if (key && pth) list.push({ key: key, path: pth });
          }
        }
        return list;
      }
      // Lấy path đã nhớ cho kích thước hiện tại (hoặc null)
      function _ponReadForSize() {
        var list = _ponReadAll();
        var key = _sizeKey();
        for (var i = 0; i < list.length; i++)
          if (list[i].key === key) return list[i].path;
        return null;
      }
      // Ghi/cập nhật path cho kích thước hiện tại (giữ nguyên các khổ khác)
      function _ponWriteForSize(path) {
        var list = _ponReadAll();
        var key = _sizeKey();
        var found = false;
        for (var i = 0; i < list.length; i++) {
          if (list[i].key === key) {
            list[i].path = path;
            found = true;
            break;
          }
        }
        if (!found) list.push({ key: key, path: path });
        var out =
          "# Bo nho pon catalogue theo kich thuoc: rongxcao<TAB>duong_dan\n";
        for (i = 0; i < list.length; i++)
          out += list[i].key + "\t" + list[i].path + "\n";
        var f = _ponMemoFile();
        try {
          f.encoding = "UTF-8";
          f.open("w");
          f.write(out);
          f.close();
        } catch (e) {}
      }
      function _ponGet() {
        // Đã từng làm khổ này -> dùng lại luôn, không hỏi.
        var saved = _ponReadForSize();
        if (saved) {
          var f = new File(saved);
          if (f.exists) return f;
        }
        // Khổ mới (hoặc file cũ đã mất) -> hỏi 1 lần rồi nhớ theo khổ.
        var chosen = File.openDialog(
          "Chọn file pon cho khổ " +
            _sizeKey() +
            " mm (.ai) - chỉ hỏi 1 lần cho khổ này",
          "*.ai",
        );
        if (chosen && chosen.exists) {
          _ponWriteForSize(chosen.fsName);
          return chosen;
        }
        return null;
      }

      if (app.documents.length === 0) {
        alert("Chưa mở tài liệu.");
        return;
      }
      var doc = app.activeDocument;
      var sel = doc.selection;
      if (!sel || sel.length === 0) {
        alert("Chưa chọn object nào.");
        return;
      }

      var N = sel.length;
      if (N % 4 !== 0) {
        alert("Số trang phải là BỘI SỐ CỦA 4.\nĐang chọn: " + N + " trang.");
        return;
      }

      // ---- Gom object và sắp theo VỊ TRÍ (trái→phải, trên→dưới) ----
      var pages = [];
      var selectionLeft = null,
        selectionTop = null,
        selectionRight = null,
        selectionBottom = null;
      for (var i = 0; i < sel.length; i++) {
        var it = sel[i];
        var b;
        try {
          b = it.visibleBounds;
        } catch (e) {
          b = it.geometricBounds;
        }
        pages.push({ item: it, left: b[0], top: b[1] });
        if (selectionLeft === null) {
          selectionLeft = b[0];
          selectionTop = b[1];
          selectionRight = b[2];
          selectionBottom = b[3];
        } else {
          selectionLeft = Math.min(selectionLeft, b[0]);
          selectionTop = Math.max(selectionTop, b[1]);
          selectionRight = Math.max(selectionRight, b[2]);
          selectionBottom = Math.min(selectionBottom, b[3]);
        }
      }
      pages.sort(function (a, b) {
        var dy = b.top - a.top;
        if (Math.abs(dy) > 50 * MM) return dy;
        return a.left - b.left;
      });
      var pageItems = [];
      for (i = 0; i < pages.length; i++) pageItems.push(pages[i].item);
      pages = pageItems; // pages[0] = trang 1

      // ============================================================
      //  HÀM PHỤ TRỢ
      // ============================================================
      function sizeMM(item) {
        // Khung Transform (trang đã clip → khung clip; group → khung group), dự phòng geometricBounds.
        var g = dcKhungHoacBounds(item);
        if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] };
        return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
      }



      function centerAt(item, cxPt, cyPt) {
        var s = sizeMM(item);
        var curCx = (s.b[0] + s.b[2]) / 2,
          curCy = (s.b[1] + s.b[3]) / 2;
        item.translate(cxPt - curCx, cyPt - curCy);
      }

      // ============================================================
      //  BƯỚC 1: XỬ LÝ TỪNG TRANG (raster + phóng về PAGE_W x PAGE_H)
      // ============================================================
      var processed = [];
      var canhBaoPhong = []; // phóng không đều > 0,5 % → báo trong kết quả
      var sizeLog = "";
      for (var p = 0; p < pages.length; p++) {
        var item = pages[p];
        var s0 = sizeMM(item); // khung Transform hiện tại (trang đã clip → khung clip)
        // Không raster: phóng nguyên vector về đúng PAGE_W x PAGE_H theo khung Transform.
        var flat = dcChuanBiTrangDan(doc, item, PAGE_W, PAGE_H, canhBaoPhong, "Trang " + (p + 1));

        if (p < 4)
          sizeLog +=
            "Trang " +
            (p + 1) +
            ": " +
            s0.w.toFixed(1) +
            " x " +
            s0.h.toFixed(1) +
            " -> " +
            PAGE_W +
            " x " +
            PAGE_H +
            " mm\n";
        processed.push(flat);
      }

      // ============================================================
      //  BƯỚC 2: TÍNH CẶP IMPOSITION
      // ============================================================
      var sheets = [];
      var numSheets = N / 4;
      for (var s = 0; s < numSheets; s++) {
        var frontL = N - 2 * s;
        var frontR = 1 + 2 * s;
        var backL = 2 + 2 * s;
        var backR = N - 1 - 2 * s;
        sheets.push({ front: [frontL, frontR], back: [backL, backR] });
      }

      // ============================================================
      //  BƯỚC 3: IMPORT PON + NHÂN BẢN ARTBOARD + DÀN + CĂN GIỮA
      // ============================================================
      var pb = processed[0].geometricBounds;
      var pageWpt = pb[2] - pb[0];
      var pageHpt = pb[1] - pb[3];
      var gapPt = GAP * MM;
      var spreadWpt = pageWpt * 2 + gapPt;

      var numFaces = numSheets * 2;

      var useAutoPon = true;
      if (useAutoPon) {
        // Pon tu ve theo cum 2 trang thuc te: ngang cach 4 mm moi ben,
        // doc cach 13 mm moi ben. Khong dung form A4 cho kho nho hon A4.
        var formWpt = spreadWpt + 8 * MM;
        var formHpt = pageHpt + 26 * MM;
        var startL = selectionLeft;
        var startT = selectionTop;
        var MAX_ROWS = 16;
        var blockWpt = formWpt * 2;
        var abPositions = [];
        var oldAbCountAuto = doc.artboards.length;
        var artworkLayer = doc.activeLayer;
        var autoPonLayer = dcCatalogueCreateAutoPonLayer(doc);
        for (var autoFace = 0; autoFace < numFaces; autoFace++) {
          var autoSheetIndex = Math.floor(autoFace / 2);
          var autoSide = autoFace % 2;
          var autoBlock = Math.floor(autoSheetIndex / MAX_ROWS);
          var autoRow = autoSheetIndex % MAX_ROWS;
          var autoLeft = startL + autoBlock * blockWpt + autoSide * formWpt;
          var autoTop = startT - autoRow * formHpt;
          var autoRect = [
            autoLeft,
            autoTop,
            autoLeft + formWpt,
            autoTop - formHpt,
          ];
          doc.artboards.add(autoRect);
          dcCatalogueAddAutoPon(autoPonLayer, autoRect);
          abPositions.push(autoRect);
        }
        try {
          autoPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
          autoPonLayer.locked = true;
          doc.activeLayer = artworkLayer;
        } catch (autoPonError) {}
        for (var autoOld = oldAbCountAuto - 1; autoOld >= 0; autoOld--) {
          try {
            doc.artboards.remove(autoOld);
          } catch (autoOldError) {}
        }
      } else {
        var ponFile = _ponGet();
        if (!ponFile) {
          alert("Chưa chọn file pon. Dừng.");
          return;
        }

        var destName = doc.name;
        var oldAbCount = doc.artboards.length;

        var ponDoc = app.open(ponFile);
        app.activeDocument = ponDoc;
        if (ponDoc.artboards.length === 0) {
          ponDoc.close(SaveOptions.DONOTSAVECHANGES);
          alert("File pon không có artboard.");
          return;
        }
        var ponAbRect = ponDoc.artboards[0].artboardRect.slice(0);
        var ponAbW = ponAbRect[2] - ponAbRect[0];
        var ponAbH = ponAbRect[1] - ponAbRect[3];

        app.activeDocument = doc;
        var destLayer = doc.activeLayer;
        app.activeDocument = ponDoc;
        var ponItems = [];
        for (var pi = 0; pi < ponDoc.pageItems.length; pi++)
          ponItems.push(ponDoc.pageItems[pi]);
        var ponGroupDup = null;
        var ponOffsetX = 0,
          ponOffsetY = 0;
        if (ponItems.length > 0) {
          var ponGroup = ponDoc.groupItems.add();
          for (pi = ponItems.length - 1; pi >= 0; pi--) {
            try {
              ponItems[pi].move(ponGroup, ElementPlacement.PLACEATBEGINNING);
            } catch (e) {}
          }
          try {
            var ponGb = ponGroup.geometricBounds;
            var ponGroupCx = (ponGb[0] + ponGb[2]) / 2;
            var ponGroupCy = (ponGb[1] + ponGb[3]) / 2;
            var ponAbCx = (ponAbRect[0] + ponAbRect[2]) / 2;
            var ponAbCy = (ponAbRect[1] + ponAbRect[3]) / 2;
            ponOffsetX = ponGroupCx - ponAbCx;
            ponOffsetY = ponGroupCy - ponAbCy;
          } catch (e) {}
          try {
            ponGroupDup = ponGroup.duplicate(
              destLayer,
              ElementPlacement.PLACEATEND,
            );
          } catch (e) {}
        }
        app.activeDocument = ponDoc;
        ponDoc.close(SaveOptions.DONOTSAVECHANGES);

        var dd = null;
        for (var di = 0; di < app.documents.length; di++)
          if (app.documents[di].name === destName) {
            dd = app.documents[di];
            break;
          }
        if (dd) {
          doc = dd;
          app.activeDocument = doc;
        }
        app.activeDocument = doc;

        var startL, startT;
        if (ponGroupDup) {
          var pgb = ponGroupDup.geometricBounds;
          var ponRealCx = (pgb[0] + pgb[2]) / 2;
          var ponRealCy = (pgb[1] + pgb[3]) / 2;
          var ab0Cx = ponRealCx - ponOffsetX;
          var ab0Cy = ponRealCy - ponOffsetY;
          startL = ab0Cx - ponAbW / 2;
          startT = ab0Cy + ponAbH / 2;
        } else {
          startL = ponAbRect[0];
          startT = ponAbRect[1];
        }

        var MAX_ROWS = 16;
        var blockWpt = ponAbW * 2;
        var abPositions = [];
        for (var fk = 0; fk < numFaces; fk++) {
          var sheetIdx = Math.floor(fk / 2);
          var faceSide = fk % 2;
          var blockNo = Math.floor(sheetIdx / MAX_ROWS);
          var rowInBlock = sheetIdx % MAX_ROWS;
          var l = startL + blockNo * blockWpt + faceSide * ponAbW;
          var t = startT - rowInBlock * ponAbH;
          abPositions.push([l, t, l + ponAbW, t - ponAbH]);
        }

        var ponGroups = [];
        for (var k = 0; k < numFaces; k++) {
          var pos = abPositions[k];
          try {
            doc.artboards.add(pos);
          } catch (e) {}
          if (ponGroupDup) {
            var g;
            try {
              g = ponGroupDup.duplicate(
                artworkLayer,
                ElementPlacement.PLACEATEND,
              );
              var gb = g.geometricBounds;
              var gcx = (gb[0] + gb[2]) / 2,
                gcy = (gb[1] + gb[3]) / 2;
              var acx = (pos[0] + pos[2]) / 2,
                acy = (pos[1] + pos[3]) / 2;
              g.translate(acx + ponOffsetX - gcx, acy + ponOffsetY - gcy);
              ponGroups.push(g);
            } catch (e) {}
          }
        }
        try {
          if (ponGroupDup) ponGroupDup.remove();
        } catch (e) {}
        if (doc.artboards.length > numFaces) {
          for (var a2 = oldAbCount - 1; a2 >= 0; a2--) {
            try {
              doc.artboards.remove(a2);
            } catch (e) {}
          }
        }
      }
      var faces = [];
      for (var sf = 0; sf < numSheets; sf++) {
        faces.push(sheets[sf].front);
        faces.push(sheets[sf].back);
      }

      function placeFaceCentered(pair, pos) {
        var leftItem = processed[pair[0] - 1];
        var rightItem = processed[pair[1] - 1];
        var acx = (pos[0] + pos[2]) / 2,
          acy = (pos[1] + pos[3]) / 2;
        var cxL = acx - spreadWpt / 2 + pageWpt / 2;
        var cxR = acx - spreadWpt / 2 + pageWpt + gapPt + pageWpt / 2;
        var cy = acy;
        if (leftItem) centerAt(leftItem, cxL, cy);
        if (rightItem) centerAt(rightItem, cxR, cy);
      }

      for (k = 0; k < faces.length; k++) {
        placeFaceCentered(faces[k], abPositions[k]);
      }

      // ============================================================
      //  BƯỚC CUỐI: BÓP NGANG CỤM ĐÃ DÀN
      // ============================================================
      function squeezePlacedFace(pair, faceIndex) {
        var leftItem = processed[pair[0] - 1];
        var rightItem = processed[pair[1] - 1];
        if (!leftItem || !rightItem) return;

        var leftBefore = sizeMM(leftItem);
        var rightBefore = sizeMM(rightItem);
        var faceCx = (leftBefore.b[0] + rightBefore.b[2]) / 2;
        var leftCy = (leftBefore.b[1] + leftBefore.b[3]) / 2;
        var rightCy = (rightBefore.b[1] + rightBefore.b[3]) / 2;

        var artboardPairIndex = Math.floor(faceIndex / 2);
        var reductionPt = artboardPairIndex * PAIR_REDUCTION * MM;
        var targetPageWpt = pageWpt - reductionPt / 2;
        var scaleX = (targetPageWpt / pageWpt) * 100;
        try {
          leftItem.resize(scaleX, 100);
        } catch (e) {}
        try {
          rightItem.resize(scaleX, 100);
        } catch (e) {}

        var targetSpreadWpt = targetPageWpt * 2 + gapPt;
        var leftCx = faceCx - targetSpreadWpt / 2 + targetPageWpt / 2;
        var rightCx =
          faceCx -
          targetSpreadWpt / 2 +
          targetPageWpt +
          gapPt +
          targetPageWpt / 2;
        centerAt(leftItem, leftCx, leftCy);
        centerAt(rightItem, rightCx, rightCy);
      }

      for (k = 0; k < faces.length; k++) {
        squeezePlacedFace(faces[k], k);
      }

      app.redraw();

      // ============================================================
      //  BƯỚC GHI CHÚ
      // ============================================================
      function showNoteDialog() {
        var w = new Window("dialog", "Nhập ghi chú");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;

        w.add("statictext", undefined, "Ghi chú BÌA (artboard 1):");
        var edBia = w.add("edittext", undefined, "");
        edBia.characters = 40;

        w.add(
          "statictext",
          undefined,
          "Ghi chú RUỘT (tự thêm 'RUOT 1, RUOT 2...'):",
        );
        var edRuot = w.add("edittext", undefined, "");
        edRuot.characters = 40;

        var row = w.add("group");
        row.alignment = "right";
        var btnCancel = row.add("button", undefined, "Bỏ qua", {
          name: "cancel",
        });
        var btnOK = row.add("button", undefined, "Điền ghi chú", {
          name: "ok",
        });

        var res = null;
        btnOK.onClick = function () {
          res = { bia: edBia.text, ruot: edRuot.text };
          w.close();
        };
        btnCancel.onClick = function () {
          res = null;
          w.close();
        };
        w.show();
        return res;
      }

      function addNote(text, pos) {
        if (!text) return;
        try {
          var lay = doc.activeLayer;
          var tf = lay.textFrames.add();
          tf.contents = text;
          try {
            tf.textRange.characterAttributes.size = 13;
          } catch (e) {}
          try {
            var black = new CMYKColor();
            black.black = 100;
            tf.textRange.characterAttributes.fillColor = black;
          } catch (e) {
            try {
              var rgb = new RGBColor();
              rgb.red = 0;
              rgb.green = 0;
              rgb.blue = 0;
              tf.textRange.characterAttributes.fillColor = rgb;
            } catch (e2) {}
          }
          var acy = (pos[1] + pos[3]) / 2;
          var topCum = acy + pageHpt / 2;
          var x = pos[0] + 10 * MM;
          var y = topCum + 2 * MM + 4 * MM;
          tf.position = [x, y];
        } catch (e) {}
      }

      var note = showNoteDialog();
      if (note) {
        var ruotNo = 0;
        for (var ab = 0; ab < abPositions.length; ab += 2) {
          var pos = abPositions[ab];
          if (ab === 0) {
            addNote(note.bia, pos);
          } else {
            ruotNo++;
            var t = "RUOT " + ruotNo + (note.ruot ? " " + note.ruot : "");
            addNote(t, pos);
          }
        }
        app.redraw();
      }
    })(wCm, hCm);
    return "OK: Đã chạy dàn catalogue khổ tùy chỉnh." + dcCauCanhBaoPhong(canhBaoPhong);
  } catch (e) {
    return "ERR: catalogue custom: " + e.toString();
  }
}

// ============================================================
//  CATALOGUE KHỔ TÙY CHỈNH kiểu A5 (2 con 1 tờ, nhỏ hơn A5).
//  Nhập kích thước 1 trang (cm), dàn giống A5. Nhớ pon theo từng khổ.
// ============================================================
function dcRunCatalogueCustomA5(wCm, hCm) {
  try {
    // ============================================================
    //  CATALOGUE KHỔ TÙY CHỈNH kiểu A5 (2 CON 1 TỜ, nhỏ hơn A5).
    //  Kích thước 1 trang lấy từ tham số panel (wCm, hCm - cm). Không có
    //  tham số hợp lệ thì mở dialog (để chạy được khi test file lẻ).
    // ============================================================

    (function (wCm, hCm) {
      var MM = 2.834645669; // số pt trên 1 mm

      // ---- BẢNG NHẬP KÍCH THƯỚC ĐÍCH (cm) - chỉ dùng khi không có tham số ----
      function showSizeDialog() {
        var w = new Window("dialog", "Kích thước 1 trang đích (cm)");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;

        w.add(
          "statictext",
          undefined,
          "Nhập kích thước MỖI 1 trang SAU khi phóng to (cm).",
        );
        w.add(
          "statictext",
          undefined,
          "Sẽ dàn 2 con 1 tờ (2 trang trên + copy xuống dưới).",
        );

        var rowW = w.add("group");
        rowW.add("statictext", undefined, "Rộng (cm):");
        var edW = rowW.add("edittext", undefined, "");
        edW.characters = 8;

        var rowH = w.add("group");
        rowH.add("statictext", undefined, "Cao  (cm):");
        var edH = rowH.add("edittext", undefined, "");
        edH.characters = 8;

        var row = w.add("group");
        row.alignment = "right";
        var btnCancel = row.add("button", undefined, "Bỏ qua", {
          name: "cancel",
        });
        var btnOK = row.add("button", undefined, "Dàn", { name: "ok" });

        var res = null;
        btnOK.onClick = function () {
          var cw = parseFloat(String(edW.text).replace(",", "."));
          var ch = parseFloat(String(edH.text).replace(",", "."));
          if (isNaN(cw) || isNaN(ch) || cw <= 0 || ch <= 0) {
            alert("Kích thước không hợp lệ. Nhập số > 0 (ví dụ 12.5).");
            return;
          }
          res = { w: cw * 10, h: ch * 10 }; // cm -> mm
          w.close();
        };
        btnCancel.onClick = function () {
          res = null;
          w.close();
        };
        w.show();
        return res;
      }

      // Ưu tiên tham số từ panel; không hợp lệ thì mở dialog.
      var _sizeInput = null;
      var _pw = parseFloat(String(wCm).replace(",", "."));
      var _ph = parseFloat(String(hCm).replace(",", "."));
      if (!isNaN(_pw) && !isNaN(_ph) && _pw > 0 && _ph > 0) {
        _sizeInput = { w: _pw * 10, h: _ph * 10 }; // cm -> mm
      } else {
        _sizeInput = showSizeDialog();
      }
      if (!_sizeInput) {
        return;
      }

      var PAGE_W = _sizeInput.w; // mm - 1 trang sau phóng to
      var PAGE_H = _sizeInput.h; // mm

      var PAIR_REDUCTION = 0.25; // mm giảm ngang mỗi cặp artboard
      var GAP = 0; // mm - khe giữa 2 trang trên 1 hàng

      // ---- Cấu hình pon: NHỚ THEO TỪNG KÍCH THƯỚC (kiểu A5) ----
      //  File nhớ riêng cho bản A5-custom, không đụng bản A4-custom.
      function _ponMemoFile() {
        return new File(Folder.userData + "/dan_catalogue_pon_custom_A5.txt");
      }
      function _sizeKey() {
        return (
          Math.round(PAGE_W * 10) / 10 + "x" + Math.round(PAGE_H * 10) / 10
        );
      }
      function _ponReadAll() {
        var list = [];
        var f = _ponMemoFile();
        if (f.exists) {
          f.encoding = "UTF-8";
          f.open("r");
          var all = f.read();
          f.close();
          var lines = all.split(/\r\n|\r|\n/);
          for (var i = 0; i < lines.length; i++) {
            var ln = lines[i];
            if (!ln || ln.charAt(0) === "#") continue;
            var tab = ln.indexOf("\t");
            if (tab < 0) continue;
            var key = ln.substring(0, tab).replace(/^\s+|\s+$/g, "");
            var pth = ln.substring(tab + 1).replace(/^\s+|\s+$/g, "");
            if (key && pth) list.push({ key: key, path: pth });
          }
        }
        return list;
      }
      function _ponReadForSize() {
        var list = _ponReadAll();
        var key = _sizeKey();
        for (var i = 0; i < list.length; i++)
          if (list[i].key === key) return list[i].path;
        return null;
      }
      function _ponWriteForSize(path) {
        var list = _ponReadAll();
        var key = _sizeKey();
        var found = false;
        for (var i = 0; i < list.length; i++) {
          if (list[i].key === key) {
            list[i].path = path;
            found = true;
            break;
          }
        }
        if (!found) list.push({ key: key, path: path });
        var out =
          "# Bo nho pon catalogue A5-custom theo kich thuoc: rongxcao<TAB>duong_dan\n";
        for (i = 0; i < list.length; i++)
          out += list[i].key + "\t" + list[i].path + "\n";
        var f = _ponMemoFile();
        try {
          f.encoding = "UTF-8";
          f.open("w");
          f.write(out);
          f.close();
        } catch (e) {}
      }
      function _ponGet() {
        var saved = _ponReadForSize();
        if (saved) {
          var f = new File(saved);
          if (f.exists) return f;
        }
        var chosen = File.openDialog(
          "Chọn file pon cho khổ " +
            _sizeKey() +
            " mm (.ai) - chỉ hỏi 1 lần cho khổ này",
          "*.ai",
        );
        if (chosen && chosen.exists) {
          _ponWriteForSize(chosen.fsName);
          return chosen;
        }
        return null;
      }

      if (app.documents.length === 0) {
        alert("Chưa mở tài liệu.");
        return;
      }
      var doc = app.activeDocument;
      var sel = doc.selection;
      if (!sel || sel.length === 0) {
        alert("Chưa chọn object nào.");
        return;
      }

      var N = sel.length;
      if (N % 4 !== 0) {
        alert("Số trang phải là BỘI SỐ CỦA 4.\nĐang chọn: " + N + " trang.");
        return;
      }

      // ---- Gom object và sắp theo VỊ TRÍ ----
      var pages = [];
      for (var i = 0; i < sel.length; i++) {
        var it = sel[i];
        var b;
        try {
          b = it.visibleBounds;
        } catch (e) {
          b = it.geometricBounds;
        }
        pages.push({ item: it, left: b[0], top: b[1] });
      }
      pages.sort(function (a, b) {
        var dy = b.top - a.top;
        if (Math.abs(dy) > 50 * MM) return dy;
        return a.left - b.left;
      });
      var pageItems = [];
      for (i = 0; i < pages.length; i++) pageItems.push(pages[i].item);
      pages = pageItems;

      // ============================================================
      //  HÀM PHỤ TRỢ (giống A4/A5)
      // ============================================================
      function sizeMM(item) {
        // Khung Transform (trang đã clip → khung clip; group → khung group), dự phòng geometricBounds.
        var g = dcKhungHoacBounds(item);
        if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] };
        return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
      }
      function centerAt(item, cxPt, cyPt) {
        var s = sizeMM(item);
        var curCx = (s.b[0] + s.b[2]) / 2,
          curCy = (s.b[1] + s.b[3]) / 2;
        item.translate(cxPt - curCx, cyPt - curCy);
      }

      // ============================================================
      //  BƯỚC 1: XỬ LÝ TỪNG TRANG (raster + phóng về PAGE_W x PAGE_H)
      // ============================================================
      var processed = [];
      var canhBaoPhong = []; // phóng không đều > 0,5 % → báo trong kết quả
      for (var p = 0; p < pages.length; p++) {
        var item = pages[p];
        var flat = dcChuanBiTrangDan(doc, item, PAGE_W, PAGE_H, canhBaoPhong, "Trang " + (p + 1)); // không raster
        processed.push(flat);
      }

      // ============================================================
      //  BƯỚC 2: TÍNH CẶP IMPOSITION
      // ============================================================
      var sheets = [];
      var numSheets = N / 4;
      for (var s = 0; s < numSheets; s++) {
        var frontL = N - 2 * s;
        var frontR = 1 + 2 * s;
        var backL = 2 + 2 * s;
        var backR = N - 1 - 2 * s;
        sheets.push({ front: [frontL, frontR], back: [backL, backR] });
      }

      // ============================================================
      //  BƯỚC 3: IMPORT PON + NHÂN BẢN ARTBOARD + DÀN + CĂN GIỮA
      // ============================================================
      var pb = processed[0].geometricBounds;
      var pageWpt = pb[2] - pb[0];
      var pageHpt = pb[1] - pb[3];
      var gapPt = GAP * MM;
      var spreadWpt = pageWpt * 2 + gapPt; // 1 hàng 2 trang

      var numFaces = numSheets * 2;

      var ponFile = _ponGet();
      if (!ponFile) {
        alert("Chưa chọn file pon. Dừng.");
        return;
      }

      var destName = doc.name;
      var oldAbCount = doc.artboards.length;

      var ponDoc = app.open(ponFile);
      app.activeDocument = ponDoc;
      if (ponDoc.artboards.length === 0) {
        ponDoc.close(SaveOptions.DONOTSAVECHANGES);
        alert("File pon không có artboard.");
        return;
      }
      var ponAbRect = ponDoc.artboards[0].artboardRect.slice(0);
      var ponAbW = ponAbRect[2] - ponAbRect[0];
      var ponAbH = ponAbRect[1] - ponAbRect[3];

      app.activeDocument = doc;
      var destLayer = doc.activeLayer;
      app.activeDocument = ponDoc;
      var ponItems = [];
      for (var pi = 0; pi < ponDoc.pageItems.length; pi++)
        ponItems.push(ponDoc.pageItems[pi]);
      var ponGroupDup = null;
      var ponOffsetX = 0,
        ponOffsetY = 0;
      if (ponItems.length > 0) {
        var ponGroup = ponDoc.groupItems.add();
        for (pi = ponItems.length - 1; pi >= 0; pi--) {
          try {
            ponItems[pi].move(ponGroup, ElementPlacement.PLACEATBEGINNING);
          } catch (e) {}
        }
        try {
          var ponGb = ponGroup.geometricBounds;
          var ponGroupCx = (ponGb[0] + ponGb[2]) / 2;
          var ponGroupCy = (ponGb[1] + ponGb[3]) / 2;
          var ponAbCx = (ponAbRect[0] + ponAbRect[2]) / 2;
          var ponAbCy = (ponAbRect[1] + ponAbRect[3]) / 2;
          ponOffsetX = ponGroupCx - ponAbCx;
          ponOffsetY = ponGroupCy - ponAbCy;
        } catch (e) {}
        try {
          ponGroupDup = ponGroup.duplicate(
            destLayer,
            ElementPlacement.PLACEATEND,
          );
        } catch (e) {}
      }
      app.activeDocument = ponDoc;
      ponDoc.close(SaveOptions.DONOTSAVECHANGES);

      var dd = null;
      for (var di = 0; di < app.documents.length; di++)
        if (app.documents[di].name === destName) {
          dd = app.documents[di];
          break;
        }
      if (dd) {
        doc = dd;
        app.activeDocument = doc;
      }
      app.activeDocument = doc;

      var startL, startT;
      if (ponGroupDup) {
        var pgb = ponGroupDup.geometricBounds;
        var ponRealCx = (pgb[0] + pgb[2]) / 2;
        var ponRealCy = (pgb[1] + pgb[3]) / 2;
        var ab0Cx = ponRealCx - ponOffsetX;
        var ab0Cy = ponRealCy - ponOffsetY;
        startL = ab0Cx - ponAbW / 2;
        startT = ab0Cy + ponAbH / 2;
      } else {
        startL = ponAbRect[0];
        startT = ponAbRect[1];
      }

      var MAX_ROWS = 12; // A5-style: cụm cao 2 hàng -> 1 cột chỉ 12 dòng
      var blockWpt = ponAbW * 2;
      var abPositions = [];
      for (var fk = 0; fk < numFaces; fk++) {
        var sheetIdx = Math.floor(fk / 2);
        var faceSide = fk % 2;
        var blockNo = Math.floor(sheetIdx / MAX_ROWS);
        var rowInBlock = sheetIdx % MAX_ROWS;
        var l = startL + blockNo * blockWpt + faceSide * ponAbW;
        var t = startT - rowInBlock * ponAbH;
        abPositions.push([l, t, l + ponAbW, t - ponAbH]);
      }

      var ponGroups = [];
      for (var k = 0; k < numFaces; k++) {
        var pos = abPositions[k];
        try {
          doc.artboards.add(pos);
        } catch (e) {}
        if (ponGroupDup) {
          var g;
          try {
            g = ponGroupDup.duplicate(
              doc.activeLayer,
              ElementPlacement.PLACEATEND,
            );
            var gb = g.geometricBounds;
            var gcx = (gb[0] + gb[2]) / 2,
              gcy = (gb[1] + gb[3]) / 2;
            var acx = (pos[0] + pos[2]) / 2,
              acy = (pos[1] + pos[3]) / 2;
            g.translate(acx + ponOffsetX - gcx, acy + ponOffsetY - gcy);
            ponGroups.push(g);
          } catch (e) {}
        }
      }
      try {
        if (ponGroupDup) ponGroupDup.remove();
      } catch (e) {}
      if (doc.artboards.length > numFaces) {
        for (var a2 = oldAbCount - 1; a2 >= 0; a2--) {
          try {
            doc.artboards.remove(a2);
          } catch (e) {}
        }
      }

      var faces = [];
      for (var sf = 0; sf < numSheets; sf++) {
        faces.push(sheets[sf].front);
        faces.push(sheets[sf].back);
      }

      // ---- DÀN 2 CON 1 TỜ: 2 trang hàng trên + copy y hệt hàng dưới, gom group ----
      function placeFaceCentered(pair, pos) {
        var leftItem = processed[pair[0] - 1];
        var rightItem = processed[pair[1] - 1];
        var acx = (pos[0] + pos[2]) / 2,
          acy = (pos[1] + pos[3]) / 2;
        var cxL = acx - spreadWpt / 2 + pageWpt / 2;
        var cxR = acx - spreadWpt / 2 + pageWpt + gapPt + pageWpt / 2;
        var cyTop = acy + pageHpt / 2;
        var cyBot = acy - pageHpt / 2;

        var members = [];
        // hàng trên = bản gốc
        if (leftItem) {
          centerAt(leftItem, cxL, cyTop);
          members.push(leftItem);
        }
        if (rightItem) {
          centerAt(rightItem, cxR, cyTop);
          members.push(rightItem);
        }
        // hàng dưới = copy y hệt
        if (leftItem) {
          try {
            var ld = leftItem.duplicate(
              leftItem.layer,
              ElementPlacement.PLACEATEND,
            );
            centerAt(ld, cxL, cyBot);
            members.push(ld);
          } catch (e) {}
        }
        if (rightItem) {
          try {
            var rd = rightItem.duplicate(
              rightItem.layer,
              ElementPlacement.PLACEATEND,
            );
            centerAt(rd, cxR, cyBot);
            members.push(rd);
          } catch (e) {}
        }
        // gom 4 trang thành 1 group
        var grp = null;
        try {
          grp = doc.activeLayer.groupItems.add();
          for (var mi = 0; mi < members.length; mi++) {
            try {
              members[mi].move(grp, ElementPlacement.PLACEATEND);
            } catch (e) {}
          }
        } catch (e) {}
        return grp;
      }

      var faceGroups = [];
      for (k = 0; k < faces.length; k++) {
        faceGroups[k] = placeFaceCentered(faces[k], abPositions[k]);
      }

      // ============================================================
      //  BƯỚC CUỐI: BÓP CHIỀU NGANG cụm (theo group), cao giữ nguyên
      // ============================================================
      function squeezeGroupWidth(grp, faceIndex) {
        if (!grp) return;
        var b = grp.geometricBounds;
        var curW = b[2] - b[0];
        var cx = (b[0] + b[2]) / 2,
          cy = (b[1] + b[3]) / 2;
        var pairIndex = Math.floor(faceIndex / 2);
        var reductionPt = pairIndex * PAIR_REDUCTION * MM;
        var targetW = curW - reductionPt;
        var scaleX = (targetW / curW) * 100;
        try {
          grp.resize(scaleX, 100);
        } catch (e) {}
        var b2 = grp.geometricBounds;
        var cx2 = (b2[0] + b2[2]) / 2,
          cy2 = (b2[1] + b2[3]) / 2;
        try {
          grp.translate(cx - cx2, cy - cy2);
        } catch (e) {}
      }

      for (k = 0; k < faceGroups.length; k++) {
        squeezeGroupWidth(faceGroups[k], k);
      }

      app.redraw();

      // ============================================================
      //  BƯỚC GHI CHÚ: chữ DỌC, bên phải cụm +2mm, từ trên xuống 1cm
      // ============================================================
      function showNoteDialog() {
        var w = new Window("dialog", "Nhập ghi chú");
        w.orientation = "column";
        w.alignChildren = "fill";
        w.margins = 16;
        w.spacing = 10;

        w.add("statictext", undefined, "Ghi chú BÌA (artboard 1):");
        var edBia = w.add("edittext", undefined, "");
        edBia.characters = 40;

        w.add(
          "statictext",
          undefined,
          "Ghi chú RUỘT (tự thêm 'RUOT 1, RUOT 2...'):",
        );
        var edRuot = w.add("edittext", undefined, "");
        edRuot.characters = 40;

        var row = w.add("group");
        row.alignment = "right";
        var btnCancel = row.add("button", undefined, "Bỏ qua", {
          name: "cancel",
        });
        var btnOK = row.add("button", undefined, "Điền ghi chú", {
          name: "ok",
        });

        var res = null;
        btnOK.onClick = function () {
          res = { bia: edBia.text, ruot: edRuot.text };
          w.close();
        };
        btnCancel.onClick = function () {
          res = null;
          w.close();
        };
        w.show();
        return res;
      }

      function addNote(text, pos, faceIndex) {
        if (!text) return;
        try {
          var lay = doc.activeLayer;
          var tf = lay.textFrames.add();
          tf.contents = text;
          try {
            tf.textRange.characterAttributes.size = 13;
          } catch (e) {}
          try {
            var black = new CMYKColor();
            black.black = 100;
            tf.textRange.characterAttributes.fillColor = black;
          } catch (e) {
            try {
              var rgb = new RGBColor();
              rgb.red = 0;
              rgb.green = 0;
              rgb.blue = 0;
              tf.textRange.characterAttributes.fillColor = rgb;
            } catch (e2) {}
          }
          var acx = (pos[0] + pos[2]) / 2,
            acy = (pos[1] + pos[3]) / 2;
          var cumH = pageHpt * 2; // cụm cao 2 hàng
          var pairIndex = Math.floor(faceIndex / 2);
          var squeezedSpreadWpt = spreadWpt - pairIndex * PAIR_REDUCTION * MM;
          var rightCum = acx + squeezedSpreadWpt / 2;
          var topCum = acy + cumH / 2;
          var targetLeft = rightCum + 2 * MM;
          var targetTop = topCum - 10 * MM;

          tf.position = [0, 0];
          try {
            tf.rotate(-90);
          } catch (e) {}
          var tb = tf.visibleBounds;
          tf.translate(targetLeft - tb[0], targetTop - tb[1]);
        } catch (e) {}
      }

      var note = showNoteDialog();
      if (note) {
        var ruotNo = 0;
        for (var ab = 0; ab < abPositions.length; ab += 2) {
          var pos = abPositions[ab];
          if (ab === 0) {
            addNote(note.bia, pos, ab);
          } else {
            ruotNo++;
            var t = "RUOT " + ruotNo + (note.ruot ? " " + note.ruot : "");
            addNote(t, pos, ab);
          }
        }
        app.redraw();
      }
    })(wCm, hCm);
    return "OK: Đã chạy dàn catalogue A5 khổ tùy chỉnh." + dcCauCanhBaoPhong(canhBaoPhong);
  } catch (e) {
    return "ERR: catalogue custom A5: " + e.toString();
  }
}

// ============================================================
//  DÀN CTL OFFSET ĐÓNG GHIM GIỮA (lồng nhau)
//  - Khổ đến 15 x 21.15 cm dùng họ A5: 4=42.8x31.3, 8=64.8x41.8,
//    16=85.8x63.8 tự trở, 32=85.8x63.8 A/B.
//  - Khổ lớn hơn dùng họ A4 đang có: 4=64.8x41.8, 8=85.8x63.8 tự trở,
//    16=85.8x63.8 A/B.
//
//  CHIA CỤM (lồng từ ngoài vào trong):
//    - Nếu CÓ BÌA: 4 trang ngoài cùng (1,2,N-1,N) dùng form bìa theo họ khổ.
//    - Phần ruột được tách tự trở trước, rồi đến các tờ A/B theo họ khổ.
//
//  BỐ TRÍ:
//    - Tự trở đứng 1 mình 1 hàng; mỗi tờ AB có A bên trái, B bên phải.
//
//  KÍCH THƯỚC / BÓP:
//    - Bóp theo tờ: bìa không bóp; ruột 1 = -0.1cm, ruột 2 = -0.2cm...
//      PON cắt luôn bám lưới danh nghĩa, không chạy theo phần ruột đã bóp.
//
//  PON: tự vẽ PON giấy + PON cắt trên layer riêng, không hỏi chọn file.
//
//  GHI CHÚ: bìa dùng ô riêng; ruột chỉ hiện các ô theo loại tờ thật có trong bài.
//
//  Cách dùng:
//   1. Chọn N trang theo thứ tự đọc (bội số của 4; phần ruột dư 0/4/8/12).
//   2. File > Scripts > chạy script.
//   3. Nhập kích thước 1 trang (cm) + tick "Có bìa" nếu chọn cả file.
//   4. Nhập ghi chú nếu cần.
// ============================================================

// ============================================================
// Catalogue KTS tự động: quyết định form 43 x 32.5 cm chứa
// một cuốn hay hai cuốn giống hệt nhau. Hai cuốn dùng chung
// đường cắt giữa và dùng PON kiểu A5.
// ============================================================
var dcCatalogueAutoVersion = 16;

function dcRunCatalogueAuto(wCm, hCm) {
  var MM = 2.834645669;

  function numberCm(value) {
    var n = parseFloat(String(value).replace(",", "."));
    return isNaN(n) ? 0 : n;
  }

  // Khung thành phẩm = khung Transform (dự phòng geometricBounds), không phụ thuộc tick.
  function getBounds(item) {
    return dcKhungHoacBounds(item);
  }

  function centerAt(item, cx, cy) {
    var b = getBounds(item);
    if (!b) throw new Error("Không đo được kích thước artwork.");
    item.translate(cx - (b[0] + b[2]) / 2, cy - (b[1] + b[3]) / 2);
  }

  try {
    var pageWCm = numberCm(wCm);
    var pageHCm = numberCm(hCm);
    if (pageWCm <= 0 || pageHCm <= 0) {
      return "ERR: Nhập kích thước 1 trang hợp lệ (cm).";
    }

    var pageW = pageWCm * 10;
    var pageH = pageHCm * 10;
    var formW = 430;
    var formH = 325;
    // Vùng an toàn cho bài bên trong form: trái/phải 4 mm, trên/dưới 13 mm.
    var safeW = 422;
    var safeH = 299;
    var tolerance = 0.05;
    var spreadW = pageW * 2;
    var spreadH = pageH;

    function fits(w, h) {
      return w <= safeW + tolerance && h <= safeH + tolerance;
    }

    // A5 được phép tới 15 x 21.1 cm. Ở bề rộng 15 cm, cụm hai cuốn
    // đã xoay cao tới 30 cm, chỉ vượt 0.5 mm ra ngoài mỗi mép vùng
    // an toàn PON 29.9 cm; PON được cung cấp vẫn nằm ngoài cụm đó.
    function fitsTwoA5Maximum() {
      return (
        pageW <= 150 + tolerance &&
        pageH <= 211 + tolerance &&
        spreadH * 2 <= safeW + tolerance &&
        spreadW <= 300 + tolerance
      );
    }

    // Ưu tiên hai con. Hai con luôn nằm trái/phải để một nhát cắt dọc
    // là tách được chúng. Cụm 2 trang đã xoay chính là cách xếp A5 chuẩn.
    var plan = null;
    if (fits(spreadW * 2, spreadH)) {
      plan = {
        copies: 2,
        rotate: false,
        bookW: spreadW,
        bookH: spreadH,
      };
    } else if (fits(spreadH * 2, spreadW) || fitsTwoA5Maximum()) {
      plan = {
        copies: 2,
        rotate: true,
        bookW: spreadH,
        bookH: spreadW,
      };
    } else if (fits(spreadW, spreadH)) {
      plan = {
        copies: 1,
        rotate: false,
        bookW: spreadW,
        bookH: spreadH,
      };
    } else if (fits(spreadH, spreadW)) {
      plan = {
        copies: 1,
        rotate: true,
        bookW: spreadH,
        bookH: spreadW,
      };
    }

    if (!plan) {
      return (
        "ERR: Khổ " +
        pageWCm.toFixed(2) +
        " x " +
        pageHCm.toFixed(2) +
        " cm không nằm trong vùng dàn 42.2 x 29.9 cm của tờ PON 43 x 32.5 cm."
      );
    }

    if (app.documents.length === 0) {
      return "ERR: Chưa mở tài liệu Illustrator.";
    }
    var doc = app.activeDocument;
    var selection = doc.selection;
    if (!selection || selection.length === 0) {
      return "ERR: Chọn các trang catalogue trước khi dàn.";
    }
    if (selection.length % 4 !== 0) {
      return (
        "ERR: Số trang catalogue phải là bội số của 4. Đang chọn " +
        selection.length +
        " trang."
      );
    }

    var source = [];
    var selectionLeft = null;
    var selectionTop = null;
    for (var si = 0; si < selection.length; si++) {
      var sourceItem = selection[si];
      var sourceBounds = getBounds(sourceItem);
      if (!sourceBounds) {
        return "ERR: Có artwork không đo được kích thước.";
      }
      try {
        if (sourceItem.locked || sourceItem.layer.locked) {
          return "ERR: Mở khóa layer và object đã chọn trước khi dàn.";
        }
      } catch (lockError) {}
      source.push({
        item: sourceItem,
        left: sourceBounds[0],
        top: sourceBounds[1],
      });
      if (selectionLeft === null) {
        selectionLeft = sourceBounds[0];
        selectionTop = sourceBounds[1];
      } else {
        selectionLeft = Math.min(selectionLeft, sourceBounds[0]);
        selectionTop = Math.max(selectionTop, sourceBounds[1]);
      }
    }

    // Thứ tự đầu vào là thứ tự đọc: trái sang phải, rồi trên xuống dưới.
    source.sort(function (a, b) {
      var dy = b.top - a.top;
      if (Math.abs(dy) > 20 * MM) return dy;
      return a.left - b.left;
    });

    var layoutLayer = doc.layers.add();
    layoutLayer.name = "Dan Catalogue tu dong";
    try {
      layoutLayer.locked = false;
      layoutLayer.visible = true;
    } catch (layerError) {}

    var processed = [];
    var canhBaoPhong = [];
    for (var pi = 0; pi < source.length; pi++) {
      // Không raster: trang nguyên vector, phóng về khổ nhập theo khung Transform.
      var flat = dcChuanBiTrangDan(doc, source[pi].item, pageW, pageH, canhBaoPhong, "Trang " + (pi + 1));
      try {
        flat.move(layoutLayer, ElementPlacement.PLACEATEND);
      } catch (moveError) {}
      processed.push(flat);
    }

    var numSheets = processed.length / 4;
    var numFaces = numSheets * 2;
    var formWPt = formW * MM;
    var formHPt = formH * MM;
    var imposedWidthPt = plan.bookW * MM * plan.copies;
    var imposedHeightPt = plan.bookH * MM;
    var artboardPositions = [];
    var oldArtboardCount = doc.artboards.length;
    var maxRows = 16;
    var blockWidth = formWPt * 2;
    var ponLayer = dcCatalogueCreateAutoPonLayer(doc);

    for (var fi = 0; fi < numFaces; fi++) {
      var sheetIndex = Math.floor(fi / 2);
      var side = fi % 2;
      var block = Math.floor(sheetIndex / maxRows);
      var row = sheetIndex % maxRows;
      var left = selectionLeft + block * blockWidth + side * formWPt;
      var top = selectionTop - row * formHPt;
      var rect = [left, top, left + formWPt, top - formHPt];
      var artboard = doc.artboards.add(rect);
      try {
        artboard.name =
          "Catalogue - " +
          (side === 0 ? "Mat truoc " : "Mat sau ") +
          (sheetIndex + 1);
      } catch (nameError) {}
      var artboardCenterX = (rect[0] + rect[2]) / 2;
      var artboardCenterY = (rect[1] + rect[3]) / 2;
      dcCatalogueAddDynamicPon(
        ponLayer,
        [
          artboardCenterX - imposedWidthPt / 2,
          artboardCenterY + imposedHeightPt / 2,
          artboardCenterX + imposedWidthPt / 2,
          artboardCenterY - imposedHeightPt / 2,
        ],
        plan.copies === 2,
      );
      artboardPositions.push(rect);
    }
    try {
      ponLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      ponLayer.locked = true;
      doc.activeLayer = layoutLayer;
    } catch (ponError) {}
    for (var oldIndex = oldArtboardCount - 1; oldIndex >= 0; oldIndex--) {
      try {
        doc.artboards.remove(oldIndex);
      } catch (removeArtboardError) {}
    }

    var faces = [];
    for (var sheet = 0; sheet < numSheets; sheet++) {
      faces.push([processed.length - 2 * sheet, 1 + 2 * sheet]);
      faces.push([2 + 2 * sheet, processed.length - 1 - 2 * sheet]);
    }

    var pageWPt = pageW * MM;
    var spineReductionPerSheet = 0.25 * MM;
    var placedGroups = [];

    function showNoteDialog() {
      var dialog = new Window("dialog", "Nh\u1eadp ghi ch\u00fa");
      dialog.orientation = "column";
      dialog.alignChildren = "fill";
      dialog.margins = 16;
      dialog.spacing = 10;

      dialog.add(
        "statictext",
        undefined,
        "Ghi ch\u00fa B\u00ccA (artboard 1):",
      );
      var coverField = dialog.add("edittext", undefined, "");
      coverField.characters = 40;

      dialog.add(
        "statictext",
        undefined,
        "Ghi ch\u00fa RU\u1ed8T (t\u1ef1 th\u00eam RU\u1ed8T 1, RU\u1ed8T 2...):",
      );
      var insideField = dialog.add("edittext", undefined, "");
      insideField.characters = 40;

      var buttons = dialog.add("group");
      buttons.alignment = "right";
      var cancelButton = buttons.add("button", undefined, "B\u1ecf qua", {
        name: "cancel",
      });
      var okButton = buttons.add(
        "button",
        undefined,
        "\u0110i\u1ec1n ghi ch\u00fa",
        { name: "ok" },
      );
      var result = null;
      okButton.onClick = function () {
        result = { bia: coverField.text, ruot: insideField.text };
        dialog.close();
      };
      cancelButton.onClick = function () {
        dialog.close();
      };
      dialog.show();
      return result;
    }

    function addCatalogueNote(text, rect) {
      if (!text) return;
      try {
        var textFrame = layoutLayer.textFrames.add();
        textFrame.contents = text;
        textFrame.textRange.characterAttributes.size = 13;
        var black = new CMYKColor();
        black.cyan = 0;
        black.magenta = 0;
        black.yellow = 0;
        black.black = 100;
        textFrame.textRange.characterAttributes.fillColor = black;

        // Đặt ghi chú vào vùng trống ngay phía trên cuốn đã dàn,
        // không đặt cách mép trên giấy một khoảng cố định.  Vị trí này khớp
        // với vị trí của CTL KTS: ghi chú vẫn in được và không bao giờ chồng lấn
        // lên bài khi khổ trang được chọn thay đổi.
        var artboardCenterY = (rect[1] + rect[3]) / 2;
        var imposedTop = artboardCenterY + imposedHeightPt / 2;
        textFrame.position = [rect[0] + 20 * MM, imposedTop + 6 * MM];
      } catch (noteError) {}
    }

    function placeBook(pair, rect, copyIndex, faceIndex) {
      var leftItem = processed[pair[0] - 1];
      var rightItem = processed[pair[1] - 1];
      if (!leftItem || !rightItem) throw new Error("Thiếu trang trong bộ dàn.");
      var book = layoutLayer.groupItems.add();
      book.name = "Catalogue " + (faceIndex + 1) + " - cuon " + (copyIndex + 1);
      if (copyIndex > 0) {
        leftItem = leftItem.duplicate(layoutLayer, ElementPlacement.PLACEATEND);
        rightItem = rightItem.duplicate(
          layoutLayer,
          ElementPlacement.PLACEATEND,
        );
      }
      leftItem.move(book, ElementPlacement.PLACEATEND);
      rightItem.move(book, ElementPlacement.PLACEATEND);

      var centerX = (rect[0] + rect[2]) / 2;
      var centerY = (rect[1] + rect[3]) / 2;
      // Ruột sau được bóp tăng dần. Vị trí PON và artboard không bao giờ
      // dịch chuyển; chỉ cuốn 2 trang hẹp lại quanh trục gáy của nó.
      var sheetNumber = Math.floor(faceIndex / 2);
      var squeezePt = sheetNumber * spineReductionPerSheet;
      var effectivePageWPt = pageWPt - squeezePt / 2;
      var effectiveBookWPt = plan.rotate
        ? plan.bookW * MM
        : effectivePageWPt * 2;
      var bookCenterX =
        plan.copies === 2
          ? centerX +
            (copyIndex === 0 ? -effectiveBookWPt / 2 : effectiveBookWPt / 2)
          : centerX;
      try {
        leftItem.resize((effectivePageWPt * 100) / pageWPt, 100);
        rightItem.resize((effectivePageWPt * 100) / pageWPt, 100);
      } catch (squeezeError) {}
      centerAt(leftItem, bookCenterX - effectivePageWPt / 2, centerY);
      centerAt(rightItem, bookCenterX + effectivePageWPt / 2, centerY);
      // Catalogue hai mặt: artboard lẻ xoay trái, còn artboard chẵn đi cặp
      // với nó xoay phải. Cả hai cuốn nhân bản trên cùng một artboard giữ
      // đúng hướng đó; chúng không bao giờ bị lật ngang.
      if (plan.rotate) book.rotate(faceIndex % 2 === 0 ? 90 : -90);
      centerAt(book, bookCenterX, centerY);
      return book;
    }

    for (var faceIndex = 0; faceIndex < faces.length; faceIndex++) {
      // Tạo các cuốn nhân bản trước. Trang nguồn chưa bị biến đổi gì
      // cho tới khi bản nhân bản của nó được tạo xong, nên con trái/phải nhận
      // cùng một lần resize và xoay duy nhất.
      for (var copyIndex = plan.copies - 1; copyIndex >= 0; copyIndex--) {
        placedGroups.push(
          placeBook(
            faces[faceIndex],
            artboardPositions[faceIndex],
            copyIndex,
            faceIndex,
          ),
        );
      }
    }

    app.redraw();
    var note = showNoteDialog();
    if (note) {
      var insideNumber = 0;
      for (
        var artboardIndex = 0;
        artboardIndex < artboardPositions.length;
        artboardIndex += 2
      ) {
        if (artboardIndex === 0) {
          addCatalogueNote(note.bia, artboardPositions[artboardIndex]);
        } else {
          insideNumber++;
          addCatalogueNote(
            "RU\u1ed8T " + insideNumber + (note.ruot ? " " + note.ruot : ""),
            artboardPositions[artboardIndex],
          );
        }
      }
    }

    try {
      doc.selection = placedGroups;
    } catch (selectError) {}
    app.redraw();

    return (
      "OK: Đã dàn " +
      plan.copies +
      (plan.copies === 2
        ? " cuốn giống nhau / tờ, xả 1 dao ở giữa. "
        : " cuốn / tờ. ") +
      "PON " +
      (plan.copies === 2 ? "2-cuốn" : "1-cuốn") +
      " đã được vẽ tự động; " +
      numFaces +
      " artboard trước/sau." +
      dcCauCanhBaoPhong(canhBaoPhong)
    );
  } catch (e) {
    return "ERR: Catalogue tự tính: " + e.toString();
  }
}

// v30: giữ PON tự vẽ tách biệt khỏi mọi phép biến đổi chỉ dành cho bài, rồi
// kiểm lại toạ độ danh định của nó sau khi bóp tăng dần.  Các vạch
// PON cắt A5 phía dưới kết thúc trên đường tâm PON giấy, như ở file nguồn
// 65 x 86 đã duyệt; chúng không bao giờ bị ruột đã bóp kéo vào trong.  Lượt
// bóp 2 trang canh giữa cũng được bù một lượng rất nhỏ ở đáy danh định,
// cần có để giữ tờ ruột đầu tiên nằm trong artboard cố định của nó.
var dcSignature8AutoPonVersion = 43;

function dcRunSignature8(wCm, hCm, coBia) {
  var previousSignatureCoordinates = app.coordinateSystem;
  try {
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    var MM = 2.834645669;

    // ---------- BẢNG NHẬP KÍCH THƯỚC (cm) ----------
    function showSizeDialog() {
      var w = new Window("dialog", "Kích thước 1 trang (cm)");
      w.orientation = "column";
      w.alignChildren = "fill";
      w.margins = 16;
      w.spacing = 10;
      w.add(
        "statictext",
        undefined,
        "Nhập kích thước 1 TRANG sau phóng to (cm).",
      );
      var rW = w.add("group");
      rW.add("statictext", undefined, "Rộng (cm):");
      var edW = rW.add("edittext", undefined, "");
      edW.characters = 8;
      var rH = w.add("group");
      rH.add("statictext", undefined, "Cao  (cm):");
      var edH = rH.add("edittext", undefined, "");
      edH.characters = 8;
      var cbBia = w.add(
        "checkbox",
        undefined,
        "Có bìa (4 trang ngoài cùng 1,2,N-1,N)",
      );
      cbBia.value = true; // mặc định có bìa (chọn cả file)
      var row = w.add("group");
      row.alignment = "right";
      var bC = row.add("button", undefined, "Bỏ qua", { name: "cancel" });
      var bO = row.add("button", undefined, "Dàn", { name: "ok" });
      var res = null;
      bO.onClick = function () {
        var cw = parseFloat(String(edW.text).replace(",", "."));
        var ch = parseFloat(String(edH.text).replace(",", "."));
        if (isNaN(cw) || isNaN(ch) || cw <= 0 || ch <= 0) {
          alert("Kích thước sai.");
          return;
        }
        res = { w: cw * 10, h: ch * 10, coBia: cbBia.value };
        w.close();
      };
      bC.onClick = function () {
        res = null;
        w.close();
      };
      w.show();
      return res;
    }
    var _si = null;
    var _pw = parseFloat(String(wCm).replace(",", "."));
    var _ph = parseFloat(String(hCm).replace(",", "."));
    if (!isNaN(_pw) && !isNaN(_ph) && _pw > 0 && _ph > 0) {
      var _cb =
        coBia === true || coBia === "true" || coBia === 1 || coBia === "1";
      _si = { w: _pw * 10, h: _ph * 10, coBia: _cb };
    } else {
      _si = showSizeDialog();
    }
    if (!_si) return "OK: (bỏ qua)";
    var PAGE_W = _si.w,
      PAGE_H = _si.h;
    // Giữ đúng chiều đã nhập để resize trang nguồn.  Còn bản thân việc dàn
    // tờ nhỏ thì luôn dùng lưới trang khổ đứng.
    var SOURCE_PAGE_W = PAGE_W,
      SOURCE_PAGE_H = PAGE_H;
    var CO_BIA = _si.coBia;
    // Họ tờ nhỏ áp dụng tới hết artboard A5 đầu tiên, tính cả allowance
    // sản xuất của nó: 15 x 21.15 cm. Giữ điều kiện này không phụ thuộc
    // chiều trang để trang nguồn nằm ngang cũng được nhận ra.
    var _shortPageSide = Math.min(PAGE_W, PAGE_H);
    var _longPageSide = Math.max(PAGE_W, PAGE_H);
    var IS_SMALL_A5 = _shortPageSide <= 150 && _longPageSide <= 211.5;
    var SMALL_SOURCE_IS_LANDSCAPE = IS_SMALL_A5 && PAGE_W > PAGE_H;
    if (SMALL_SOURCE_IS_LANDSCAPE) {
      PAGE_W = _shortPageSide;
      PAGE_H = _longPageSide;
    }

    var TOP_GAP = 23 * MM; // mép trên bài dàn cách mép trên artboard 2.3cm

    if (app.documents.length === 0) {
      return "ERR: Chưa mở tài liệu.";
    }
    var doc = app.activeDocument;

    // Lượt chạy lại chỉ được bắt đầu từ bài.  Ở cách cài đặt trước đây,
    // selection được lấy trước khi hai layer tự tạo này bị xoá.
    // Nếu một layer PON cũ đang mở khoá/được chọn, PON của nó bị raster thành
    // trang nguồn rồi bị bóp chung với ruột, trong khi PON mới
    // vẫn ở vị trí danh định. Loại trừ PON do công cụ tự tạo nhưng chưa xoá gì cho
    // tới khi toàn bộ bước preflight canvas/artboard đã thành công.
    var CTL_OFFSET_PAPER_PON_LAYER = "Pon CTL Offset tu dong";
    var CTL_OFFSET_CUT_PON_LAYER = "Pon cat CTL Offset tu dong";
    function removePreviousCtlOffsetPonLayers() {
      for (
        var oldPonIndex = doc.layers.length - 1;
        oldPonIndex >= 0;
        oldPonIndex--
      ) {
        var oldPonLayer = null;
        try {
          oldPonLayer = doc.layers[oldPonIndex];
        } catch (oldPonReadError) {
          continue;
        }
        var oldPonName = "";
        try {
          oldPonName = oldPonLayer.name;
        } catch (oldPonNameError) {}
        if (
          oldPonName !== CTL_OFFSET_PAPER_PON_LAYER &&
          oldPonName !== CTL_OFFSET_CUT_PON_LAYER
        )
          continue;
        try {
          oldPonLayer.locked = false;
        } catch (oldPonUnlockError) {}
        try {
          oldPonLayer.remove();
        } catch (oldPonRemoveError) {}
      }
    }
    var sel = [];
    var selectedPages = doc.selection;
    for (
      var selectedIndex = 0;
      selectedPages && selectedIndex < selectedPages.length;
      selectedIndex++
    ) {
      var selectedPage = selectedPages[selectedIndex];
      var ancestor = selectedPage;
      var isOldPon = false;
      for (
        var ancestorDepth = 0;
        ancestor && ancestorDepth < 50;
        ancestorDepth++
      ) {
        if (
          ancestor.typename === "Layer" &&
          (ancestor.name === CTL_OFFSET_PAPER_PON_LAYER ||
            ancestor.name === CTL_OFFSET_CUT_PON_LAYER)
        ) {
          isOldPon = true;
          break;
        }
        if (ancestor.typename === "Document") break;
        ancestor = ancestor.parent;
      }
      if (!isOldPon) sel.push(selectedPage);
    }
    if (!sel || sel.length === 0) {
      return "ERR: Chưa chọn trang ruột.";
    }

    var N = sel.length;
    if (N % 4 !== 0) {
      return "ERR: Số trang phải là BỘI SỐ CỦA 4. Đang chọn: " + N;
    }
    // Nếu có bìa, 4 trang ngoài cùng làm TT4 bìa -> phần ruột còn lại = N-4.
    var _nRuot = CO_BIA ? N - 4 : N;
    if (_nRuot < 0) {
      return "ERR: Số trang quá ít.";
    }
    var _du16 = _nRuot % 16;
    if (_du16 !== 0 && _du16 !== 4 && _du16 !== 8 && _du16 !== 12) {
      return "ERR: Số trang không hợp lệ (phần ruột dư " +
          _du16 +
          " khi chia 16). Chỉ hỗ trợ dư 0/4/8/12.";
    }

    // ---------- Gom + sắp theo VỊ TRÍ (thứ tự đọc) ----------
    var arr = [];
    // CTL Offset bắt đầu đúng tại vị trí các trang nguồn đang chọn.  Lưu điểm
    // neo trước khi raster vì lệnh rasterize có thể thay thế object nguồn.
    var selectionLeft = null;
    var selectionTop = null;
    for (var i = 0; i < sel.length; i++) {
      var it = sel[i];
      var b = dcKhungHoacBounds(it) || it.geometricBounds;
      arr.push({ item: it, left: b[0], top: b[1] });
      if (selectionLeft === null) {
        selectionLeft = b[0];
        selectionTop = b[1];
      } else {
        selectionLeft = Math.min(selectionLeft, b[0]);
        selectionTop = Math.max(selectionTop, b[1]);
      }
    }
    arr.sort(function (a, b) {
      var dy = b.top - a.top;
      if (Math.abs(dy) > 50 * MM) return dy;
      return a.left - b.left;
    });
    var pages = [];
    for (i = 0; i < arr.length; i++) pages.push(arr[i].item); // pages[0]=trang ruột đầu tiên

    // ============================================================
    //  HÀM PHỤ TRỢ (đo/clip/union giống các hàm catalogue khác)
    // ============================================================
    function sizeMM(item) {
      // Khung Transform (trang đã clip → khung clip; group → khung group), dự phòng geometricBounds.
      var g = dcKhungHoacBounds(item);
      if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] };
      return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
    }
    function centerAt(item, cx, cy) {
      var s = sizeMM(item);
      var ccx = (s.b[0] + s.b[2]) / 2,
        ccy = (s.b[1] + s.b[3]) / 2;
      item.translate(cx - ccx, cy - ccy);
    }

    // ============================================================
    //  BƯỚC 1: phóng từng trang về PAGE_W x PAGE_H theo khung Transform
    //  Không raster (anh Lộc 22/10): trang giữ nguyên vector, chỉ phóng về khổ nhập.
    // ============================================================
    var processed = [];
    var canhBaoPhong = []; // phóng không đều > 0,5 % → báo trong kết quả
    function prepareSignaturePages() {
      for (var p = 0; p < pages.length; p++) {
        var item = pages[p];
        // Không raster: trang nguyên vector, phóng về khổ nhập theo khung Transform.
        var flat = dcChuanBiTrangDan(
          doc,
          item,
          SOURCE_PAGE_W,
          SOURCE_PAGE_H,
          canhBaoPhong,
          "Trang " + (p + 1),
        );
        // Artboard sản xuất A5 đôi khi được nhập thành 21.15 x 15.
        // Chuẩn hoá kiểu nhập nằm ngang đó về lưới A5 khổ đứng để form giấy
        // được chọn không phụ thuộc thứ tự ô nhập trong panel.
        if (SMALL_SOURCE_IS_LANDSCAPE) {
          try {
            flat.rotate(90);
          } catch (smallPortraitRotateError) {}
        }
        processed.push(flat);
      }
    }

    // ============================================================
    //  BƯỚC 2: CHIA CỤM (đóng gáy giữa lồng nhau, từ ngoài vào trong)
    //  Quy tac:
    //   - Phần dư (N%16) xử lý TỰ TRỞ trước: dư 12=cụm4+cụm8; dư 8=cụm8;
    //     dư 4=cụm4; dư 0=không có tự trở.
    //   - Thứ tự bình: cụm4 (65x43) -> cụm8 (65x86) -> các tờ AB (16 trang).
    //   - Cụm lồng từ ngoài vào (2 đầu dãy).
    //
    //  Công thức trang (a=đầu lớp, b=cuối lớp, 1-based):
    //   cum4 (2 cot): tren=[b, a]        duoi=[a+1, b-1]        (cuối-đầu/đầu-cuối)
    //   cụm8 (4 cột): trên=[b-3,a+3,a+2,b-2] dưới=[b,a,a+1,b-1]
    //  Khớp mẫu N=76: cum4 tren=[76,1] duoi=[2,75]; cum8 tren=[71,6,5,72]...
    //  *** Nếu lệch, sửa 2 công thức dưới trong cum4Pages/cum8Pages ***
    // ============================================================
    //  TT4: 1 HÀNG 4 trang, thứ tự trái->phải = [b, a, a+1, b-1].
    //   2 trang trái (b, a) xoay 180; 2 trang phải (a+1, b-1) xuôi. Khe 0.76cm giữa.
    //   Ví dụ N=76: [76, 1, 2, 75].
    function cum4Pages(a, b) {
      return { type: "TT4", row: [b, a, a + 1, b - 1] };
    }
    function cum8Pages(a, b) {
      return {
        type: "AB",
        top: [b - 3, a + 3, a + 2, b - 2],
        bottom: [b, a, a + 1, b - 1],
      };
    }

    // ---- 1 CỤM-4-CON của tờ AB (2 hàng x 2 cột) theo lớp [a..b] ----
    //  C1 (ngoài): cặp (a,b)+(a+3,b-3); C2: (a+1,b-1)+(a+2,b-2);
    //  C3: (a+4,b-4)+(a+7,b-7);        C4 (trong): (a+5,b-5)+(a+6,b-6).
    function cum4con(a, b) {
      var a2 = a + 4,
        b2 = b - 4;
      return {
        C1: { top: [b - 3, a + 3], bottom: [b, a] },
        C2: { top: [a + 2, b - 2], bottom: [a + 1, b - 1] },
        C3: { top: [b2 - 3, a2 + 3], bottom: [b2, a2] },
        C4: { top: [a2 + 2, b2 - 2], bottom: [a2 + 1, b2 - 1] },
      };
    }
    //  Ghép 1 mặt từ 2 cụm-4-con (nửa trái + nửa phải). top/bottom = 4 cột.
    function faceFrom(left, right) {
      return {
        top: left.top.concat(right.top),
        bottom: left.bottom.concat(right.bottom),
      };
    }
    //  1 TO AB (16 trang lop [a..b]) -> 2 mặt, dat cum dung vi tri:
    //   Mặt A: trái=C3, phải=C1 ; Mặt B: trái=C2, phải=C4.
    function buildToAB(a, b) {
      var c = cum4con(a, b);
      return { A: faceFrom(c.C3, c.C1), B: faceFrom(c.C2, c.C4) };
    }

    // Xây dựng danh sách FACES (mỗi face = 1 artboard).
    //  sheetNo = số TỜ RUỘT dùng để bóp: bia=0 (không bóp), mỗi TT ruột=1 tờ,
    //  mỗi cặp AB (2 mặt) dùng chung 1 sheetNo.
    var faces = [];
    var _a = 1,
      _b = N;
    var sheetNo = 0; // to ruot hien tai (0 = bia, không bóp)

    // Nếu CÓ BÌA: cụm ngoài cùng nhất (1,2,N-1,N) = TT4 BIA. Làm đầu tiên.
    if (CO_BIA) {
      var fBia = cum4Pages(_a, _b);
      faces.push({
        type: IS_SMALL_A5 ? "SMALL4" : "TT4",
        label: IS_SMALL_A5 ? "BIA A5 (4 trang)" : "TT4 BIA A4 (4 trang)",
        row: fBia.row,
        sheetNo: 0,
      });
      _a += 2;
      _b -= 2;
    }

    // Phần còn lại (ruot) = số trang từ _a den _b.
    if (IS_SMALL_A5) {
      // A5 trở xuống: 4 trang = 42.8 x 31.3, 8 trang = 64.8 x 41.8,
      // 16 trang = 85.8 x 63.8 tự trở, 32 trang = 85.8 x 62.5 A/B.
      var nSmallRemain = _b - _a + 1;
      var smallRemainder = nSmallRemain % 32;
      var smallOrder = [];
      if (smallRemainder === 28) smallOrder = [4, 8, 16];
      else if (smallRemainder === 24) smallOrder = [8, 16];
      else if (smallRemainder === 20) smallOrder = [4, 16];
      else if (smallRemainder === 16) smallOrder = [16];
      else if (smallRemainder === 12) smallOrder = [4, 8];
      else if (smallRemainder === 8) smallOrder = [8];
      else if (smallRemainder === 4) smallOrder = [4];

      for (var soi = 0; soi < smallOrder.length; soi++) {
        sheetNo++;
        var smallCount = smallOrder[soi];
        if (smallCount === 4) {
          var sf4 = cum4Pages(_a, _b);
          faces.push({
            type: "SMALL4",
            label: "TU TRO A5 4 trang",
            row: sf4.row,
            sheetNo: sheetNo,
          });
          _a += 2;
          _b -= 2;
        } else if (smallCount === 8) {
          var sf8 = cum8Pages(_a, _b);
          faces.push({
            type: "SMALL8",
            label: "TU TRO A5 8 trang",
            top: sf8.top,
            bottom: sf8.bottom,
            cols: 4,
            sheetNo: sheetNo,
          });
          _a += 4;
          _b -= 4;
        } else {
          var sf16 = buildToAB(_a, _b);
          faces.push({
            type: "SMALL16",
            label: "TU TRO A5 16 trang",
            leftFace: sf16.A,
            rightFace: sf16.B,
            sheetNo: sheetNo,
          });
          _a += 8;
          _b -= 8;
        }
      }

      // Mỗi tay 32 trang có hai mặt (A/B). Mỗi mặt chứa hai
      // panel 8 trang lồng nhau trên cùng một artboard 85.8 x 62.5.
      var smallToNo = 0;
      while (_a < _b) {
        smallToNo++;
        sheetNo++;
        var outer16 = buildToAB(_a, _b);
        var inner16 = buildToAB(_a + 8, _b - 8);
        faces.push({
          type: "SMALLAB",
          label: "To" + smallToNo + " - A",
          leftFace: outer16.A,
          rightFace: inner16.A,
          sheetNo: sheetNo,
        });
        faces.push({
          type: "SMALLAB",
          label: "To" + smallToNo + " - B",
          leftFace: outer16.B,
          rightFace: inner16.B,
          sheetNo: sheetNo,
        });
        _a += 16;
        _b -= 16;
      }
    } else {
      var nRemain = _b - _a + 1;
      var du = nRemain % 16;
      var ttOrder = [];
      if (du === 12) ttOrder = [4, 8];
      else if (du === 8) ttOrder = [8];
      else if (du === 4) ttOrder = [4];
      // else dư===0 -> không thêm tự trở cho ruột

      // Tự trở cho ruột (cum4 -> cum8 theo thứ tự ttOrder). Mỗi TT ruột = 1 to.
      for (var oi = 0; oi < ttOrder.length; oi++) {
        sheetNo++;
        if (ttOrder[oi] === 4) {
          var f4 = cum4Pages(_a, _b);
          faces.push({
            type: "TT4",
            label: "TU TRO A4 4 trang",
            row: f4.row,
            sheetNo: sheetNo,
          });
          _a += 2;
          _b -= 2;
        } else {
          var f8 = cum8Pages(_a, _b);
          faces.push({
            type: "TT8",
            label: "TU TRO A4 8 trang",
            top: f8.top,
            bottom: f8.bottom,
            cols: 4,
            sheetNo: sheetNo,
          });
          _a += 4;
          _b -= 4;
        }
      }

      // Phần còn lại = cac TO AB (mỗi tờ 16 trang lop [_a.._b] -> 2 mặt A,B).
      var toNo = 0;
      while (_a < _b) {
        toNo++;
        sheetNo++;
        var t = buildToAB(_a, _b); // lấy 16 trang: 8 dau + 8 cuoi cua lop
        _a += 8;
        _b -= 8; // 1 tờ tiêu thụ 16 trang (8 moi dau)
        faces.push({
          type: "AB",
          label: "To" + toNo + " - A",
          top: t.A.top,
          bottom: t.A.bottom,
          cols: 4,
          sheetNo: sheetNo,
        });
        faces.push({
          type: "AB",
          label: "To" + toNo + " - B",
          top: t.B.top,
          bottom: t.B.bottom,
          cols: 4,
          sheetNo: sheetNo,
        });
      }
    }

    var numFaces = faces.length;

    // Đánh dấu xem face nào là TỰ TRỞ (đứng 1 mình) và gom cặp AB.
    //  isSolo = artboard đứng 1 mình 1 hàng (TT4, TT8).
    //  Các face AB đi theo cặp: A bên trái, B bên phải.
    for (var fi = 0; fi < faces.length; fi++) {
      faces[fi].solo =
        faces[fi].type === "TT4" ||
        faces[fi].type === "TT8" ||
        faces[fi].type === "SMALL4" ||
        faces[fi].type === "SMALL8" ||
        faces[fi].type === "SMALL16";
    }

    // ============================================================
    //  BƯỚC 3: IMPORT PON (2 loai: chinh 65x86 + rieng TT4 65x43)
    //  -> artboard theo pon -> nhân bản pon -> đặt cụm căn giữa, đỉnh 2.3cm.
    // ============================================================
    // Dùng kích thước nhập vào đã chuẩn hoá, thay vì bounds của raster vốn có thể
    // mang sai số làm tròn phần lẻ của Illustrator. Kích thước nhập danh định là
    // mốc tham chiếu cho mọi toạ độ giấy/PON.
    var pageWpt = PAGE_W * MM,
      pageHpt = PAGE_H * MM;

    var GAP_ROW = 12 * MM;
    var GAP_COL = 20 * MM;

    // ==========================================================
    //  LƯỚI DANH ĐỊNH (nominal grid)
    //  Lưới luôn dựng từ kích thước trang NHẬP VÀO, không bao giờ đọc
    //  bounds của bài đã bóp. Artboard và PON bám lưới này; chỉ ruột bên
    //  trong mới bị bóp. Mọi số dưới đây đơn vị mm, làm tròn 0.01 mm —
    //  mịn hơn mức đó là vô nghĩa trên bản kẽm (0.01 mm = 0.028 pt).
    // ==========================================================

    // Khe giữa (gutter) của từng loại form.
    var MID_GAP = 8 * MM; // 65 x 86 A4 — khe 0.8 cm
    var MID_GAP_TT4 = 7.6 * MM; // 65 x 43 TT4
    var MID_GAP_A5_MAIN = 6 * MM; // 65 x 86 A5
    var MID_GAP_A5_COVER = 5 * MM; // 43 x 32.5 bìa A5

    // ==========================================================
    //  KHỔ GIẤY CỐ ĐỊNH
    //  Offset chạy tờ giấy cố định, không co giãn theo khổ trang.
    //  Nhập trang nhỏ thì lề rộng ra, chứ tờ giấy vẫn nguyên.
    //  Các form dùng khổ giấy cố định; tờ AB có khổ riêng:
    // ==========================================================
    var SHEET_65x86 = { W: 858 * MM, H: 638 * MM }; // giữ khổ các tờ tự trở
    var SHEET_AB = { W: 858 * MM, H: 625 * MM }; // AB A4/A5: 85.8 × 62.5 cm
    var SHEET_65x43 = { W: 648 * MM, H: 418 * MM }; // tự trở 8 A5, TT4
    var SHEET_43x32 = { W: 428 * MM, H: 313 * MM }; // bìa A5

    // Khe hàng và lề nhíp (mép trên tờ tới mép trên bài).
    var A5_MAIN_ROW_GAP = 15 * MM;
    var SMALL8_TRIM_OVERLAP = 2.5 * MM;

    // ==========================================================
    //  BÓP (bù độ dày gáy)
    //  Mỗi tờ vào trong bóp thêm 0.1 cm ở chiều vuông góc với gáy.
    //  Bìa (sheetNo 0) không bóp. Chỉ bóp ARTWORK, không bóp lưới/PON.
    // ==========================================================
    var BOP_PER_SHEET = 1 * MM; // 0.1 cm mỗi tờ

    // Co một group quanh chính tâm nó. Dùng chung cho mọi chỗ bóp, để
    // ba kiểu form không trôi mỗi nơi một kiểu như trước.
    function squeezeAboutCentre(grp, scaleXPercent, scaleYPercent) {
      if (!grp) return;
      var before = dcKhungHoacBounds(grp),
        after;
      if (!before) return;
      var cx = (before[0] + before[2]) / 2;
      var cy = (before[1] + before[3]) / 2;
      try {
        grp.resize(scaleXPercent, scaleYPercent);
      } catch (squeezeError) {
        return;
      }
      try {
        after = dcKhungHoacBounds(grp) || grp.geometricBounds;
        grp.translate(
          cx - (after[0] + after[2]) / 2,
          cy - (after[1] + after[3]) / 2,
        );
      } catch (recentreError) {}
    }

    // Gom một danh sách SỐ TRANG thành group tạm để bóp cả cụm.
    function groupPages(pageNumbers) {
      var members = [];
      for (var i = 0; i < pageNumbers.length; i++) {
        var it = processed[pageNumbers[i] - 1];
        if (it) members.push(it);
      }
      if (members.length === 0) return null;
      var grp;
      try {
        grp = artworkLayer.groupItems.add();
      } catch (groupError) {
        return null;
      }
      for (var m = 0; m < members.length; m++) {
        try {
          members[m].move(grp, ElementPlacement.PLACEATEND);
        } catch (moveError) {}
      }
      return grp;
    }

    // Trả các con trong group tạm về layer (Illustrator giữ nguyên vị trí
    // sau khi resize), rồi bỏ group rỗng.
    function ungroupInto(grp, layer) {
      if (!grp) return;
      for (var i = grp.pageItems.length - 1; i >= 0; i--) {
        try {
          grp.pageItems[i].move(layer, ElementPlacement.PLACEATEND);
        } catch (moveBackError) {}
      }
      try {
        grp.remove();
      } catch (removeGroupError) {}
    }

    // ==========================================================
    //  BẢN MÔ TẢ FORM
    //  Mỗi loại tờ chỉ khai báo MỘT lần ở đây. Lưới danh định, PON
    //  giấy và PON cắt đều sinh ra từ bản mô tả này, nên năm loại
    //  form dùng chung một đường tính — không còn mỗi loại một nhánh.
    //
    //    cols / rows : số cột, số hàng trang trên tờ
    //    rotated     : trang nằm xoay 90° (cạnh dài nằm ngang)
    //    gutter      : khe giữa, chèn vào chính giữa dãy cột
    //    rowGap      : khe giữa hai block hàng (0 = không có)
    //    side/top/bottom : lề quanh lưới
    //    trimCut     : allowance tối đa mỗi hàng (chỉ form tự trở 8 A5)
    //    pon         : nhóm thông số PON giấy ("large" | "small")
    //    midAxis     : có vạch PON ở đúng tâm khe giữa không
    //    rowSeam     : có vạch PON ở đường nối giữa hai hàng không
    //    cornerLegs  : có chân ngang (chữ L) kèm nét dọc không
    //    anchor      : "bottom" = lưới tì vào MÉP DƯỚI artboard (họ A5 —
    //                  mọi khổ trang đều bắt đầu từ đáy tờ, lề thừa dồn
    //                  lên trên); "top" = chừa lề nhíp (AB/TT8 A4);
    //                  "center" = canh giữa như artwork TT4 A4 thực tế.
    //    pageAxes    : có đánh PON ở biên trang BÊN TRONG mỗi nửa không
    //                  (form tự trở A5 cần, để cắt ra cụm 2 rồi xếp lại;
    //                   form đóng ghim giữa A4 không cần vì chỗ đó là nếp gấp)
    // ==========================================================
    function formSpec(type) {
      if (type === "SMALL4")
        return {
          cols: 2,
          rows: 2,
          rotated: true,
          gutter: MID_GAP_A5_COVER,
          rowGap: 0,
          sheet: SHEET_43x32,
          anchor: "bottom",
          trimCut: 0,
          pon: "small",
          midAxis: true,
          rowSeam: false,
          cornerLegs: true,
          pageAxes: true,
        };
      if (type === "SMALL8")
        return {
          cols: 4,
          rows: 2,
          rotated: false,
          gutter: MID_GAP,
          rowGap: 0,
          sheet: SHEET_65x43,
          anchor: "bottom",
          trimCut: SMALL8_TRIM_OVERLAP,
          pon: "small",
          midAxis: true,
          // Cắt ngang giữa hai hàng. Trục giữa hai trang của mỗi cụm
          // là nếp gấp dọc, không đánh PON cắt tại đó.
          rowSeam: true,
          cornerLegs: true,
          pageAxes: false,
        };
      if (type === "SMALL16" || type === "SMALLAB")
        return {
          cols: 4,
          rows: 4,
          rotated: true,
          gutter: MID_GAP_A5_MAIN,
          rowGap: A5_MAIN_ROW_GAP,
          sheet: type === "SMALLAB" ? SHEET_AB : SHEET_65x86,
          anchor: "bottom",
          trimCut: 0,
          pon: "large",
          midAxis: true,
          rowSeam: true,
          cornerLegs: true,
          pageAxes: true,
        };
      if (type === "TT4")
        return {
          cols: 2,
          rows: 2,
          rotated: true,
          gutter: MID_GAP_TT4,
          rowGap: 0,
          sheet: SHEET_65x43,
          anchor: "center",
          top: 0,
          trimCut: 0,
          pon: "small",
          midAxis: true,
          rowSeam: false,
          // Form bìa A4 65x43 xưa nay chỉ có nét dọc, không có chân ngang.
          // Giữ đúng như cũ vì bên A4 đang chạy tốt.
          cornerLegs: false,
          pageAxes: false,
        };
      return {
        cols: 4,
        rows: 2,
        rotated: false,
        gutter: MID_GAP,
        rowGap: 0,
        sheet: type === "AB" ? SHEET_AB : SHEET_65x86,
        anchor: "top",
        top: TOP_GAP,
        trimCut: 0,
        pon: "large",
        midAxis: false,
        rowSeam: true,
        cornerLegs: true,
        pageAxes: false,
      };
    }

    // Lưới danh định của một form. Luôn dựng từ kích thước trang NHẬP
    // VÀO; không bao giờ đọc bounds của bài đã bóp. Gọi không kèm rect
    // thì chỉ trả về khổ giấy (dùng để xếp artboard).
    function nominalGridFor(face, rect) {
      var spec = formSpec(face.type);
      var cellW = spec.rotated ? pageHpt : pageWpt;
      var fullCellH = spec.rotated ? pageWpt : pageHpt;
      // Chỉ dùng allowance khi hai hàng thật sự cao hơn tờ. Trang 14 x 20
      // đã lọt 41.8 cm nên không được trừ 2.5 mm rồi đặt bài nguyên cao
      // theo tâm ô ngắn hơn: cách đó làm mép dưới tràn 1.25 mm.
      var requiredTrim = Math.max(
        0,
        (fullCellH * spec.rows + spec.rowGap - spec.sheet.H) / spec.rows,
      );
      var cellH = fullCellH - Math.min(spec.trimCut, requiredTrim);
      if (cellH <= 0) throw new Error("Chiều cao trang quá nhỏ cho form này.");

      var grid = {
        type: face.type,
        spec: spec,
        pageW: pageWpt,
        pageH: pageHpt,
        cellW: cellW,
        cellH: cellH,
      };
      if (spec.trimCut > 0) grid.trimH = cellH;
      grid.contentW = cellW * spec.cols + spec.gutter;
      grid.contentH = cellH * spec.rows + spec.rowGap;

      // Khổ giấy CỐ ĐỊNH, không tính từ khổ trang.
      grid.paperW = spec.sheet.W;
      grid.paperH = spec.sheet.H;

      // Bài phải lọt tờ giấy. Thà báo lỗi rõ còn hơn âm thầm phình
      // artboard ra một khổ giấy không có thật.
      var topGap = 0;
      if (spec.anchor === "top") topGap = spec.top;
      var overW = grid.contentW - grid.paperW;
      var overH = grid.contentH + topGap - grid.paperH;
      if (overW > 0.5 || overH > 0.5) {
        var mm = function (v) {
          return (Math.round((v / MM) * 10) / 10).toString();
        };
        throw new Error(
          "Khổ trang nhập quá lớn cho tờ " +
            mm(grid.paperW) +
            " x " +
            mm(grid.paperH) +
            " mm: bài cần " +
            mm(grid.contentW) +
            " x " +
            mm(grid.contentH + topGap) +
            " mm, dư " +
            (overW > 0.5 ? "ngang " + mm(overW) + " mm" : "") +
            (overW > 0.5 && overH > 0.5 ? " và " : "") +
            (overH > 0.5 ? "dọc " + mm(overH) + " mm" : "") +
            ". Hãy nhập lại khổ trang nhỏ hơn.",
        );
      }
      if (!rect) return grid;

      grid.left = rect[0];
      grid.top = rect[1];
      grid.right = rect[2];
      grid.bottom = rect[3];
      grid.cx = (rect[0] + rect[2]) / 2;
      grid.cy = (rect[1] + rect[3]) / 2;

      // Bài luôn canh giữa theo chiều ngang tờ.
      grid.gridLeft = grid.left + (grid.paperW - grid.contentW) / 2;
      grid.gridRight = grid.gridLeft + grid.contentW;
      // Chiều dọc: họ A5 tì vào MÉP DƯỚI artboard, lề thừa dồn lên trên,
      // nên PON đáy luôn bắt đầu từ đáy tờ với mọi khổ trang. AB/TT8 A4
      // giữ lề nhíp cố định; TT4 A4 canh giữa để PON khớp artwork.
      if (spec.anchor === "bottom") {
        grid.gridBottom = grid.bottom;
        grid.gridTop = grid.gridBottom + grid.contentH;
      } else if (spec.anchor === "center") {
        grid.gridTop = grid.cy + grid.contentH / 2;
        grid.gridBottom = grid.cy - grid.contentH / 2;
      } else {
        grid.gridTop = grid.top - spec.top;
        grid.gridBottom = grid.gridTop - grid.contentH;
      }
      // Lưới đối xứng nên tâm khe giữa luôn trùng tâm artboard.
      grid.gapLeft = grid.gridLeft + cellW * (spec.cols / 2);
      grid.gapRight = grid.gapLeft + spec.gutter;

      // Các đường cột (mép trang), kể cả hai mép khe giữa.
      grid.colLines = [];
      for (var c = 0; c <= spec.cols; c++)
        grid.colLines.push(
          grid.gridLeft + c * cellW + (c > spec.cols / 2 ? spec.gutter : 0),
        );

      // Các đường hàng có đánh PON. vDir = hướng nét dọc, luôn trỏ vào
      // khoảng trắng bên cạnh; 0 nghĩa là hai hàng dính nhau, không có
      // chỗ trống để vẽ nên chỉ đánh chân ngang.
      grid.rowLines = [{ y: grid.gridTop, vDir: 1 }];
      if (spec.rowGap > 0) {
        grid.blockBottom = grid.gridTop - cellH * (spec.rows / 2);
        grid.blockTop = grid.blockBottom - spec.rowGap;
        grid.rowLines.push(
          { y: grid.blockBottom, vDir: -1 },
          { y: grid.blockTop, vDir: 1 },
        );
      } else if (spec.rowSeam) {
        grid.rowLines.push({
          y: grid.gridTop - cellH * (spec.rows / 2),
          vDir: 0,
        });
      }
      grid.rowLines.push({ y: grid.gridBottom, vDir: -1 });

      // ---- Bí danh theo tên cũ, để phần đặt trang không phải sửa ----
      grid.coverLeft =
        grid.small8Left =
        grid.tt4Left =
        grid.a4Left =
          grid.gridLeft;
      grid.coverRight = grid.small8Right = grid.tt4Right = grid.gridRight;
      grid.coverTop = grid.small8Top = grid.a4Top = grid.tt4Top = grid.gridTop;
      grid.mainGridTop = grid.gridTop;
      grid.coverBottom = grid.small8Bottom = grid.a4Bottom = grid.gridBottom;
      grid.tt4Bottom = grid.gridBottom;
      grid.coverGapLeft = grid.small8GapLeft = grid.gapLeft;
      grid.coverGapRight = grid.small8GapRight = grid.gapRight;
      grid.a4Middle = grid.gridTop - cellH;
      grid.mainX0 = grid.colLines[0];
      grid.mainX1 = grid.colLines[1];
      grid.mainX2 = grid.gapLeft;
      grid.mainX3 = grid.cx;
      grid.mainX4 = grid.gapRight;
      grid.mainX5 = grid.gapRight + cellW;
      grid.mainX6 = grid.gridRight;
      grid.mainUpperBlockBottom = grid.blockBottom;
      grid.mainLowerBlockTop = grid.blockTop;
      grid.mainLowerBlockBottom = grid.gridBottom;
      return grid;
    }

    var oldAb = doc.artboards.length;

    // Các file bìa/ruột A5 được cung cấp dùng để cân chỉnh lề trong lưới danh định
    // ở trên; form giấy thực tế vẫn do kích thước nhập vào quyết định.
    var hasTT4 = false;
    for (var ci2 = 0; ci2 < faces.length; ci2++)
      if (faces[ci2].type === "TT4") {
        hasTT4 = true;
        break;
      }
    // Kích thước artboard là hình chữ nhật đi qua TIM của bốn
    // nét PON giấy. Không suy ra nó từ phần bài nhìn thấy hay từ PON cắt.
    // AB A4/A5 giờ dùng 85.8 x 62.5 cm theo khổ giấy được yêu cầu.
    // Các form khác giữ kích thước cũ; PON bám theo từng rect.

    function createAutoPonLayer(layerName) {
      for (var li = doc.layers.length - 1; li >= 0; li--) {
        try {
          if (doc.layers[li].name === layerName) {
            doc.layers[li].locked = false;
            doc.layers[li].remove();
          }
        } catch (removePonLayerError) {}
      }
      var layer = doc.layers.add();
      layer.name = layerName;
      try {
        layer.locked = false;
        layer.visible = true;
      } catch (ponLayerStateError) {}
      return layer;
    }

    // ==========================================================
    //  PON GIẤY — dấu góc trên 4 góc artboard.
    //  Artboard chính là khổ giấy nhập vào, và tim nét PON nằm đúng
    //  trên mép artboard. Chỉ còn HAI bộ thông số: form lớn (65x86)
    //  và form nhỏ (65x43, 43x32.5). Trước đây cùng một khổ giấy mà
    //  job A4 và job A5 lại vẽ hai kiểu dấu khác nhau.
    // ==========================================================
    var PON_PAPER = {
      large: { arm: 18.766, leg: 21.091, stroke: 3.971 },
      small: { arm: 14.173, leg: 14.106, stroke: 1.995 },
    };
    //  PON CẮT — dấu 2 mm, nét 1 pt, nằm ĐÚNG trên đường cắt.
    var CUT_MARK = 2 * MM;
    var CUT_STROKE = 1;
    // Luật chung: KHÔNG nét PON cắt nào được nằm ngoài artboard. Mốc dấu
    // lọt ra ngoài thì kéo về đúng mép, nét ở sát mép thì quay vào trong.
    // Mốc nằm đúng trên mép artboard là hợp lệ, không bị đẩy vào.
    var ponClampCount = 0;

    function ctlBlack() {
      var black = new CMYKColor();
      black.cyan = 0;
      black.magenta = 0;
      black.yellow = 0;
      black.black = 100;
      return black;
    }

    function addAutoPon(layer, rect, ponClass) {
      var s = PON_PAPER[ponClass] || PON_PAPER.large;
      var black = ctlBlack();
      function draw(x1, y1, x2, y2) {
        var mark = layer.pathItems.add();
        mark.setEntirePath([
          [x1, y1],
          [x2, y2],
        ]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = s.stroke;
      }
      var left = rect[0],
        top = rect[1],
        right = rect[2],
        bottom = rect[3];
      draw(left, top, left + s.arm, top);
      draw(left, top, left, top - s.leg);
      draw(right - s.arm, top, right, top);
      draw(right, top, right, top - s.leg);
      draw(left, bottom, left + s.arm, bottom);
      draw(left, bottom, left, bottom + s.leg);
      draw(right - s.arm, bottom, right, bottom);
      draw(right, bottom, right, bottom + s.leg);
      return 8;
    }

    // ==========================================================
    //  PON CẮT
    //  Một quy tắc duy nhất cho mọi form:
    //    - Trục đánh dấu = 2 mép ngoài lưới + 2 mép khe giữa
    //      (+ tâm khe nếu form có).
    //    - Ở đầu trên và đầu dưới lưới: một chữ L (nét dọc hướng ra
    //      ngoài bài + nét ngang hướng vào rãnh trống).
    //    - Ở đường nối hàng bên trong: chỉ một nét ngang.
    //  Toạ độ lấy từ lưới danh định, nên ruột có bóp thì PON vẫn
    //  đứng yên.
    // ==========================================================
    function addAutoCutPon(layer, face, artboardRect) {
      var grid = nominalGridFor(face, artboardRect);
      var black = ctlBlack();
      var count = 0;

      function draw(p1, p2) {
        var mark = layer.pathItems.add();
        mark.locked = false;
        mark.setEntirePath([p1, p2]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = CUT_STROKE;
        count++;
      }
      // --- giữ mọi nét nằm trong artboard ---
      var xLo = artboardRect[0],
        xHi = artboardRect[2];
      var yLo = artboardRect[3],
        yHi = artboardRect[1];
      function clamp(v, lo, hi) {
        if (v < lo) {
          if (lo - v > 0.001) ponClampCount++;
          return lo;
        }
        if (v > hi) {
          if (v - hi > 0.001) ponClampCount++;
          return hi;
        }
        return v;
      }
      // Vẽ theo hướng mong muốn; nếu hướng đó tràn ra ngoài thì quay
      // ngược lại; nếu cả hai phía đều chật thì chọn phía rộng hơn.
      function tickEnd(start, dir, lo, hi) {
        var want = start + dir * CUT_MARK;
        if (want >= lo && want <= hi) return want;
        var back = start - dir * CUT_MARK;
        if (back >= lo && back <= hi) return back;
        return hi - start > start - lo ? hi : lo;
      }
      function vTick(x, y, dir) {
        if (!dir) return;
        var ax = clamp(x, xLo, xHi);
        var ay = clamp(y, yLo, yHi);
        draw([ax, ay], [ax, tickEnd(ay, dir, yLo, yHi)]);
      }
      function hTick(x, y, dir) {
        if (!dir || !grid.spec.cornerLegs) return;
        var ax = clamp(x, xLo, xHi);
        var ay = clamp(y, yLo, yHi);
        draw([ax, ay], [tickEnd(ax, dir, xLo, xHi), ay]);
      }

      // Trục đánh dấu: hai mép ngoài lưới, hai mép khe giữa, tâm khe, và
      // (nếu form cần cắt ra cụm) cả các biên trang bên trong mỗi nửa.
      // dir = hướng chân ngang, luôn trỏ vào rãnh trống bên cạnh; 0 nghĩa
      // là hai trang dính nhau, chỗ đó chỉ có nét dọc.
      var spec = grid.spec;
      var axes = [];
      function addAxis(x, dir) {
        for (var i = 0; i < axes.length; i++)
          if (Math.abs(axes[i].x - x) < 0.001) return;
        axes.push({ x: x, dir: dir });
      }
      addAxis(grid.gridLeft, -1);
      addAxis(grid.gapLeft, 1);
      addAxis(grid.gapRight, -1);
      addAxis(grid.gridRight, 1);
      if (spec.midAxis) addAxis(grid.cx, 0);
      if (spec.pageAxes)
        for (var ci = 1; ci < grid.colLines.length - 1; ci++)
          addAxis(grid.colLines[ci], 0);

      for (var a = 0; a < axes.length; a++)
        for (var r = 0; r < grid.rowLines.length; r++) {
          var row = grid.rowLines[r];
          vTick(axes[a].x, row.y, row.vDir);
          hTick(axes[a].x, row.y, axes[a].dir);
        }
      return count;
    }

    var artworkLayer = doc.activeLayer;
    var ponLayer = null;
    var cutPonLayer = null;
    function prepareSignatureLayers() {
      removePreviousCtlOffsetPonLayers();
      ponLayer = createAutoPonLayer(CTL_OFFSET_PAPER_PON_LAYER);
      cutPonLayer = createAutoPonLayer(CTL_OFFSET_CUT_PON_LAYER);
      try {
        doc.activeLayer = artworkLayer;
      } catch (restoreArtworkLayerError) {
        for (
          var fallbackLayer = 0;
          fallbackLayer < doc.layers.length;
          fallbackLayer++
        ) {
          try {
            if (
              doc.layers[fallbackLayer] !== ponLayer &&
              doc.layers[fallbackLayer] !== cutPonLayer
            ) {
              artworkLayer = doc.layers[fallbackLayer];
              doc.activeLayer = artworkLayer;
              break;
            }
          } catch (findArtworkLayerError) {}
        }
      }
    }

    // PON là một tập path thẳng, đơn giản. Lưu toạ độ danh định của nó
    // ngay sau khi vẽ để sau này dù Illustrator hay trạng thái layer có đổi
    // cũng không âm thầm kéo nó đi theo group bài đã bóp. Chỗ này chỉ ghi lại
    // PON tự vẽ; bài nguồn không bao giờ bị đọc hay sửa ở đây.
    function capturePonGeometry(layer) {
      var records = [];
      for (
        var ponPathIndex = 0;
        ponPathIndex < layer.pathItems.length;
        ponPathIndex++
      ) {
        var ponPath = layer.pathItems[ponPathIndex];
        var points = [];
        try {
          for (
            var ponPointIndex = 0;
            ponPointIndex < ponPath.pathPoints.length;
            ponPointIndex++
          ) {
            var anchor = ponPath.pathPoints[ponPointIndex].anchor;
            points.push([anchor[0], anchor[1]]);
          }
          records.push({
            item: ponPath,
            points: points,
            strokeWidth: ponPath.strokeWidth,
          });
        } catch (capturePonError) {}
      }
      return records;
    }

    // Lượt chạy bình thường luôn trả về 0: PON cắt và PON giấy phải giữ đúng
    // lưới ban đầu, không phụ thuộc face.sheetNo hay mức bóp bài.
    function restoreNominalPonGeometry(records) {
      var fixed = 0;
      var epsilon = 0.01; // pt; chỉ bỏ qua sai số làm tròn hiển thị của Illustrator.
      for (
        var restoreIndex = 0;
        restoreIndex < records.length;
        restoreIndex++
      ) {
        var record = records[restoreIndex];
        var moved = false;
        try {
          if (record.item.pathPoints.length !== record.points.length) {
            moved = true;
          } else {
            for (
              var restorePointIndex = 0;
              restorePointIndex < record.points.length;
              restorePointIndex++
            ) {
              var current = record.item.pathPoints[restorePointIndex].anchor;
              var saved = record.points[restorePointIndex];
              if (
                Math.abs(current[0] - saved[0]) > epsilon ||
                Math.abs(current[1] - saved[1]) > epsilon
              ) {
                moved = true;
                break;
              }
            }
          }
          if (moved) {
            record.item.setEntirePath(record.points);
            record.item.strokeWidth = record.strokeWidth;
            fixed++;
          }
        } catch (restorePonError) {}
      }
      return fixed;
    }

    function unlockNominalPonLayers() {
      try {
        ponLayer.locked = false;
      } catch (unlockPaperPonError) {}
      try {
        cutPonLayer.locked = false;
      } catch (unlockCutPonError) {}
    }

    // Giữ PON tự vẽ nằm trên bài sau khi thêm ghi chú và icon nhập vào.
    // PON cắt cố ý nằm trên cùng để bài raster không thể
    // che mất dấu cắt màu đen.
    function lockNominalPonLayersOnTop() {
      unlockNominalPonLayers();
      try {
        ponLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      } catch (raisePaperPonError) {}
      try {
        cutPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      } catch (raiseCutPonError) {}
      try {
        ponLayer.locked = true;
      } catch (lockPaperPonError) {}
      try {
        cutPonLayer.locked = true;
      } catch (lockCutPonError) {}
      try {
        doc.activeLayer = artworkLayer;
      } catch (restoreArtworkLayerError2) {}
    }

    // Chọn form theo loại face.
    function ponFor(face) {
      var grid = nominalGridFor(face);
      return { W: grid.paperW, H: grid.paperH };
    }
    // Nhóm PON giấy lấy thẳng từ bản mô tả form, khỏi liệt kê lại.
    function paperKindFor(face) {
      return formSpec(face.type).pon;
    }

    // Các form PON được cung cấp lấy góc trên trái làm gốc toạ độ.
    var startL = selectionLeft;
    var startT = selectionTop;
    if (startL === null || startT === null)
      throw new Error("Không xác định được vị trí object nguồn.");

    // ---- Vị trí artboard theo faces[] ----
    //  - SOLO (TT4/TT8): 1 minh 1 hang (cot 0).
    //  - AB: cặp A|B cùng hàng.
    //  Chiều cao mỗi hàng lấy theo pon của face đầu hàng; row cách nhau GAP_ROW.
    // Mỗi cột trên canvas chừa theo form PON thực tế rộng nhất của lượt chạy này.
    // Nhờ vậy form tham chiếu A5 65 x 86 không phụ thuộc vào form A4.
    var mainW = 0;
    for (var formIndex = 0; formIndex < faces.length; formIndex++) {
      var formW = ponFor(faces[formIndex]).W;
      if (formW > mainW) mainW = formW;
    }

    function readCanvasBounds() {
      // File AI đã lưu có ghi gốc canvas thực tế, không nhất thiết là (0,0).
      var savedCanvas = dcDanTheoMauReadCanvasBounds(doc);
      if (savedCanvas) return savedCanvas;
      // Phương án dự phòng thận trọng cho tài liệu chưa lưu, không có metadata AI.
      var halfSize = 7200;
      try {
        if (doc.scaleFactor && doc.scaleFactor < 1)
          halfSize = halfSize / doc.scaleFactor;
      } catch (canvasScaleError) {}
      return [-halfSize, halfSize, halfSize, -halfSize];
    }

    var canvasRect = readCanvasBounds();
    // Tính cả phần PON giấy thò ra ngay ngoài artboard, cộng thêm một
    // lề an toàn nhỏ, trước khi yêu cầu Illustrator tạo artboard.
    var canvasGuard = 10 * MM + 22;
    var safeLeft = canvasRect[0] + canvasGuard;
    var safeTop = canvasRect[1] - canvasGuard;
    var safeRight = canvasRect[2] - canvasGuard;
    var safeBottom = canvasRect[3] + canvasGuard;
    if (startL < safeLeft || startT > safeTop)
      throw new Error(
        "Object nguồn đang quá sát biên canvas Illustrator; không thể bắt đầu dàn đúng tại vị trí đó.",
      );

    // Mỗi cột bố cục chừa chỗ cho một cặp A|B. Khi chạm biên dưới của
    // canvas, hàng kế tiếp bắt đầu ở cột kế bên, tại startT.
    var layoutColumnWidth = mainW * 2 + GAP_COL;
    var layoutColumnStep = layoutColumnWidth + GAP_COL;
    var columnLeft = startL;
    var usedColumns = 1;
    var columnOffsets = { 0: true };
    var columnOffset = 0;

    function findNextColumn(rowWidth) {
      // Trước hết làm giống CTL KTS (đi tiếp sang phải). Nếu nguồn đã nằm
      // quá sát mép phải canvas thì dùng cột trống tương ứng
      // bên trái trước khi báo là cần Large Canvas.
      for (var distance = 1; distance < 1000; distance++) {
        var rightOffset = distance;
        var rightKey = String(rightOffset);
        var rightLeft = startL + rightOffset * layoutColumnStep;
        if (
          !columnOffsets[rightKey] &&
          rightLeft >= safeLeft &&
          rightLeft + rowWidth <= safeRight
        )
          return { offset: rightOffset, left: rightLeft };

        var leftOffset = -distance;
        var leftKey = String(leftOffset);
        var leftLeft = startL + leftOffset * layoutColumnStep;
        if (
          !columnOffsets[leftKey] &&
          leftLeft >= safeLeft &&
          leftLeft + rowWidth <= safeRight
        )
          return { offset: leftOffset, left: leftLeft };
      }
      throw new Error(
        "Đã hết chỗ trong canvas Illustrator để dàn tiếp CTL Offset. Hãy mở tài liệu Large Canvas rồi chạy lại.",
      );
    }

    function reserveRow(rowWidth, rowHeight, currentTop) {
      if (startT - rowHeight < safeBottom)
        throw new Error(
          "Không đủ chiều cao canvas từ vị trí object nguồn để đặt một tờ CTL Offset.",
        );
      if (usedColumns === 1 && columnLeft + rowWidth > safeRight)
        throw new Error(
          "Tờ CTL Offset đầu tiên không nằm vừa bên phải vị trí object nguồn.",
        );
      while (
        currentTop - rowHeight < safeBottom ||
        columnLeft + rowWidth > safeRight
      ) {
        var nextColumn = findNextColumn(rowWidth);
        columnOffset = nextColumn.offset;
        columnOffsets[String(columnOffset)] = true;
        usedColumns++;
        columnLeft = nextColumn.left;
        currentTop = startT;
      }
      return { left: columnLeft, top: currentTop };
    }

    var abPos = [];
    var curT = startT; // dinh hang hien tai
    var fk = 0;
    while (fk < numFaces) {
      var pA = ponFor(faces[fk]);
      var wA = pA.W,
        hA = pA.H;
      if (faces[fk].solo) {
        var soloRow = reserveRow(wA, hA, curT);
        curT = soloRow.top;
        abPos[fk] = [soloRow.left, curT, soloRow.left + wA, curT - hA];
        curT = curT - hA - GAP_ROW;
        fk++;
      } else {
        var nextPon = fk + 1 < numFaces ? ponFor(faces[fk + 1]) : null;
        var reservedHeight = nextPon && nextPon.H > hA ? nextPon.H : hA;
        var reservedWidth = nextPon ? wA + GAP_COL + nextPon.W : wA;
        var pairRow = reserveRow(reservedWidth, reservedHeight, curT);
        curT = pairRow.top;
        var lA = pairRow.left;
        abPos[fk] = [lA, curT, lA + wA, curT - hA];
        var hRow = hA;
        if (fk + 1 < numFaces) {
          var pB = ponFor(faces[fk + 1]);
          var lB = pairRow.left + wA + GAP_COL;
          abPos[fk + 1] = [lB, curT, lB + pB.W, curT - pB.H];
          if (pB.H > hRow) hRow = pB.H;
        }
        curT = curT - hRow - GAP_ROW;
        fk += 2;
      }
    }

    // ---- Tạo artboard (chưa nhân bản pon - sẽ làm SAU khi đặt trang) ----
    var k = 0;
    try {
      for (; k < numFaces; k++) {
        var pos = abPos[k];
        doc.artboards.add(pos);
      }
    } catch (artboardError) {
      for (
        var rollbackAb = doc.artboards.length - 1;
        rollbackAb >= oldAb;
        rollbackAb--
      ) {
        try {
          doc.artboards.remove(rollbackAb);
        } catch (rollbackError) {}
      }
      throw new Error(
        "Illustrator không tạo được artboard CTL Offset thứ " + (k + 1) + ".",
      );
    }
    prepareSignatureLayers();
    prepareSignaturePages();

    // ---------- đặt trang lên 1 MẶT ----------
    function centerItem(it, cx, cy) {
      var gb = dcKhungHoacBounds(it); // khung Transform, không phải bound nội dung
      if (!gb || gb.length < 4) return;
      var ccx = (gb[0] + gb[2]) / 2,
        ccy = (gb[1] + gb[3]) / 2;
      var dx = cx - ccx,
        dy = cy - ccy;
      if (isNaN(dx) || isNaN(dy)) return;
      try {
        it.translate(dx, dy);
      } catch (e) {}
    }
    //  face.top/bottom = số trang THẬT (1-based).
    //  - Cụm 8 (TT8/AB, 4 cột): đỉnh cụm cách đỉnh artboard 2.3cm;
    //    2 cụm nhỏ 4 trang trái/phải cách nhau MID_GAP (0.8cm).
    //  - Cụm 4 (TT4, 2 cột): CĂN GIỮA artboard (ngang+dọc);
    //    2 cột (2 cụm nhỏ 2 trang) cách nhau MID_GAP_TT4 (0.76cm).
    // Form ruột A5 65 x 86: hai block 2 hàng cách nhau 15 mm.  Mốc trên
    // được đo trực tiếp từ file mẫu (24.351972 mm dưới mép artboard), không
    // dùng TOP_GAP của form A4.

    //  Đặt 1 hàng (top/bottom) cho CỤM 8 (4 cột), căn giữa ngang, đỉnh = cumTop.
    function placeRow8(pageArr, rot, pos, cumTop, rowIsTop, rowTrimH) {
      var acx = (pos[0] + pos[2]) / 2;
      var totalW = pageWpt * 4 + MID_GAP;
      var leftEdge = acx - totalW / 2;
      var trimH = rowTrimH || pageHpt;
      // Neo mép ngoài bằng chiều cao BÀI thật, không bằng chiều cao ô.
      // Nếu A5 tối đa cần allowance, nó nằm ở đường ghép hai hàng bên
      // trong; không đẩy artwork qua mép trên/dưới của giấy.
      var cy = rowIsTop
        ? cumTop - pageHpt / 2
        : cumTop - trimH * 2 + pageHpt / 2;
      for (var c = 0; c < 4; c++) {
        var it = processed[pageArr[c] - 1];
        if (!it) continue;
        if (rot) {
          try {
            it.rotate(180);
          } catch (e) {}
        }
        var extra = c >= 2 ? MID_GAP : 0;
        centerItem(it, leftEdge + c * pageWpt + extra + pageWpt / 2, cy);
      }
    }
    function placeFace8(face, pos) {
      var grid = nominalGridFor(face, pos);
      // SMALL8 chỉ dùng allowance cần thiết trên tờ 64.8 x 41.8. Mép
      // ngoài của bài nằm trong giấy; PON vẫn lấy từ lưới chưa bóp.
      var small8TrimH = grid.trimH;
      var cumTop = face.type === "SMALL8" ? grid.small8Top : grid.a4Top;
      var rowTrimH = face.type === "SMALL8" ? small8TrimH : pageHpt;
      placeRow8(face.top, true, pos, cumTop, true, rowTrimH);
      placeRow8(face.bottom, false, pos, cumTop, false, rowTrimH);

      // ---- BÓP: co ngang mỗi NỬA (cụm 2-trang) theo sheetNo ----
      //  Nửa trái = 4 trang (top[0],top[1],bottom[0],bottom[1]);
      //  nửa phải = 4 trang (top[2],top[3],bottom[2],bottom[3]).
      //  Bề rộng cụm 2-trang gốc = 2*pageWpt. Bóp bớt sheetNo*0.1cm (giữ cao).
      var reducePt = face.sheetNo * BOP_PER_SHEET;
      if (reducePt <= 0) return; // bìa (sheetNo 0) không bóp
      var origW = 2 * pageWpt; // bề rộng cụm 2-trang gốc
      var scaleX = ((origW - reducePt) / origW) * 100;

      // Gom 4 trang của một nửa thành group, co ngang quanh tâm, rồi trả
      // lại layer. Co ngang - giữ cao.
      function squeezeHalf(pArr) {
        var grp = groupPages(pArr);
        if (!grp) return;
        squeezeAboutCentre(grp, scaleX, 100);
        ungroupInto(grp, artworkLayer);
      }
      squeezeHalf([face.top[0], face.top[1], face.bottom[0], face.bottom[1]]); // nửa trái
      squeezeHalf([face.top[2], face.top[3], face.bottom[2], face.bottom[3]]); // nửa phải
    }

    //  Đặt CỤM 4 (TT4): 2 CỤM NHỎ, mỗi cụm 2 trang, XOAY CẢ CỤM 90 độ.
    //  row = [b, a, a+1, b-1] = [76,1,2,75] (N=76).
    //   Cụm TRÁI  = 2 trang (row[0], row[1]) xếp cạnh nhau ngang -> xoay CẢ CỤM 90 CCW.
    //   Cụm PHẢI  = 2 trang (row[2], row[3]) xếp cạnh nhau ngang -> xoay CẢ CỤM 90 CW.
    //  2 cụm cách nhau 0.76cm. Căn giữa artboard.
    function buildPairGroup(pageL, pageR) {
      // gom 2 trang thành 1 group, đặt cạnh nhau ngang (L trái, R phải), căn tâm.
      var itL = processed[pageL - 1],
        itR = processed[pageR - 1];
      if (!itL || !itR) return null;
      // đặt itR ngay bên phải itL (theo bề rộng trang gốc)
      var bl = dcKhungHoacBounds(itL) || itL.geometricBounds;
      var lcx = (bl[0] + bl[2]) / 2,
        lcy = (bl[1] + bl[3]) / 2;
      var br = dcKhungHoacBounds(itR) || itR.geometricBounds;
      var rcx = (br[0] + br[2]) / 2,
        rcy = (br[1] + br[3]) / 2;
      // đưa itR về cùng hàng, cạnh phải itL
      var targetRcx = lcx + pageWpt; // cạnh nhau, không khe trong cụm
      itR.translate(targetRcx - rcx, lcy - rcy);
      // gom group
      var grp = null;
      try {
        grp = artworkLayer.groupItems.add();
        itL.move(grp, ElementPlacement.PLACEATEND);
        itR.move(grp, ElementPlacement.PLACEATEND);
      } catch (e) {
        grp = null;
      }
      return grp;
    }
    function centerGroupAt(grp, cx, cy) {
      if (!grp) return;
      var gb = dcKhungHoacBounds(grp);
      if (!gb) return;
      var gcx = (gb[0] + gb[2]) / 2,
        gcy = (gb[1] + gb[3]) / 2;
      try {
        grp.translate(cx - gcx, cy - gcy);
      } catch (e) {}
    }
    function placeFace4(face, pos) {
      var grid = nominalGridFor(face, pos);
      var acx = grid.cx;
      // Form 43 x 32.5 A5 đặt cụm theo PON cắt ở mép trên, thay vì căn
      // giữa như 65 x 43 A4. Nhờ đó PON và bài luôn cùng vị trí.
      var acy = face.type === "SMALL4" ? grid.coverTop - pageWpt : grid.cy;
      // cụm trái (row0,row1) + cụm phải (row2,row3)
      var gL = buildPairGroup(face.row[0], face.row[1]);
      var gR = buildPairGroup(face.row[2], face.row[3]);
      // xoay cả cụm: trái 90 CCW, phải 90 CW
      if (gL) {
        try {
          gL.rotate(90);
        } catch (e) {}
      }
      if (gR) {
        try {
          gR.rotate(-90);
        } catch (e) {}
      }
      // sau khi xoay, bề rộng 1 cụm = chiều cao trước xoay = pageHpt (1 hàng 1 trang cao)
      // (cụm 2 trang ngang cao = pageHpt, rộng = 2*pageWpt; xoay 90 -> rộng=pageHpt, cao=2*pageWpt)
      var cumW = pageHpt; // bề rộng 1 cụm sau xoay
      var gap4 = face.type === "SMALL4" ? MID_GAP_A5_COVER : MID_GAP_TT4;
      var totalW = cumW * 2 + gap4;
      var leftEdge = acx - totalW / 2;
      centerGroupAt(gL, leftEdge + cumW / 2, acy);
      centerGroupAt(gR, leftEdge + cumW + gap4 + cumW / 2, acy);

      // ---- BÓP DỌC: co chiều DỌC (= bề rộng cụm 2-trang gốc) theo sheetNo ----
      //  Sau xoay 90, chiều "rộng cụm 2-trang gốc" (2*pageWpt) nằm DỌC (cao group).
      //  Bop bot sheetNo*0.1cm o chieu do. Bia (sheetNo 0) không bóp.
      var reducePt4 = face.sheetNo * BOP_PER_SHEET;
      if (reducePt4 > 0) {
        var origH = 2 * pageWpt; // chiều dọc cụm sau xoay
        var scaleY = ((origH - reducePt4) / origH) * 100;
        squeezeAboutCentre(gL, 100, scaleY); // co dọc, giữ ngang
        squeezeAboutCentre(gR, 100, scaleY);
      }
    }

    // Mặt 16 trang khổ nhỏ dùng hai panel 8 trang trên một tờ 65 x 86. Mỗi
    // panel ban đầu là lưới A5 4 x 2, sau đó xoay nguyên cả panel. Hình học này
    // giống hệt form ruột A5 tự trở được cung cấp.
    function placeSmallPanel(panelFace, cx, cy, angle, sheetNo) {
      if (!panelFace) return null;
      // Sau khi xoay, khe này trở thành khe NGANG 15 mm giữa hai block
      // 2-hàng của form 65 x 86 A5.  Không được nén nó thành một đường cắt.
      var rawW = pageWpt * 4 + A5_MAIN_ROW_GAP;
      var rawH = pageHpt * 2;
      var members = [];
      var memberCount = 0;
      var rows = [panelFace.top, panelFace.bottom];
      for (var row = 0; row < 2; row++) {
        var pageArr = rows[row];
        for (var col = 0; col < 4; col++) {
          var item = processed[pageArr[col] - 1];
          if (!item) continue;
          if (row === 0) {
            try {
              item.rotate(180);
            } catch (smallPanelRotateError) {
              throw new Error(
                "Không xoay được trang trên của khối ruột A5: " +
                  smallPanelRotateError,
              );
            }
          }
          centerItem(
            item,
            cx -
              rawW / 2 +
              col * pageWpt +
              (col >= 2 ? A5_MAIN_ROW_GAP : 0) +
              pageWpt / 2,
            cy + rawH / 2 - row * pageHpt - pageHpt / 2,
          );
          members[row * 4 + col] = item;
          memberCount++;
        }
      }
      if (memberCount !== 8)
        throw new Error(
          "Khối ruột A5 thiếu trang để dàn: " + memberCount + "/8.",
        );
      var panel = null;
      try {
        panel = artworkLayer.groupItems.add();
        for (var mi = 0; mi < members.length; mi++)
          if (members[mi]) members[mi].move(panel, ElementPlacement.PLACEATEND);
        panel.rotate(angle);
        centerGroupAt(panel, cx, cy);
      } catch (smallPanelGroupError) {
        throw new Error(
          "Không tạo được khối dàn ruột A5: " + smallPanelGroupError,
        );
      }
      if (!panel || sheetNo <= 0) return panel;

      // Sau khi xoay ±90°, rãnh 15 mm chạy theo chiều dọc. Không co
      // cả panel: co riêng từng khối 2 cột của nó quanh
      // tâm của chính khối đó. Rãnh vẫn là khe trống và mở rộng thêm đúng bằng
      // mức bóp; PON giấy/PON cắt vẫn nằm trên lưới danh định trước khi bóp.
      var reducePt = sheetNo * BOP_PER_SHEET;
      var nominalBlockH = pageWpt * 2;
      if (reducePt <= 0) return panel;
      if (reducePt >= nominalBlockH)
        throw new Error("Mức bóp ruột A5 lớn hơn khối trang gốc.");
      var blockScaleY = ((nominalBlockH - reducePt) / nominalBlockH) * 100;

      // Không co cả panel: co riêng từng khối 2 cột quanh tâm của nó, để
      // khe 15 mm ở giữa vẫn là rãnh trống, không bị kéo thành đường cắt.
      // PON giấy và PON cắt vẫn đứng ở lưới danh định trước khi bóp.
      function squeezeBlock(indexes) {
        var block = panel.groupItems.add();
        var moved = 0;
        for (var i = 0; i < indexes.length; i++) {
          var member = members[indexes[i]];
          if (!member) continue;
          try {
            member.move(block, ElementPlacement.PLACEATEND);
            moved++;
          } catch (moveMemberError) {}
        }
        if (moved === 0) {
          try {
            block.remove();
          } catch (dropEmptyBlockError) {}
          throw new Error("Không tạo được khối bóp ruột A5.");
        }
        squeezeAboutCentre(block, 100, blockScaleY);
        ungroupInto(block, panel);
      }

      try {
        squeezeBlock([0, 1, 4, 5]);
        squeezeBlock([2, 3, 6, 7]);
      } catch (smallPanelSqueezeError) {
        throw new Error(
          "Không bóp được khối ruột A5: " + smallPanelSqueezeError,
        );
      }
      return panel;
    }

    function placeSmallFace16(face, pos) {
      var grid = nominalGridFor(face, pos);
      var acx = grid.cx;
      // Khớp với form A5 65 x 86: 4 x 4 trang đã xoay, một rãnh dọc
      // 6 mm, một rãnh ngang 15 mm, và mốc đỉnh đã đo.
      var panelH = pageWpt * 4 + A5_MAIN_ROW_GAP;
      // Lề dưới giờ là 3 mm dương nên lưới nằm trọn trong artboard; không
      // còn phải nhấc bù như bản cũ (fitLift đã bỏ).
      var acy = grid.mainGridTop - panelH / 2;
      var panelW = pageHpt * 2;
      var totalW = panelW * 2 + MID_GAP_A5_MAIN;
      var leftCx = acx - totalW / 2 + panelW / 2;
      var rightCx = leftCx + panelW + MID_GAP_A5_MAIN;
      placeSmallPanel(face.leftFace, leftCx, acy, 90, face.sheetNo);
      placeSmallPanel(face.rightFace, rightCx, acy, -90, face.sheetNo);
    }

    function placeFace(face, pos) {
      if (face.type === "TT4" || face.type === "SMALL4") placeFace4(face, pos);
      else if (face.type === "SMALL16" || face.type === "SMALLAB")
        placeSmallFace16(face, pos);
      else placeFace8(face, pos);
    }

    // Vẽ PON danh định trước khi đặt bài. PON giấy canh theo tâm artboard. Các
    // form A5 được cung cấp giữ lưới cắt danh định đã đo; A4 dùng cùng
    // quy tắc đó, chỉ riêng phần bài của nó bị bóp 1 mm mỗi tờ.
    var cutPonCount = 0;
    for (var kc = 0; kc < numFaces; kc++) {
      cutPonCount += addAutoCutPon(cutPonLayer, faces[kc], abPos[kc]);
    }
    for (var kp = 0; kp < numFaces; kp++) {
      addAutoPon(ponLayer, abPos[kp], paperKindFor(faces[kp]));
    }
    var nominalPonGeometry = capturePonGeometry(ponLayer).concat(
      capturePonGeometry(cutPonLayer),
    );
    lockNominalPonLayersOnTop();

    // Bài chỉ được đặt sau khi PON danh định đã vẽ và khoá xong. Nhờ vậy
    // phần bóp tăng dần bên dưới không thể làm xê dịch PON cắt hay PON giấy.
    for (var ff = 0; ff < numFaces; ff++) {
      placeFace(faces[ff], abPos[ff]);
    }

    // ============================================================
    //  GHI CHU "RUOT N" (+ text them). A5 dùng các vùng trống được đo riêng
    //  cho nó; A4 TT4 giữ ghi chú dọc, còn A4 TT8/AB giữ ghi chú ngang.
    //   - TT4 (65x43): chữ DỌC, cách mép DƯỚI lên 1.5cm, mép TRÁI vào 0.9cm.
    //   - TT8/AB (65x86): chữ NGANG, cách mép TRÁI vào 2cm, mep TREN xuong 1.1cm.
    //   - Mép = mép ARTBOARD.
    //   - TT: điền cho artboard đó. AB: chỉ điền MẶT A (ben trai), mặt B bỏ trống.
    //   - Bìa chỉ nhận ghi chú nếu người dùng điền nội dung bìa.
    // ============================================================
    // Chi hien o ghi chu rieng khi dung loai to do thuc su co trong bai.
    var hasTT4Ruot = false;
    var hasTT8Ruot = false;
    var hasABRuot = false;
    var hasSmall4Ruot = false;
    var hasSmall8Ruot = false;
    var hasSmall16Ruot = false;
    var hasSmallABRuot = false;
    var hasBia = false;
    for (var noteFaceIndex = 0; noteFaceIndex < numFaces; noteFaceIndex++) {
      var noteFace = faces[noteFaceIndex];
      if (noteFace.sheetNo <= 0) {
        hasBia = true;
        continue;
      }
      if (noteFace.type === "TT4") hasTT4Ruot = true;
      else if (noteFace.type === "TT8") hasTT8Ruot = true;
      else if (noteFace.type === "AB") hasABRuot = true;
      else if (noteFace.type === "SMALL4") hasSmall4Ruot = true;
      else if (noteFace.type === "SMALL8") hasSmall8Ruot = true;
      else if (noteFace.type === "SMALL16") hasSmall16Ruot = true;
      else if (noteFace.type === "SMALLAB") hasSmallABRuot = true;
    }

    function showNoteDialog() {
      var w = new Window("dialog", "Nhập ghi chú");
      w.orientation = "column";
      w.alignChildren = "fill";
      w.margins = 16;
      w.spacing = 10;
      function addRedLabel(text) {
        var label = w.add("statictext", undefined, text);
        try {
          label.graphics.foregroundColor = label.graphics.newPen(
            label.graphics.PenType.SOLID_COLOR,
            [1, 0, 0, 1],
            1,
          );
        } catch (labelColorError) {}
        return label;
      }
      var edBia = null;
      if (hasBia) {
        w.add("statictext", undefined, "Ghi chú BÌA (không tự thêm chữ):");
        edBia = w.add("edittext", undefined, "");
        edBia.characters = 40;
      }
      var edTT4 = null;
      var edTT8 = null;
      var edAB = null;
      var edSmall4 = null;
      var edSmall8 = null;
      var edSmall16 = null;
      var edSmallAB = null;
      if (IS_SMALL_A5) {
        if (hasSmall4Ruot) {
          addRedLabel("Ghi chú TỰ TRỞ A5 (4 trang):");
          edSmall4 = w.add("edittext", undefined, "");
          edSmall4.characters = 40;
        }
        if (hasSmall8Ruot) {
          addRedLabel("Ghi chú TỰ TRỞ A5 (8 trang):");
          edSmall8 = w.add("edittext", undefined, "");
          edSmall8.characters = 40;
        }
        if (hasSmall16Ruot) {
          addRedLabel("Ghi chú TỰ TRỞ A5 (16 trang):");
          edSmall16 = w.add("edittext", undefined, "");
          edSmall16.characters = 40;
        }
        if (hasSmallABRuot) {
          addRedLabel("Ghi chú TỜ AB A5 (32 trang, chỉ mặt A):");
          edSmallAB = w.add("edittext", undefined, "");
          edSmallAB.characters = 40;
        }
      } else {
        if (hasTT4Ruot) {
          addRedLabel("Ghi chú TỰ TRỞ A4 (4 trang):");
          edTT4 = w.add("edittext", undefined, "");
          edTT4.characters = 40;
        }
        if (hasTT8Ruot) {
          addRedLabel("Ghi chú TỰ TRỞ A4 (8 trang):");
          edTT8 = w.add("edittext", undefined, "");
          edTT8.characters = 40;
        }
        if (hasABRuot) {
          addRedLabel("Ghi chú TỜ AB (16 trang, chỉ mặt A):");
          edAB = w.add("edittext", undefined, "");
          edAB.characters = 40;
        }
      }
      var row = w.add("group");
      row.alignment = "right";
      var btnCancel = row.add("button", undefined, "Bỏ qua", {
        name: "cancel",
      });
      var btnOK = row.add("button", undefined, "Điền ghi chú", { name: "ok" });
      var res = null;
      btnOK.onClick = function () {
        res = {
          bia: edBia ? edBia.text : "",
          tt4: edTT4 ? edTT4.text : "",
          tt8: edTT8 ? edTT8.text : "",
          ab: edAB ? edAB.text : "",
          small4: edSmall4 ? edSmall4.text : "",
          small8: edSmall8 ? edSmall8.text : "",
          small16: edSmall16 ? edSmall16.text : "",
          smallAB: edSmallAB ? edSmallAB.text : "",
        };
        w.close();
      };
      btnCancel.onClick = function () {
        res = null;
        w.close();
      };
      w.show();
      return res;
    }

    // Icon duoc duplicate nguyen vector tu file nguon; khong resize o bat ky
    // buoc nao. Template an di, moi ghi chu lay mot ban sao moi tu template.
    // Thiếu file icon (máy khác, chưa chép assets/icon.ai) → null: ghi chú vẫn điền, không có icon.
    function loadNoteIconTemplate() {
      var iconFile = dcNoteIconFile();
      if (!iconFile) return null;
      var iconDoc = app.open(iconFile);
      var roots = [];
      for (var ii = 0; ii < iconDoc.pageItems.length; ii++) {
        var candidate = iconDoc.pageItems[ii];
        try {
          if (candidate.parent && candidate.parent.typename === "Layer")
            roots.push(candidate);
        } catch (iconRootError) {}
      }
      if (roots.length === 0) {
        iconDoc.close(SaveOptions.DONOTSAVECHANGES);
        throw new Error("icon.ai không có artwork để duplicate.");
      }
      var sourceGroup = iconDoc.groupItems.add();
      for (var ir = roots.length - 1; ir >= 0; ir--) {
        try {
          roots[ir].move(sourceGroup, ElementPlacement.PLACEATBEGINNING);
        } catch (iconMoveError) {}
      }
      var template = null;
      try {
        template = sourceGroup.duplicate(
          artworkLayer,
          ElementPlacement.PLACEATEND,
        );
        template.name = "_Mau icon ghi chu CTL Offset";
        template.hidden = true;
      } catch (iconCopyError) {}
      try {
        iconDoc.close(SaveOptions.DONOTSAVECHANGES);
      } catch (iconCloseError) {}
      try {
        app.activeDocument = doc;
      } catch (iconReturnDocError) {}
      if (!template)
        throw new Error("Không duplicate được icon ghi chú vào bài đang dàn.");
      return template;
    }

    var noteIconTemplate = null;
    function duplicateNoteIcon() {
      if (!noteIconTemplate) return null;
      try {
        var iconCopy = noteIconTemplate.duplicate(
          artworkLayer,
          ElementPlacement.PLACEATEND,
        );
        iconCopy.hidden = false;
        return iconCopy;
      } catch (iconDuplicateError) {
        return null;
      }
    }
    function moveCenterTo(item, x, y) {
      if (!item) return;
      try {
        var b = item.geometricBounds;
        item.translate(x - (b[0] + b[2]) / 2, y - (b[1] + b[3]) / 2);
      } catch (iconPositionError) {}
    }

    function setNoteStyle(tf, isRed) {
      try {
        tf.textRange.characterAttributes.size = 13;
      } catch (e) {}
      try {
        var ink = new CMYKColor();
        if (isRed) {
          ink.cyan = 0;
          ink.magenta = 100;
          ink.yellow = 100;
          ink.black = 0;
        } else {
          ink.cyan = 0;
          ink.magenta = 0;
          ink.yellow = 0;
          ink.black = 100;
        }
        tf.textRange.characterAttributes.fillColor = ink;
      } catch (e) {
        try {
          var rgb = new RGBColor();
          rgb.red = isRed ? 255 : 0;
          rgb.green = 0;
          rgb.blue = 0;
          tf.textRange.characterAttributes.fillColor = rgb;
        } catch (e2) {}
      }
    }
    //  Ghi chú cho TT4 (chữ DỌC): mép dưới lên 1.5cm, mép trái vào 0.9cm.
    function addNote4(text, pos, isRed) {
      if (!text) return;
      try {
        var icon = duplicateNoteIcon();
        var iconH = 0;
        if (icon) {
          try {
            var ib = icon.geometricBounds;
            iconH = ib[1] - ib[3];
          } catch (iconBoundsError) {}
        }
        var tf = artworkLayer.textFrames.add();
        tf.contents = text;
        setNoteStyle(tf, isRed);
        var abLeft = pos[0],
          abBottom = pos[3];
        var targetLeft = abLeft + 9 * MM; // mép trái vào 0.9cm
        var targetBottom = abBottom + 15 * MM; // mép dưới lên 1.5cm (day chu)
        // xoay chữ dọc trước, rồi đặt theo bounds
        tf.position = [0, 0];
        try {
          tf.rotate(90);
        } catch (e) {} // chữ dọc (đọc từ dưới lên)
        var tb = tf.visibleBounds; // [l,t,r,b]
        // Icon dung thang o dau chieu doc; chu bat dau phia tren icon.
        var textBottom = targetBottom + (icon ? iconH + 3 : 0);
        tf.translate(targetLeft - tb[0], textBottom - tb[3]);
        if (icon) {
          tb = tf.visibleBounds;
          moveCenterTo(icon, (tb[0] + tb[2]) / 2, targetBottom + iconH / 2);
        }
      } catch (e) {}
    }
    //  Ghi chú ngang cho TT8/AB A4: mép trái vào 2cm, mép trên xuống 1.1cm.
    // Đặt trọn ghi chú A5 vào một dải trống thật, không chỉ riêng đường chân chữ.
    // Icon giữ nguyên kích thước gốc; SMALL8 luôn dùng dải phía dưới bên trái.
    function a5NotePlacement(
      rect,
      artwork,
      width,
      height,
      ponBounds,
      prefer,
      sideOnly,
      leftOnly,
    ) {
      var inset = 1 * MM,
        artClear = 2 * MM,
        ponClear = 0.5 * MM;
      var l = rect[0] + inset,
        t = rect[1] - inset;
      var r = rect[2] - inset,
        b = rect[3] + inset;
      var zones = [];
      if (!sideOnly) {
        zones.push([l, t, r, Math.max(b, artwork[1] + artClear)]);
        zones.push([l, Math.min(t, artwork[3] - artClear), r, b]);
      }
      zones.push([l, t, Math.min(r, artwork[0] - artClear), b]);
      if (!leftOnly) zones.push([Math.max(l, artwork[2] + artClear), t, r, b]);
      function overlaps(a, obstacle) {
        return (
          a[0] < obstacle[2] + ponClear &&
          a[2] > obstacle[0] - ponClear &&
          a[3] < obstacle[1] + ponClear &&
          a[1] > obstacle[3] - ponClear
        );
      }
      function clamp(value, lo, hi) {
        return Math.max(lo, Math.min(hi, value));
      }
      for (var zi = 0; zi < zones.length; zi++) {
        var z = zones[zi];
        if (z[2] - z[0] < width - 0.001 || z[1] - z[3] < height - 0.001)
          continue;
        var xs = [clamp(prefer[0], z[0], z[2] - width)];
        var ys = [clamp(prefer[1], z[3] + height, z[1])];
        if (!leftOnly) {
          xs.push(z[0], z[2] - width);
          ys.push(z[1], z[3] + height);
        }
        for (var oi = 0; oi < ponBounds.length; oi++) {
          var obstacle = ponBounds[oi];
          if (
            obstacle[2] < z[0] - ponClear ||
            obstacle[0] > z[2] + ponClear ||
            obstacle[1] < z[3] - ponClear ||
            obstacle[3] > z[1] + ponClear
          )
            continue;
          xs.push(obstacle[2] + ponClear, obstacle[0] - ponClear - width);
          ys.push(obstacle[3] - ponClear, obstacle[1] + ponClear + height);
        }
        if (leftOnly) {
          xs.push(z[0], z[2] - width);
          ys.push(z[3] + height, z[1]);
        }
        for (var yi = 0; yi < ys.length; yi++)
          for (var xi = 0; xi < xs.length; xi++) {
            var x = xs[xi],
              y = ys[yi];
            if (
              x < z[0] - 0.001 ||
              x + width > z[2] + 0.001 ||
              y > z[1] + 0.001 ||
              y - height < z[3] - 0.001
            )
              continue;
            var candidate = [x, y, x + width, y - height],
              clear = true;
            for (oi = 0; oi < ponBounds.length; oi++) {
              if (overlaps(candidate, ponBounds[oi])) {
                clear = false;
                break;
              }
            }
            if (clear) return { left: x, top: y, zone: zi, bounds: candidate };
          }
      }
      return null;
    }
    function addNoteA5(text, pos, isRed, face) {
      if (!text) return;
      var icon = null,
        tf = null;
      try {
        function bounds(item) {
          var v = item.visibleBounds;
          return [v[0], v[1], v[2], v[3]];
        }
        function union(a, v) {
          if (!a) return v.slice(0);
          return [
            Math.min(a[0], v[0]),
            Math.max(a[1], v[1]),
            Math.max(a[2], v[2]),
            Math.min(a[3], v[3]),
          ];
        }
        var artwork = null,
          seen = {};
        function readFacePages(part) {
          if (!part) return;
          var lists = [part.row, part.top, part.bottom];
          for (var li = 0; li < lists.length; li++) {
            var list = lists[li];
            if (!list) continue;
            for (var pi = 0; pi < list.length; pi++) {
              var pageNo = list[pi];
              if (seen[String(pageNo)]) continue;
              seen[String(pageNo)] = true;
              var page = processed[pageNo - 1];
              if (!page)
                throw new Error("Thiếu trang để đo vùng trống ghi chú.");
              artwork = union(artwork, bounds(page));
            }
          }
          readFacePages(part.leftFace);
          readFacePages(part.rightFace);
        }
        readFacePages(face);
        if (!artwork) throw new Error("Không đo được vùng trống ghi chú A5.");

        // Dùng các dấu PON danh định đã lưu, tính cả nửa độ dày nét của chúng.
        // Cách này không đọc bounds bài/PON nào còn có thể thay đổi sau khi bóp.
        var obstacles = [];
        for (var gi = 0; gi < nominalPonGeometry.length; gi++) {
          var mark = nominalPonGeometry[gi],
            mb = null;
          for (var qi = 0; qi < mark.points.length; qi++) {
            var point = mark.points[qi];
            mb = union(mb, [point[0], point[1], point[0], point[1]]);
          }
          if (!mb) continue;
          var halfStroke = mark.strokeWidth / 2;
          mb = [
            mb[0] - halfStroke,
            mb[1] + halfStroke,
            mb[2] + halfStroke,
            mb[3] - halfStroke,
          ];
          if (
            mb[2] >= pos[0] &&
            mb[0] <= pos[2] &&
            mb[1] >= pos[3] &&
            mb[3] <= pos[1]
          )
            obstacles.push(mb);
        }

        icon = duplicateNoteIcon();
        tf = artworkLayer.textFrames.add();
        tf.contents = text;
        setNoteStyle(tf, isRed);
        var textX, textY;
        if (face.type === "SMALL4") {
          textX = pos[0] + 6.637 * MM;
          textY = pos[1] - 5.342 * MM;
        } else if (face.type === "SMALL16" || face.type === "SMALLAB") {
          textX = pos[0] + 12.968 * MM;
          textY = pos[1] - 17.202 * MM;
        } else {
          textX = pos[0] + 8 * MM;
          textY = pos[1] - 8 * MM;
        }
        var rotation = 0;
        function arrange(vertical) {
          if (rotation) tf.rotate(-rotation);
          rotation = vertical ? 90 : 0;
          if (rotation) tf.rotate(rotation);
          tf.position = [textX, textY];
          if (icon) {
            var tb = bounds(tf),
              ib = bounds(icon);
            var iw = ib[2] - ib[0],
              ih = ib[1] - ib[3];
            if (vertical) {
              // Icon đứng thẳng nằm dưới chữ, giống kiểu ghi chú A4 hiện có.
              var cx = (tb[0] + tb[2]) / 2;
              icon.translate(cx - (ib[0] + ib[2]) / 2, tb[3] - 3 - ib[1]);
            } else {
              icon.translate(
                tb[0] - 3 - iw - ib[0],
                (tb[1] + tb[3]) / 2 + ih / 2 - ib[1],
              );
            }
          }
          return icon ? union(bounds(tf), bounds(icon)) : bounds(tf);
        }
        function findPlacement(block, sideOnly) {
          var lowerLeft = face.type === "SMALL8";
          return a5NotePlacement(
            pos,
            artwork,
            block[2] - block[0],
            block[1] - block[3],
            obstacles,
            lowerLeft
              ? [pos[0] + 9 * MM, pos[3] + 15 * MM + block[1] - block[3]]
              : [block[0], block[1]],
            sideOnly,
            lowerLeft,
          );
        }
        // Point text được đo lại sau mỗi lần ngắt dòng/xoay; không dùng
        // độ rộng font hay đường chân chữ ước đoán để ép chữ nằm trong biên giấy.
        function wrapText(contents, maxWidth) {
          if (rotation) {
            tf.rotate(-rotation);
            rotation = 0;
          }
          var paragraphs = String(contents)
            .replace(/\r\n/g, "\n")
            .replace(/\r/g, "\n")
            .split("\n");
          var lines = [];
          function fitsLine(value) {
            tf.contents = value;
            var v = bounds(tf);
            return v[2] - v[0] <= maxWidth + 0.001;
          }
          for (var paragraph = 0; paragraph < paragraphs.length; paragraph++) {
            var words = paragraphs[paragraph].split(/\s+/),
              line = "";
            for (var wi = 0; wi < words.length; wi++) {
              var word = words[wi];
              if (!word) continue;
              var combined = line ? line + " " + word : word;
              if (fitsLine(combined)) {
                line = combined;
                continue;
              }
              if (line) {
                lines.push(line);
                line = "";
              }
              while (word && !fitsLine(word)) {
                var lo = 1,
                  hi = word.length,
                  best = 0;
                while (lo <= hi) {
                  var middle = Math.floor((lo + hi) / 2);
                  if (fitsLine(word.substring(0, middle))) {
                    best = middle;
                    lo = middle + 1;
                  } else hi = middle - 1;
                }
                if (!best)
                  throw new Error("Không đủ chỗ ghi chú A5 ở cỡ chữ hiện tại.");
                lines.push(word.substring(0, best));
                word = word.substring(best);
              }
              line = word;
            }
            lines.push(line);
          }
          return lines.join("\r");
        }
        var small8Vertical = face.type === "SMALL8";
        var block = arrange(small8Vertical),
          placement = findPlacement(block, small8Vertical);
        if (!placement) {
          block = arrange(true);
          placement = findPlacement(block, true);
        }
        var ib = icon ? bounds(icon) : null;
        if (!placement && !small8Vertical) {
          tf.contents = wrapText(
            text,
            pos[2] - pos[0] - 2 * MM - (ib ? ib[2] - ib[0] + 3 : 0),
          );
          block = arrange(false);
          placement = findPlacement(block, false);
        }
        if (!placement) {
          tf.contents = wrapText(
            text,
            pos[1] -
              pos[3] -
              (small8Vertical ? 16 : 2) * MM -
              (ib ? ib[1] - ib[3] + 3 : 0),
          );
          block = arrange(true);
          placement = findPlacement(block, true);
        }
        if (!placement)
          throw new Error(
            "Ghi chú A5 quá dài để nằm trong vùng trống của tờ. Hãy rút ngắn ghi chú.",
          );
        var dx = placement.left - block[0],
          dy = placement.top - block[1];
        tf.translate(dx, dy);
        if (icon) icon.translate(dx, dy);
      } catch (a5NoteError) {
        try {
          if (tf) tf.remove();
        } catch (removeNoteTextError) {}
        try {
          if (icon) icon.remove();
        } catch (removeNoteIconError) {}
        try {
          if (noteIconTemplate) noteIconTemplate.remove();
        } catch (removeNoteTemplateError) {}
        noteIconTemplate = null;
        throw a5NoteError;
      }
    }

    function addNote8(text, pos, isRed) {
      if (!text) return;
      try {
        var icon = duplicateNoteIcon();
        var iconW = 0;
        if (icon) {
          try {
            var ib = icon.geometricBounds;
            iconW = ib[2] - ib[0];
          } catch (iconBoundsError) {}
        }
        var tf = artworkLayer.textFrames.add();
        tf.contents = text;
        setNoteStyle(tf, isRed);
        var abLeft = pos[0],
          abTop = pos[1];
        var x = abLeft + 20 * MM; // mép trái vào 2cm
        var y = abTop - 11 * MM; // mép trên xuống 1.1cm
        tf.position = [x + (icon ? iconW + 3 : 0), y];
        if (icon) {
          var tb = tf.visibleBounds;
          moveCenterTo(icon, x + iconW / 2, (tb[1] + tb[3]) / 2);
        }
      } catch (e) {}
    }

    var note = showNoteDialog();
    var noteIconMissing = false;
    if (note) {
      noteIconTemplate = loadNoteIconTemplate();
      noteIconMissing = !noteIconTemplate;
      for (var ni = 0; ni < numFaces; ni++) {
        var face = faces[ni];
        // AB: chỉ điền MẶT A (label ket thuc " - A"); mặt B bỏ qua.
        if (
          (face.type === "AB" || face.type === "SMALLAB") &&
          face.label.indexOf("- B") >= 0
        )
          continue;
        if (face.sheetNo <= 0) {
          // BÌA (sheetNo 0): A5 dùng vùng an toàn A5 đã đo; A4 TT4 giữ
          // ghi chú dọc của form 65 x 43.
          if (note.bia) {
            if (IS_SMALL_A5) addNoteA5(note.bia, abPos[ni], false, face);
            else addNote4(note.bia, abPos[ni], false);
          }
          continue;
        }
        // Moi loai to co o ghi chu rieng; no duoc ve mau do de nhan biet
        // khi ra binh. Bo trong o thi chi con nhan RUOT N tu dong.
        var specificText = "";
        if (face.type === "TT4") specificText = note.tt4;
        else if (face.type === "TT8") specificText = note.tt8;
        else if (face.type === "AB") specificText = note.ab;
        else if (face.type === "SMALL4") specificText = note.small4;
        else if (face.type === "SMALL8") specificText = note.small8;
        else if (face.type === "SMALL16") specificText = note.small16;
        else if (face.type === "SMALLAB") specificText = note.smallAB;
        var isSpecificRed = specificText ? true : false;
        var noteTail = specificText;
        var txt = "RUỘT " + face.sheetNo + (noteTail ? " " + noteTail : "");
        if (IS_SMALL_A5) addNoteA5(txt, abPos[ni], isSpecificRed, face);
        else if (face.type === "TT4") addNote4(txt, abPos[ni], isSpecificRed);
        else addNote8(txt, abPos[ni], isSpecificRed);
      }
      try {
        if (noteIconTemplate) noteIconTemplate.remove();
      } catch (iconTemplateRemoveError) {}
      noteIconTemplate = null;
    }

    // Bước này cố ý đặt sau toàn bộ việc đặt bài, bóp và làm ghi chú.
    // Bất biến cuối cùng: PON tự vẽ vẫn nằm đúng toạ độ giấy/lưới danh định
    // đã ghi lại trước khi bài ruột bị bóp.
    unlockNominalPonLayers();
    var restoredPonCount = restoreNominalPonGeometry(nominalPonGeometry);
    lockNominalPonLayersOnTop();

    dcRemoveOldCanvasArtboards(doc, oldAb);
    app.redraw();
    alert(
      "Đã dàn " +
        numFaces +
        " artboard.\n" +
        (IS_SMALL_A5
          ? "A5: artboard/PON lấy theo kích thước trang đã nhập; ruột được bóp dần, PON giữ lưới gốc.\n"
          : "Dư " +
            du +
            " -> tự trở trước (4 và/hoặc 8), rồi các tờ AB; PON giữ lưới gốc.\n") +
        (hasTT4 ? "TT4 dùng PON tự vẽ theo kích thước đã nhập.\n" : "") +
        "PON tự vẽ nằm trên cùng. " +
        (note ? "Ghi chú đã xử lý." : "Đã bỏ qua ghi chú."),
    );
    var ponNote =
      "OK: Đã dàn CTL Offset; đã vẽ " + cutPonCount + " nét PON cắt." + dcCauCanhBaoPhong(canhBaoPhong);
    if (noteIconMissing) ponNote += DC_THIEU_ICON_GHI_CHU;
    if (ponClampCount > 0)
      ponNote +=
        " Lưu ý: " +
        ponClampCount +
        " mốc PON bị kéo về mép artboard vì lưới danh định của form này lòi ra ngoài khổ giấy.";
    // Kèm danh sách khổ vừa dàn để panel hiện nút Lưu PDF cho từng khổ.
    return ponNote + dcCtlOffsetPdfPlan(doc, faces, abPos);
  } catch (e) {
    return "ERR: signature8: " + e.toString();
  } finally {
    app.coordinateSystem = previousSignatureCoordinates;
  }
}

// ============================================================
//  LƯU PDF THEO KHỔ — CTL Offset (Đóng ghim giữa + Keo gáy)
//
//  Dàn xong, bài có khổ nào thì panel hiện nút Lưu PDF của khổ đó, giống
//  bảng ghi chú chỉ hiện ô của loại tờ thật sự có trong bài.
//
//  Mỗi TỜ in là một file PDF:
//    - Bìa            -> BIA.pdf      (1 trang)
//    - Tự trở         -> RUOT N.pdf   (1 trang)
//    - Tờ AB          -> RUOT N.pdf   (2 trang: mặt A rồi mặt B)
//  Số N trùng với ghi chú "RUỘT N" in trên tờ.
//
//  Không lưu đè file AI đang mở: chép trực tiếp các object/layer sang tài
//  liệu tạm rồi lưu AI (entry PDF cũ vẫn dùng chung cơ chế an toàn).
//  Không group/undo hay mở khoá trong tài liệu nguồn.
// ============================================================
var dcCtlOffsetPdfVersion = 6;

// Action Export As native, không phải bộ xuất script Save-for-Web chỉ có RGB.
// Trường raw của JPEG: quality/method/scans/AA/DPI fixed-point/color/map/profile.
// Giao thức đã test trên Illustrator 28; xem tests/ctl_package_native.jsx.
function dcCtlJpegActionText(path, setName) {
  function hexByte(n) {
    return ("0" + (n & 255).toString(16)).slice(-2);
  }
  function utf8Hex(s) {
    var bytes = unescape(encodeURIComponent(s)),
      result = "";
    for (var i = 0; i < bytes.length; i++)
      result += hexByte(bytes.charCodeAt(i));
    return "[ " + bytes.length + " " + result + " ]";
  }
  var bytes = [],
    values = [10, 0, 3, 3, 300 * 65536, 2, 0, 1],
    i;
  for (i = 0; i < 100; i++) bytes.push(0);
  for (i = 0; i < values.length; i++)
    for (var j = 0; j < 4; j++)
      bytes[i * 4 + j] = (values[i] >>> (8 * j)) & 255;
  var mapLabel = "imagemap";
  for (i = 0; i < mapLabel.length; i++)
    bytes[32 + i * 2] = mapLabel.charCodeAt(i);
  bytes[98] = 1; // nhúng ICC profile
  var raw = "";
  for (i = 0; i < bytes.length; i++) raw += hexByte(bytes[i]);
  function param(key, type, value) {
    return (
      "/parameter-" +
      ++count +
      " { /key " +
      key +
      " /showInPalette -1 /type (" +
      type +
      ") /value " +
      value +
      " }\n"
    );
  }
  var count = 1;
  return (
    "/version 3\n/name " +
    utf8Hex(setName) +
    "\n/isOpen 0\n/actionCount 1\n" +
    "/action-1 { /name " +
    utf8Hex("Export") +
    " /keyIndex 0 /colorIndex 0 /isOpen 0 /eventCount 1\n" +
    "/event-1 { /useRulersIn1stQuadrant 0 /internalName (adobe_exportDocument) /isOpen 0 /isOn 1 /hasDialog 1 /showDialog 0 /parameterCount 7\n" +
    "/parameter-1 { /key 1885434477 /showInPalette 0 /type (raw) /value < 100 " +
    raw +
    " > /size 100 }\n" +
    param(1851878757, "ustring", utf8Hex(path)) +
    param(1718775156, "ustring", utf8Hex("JPEG file format")) +
    param(1702392942, "ustring", utf8Hex("jpg,jpe,jpeg")) +
    param(1936548194, "boolean", "0") + // Use Artboards TẮT: một JPG gộp duy nhất
    param(1935764588, "boolean", "1") +
    param(1936875886, "ustring", "[ 0 ]") +
    "} }\n"
  );
}
function dcCtlExportJpeg(doc, file) {
  var setName =
    "CTL_JPG_" +
    new Date().getTime() +
    "_" +
    Math.floor(Math.random() * 1000000);
  var actionFile = new File(Folder.temp.fsName + "/" + setName + ".aia"),
    loaded = false;
  if (actionFile.exists) throw new Error("Trùng file action tạm; hãy thử lại.");
  try {
    actionFile.encoding = "UTF-8";
    if (!actionFile.open("w"))
      throw new Error("Không ghi được action JPG tạm.");
    actionFile.write(dcCtlJpegActionText(file.fsName, setName));
    actionFile.close();
    doc.activate();
    app.loadAction(actionFile);
    loaded = true;
    app.doScript("Export", setName, false);
    if (!file.exists || file.length <= 0)
      throw new Error("Illustrator chưa tạo được JPG.");
  } finally {
    if (loaded) {
      try {
        app.unloadAction(setName, "");
      } catch (unloadError) {}
    }
    try {
      actionFile.close();
    } catch (closeError) {}
    if (actionFile.exists) actionFile.remove();
  }
}

// Gọi ở cuối lượt dàn. Trả về đuôi "||CTLPDF:{...}" để gắn sau chuỗi OK;
// panel đọc đuôi này để biết bài có những khổ nào, mỗi khổ gồm những tờ nào
// và tờ đó nằm ở artboard số mấy.
// Lỗi ở đây không được làm hỏng lượt dàn: có gì bất thường thì trả "" và
// panel đơn giản là không hiện nút.
function dcCtlOffsetPdfPlan(doc, faces, abPos) {
  try {
    var total = doc.artboards.length;
    var used = {};
    var groups = [];
    var groupByKey = {};
    // Tìm artboard theo đúng toạ độ đã tạo, không đoán theo số thứ tự: nếu
    // Illustrator không xoá được artboard cũ thì số thứ tự sẽ lệch.
    function findArtboard(rect) {
      for (var a = 0; a < total; a++) {
        if (used[a]) continue;
        var r = doc.artboards[a].artboardRect;
        if (
          Math.abs(r[0] - rect[0]) < 1 &&
          Math.abs(r[1] - rect[1]) < 1 &&
          Math.abs(r[2] - rect[2]) < 1 &&
          Math.abs(r[3] - rect[3]) < 1
        )
          return a;
      }
      return -1;
    }
    for (var k = 0; k < faces.length; k++) {
      var face = faces[k];
      var pos = abPos[k];
      if (!face || !pos) return "";
      var artboardIndex = findArtboard(pos);
      if (artboardIndex < 0) return "";
      used[artboardIndex] = true;

      // Bìa mang sheetNo 0; mọi tờ ruột đều có sheetNo từ 1 trở lên. Hai mặt
      // A/B của một tờ AB dùng chung sheetNo nên rơi vào cùng một file.
      var isCover = !(face.sheetNo > 0);
      var key = isCover ? "BIA" : String(face.type);
      var fileName = isCover ? "BIA" : "RUOT " + face.sheetNo;
      var group = groupByKey[key];
      if (!group) {
        group = { key: key, jobs: [], jobByName: {} };
        groupByKey[key] = group;
        groups.push(group);
      }
      var job = group.jobByName[fileName];
      if (!job) {
        job = {
          name: fileName,
          ab: [],
          w: Math.round((pos[2] - pos[0]) * 100) / 100,
          h: Math.round((pos[1] - pos[3]) * 100) / 100,
        };
        group.jobByName[fileName] = job;
        group.jobs.push(job);
      }
      job.ab.push(artboardIndex + 1);
    }
    if (groups.length === 0) return "";

    // ExtendScript không có JSON.stringify. Dữ liệu chỉ gồm chữ không dấu
    // và số nên ghép chuỗi trực tiếp là đủ.
    var groupTexts = [];
    for (var g = 0; g < groups.length; g++) {
      var jobTexts = [];
      for (var j = 0; j < groups[g].jobs.length; j++) {
        var item = groups[g].jobs[j];
        jobTexts.push(
          '{"name":"' +
            item.name +
            '","ab":[' +
            item.ab.join(",") +
            '],"w":' +
            item.w +
            ',"h":' +
            item.h +
            "}",
        );
      }
      groupTexts.push(
        '{"key":"' + groups[g].key + '","jobs":[' + jobTexts.join(",") + "]}",
      );
    }
    return (
      '||CTLPDF:{"total":' + total + ',"groups":[' + groupTexts.join(",") + "]}"
    );
  } catch (e) {
    return "";
  }
}

// Lưu AI cho MỘT khổ (một nút trên panel); giữ entry PDF cho caller cũ.
//   totalText : số artboard của tài liệu lúc dàn xong.
//   jobsText  : "TÊN=artboard,artboard@rộngxcao|..." (pt), mỗi phần là một
//               file. Ví dụ "RUOT 2=3,4@2432.13x1808.5|RUOT 3=5,6@2432.13x1808.5".
// Số artboard và khổ từng artboard được so lại với lúc dàn; tài liệu đã bị
// đổi thì báo lỗi chứ không lưu nhầm tờ.
function dcLuuCtlOffsetPDF(totalText, jobsText) {
  return dcLuuCtlOffsetFiles(totalText, jobsText, "PDF");
}
function dcLuuCtlOffsetAI(totalText, jobsText) {
  return dcLuuCtlOffsetFiles(totalText, jobsText, "AI");
}
function dcLuuCtlOffsetAIPackage(totalText, jobsText, suffixText) {
  return dcLuuCtlOffsetFiles(
    totalText,
    jobsText,
    "AI_PACKAGE",
    suffixText,
  );
}
function dcLuuCtlOffsetFiles(totalText, jobsText, format, suffixText) {
  var originalCoordinates = app.coordinateSystem;
  try {
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    var isPackage = format === "AI_PACKAGE";
    var isAI = format === "AI" || isPackage;
    var formatLabel = isPackage ? "AI + JPG" : isAI ? "AI" : "PDF";
    var extension = isAI ? ".ai" : ".pdf";
    var suffix = isPackage
      ? String(
          suffixText === undefined || suffixText === null ? "" : suffixText,
        ).replace(/^\s+|\s+$/g, "")
      : "";
    if (/[\\\/:*?"<>|\x00-\x1f]/.test(suffix))
      return 'ERR: Nội dung tên file không được chứa \\ / : * ? " < > | hoặc xuống dòng.';
    if (/[. ]$/.test(suffix))
      return "ERR: Tên file không được kết thúc bằng dấu chấm.";
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
    var sourceDoc = app.activeDocument;
    var CHANGED =
      " Tài liệu đã khác lúc dàn — hãy dàn lại rồi lưu " + formatLabel + ".";
    var artboardCount = sourceDoc.artboards.length;
    var total = parseInt(String(totalText), 10);
    if (isNaN(total) || total !== artboardCount)
      return (
        "ERR: Tài liệu đang mở có " +
        artboardCount +
        " artboard, lúc dàn là " +
        (isNaN(total) ? "?" : total) +
        "." +
        CHANGED
      );

    // ---------- Đọc danh sách file cần lưu ----------
    var jobs = [];
    var parts = String(
      jobsText === undefined || jobsText === null ? "" : jobsText,
    ).split("|");
    for (var p = 0; p < parts.length; p++) {
      if (parts[p] === "") continue;
      var m = /^([^=@|]+)=([0-9,]+)@([0-9.]+)x([0-9.]+)$/.exec(parts[p]);
      if (!m)
        return (
          "ERR: Thiếu thông tin tờ cần lưu — hãy dàn lại rồi lưu " +
          formatLabel +
          "."
        );
      var baseName = m[1]
        .replace(/^\s+|\s+$/g, "")
        .replace(/[\\\/:*?"<>|]/g, "-");
      if (suffix) baseName += " " + suffix;
      var wantW = parseFloat(m[3]);
      var wantH = parseFloat(m[4]);
      var numbers = m[2].split(",");
      var indices = [];
      var pages = [];
      for (var q = 0; q < numbers.length; q++) {
        var no = parseInt(numbers[q], 10);
        if (isNaN(no) || no < 1 || no > artboardCount)
          return "ERR: Không có artboard số " + numbers[q] + "." + CHANGED;
        var rect = sourceDoc.artboards[no - 1].artboardRect;
        if (
          Math.abs(rect[2] - rect[0] - wantW) > 1 ||
          Math.abs(rect[1] - rect[3] - wantH) > 1
        )
          return (
            "ERR: Artboard " +
            no +
            " không còn đúng khổ của " +
            baseName +
            "." +
            CHANGED
          );
        indices.push(no - 1);
        pages.push({
          index: no - 1,
          rect: rect.slice(0),
          name: sourceDoc.artboards[no - 1].name,
        });
      }
      if (baseName === "" || indices.length === 0)
        return (
          "ERR: Thiếu thông tin tờ cần lưu — hãy dàn lại rồi lưu " +
          formatLabel +
          "."
        );
      for (var duplicateJob = 0; duplicateJob < jobs.length; duplicateJob++)
        if (
          jobs[duplicateJob].name.toLowerCase() ===
          (baseName + extension).toLowerCase()
        )
          return "ERR: Hai tờ trùng tên " + formatLabel + ": " + baseName + ".";
      jobs.push({
        baseName: baseName,
        name: baseName + extension,
        indices: indices,
        pages: pages,
        file: null,
      });
    }
    if (jobs.length === 0) return "ERR: Không có tờ nào để lưu.";

    var folder = dcChonThuMucLuuPDF(
      "Chọn nơi lưu " + formatLabel + " CTL Offset",
    );
    if (!folder)
      return "ERR: Chưa chọn thư mục lưu " + formatLabel + " - đã huỷ.";
    for (var jf = 0; jf < jobs.length; jf++) {
      jobs[jf].file = new File(folder.fsName + "/" + jobs[jf].name);
      if (jobs[jf].file.exists)
        return "ERR: File đã tồn tại: " + jobs[jf].name + ".";
      if (isPackage) {
        var jobBase = folder.fsName + "/" + jobs[jf].baseName;
        if (jobBase.length > 245)
          return "ERR: Tên/đường dẫn quá dài; hãy rút ngắn nội dung hoặc chọn thư mục ngắn hơn.";
        jobs[jf].jpg = new File(jobBase + ".jpg");
        jobs[jf].zip = new File(jobBase + ".zip");
        if (jobs[jf].jpg.exists || jobs[jf].zip.exists)
          return (
            "ERR: File đã tồn tại: " + jobs[jf].baseName + " (.jpg hoặc .zip)."
          );
      }
    }

    // ---------- Ghi lại trạng thái để trả về như cũ ----------
    var originalSelection = [];
    try {
      for (var os = 0; os < sourceDoc.selection.length; os++)
        originalSelection.push(sourceDoc.selection[os]);
    } catch (selectionError) {}
    var originalArtboard = 0;
    try {
      originalArtboard = sourceDoc.artboards.getActiveArtboardIndex();
    } catch (artboardError) {}
    var colorSpace = DocumentColorSpace.CMYK;
    try {
      colorSpace = sourceDoc.documentColorSpace;
    } catch (colorError) {}

    var originalLayer = sourceDoc.activeLayer;
    // Đọc trực tiếp cả layer PON khoá. Không dùng selection/group/undo,
    // không di chuyển object hay thay đổi khoá của tài liệu nguồn.
    function readLayer(layer) {
      if (!layer.visible || layer.printable === false) return null;
      var node = { name: layer.name, items: [], children: [] };
      for (var it = 0; it < layer.pageItems.length; it++) {
        var item = layer.pageItems[it];
        if (item.parent !== layer || item.hidden) continue;
        // Rasterize có thể để lại một group nguồn rỗng. Illustrator ném lỗi
        // PARM khi đọc bounds của nó; đó không phải bài in được nên phải bỏ qua.
        if (item.typename === "GroupItem" && item.pageItems.length === 0)
          continue;
        node.items.push({ item: item, bounds: item.visibleBounds.slice(0) });
      }
      for (var sub = 0; sub < layer.layers.length; sub++) {
        var child = readLayer(layer.layers[sub]);
        if (child) node.children.push(child);
      }
      return node;
    }
    var sourceLayers = [];
    for (var li = 0; li < sourceDoc.layers.length; li++) {
      var layerData = readLayer(sourceDoc.layers[li]);
      if (layerData) sourceLayers.push(layerData);
    }
    function makePdfOptions(pageCount) {
      var opt = new PDFSaveOptions();
      try {
        opt.compatibility = PDFCompatibility.ACROBAT5;
      } catch (e) {}
      try {
        opt.generateThumbnails = false;
      } catch (e2) {}
      try {
        opt.preserveEditability = false;
      } catch (e3) {}
      try {
        opt.optimization = true;
      } catch (e4) {}
      try {
        opt.viewAfterSaving = false;
      } catch (e5) {}
      try {
        opt.saveMultipleArtboards = true;
      } catch (e6) {}
      try {
        opt.artboardRange = pageCount === 1 ? "1" : "1-" + pageCount;
      } catch (e7) {}
      return opt;
    }
    function makeAiOptions() {
      var opt = new IllustratorSaveOptions();
      // AI gốc, không sinh thêm phần PDF; vẫn giữ object/layer để chỉnh sửa.
      opt.pdfCompatible = false;
      opt.compressed = true;
      opt.embedLinkedFiles = true;
      opt.embedICCProfile = true;
      // Giữ format AI hiện đại mặc định. Không dùng saveMultipleArtboards /
      // artboardRange: đó là tách asset cho AI 13 trở về trước, không phải cặp A/B.
      return opt;
    }

    function copyLayer(node, targetLayer, page, batch, workDoc) {
      var copied = 0;
      workDoc.activate();
      targetLayer.locked = false;
      targetLayer.visible = true;
      workDoc.activeLayer = targetLayer;
      var group = targetLayer.groupItems.add();
      group.locked = false;
      group.name = "CTL " + (page.name || "Artboard " + (page.index + 1));
      var pendingCopies = [];
      sourceDoc.activate();
      // pageItems có thứ tự trên -> dưới; PLACEATEND giữ đúng thứ tự đó.
      // Chỉ copy vào nhóm, KHÔNG snap/đổi tài liệu cho từng object.
      for (var ci = 0; ci < node.items.length; ci++) {
        var entry = node.items[ci];
        var b = entry.bounds,
          r = page.rect;
        if (b[2] < r[0] || b[0] > r[2] || b[1] < r[3] || b[3] > r[1]) continue;
        // Một số bản Illustrator tự đổi activeDocument khi duplicate.
        if (app.activeDocument !== sourceDoc) sourceDoc.activate();
        var referenceBounds = batch.reference
          ? null
          : entry.item.geometricBounds.slice(0);
        // Chép sang tài liệu khác, Illustrator nhận đích là Layer, không nhận
        // GroupItem (PARM). Gom vào layer đích rồi group một lượt trong tài liệu tạm.
        var duplicate = entry.item.duplicate(
          targetLayer,
          ElementPlacement.PLACEATEND,
        );
        pendingCopies.push(duplicate);
        if (!batch.reference)
          batch.reference = { item: duplicate, bounds: referenceBounds };
        copied++;
      }
      workDoc.activate();
      workDoc.selection = null;
      for (
        var pendingIndex = 0;
        pendingIndex < pendingCopies.length;
        pendingIndex++
      ) {
        unlockWorkCopy(pendingCopies[pendingIndex]);
        pendingCopies[pendingIndex].move(group, ElementPlacement.PLACEATEND);
      }
      if (copied) batch.groups.push({ group: group, layer: targetLayer });
      else group.remove();
      // layers.add đặt layer mới ở trên cùng: tạo từ dưới lên trên.
      for (var ch = node.children.length - 1; ch >= 0; ch--) {
        var childLayer = targetLayer.layers.add();
        childLayer.name = node.children[ch].name;
        copied += copyLayer(
          node.children[ch],
          childLayer,
          page,
          batch,
          workDoc,
        );
      }
      return copied;
    }
    function unlockWorkCopy(item) {
      // Chỉ mở khoá bản sao ở tài liệu tạm, không đụng khoá của layer/object nguồn.
      item.locked = false;
      if (item.typename === "GroupItem") {
        for (var child = 0; child < item.pageItems.length; child++)
          if (item.pageItems[child].parent === item)
            unlockWorkCopy(item.pageItems[child]);
      }
    }
    function positionSheetBatch(batch, page, targetRect, workDoc) {
      workDoc.activate();
      workDoc.selection = null;
      // Gom toàn bộ bài + ghi chú + PON của MỘT artboard trên bản sao.
      // Dời một lần cho cả bộ, rồi trả các nhóm về đúng layer của chúng.
      var batchLayer = workDoc.layers.add();
      batchLayer.name = "_CTL temporary batch";
      batchLayer.locked = false;
      batchLayer.visible = true;
      workDoc.activeLayer = batchLayer;
      var wholeSheet = batchLayer.groupItems.add();
      wholeSheet.locked = false;
      for (var gi = 0; gi < batch.groups.length; gi++)
        batch.groups[gi].group.move(wholeSheet, ElementPlacement.PLACEATEND);
      var before = batch.reference.bounds;
      var after = batch.reference.item.geometricBounds;
      wholeSheet.translate(
        targetRect[0] + before[0] - page.rect[0] - after[0],
        targetRect[1] + before[1] - page.rect[1] - after[1],
      );
      for (
        var restoreGroup = 0;
        restoreGroup < batch.groups.length;
        restoreGroup++
      )
        batch.groups[restoreGroup].group.move(
          batch.groups[restoreGroup].layer,
          ElementPlacement.PLACEATEND,
        );
      wholeSheet.remove();
      batchLayer.remove();
    }
    function exportJob(job) {
      var pages = job.pages;
      var maxPageWidth = 1;
      var maxPageHeight = 1;
      for (var pi = 0; pi < job.indices.length; pi++) {
        var pageRect = pages[pi].rect;
        maxPageWidth = Math.max(maxPageWidth, pageRect[2] - pageRect[0]);
        maxPageHeight = Math.max(maxPageHeight, pageRect[1] - pageRect[3]);
      }
      var workDoc = null;
      var completed = false;
      var aiSaved = false;
      try {
        // Tạo đủ trang ngay từ đầu. Không gán artboardRect hay gọi
        // artboards.add ở tài liệu tạm: cả hai gây lỗi 1200 trên một số file.
        workDoc = app.documents.add(
          colorSpace,
          maxPageWidth,
          maxPageHeight,
          pages.length,
        );
        workDoc.activate();
        if (workDoc.artboards.length !== pages.length)
          throw new Error(
            "Không tạo đủ artboard tạm để xuất " + formatLabel + ".",
          );
        var targetRects = [];
        for (var ti = 0; ti < pages.length; ti++) {
          targetRects.push(workDoc.artboards[ti].artboardRect.slice(0));
          if (isAI && pages[ti].name)
            workDoc.artboards[ti].name = pages[ti].name;
        }
        var targetLayers = [];
        for (var tl = sourceLayers.length - 1; tl >= 0; tl--) {
          var targetLayer = workDoc.layers.add();
          targetLayer.name = sourceLayers[tl].name;
          targetLayers[tl] = targetLayer;
        }
        for (var ci = 0; ci < pages.length; ci++) {
          var copiedCount = 0;
          var batch = { groups: [], reference: null };
          for (var sl = 0; sl < sourceLayers.length; sl++)
            copiedCount += copyLayer(
              sourceLayers[sl],
              targetLayers[sl],
              pages[ci],
              batch,
              workDoc,
            );
          if (!copiedCount)
            throw new Error(
              "Artboard " + (pages[ci].index + 1) + " không có object để lưu.",
            );
          positionSheetBatch(batch, pages[ci], targetRects[ci], workDoc);
        }
        workDoc.activate();
        workDoc.saveAs(
          job.file,
          isAI ? makeAiOptions() : makePdfOptions(pages.length),
        );
        aiSaved = true;
        if (isPackage) {
          try {
            dcCtlExportJpeg(workDoc, job.jpg);
          } catch (jpegError) {
            throw new Error("AI đã lưu; xuất JPG lỗi: " + jpegError);
          }
        }
        completed = true;
      } finally {
        try {
          if (workDoc) {
            workDoc.activate();
            workDoc.close(SaveOptions.DONOTSAVECHANGES);
          }
        } catch (closeError) {}
        sourceDoc.activate();
        if (!completed) {
          try {
            if (!(isPackage && aiSaved) && job.file.exists) job.file.remove();
            if (isPackage && job.jpg.exists) job.jpg.remove();
          } catch (removeError) {}
        }
      }
    }

    var saved = [];
    var packages = [];
    var saveErrors = [];
    try {
      for (var ji = 0; ji < jobs.length; ji++) {
        try {
          exportJob(jobs[ji]);
          saved.push(jobs[ji].name);
          if (isPackage) packages.push(jobs[ji]);
        } catch (saveError) {
          saveErrors.push(
            jobs[ji].name +
              ": " +
              (typeof dcMoTaLoi === "function"
                ? dcMoTaLoi(saveError)
                : saveError.toString()),
          );
        }
      }
    } finally {
      try {
        sourceDoc.activate();
      } catch (activateError) {}
      try {
        sourceDoc.artboards.setActiveArtboardIndex(originalArtboard);
      } catch (restoreArtboardError) {}
      try {
        sourceDoc.selection = null;
        for (var rs = 0; rs < originalSelection.length; rs++)
          originalSelection[rs].selected = true;
      } catch (restoreSelectionError) {}
      try {
        sourceDoc.activeLayer = originalLayer;
      } catch (restoreLayerError) {}
    }

    if (saved.length === 0)
      return (
        "ERR: Không lưu được " +
        formatLabel +
        " nào." +
        (saveErrors.length ? " " + saveErrors.join(" | ") : "")
      );
    var message =
      "OK: Đã lưu " +
      saved.length +
      " " +
      formatLabel +
      " vào " +
      folder.fsName +
      ": " +
      saved.join(", ") +
      ".";
    if (saveErrors.length)
      message +=
        " Lỗi " + saveErrors.length + " file: " + saveErrors.join(" | ");
    if (isPackage) {
      function quotePack(s) {
        return (
          '"' +
          String(s)
            .replace(/\\/g, "\\\\")
            .replace(/"/g, '\\"')
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n")
            .replace(/\t/g, "\\t") +
          '"'
        );
      }
      var packTexts = [];
      for (var pk = 0; pk < packages.length; pk++) {
        var packaged = packages[pk];
        packTexts.push(
          '{"baseName":' +
            quotePack(packaged.baseName) +
            ',"ai":' +
            quotePack(packaged.file.fsName) +
            ',"jpg":' +
            quotePack(packaged.jpg.fsName) +
            ',"zip":' +
            quotePack(packaged.zip.fsName) +
            "}",
        );
      }
      message +=
        '||CTLPACK:{"folder":' +
        quotePack(folder.fsName) +
        ',"system":' +
        quotePack(Folder.system.fsName) +
        ',"temp":' +
        quotePack(Folder.temp.fsName) +
        ',"jobs":[' +
        packTexts.join(",") +
        "]}";
    }
    return message;
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  } finally {
    app.coordinateSystem = originalCoordinates;
  }
}

// ============================================================
//  TEST: Dàn CATALOGUE KEO GÁY (dán keo gáy, in offset khổ lớn 65×86)
//  Khác signature đóng gáy giữa: TUẦN TỰ, KHÔNG bóp, KHÔNG khe.
//
//  Mỗi tay giữ form 16 trang. A4: một tay/tờ AB; A5: hai tay liên tiếp
//  trên cùng tờ AB (32 trang), xoay cụm 90° để vừa tờ, B đảo cụm/góc xoay.
//  Dàn AB trước, phần dư tự trở TT16 (A5), rồi TT8/TT4 ở cuối.
//
//  CÔNG THỨC SIGNATURE 16 KEO GÁY (local 1..16 theo mỗi tay), khớp file mẫu:
//    Mặt A: trên(180)=[5,12,9,8]  dưới=[4,13,16,1]
//    Mặt B: trên(180)=[7,10,11,6] dưới=[2,15,14,3]
//    (trang thật = base + local, base = 16*(tay-1))
//
//  BỐ TRÍ: mỗi tờ AB 2 artboard: mặt A trái, mặt B phải.
//  KÍCH THƯỚC: trang căn giữa ngang; mép trên bài dàn cách mép trên
//              artboard 2.37cm. KHÔNG bóp.
//  PON: tự vẽ theo hai form ruột 65×43 / 65×86, không hỏi chọn file.
//  GHI CHÚ: "RUỘT N" (+ chữ thêm), vị trí như signature (mép trái vào 2cm,
//           mép trên xuống 1.1cm). Điền mặt A của mỗi tay.
//
//  Bìa tự dàn tay; không bóp hoặc tự thêm trang trắng.
//
//  Cách dùng:
//   1. Chọn N trang ruột theo thứ tự đọc (bội số của 4).
//   2. File > Scripts > chạy script.
//   3. Nhập kích thước 1 trang (cm).
//   4. Tool tự vẽ PON đúng loại tờ.
//   5. Nhập ghi chú (RUỘT N + chữ thêm).
// ============================================================

var dcKeoGayAutoPonVersion = 16;

// Toàn bộ dùng mm. Panel giờ chỉ định chính xác CẢ HAI chiều của trang.
// Co giãn độc lập theo từng trục tài liệu cũng sửa luôn sai số làm tròn
// pixel của raster; cách này cố ý thay cho kiểu co đều tỷ lệ vừa khung chứa cũ.
function dcKeoGayPageScales(w, h, targetW, targetH) {
  if (
    !(w > 0 && h > 0 && targetW > 0 && targetH > 0) ||
    !isFinite(w) ||
    !isFinite(h) ||
    !isFinite(targetW) ||
    !isFinite(targetH)
  )
    throw new Error("Không đo được kích thước trang ruột.");
  var x = (targetW / w) * 100,
    y = (targetH / h) * 100;
  if (!(x > 0 && y > 0) || !isFinite(x) || !isFinite(y))
    throw new Error("Không tính được tỷ lệ kích thước trang ruột.");
  return { x: x, y: y };
}

// Áp allowance cho khổ giấy nhỏ lên toàn bộ khung, giữ nguyên tỷ lệ.
// A4 TT4 đặt cạnh ngắn dọc theo nửa chiều cao tờ 41.8 cm; A5
// TT4 đặt cạnh dài dọc theo nửa chiều rộng tờ 42.8 cm.
function dcKeoGayFrameForPaper(w, h, smallA5, smallPaper) {
  var scale = smallPaper ? Math.min(1, 209 / (smallA5 ? h : w)) : 1;
  return { w: w * scale, h: h * scale, scale: scale };
}

// A5 xếp HAI tay 16 trang kiểu A4, không thay đổi gì, lên cùng một tờ A/B.
// Đây không phải một tay gấp 32 trang mới. Mặt B đảo thứ tự khối
// và chiều xoay để trở tờ theo chiều ngang; các tờ lẻ nằm sau toàn bộ tờ AB.
function dcKeoGayPlan(pageCount, smallA5) {
  if (!(pageCount > 0) || pageCount % 4 !== 0)
    throw new Error("Số trang ruột phải là bội số của 4.");
  var sig = {
    A: { top: [5, 12, 9, 8], bottom: [4, 13, 16, 1] },
    B: { top: [7, 10, 11, 6], bottom: [2, 15, 14, 3] },
  };
  function block(base, side, rotation) {
    var result = { top: [], bottom: [], rotation: rotation };
    for (var c = 0; c < 4; c++) {
      result.top.push(base + sig[side].top[c]);
      result.bottom.push(base + sig[side].bottom[c]);
    }
    return result;
  }
  var faces = [],
    sheetNo = 0,
    capacity = smallA5 ? 32 : 16;
  var full = Math.floor(pageCount / capacity),
    base;
  for (var t = 0; t < full; t++) {
    base = t * capacity;
    sheetNo++;
    var a = block(base, "A", 90),
      b = block(base, "B", -90);
    var faceA = {
      type: "AB",
      sheetNo: sheetNo,
      label: "Ruột" + sheetNo + "-A",
    };
    var faceB = {
      type: "AB",
      sheetNo: sheetNo,
      label: "Ruột" + sheetNo + "-B",
    };
    if (smallA5) {
      faceA.blocks = [a, block(base + 16, "A", 90)];
      faceB.blocks = [block(base + 16, "B", -90), b];
    } else {
      faceA.top = a.top;
      faceA.bottom = a.bottom;
      faceB.top = b.top;
      faceB.bottom = b.bottom;
    }
    faces.push(faceA, faceB);
  }
  var remainder = pageCount - full * capacity;
  base = full * capacity;
  if (smallA5 && remainder >= 16) {
    sheetNo++;
    faces.push({
      type: "TT16",
      sheetNo: sheetNo,
      label: "Ruột" + sheetNo + " TT16",
      blocks: [block(base, "A", 90), block(base, "B", -90)],
    });
    base += 16;
    remainder -= 16;
  }
  // Giữ nguyên thứ tự TT8 + TT4 lồng nhau hiện có cho phần dư 12 trang.
  var first = base + 1,
    last = pageCount;
  if (remainder >= 8) {
    sheetNo++;
    faces.push({
      type: "TT8",
      sheetNo: sheetNo,
      label: "Ruột" + sheetNo + " TT8",
      top: [last - 3, first + 3, first + 2, last - 2],
      bottom: [last, first, first + 1, last - 1],
      smallSelfTurn: !!smallA5,
    });
    first += 4;
    last -= 4;
    remainder -= 8;
  }
  if (remainder === 4) {
    sheetNo++;
    faces.push({
      type: "TT4",
      sheetNo: sheetNo,
      label: "Ruột" + sheetNo + " TT4",
      row: [first, last, first + 1, last - 1],
    });
  }
  return faces;
}

// Toạ độ của hai khối 16 trang đã xoay, dùng chung cho phần vẽ và test.
// Mỗi khối giữ nguyên thứ tự trang và chiều gấp SIG16 gốc của nó.
function dcKeoGayPackedGrid(face, pageW, pageH, rect, topGap) {
  var width = face.blocks.length * 2 * pageH,
    height = 4 * pageW;
  var left = (rect[0] + rect[2] - width) / 2,
    top = rect[1] - topGap;
  var cells = [];
  for (var bi = 0; bi < face.blocks.length; bi++) {
    var block = face.blocks[bi],
      ccw = block.rotation === 90;
    for (var r = 0; r < 2; r++) {
      var row = r === 0 ? block.top : block.bottom;
      for (var c = 0; c < 4; c++) {
        var col = ccw ? r : 1 - r,
          rr = ccw ? 3 - c : c;
        cells.push({
          page: row[c],
          angle: (r === 0 ? 180 : 0) + block.rotation,
          cx: left + (bi * 2 + col + 0.5) * pageH,
          cy: top - (rr + 0.5) * pageW,
        });
      }
    }
  }
  return { left: left, top: top, width: width, height: height, cells: cells };
}

function dcRunKeoGay(wCm, hCm) {
  var previousKeoCoordinates = app.coordinateSystem;
  try {
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    var MM = 2.834645669;

    // ---------- BẢNG NHẬP KÍCH THƯỚC (cm) ----------
    function showSizeDialog() {
      var w = new Window("dialog", "Kích thước 1 trang (cm)");
      w.orientation = "column";
      w.alignChildren = "fill";
      w.margins = 16;
      w.spacing = 10;
      w.add(
        "statictext",
        undefined,
        "Nhập kích thước 1 TRANG sau phóng to (cm).",
      );
      var rW = w.add("group");
      rW.add("statictext", undefined, "Rộng (cm):");
      var edW = rW.add("edittext", undefined, "");
      edW.characters = 8;
      var rH = w.add("group");
      rH.add("statictext", undefined, "Cao  (cm):");
      var edH = rH.add("edittext", undefined, "");
      edH.characters = 8;
      var row = w.add("group");
      row.alignment = "right";
      var bC = row.add("button", undefined, "Bỏ qua", { name: "cancel" });
      var bO = row.add("button", undefined, "Dàn", { name: "ok" });
      var res = null;
      bO.onClick = function () {
        var cw = parseFloat(String(edW.text).replace(",", "."));
        var ch = parseFloat(String(edH.text).replace(",", "."));
        if (isNaN(cw) || isNaN(ch) || cw <= 0 || ch <= 0) {
          alert("Kích thước sai.");
          return;
        }
        res = { w: cw * 10, h: ch * 10 };
        w.close();
      };
      bC.onClick = function () {
        res = null;
        w.close();
      };
      w.show();
      return res;
    }
    var _si = null;
    var _pw = parseFloat(String(wCm).replace(",", "."));
    var _ph = parseFloat(String(hCm).replace(",", "."));
    if (!isNaN(_pw) && !isNaN(_ph) && _pw > 0 && _ph > 0) {
      _si = { w: _pw * 10, h: _ph * 10 };
    } else {
      _si = showSizeDialog();
    }
    if (!_si) return "OK: (bỏ qua)";
    var PAGE_W = _si.w,
      PAGE_H = _si.h;

    var SOURCE_PAGE_W = PAGE_W,
      SOURCE_PAGE_H = PAGE_H;
    // Cùng họ khổ A5/allowance như khi dàn CTL đóng ghim giữa. Nguồn nằm ngang
    // được đổi kích thước theo đúng chiều đã nhập rồi mới xoay về khổ đứng.
    var IS_SMALL_A5 =
      Math.min(PAGE_W, PAGE_H) <= 150 && Math.max(PAGE_W, PAGE_H) <= 211.5;
    var SMALL_SOURCE_IS_LANDSCAPE = IS_SMALL_A5 && PAGE_W > PAGE_H;
    if (SMALL_SOURCE_IS_LANDSCAPE) {
      PAGE_W = SOURCE_PAGE_H;
      PAGE_H = SOURCE_PAGE_W;
    }
    if (!IS_SMALL_A5 && (PAGE_W > 212 + 0.000001 || PAGE_H > 300 + 0.000001))
      throw new Error("Khung A4 tối đa 21,2 × 30 cm (rộng × cao).");

    var TOP_GAP = 23.7 * MM; // mép trên bài dàn cách mép trên artboard 2.37cm

    // PON được vẽ theo các form tờ ruột 65x43 và 65x86 được cung cấp.

    if (app.documents.length === 0) {
      return "ERR: Chưa mở tài liệu.";
    }
    var doc = app.activeDocument;
    var sel = doc.selection;
    if (!sel || sel.length === 0) {
      return "ERR: Chưa chọn trang ruột.";
    }

    var N = sel.length;
    if (N % 4 !== 0) {
      return "ERR: Số trang phải là BỘI SỐ CỦA 4. Đang chọn: " + N;
    }
    var faces = dcKeoGayPlan(N, IS_SMALL_A5);

    // ---------- Gom + sắp theo VỊ TRÍ (thứ tự đọc) ----------
    var arr = [];
    // Giữ lại điểm neo của nguồn trước khi làm phẳng; làm phẳng có thể thay
    // object đang chọn, nhưng artboard Keo gáy đầu tiên phải bắt đầu tại đây.
    var selectionLeft = null;
    var selectionTop = null;
    for (var i = 0; i < sel.length; i++) {
      var it = sel[i];
      var b;
      try {
        b = it.visibleBounds;
      } catch (e) {
        b = it.geometricBounds;
      }
      arr.push({ item: it, left: b[0], top: b[1] });
      if (selectionLeft === null) {
        selectionLeft = b[0];
        selectionTop = b[1];
      } else {
        selectionLeft = Math.min(selectionLeft, b[0]);
        selectionTop = Math.max(selectionTop, b[1]);
      }
    }
    arr.sort(function (a, b) {
      var dy = b.top - a.top;
      if (Math.abs(dy) > 50 * MM) return dy;
      return a.left - b.left;
    });
    var pages = [];
    for (i = 0; i < arr.length; i++) pages.push(arr[i].item); // pages[0]=trang ruột đầu tiên

    // ============================================================
    //  HÀM PHỤ TRỢ (đo/clip/union giống các hàm catalogue khác)
    // ============================================================
    function sizeMM(item) {
      // Khung Transform (trang đã clip → khung clip; group → khung group), dự phòng geometricBounds.
      var g = dcKhungHoacBounds(item);
      if (!g) return { w: 0, h: 0, b: [0, 0, 0, 0] };
      return { w: (g[2] - g[0]) / MM, h: (g[1] - g[3]) / MM, b: g };
    }

    // ============================================================
    //  BƯỚC 1: kiểm tra tất cả trang trước khi raster/tạo khung.
    //  Khớp hai cạnh theo panel; kiểm tra nguồn trước khi thay đổi bài.
    // ============================================================
    var processed = [];
    var canhBaoPhong = []; // phóng không đều > 0,5 % → báo trong kết quả
    var sourcePageSizes = [];
    for (var checkPage = 0; checkPage < pages.length; checkPage++) {
      var sourceSize = sizeMM(pages[checkPage]);
      try {
        dcKeoGayPageScales(
          sourceSize.w,
          sourceSize.h,
          SOURCE_PAGE_W,
          SOURCE_PAGE_H,
        );
      } catch (ratioError) {
        throw new Error(
          "Trang ruột " + (checkPage + 1) + ": " + ratioError.message,
        );
      }
      sourcePageSizes.push(sourceSize);
    }
    function prepareKeoGayPages() {
      for (var p = 0; p < pages.length; p++) {
        var item = pages[p];
        // Không raster: trang nguyên vector, phóng về khổ đích theo khung Transform
        // (ma trận theo trục tài liệu, trang xoay sẵn vẫn đúng).
        var targetFrame = pageFrames[p];
        var targetW = SMALL_SOURCE_IS_LANDSCAPE ? targetFrame.h : targetFrame.w;
        var targetH = SMALL_SOURCE_IS_LANDSCAPE ? targetFrame.w : targetFrame.h;
        var flat = dcChuanBiTrangDan(
          doc,
          item,
          targetW,
          targetH,
          canhBaoPhong,
          "Trang ruột " + (p + 1),
        );
        var exactSize = sizeMM(flat);
        if (
          !isFinite(exactSize.w) ||
          !isFinite(exactSize.h) ||
          Math.abs(exactSize.w - targetW) > DC_DUNG_SAI_PHONG_MM ||
          Math.abs(exactSize.h - targetH) > DC_DUNG_SAI_PHONG_MM
        )
          throw new Error(
            "Trang ruột " + (p + 1) + ": không khớp kích thước đã nhập.",
          );
        if (SMALL_SOURCE_IS_LANDSCAPE) flat.rotate(90);
        processed.push(flat);
      }
    }

    // ============================================================
    //  A4: 16 trang mỗi tờ A/B. A5: hai khối SIG16, 32 trang mỗi tờ A/B.
    //  Các trang A5 còn dư dùng TT16, rồi tới các form TT8/TT4 lồng nhau kiểu cũ.
    // ============================================================
    var numFaces = faces.length;

    // ============================================================
    //  Tính vị trí trên canvas -> tạo khung -> đặt trang -> vẽ PON lên trên cùng.
    // ============================================================
    var pageWpt = PAGE_W * MM,
      pageHpt = PAGE_H * MM;

    var GAP_ROW = 12 * MM;
    var GAP_COL = 20 * MM;
    var MID_GAP_TT4 = (IS_SMALL_A5 ? 5 : 6) * MM; // A5 giống bấm ghim: khe 5mm

    var oldAb = doc.artboards.length;

    // Cùng khổ giấy thực với Đóng ghim giữa, đo qua TIM của 4 PON giấy.
    // Tên form 65x86 / 65x43 / 43x32.5 không phải kích thước artboard.
    var ponMain = { W: 858 * MM, H: 638 * MM };
    var ponAB = { W: 858 * MM, H: 625 * MM };
    var ponTT4 = { W: 648 * MM, H: 418 * MM };
    var ponSmall4 = { W: 428 * MM, H: 313 * MM };
    // Ở khổ 14.5x20.7 cm, TT8 canh giữa còn dư 2 mm phía trên/dưới. Rút ngắn
    // đầu mút PON cắt bằng safePoint thay vì chọn 65x86 một cách không cần thiết.
    // TT8 thật sự quá khổ thì vẫn dùng tờ lớn hơn, không bao giờ bị bóp.
    var smallTT8Fits =
      pageWpt * 4 + 4 * MM + 1 <= ponTT4.W && pageHpt * 2 + 1 <= ponTT4.H;
    function ponFor(face) {
      if (face.type === "AB") return ponAB;
      if (face.type === "TT4") return IS_SMALL_A5 ? ponSmall4 : ponTT4;
      return face.smallSelfTurn && smallTT8Fits ? ponTT4 : ponMain;
    }
    function isSmallKeoPaper(face) {
      var paper = ponFor(face);
      return paper === ponSmall4 || paper === ponTT4;
    }
    var faceFrames = [],
      pageFrames = [];
    for (var paperCheck = 0; paperCheck < faces.length; paperCheck++) {
      var checkedFace = faces[paperCheck],
        checkedPaper = ponFor(checkedFace);
      var frame = dcKeoGayFrameForPaper(
        PAGE_W,
        PAGE_H,
        IS_SMALL_A5,
        isSmallKeoPaper(checkedFace),
      );
      faceFrames.push(frame);
      var framePages = [];
      if (checkedFace.blocks) {
        for (
          var blockCheck = 0;
          blockCheck < checkedFace.blocks.length;
          blockCheck++
        )
          framePages = framePages.concat(
            checkedFace.blocks[blockCheck].top,
            checkedFace.blocks[blockCheck].bottom,
          );
      } else
        framePages =
          checkedFace.row || checkedFace.top.concat(checkedFace.bottom);
      for (var framePage = 0; framePage < framePages.length; framePage++)
        pageFrames[framePages[framePage] - 1] = frame;
      if (
        checkedFace.type === "TT4" &&
        (2 * frame.h * MM + MID_GAP_TT4 > checkedPaper.W + 0.01 ||
          2 * frame.w * MM + (IS_SMALL_A5 ? 4 * MM + 1 : 0) >
            checkedPaper.H + 0.01)
      )
        throw new Error(
          "Khổ trang không vừa tờ tự trở 4 trang; hãy giảm khổ trang.",
        );
      if (
        checkedFace.blocks &&
        (frame.h * 4 * MM + 4 * MM + 1 > checkedPaper.W ||
          frame.w * 4 * MM + TOP_GAP + 0.5 > checkedPaper.H)
      )
        throw new Error(
          "Khổ trang A5 không vừa tờ " +
            (checkedFace.type === "AB"
              ? "AB 85,8 × 62,5 cm"
              : "tự trở 65 × 86") +
            "; hãy giảm khổ trang.",
        );
    }
    function useFaceFrame(index) {
      pageWpt = faceFrames[index].w * MM;
      pageHpt = faceFrames[index].h * MM;
    }

    function createAutoPonLayer(layerName) {
      for (var li = doc.layers.length - 1; li >= 0; li--) {
        try {
          if (doc.layers[li].name === layerName) {
            doc.layers[li].locked = false;
            doc.layers[li].remove();
          }
        } catch (autoPonLayerRemoveError) {}
      }
      var layer = doc.layers.add();
      layer.name = layerName;
      try {
        layer.locked = false;
        layer.visible = true;
      } catch (autoPonLayerStateError) {}
      return layer;
    }

    var artworkLayer = doc.activeLayer;
    var paperPonLayer = null;
    var cutPonLayer = null;
    try {
      doc.activeLayer = artworkLayer;
    } catch (restoreArtworkLayerError) {
      for (
        var fallbackLayer = 0;
        fallbackLayer < doc.layers.length;
        fallbackLayer++
      ) {
        try {
          if (
            doc.layers[fallbackLayer] !== paperPonLayer &&
            doc.layers[fallbackLayer] !== cutPonLayer
          ) {
            artworkLayer = doc.layers[fallbackLayer];
            doc.activeLayer = artworkLayer;
            break;
          }
        } catch (fallbackArtworkLayerError) {}
      }
    }

    function makeBlack() {
      var black = new CMYKColor();
      black.cyan = 0;
      black.magenta = 0;
      black.yellow = 0;
      black.black = 100;
      return black;
    }

    // Cùng độ dài/nét với Bấm ghim; tim dấu nằm đúng 4 góc artboard.
    function addAutoPaperPon(layer, rect, isTT4) {
      var horizontalLength = isTT4 ? 14.173 : 18.766;
      var verticalLength = isTT4 ? 14.106 : 21.091;
      var strokeWidth = isTT4 ? 1.995 : 3.971;
      var black = makeBlack();
      function draw(x1, y1, x2, y2) {
        var mark = layer.pathItems.add();
        mark.locked = false;
        mark.setEntirePath([
          [x1, y1],
          [x2, y2],
        ]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = strokeWidth;
      }
      var left = rect[0],
        top = rect[1],
        right = rect[2],
        bottom = rect[3];
      draw(left, top, left + horizontalLength, top);
      draw(left, top, left, top - verticalLength);
      draw(right - horizontalLength, top, right, top);
      draw(right, top, right, top - verticalLength);
      draw(left, bottom, left + horizontalLength, bottom);
      draw(left, bottom, left, bottom + verticalLength);
      draw(right - horizontalLength, bottom, right, bottom);
      draw(right, bottom, right, bottom + verticalLength);
    }

    // PON cắt lấy theo các form tờ ruột được cung cấp. PON mép tờ vẫn bám
    // theo giấy, còn PON cắt luôn bám theo kích thước bài dàn.
    // Keo gáy 65x86 không có khe giữa; TT4 giữ ba dấu quanh
    // khe giữa 6 mm.
    function addAutoCutPon(layer, face, rect) {
      var markLength = face.type === "TT4" ? 5.642 : 2 * MM;
      var black = makeBlack();
      function draw(p1, p2) {
        // A5 TT4 có thể vừa khít chiều ngang tờ 42.8. Dấu ở biên phải
        // giữ cả nét trong giấy, không để allowance cắt 0.2mm lòi ra ngoài.
        function safePoint(p) {
          return [
            Math.max(rect[0] + 0.5, Math.min(rect[2] - 0.5, p[0])),
            Math.max(rect[3] + 0.5, Math.min(rect[1] - 0.5, p[1])),
          ];
        }
        var mark = layer.pathItems.add();
        mark.locked = false;
        mark.setEntirePath([safePoint(p1), safePoint(p2)]);
        mark.filled = false;
        mark.stroked = true;
        mark.strokeColor = black;
        mark.strokeWidth = 1;
      }
      if (face.blocks) {
        var grid = dcKeoGayPackedGrid(face, pageWpt, pageHpt, rect, TOP_GAP);
        // Đánh biên cả 4 cột để cắt ra các cụm 2 trang. Hai trục cột
        // 1 và 3 thêm dấu ở trên/dưới (4 nét); không vẽ xuyên vào artwork.
        var axes = [
          grid.left,
          grid.left + grid.width / 4,
          grid.left + grid.width / 2,
          grid.left + (grid.width * 3) / 4,
          grid.left + grid.width,
        ];
        var ys = [grid.top, grid.top - grid.height / 2, grid.top - grid.height];
        for (var ax = 0; ax < axes.length; ax++) {
          draw([axes[ax], ys[0] + markLength], [axes[ax], ys[0]]);
          draw([axes[ax], ys[2]], [axes[ax], ys[2] - markLength]);
        }
        for (var yy = 0; yy < ys.length; yy++) {
          draw([axes[0] - markLength, ys[yy]], [axes[0], ys[yy]]);
          draw([axes[4], ys[yy]], [axes[4] + markLength, ys[yy]]);
        }
        return 16;
      }
      if (face.type === "TT4") {
        var acx4 = (rect[0] + rect[2]) / 2;
        var cumW4 = pageHpt;
        var totalW4 = cumW4 * 2 + MID_GAP_TT4;
        var left4 = acx4 - totalW4 / 2;
        // Form 65x43 được cung cấp đặt đường cắt lệch 0.2 mm ra phía ngoài ở
        // hai mép ngoài, và lệch về phía khe giữa ở các mép trong.
        var cutOffset4 = 0.2 * MM;
        var axes4 = [
          left4 - cutOffset4,
          left4 + cumW4 + cutOffset4,
          acx4,
          left4 + cumW4 + MID_GAP_TT4 - cutOffset4,
          left4 + totalW4 + cutOffset4,
        ];
        // TT4 gồm hai cặp trang xoay 90 độ. Vì vậy biên cắt theo chiều
        // dọc của nó chính là chiều cao thực của hai trang nhập vào,
        // chứ không phải mép trên/dưới của artboard giấy 65 x 43 cố định. Vị trí
        // tính theo artboard kiểu cũ chỉ tình cờ khớp với đầu vào A4.
        var acy4 = (rect[1] + rect[3]) / 2;
        var top4 = acy4 + pageWpt;
        var bottom4 = acy4 - pageWpt;
        for (var a4 = 0; a4 < axes4.length; a4++) {
          // A4 ở khổ 20.9 cm chạm tới hai mép giấy 41.8 cm. Các trục lệch của nó
          // nằm ngoài bài, nên tại đó quay nét cắt hướng vào trong
          // thay vì để hai đầu mút chập lại thành một chấm có độ dài 0.
          var topDirection = top4 + markLength > rect[1] - 0.5 ? -1 : 1;
          var bottomDirection = bottom4 - markLength < rect[3] + 0.5 ? 1 : -1;
          draw(
            [axes4[a4], top4 + topDirection * markLength],
            [axes4[a4], top4],
          );
          draw(
            [axes4[a4], bottom4],
            [axes4[a4], bottom4 + bottomDirection * markLength],
          );
        }
        return axes4.length * 2;
      }

      var acx8 = (rect[0] + rect[2]) / 2;
      var left8 = acx8 - pageWpt * 2;
      var centre8 = acx8;
      var right8 = acx8 + pageWpt * 2;
      var yTop8 = face.smallSelfTurn
        ? (rect[1] + rect[3]) / 2 + pageHpt
        : rect[1] - TOP_GAP;
      var yMiddle8 = yTop8 - pageHpt;
      var yBottom8 = yTop8 - pageHpt * 2;
      var axes8 = [left8, centre8, right8];
      for (var a8 = 0; a8 < axes8.length; a8++) {
        draw([axes8[a8], yTop8 + markLength], [axes8[a8], yTop8]);
        draw([axes8[a8], yBottom8], [axes8[a8], yBottom8 - markLength]);
      }
      draw([left8, yTop8], [left8 - markLength, yTop8]);
      draw([right8, yTop8], [right8 + markLength, yTop8]);
      draw([left8, yMiddle8], [left8 - markLength, yMiddle8]);
      draw([right8, yMiddle8], [right8 + markLength, yMiddle8]);
      draw([left8, yBottom8], [left8 - markLength, yBottom8]);
      draw([right8, yBottom8], [right8 + markLength, yBottom8]);
      return 12;
    }

    function moveCenterTo(item, x, y) {
      if (!item) return;
      try {
        var b = item.geometricBounds;
        item.translate(x - (b[0] + b[2]) / 2, y - (b[1] + b[3]) / 2);
      } catch (registrationPositionError) {}
    }

    // Artboard đầu tiên bắt đầu đúng tại góc trên trái của group nguồn
    // đang chọn. Mọi cột bố cục về sau đều quay lại đúng toạ độ đỉnh này.
    var startL = selectionLeft;
    var startT = selectionTop;
    if (startL === null || startT === null)
      throw new Error("Không xác định được vị trí object nguồn.");

    // Chừa một lề an toàn bên trong canvas Illustrator. Canvas thường rộng
    // 14,400 pt; Large Canvas báo scaleFactor cho vùng làm việc lớn hơn của nó.
    function readCanvasBounds() {
      var savedCanvas = dcDanTheoMauReadCanvasBounds(doc);
      if (savedCanvas) return savedCanvas;
      var halfSize = 7200;
      try {
        if (doc.scaleFactor && doc.scaleFactor < 1)
          halfSize = halfSize / doc.scaleFactor;
      } catch (canvasScaleError) {}
      return [-halfSize, halfSize, halfSize, -halfSize];
    }
    var canvasRect = readCanvasBounds();
    var canvasGuard = 10 * MM + 22;
    var safeLeft = canvasRect[0] + canvasGuard;
    var safeTop = canvasRect[1] - canvasGuard;
    var safeRight = canvasRect[2] - canvasGuard;
    var safeBottom = canvasRect[3] + canvasGuard;
    if (startL < safeLeft || startT > safeTop)
      throw new Error(
        "Object nguồn đang quá sát biên canvas Illustrator; không thể bắt đầu dàn đúng tại vị trí đó.",
      );

    // Vị trí artboard: AB đi cặp (A trái, B phải) cùng hàng; TT (solo) đứng
    // một mình. Hết chiều cao thì tìm cột trống bên phải trước, rồi bên trái.
    var mainW = ponMain.W;
    var layoutColumnWidth = mainW * 2 + GAP_COL;
    var layoutColumnStep = layoutColumnWidth + GAP_COL;
    var columnLeft = startL;
    var usedColumns = 1;
    var columnOffsets = { 0: true };
    var columnOffset = 0;

    function findNextColumn(rowWidth) {
      for (var distance = 1; distance < 1000; distance++) {
        var rightOffset = distance;
        var rightKey = String(rightOffset);
        var rightLeft = startL + rightOffset * layoutColumnStep;
        if (
          !columnOffsets[rightKey] &&
          rightLeft >= safeLeft &&
          rightLeft + rowWidth <= safeRight
        )
          return { offset: rightOffset, left: rightLeft };

        var leftOffset = -distance;
        var leftKey = String(leftOffset);
        var leftLeft = startL + leftOffset * layoutColumnStep;
        if (
          !columnOffsets[leftKey] &&
          leftLeft >= safeLeft &&
          leftLeft + rowWidth <= safeRight
        )
          return { offset: leftOffset, left: leftLeft };
      }
      throw new Error(
        "Đã hết chỗ trong canvas Illustrator để dàn tiếp CTL Keo Gáy. Hãy mở tài liệu Large Canvas rồi chạy lại.",
      );
    }

    function reserveRow(rowWidth, rowHeight, currentTop) {
      if (startT - rowHeight < safeBottom)
        throw new Error(
          "Không đủ chiều cao canvas từ vị trí object nguồn để đặt một tờ CTL Keo Gáy.",
        );
      if (usedColumns === 1 && columnLeft + rowWidth > safeRight)
        throw new Error(
          "Tờ CTL Keo Gáy đầu tiên không nằm vừa bên phải vị trí object nguồn.",
        );
      while (
        currentTop - rowHeight < safeBottom ||
        columnLeft + rowWidth > safeRight
      ) {
        var nextColumn = findNextColumn(rowWidth);
        columnOffset = nextColumn.offset;
        columnOffsets[String(columnOffset)] = true;
        usedColumns++;
        columnLeft = nextColumn.left;
        currentTop = startT;
      }
      return { left: columnLeft, top: currentTop };
    }

    var abPos = [];
    var curT = startT;
    var fk = 0;
    while (fk < numFaces) {
      var pA = ponFor(faces[fk]);
      if (faces[fk].type === "AB") {
        var pB =
          fk + 1 < numFaces && faces[fk + 1].type === "AB"
            ? ponFor(faces[fk + 1])
            : null;
        var rowWidth = pB ? mainW + GAP_COL + pB.W : pA.W;
        var rowHeight = pB && pB.H > pA.H ? pB.H : pA.H;
        var abRow = reserveRow(rowWidth, rowHeight, curT);
        curT = abRow.top;
        abPos[fk] = [abRow.left, curT, abRow.left + pA.W, curT - pA.H];
        if (pB) {
          var lB = abRow.left + mainW + GAP_COL;
          abPos[fk + 1] = [lB, curT, lB + pB.W, curT - pB.H];
          fk += 2;
        } else {
          fk += 1;
        }
        curT = curT - rowHeight - GAP_ROW;
      } else {
        var soloRow = reserveRow(pA.W, pA.H, curT);
        curT = soloRow.top;
        abPos[fk] = [soloRow.left, curT, soloRow.left + pA.W, curT - pA.H];
        curT = curT - pA.H - GAP_ROW;
        fk += 1;
      }
    }

    // Tạo hết các khung kết quả trước khi dùng tới trang nguồn. Nếu canvas/API
    // lỗi thì chỉ gỡ các khung của lượt chạy này, mọi khung nguồn vẫn giữ nguyên.
    try {
      for (var k = 0; k < numFaces; k++) {
        var newBoard = doc.artboards.add(abPos[k]);
        newBoard.name = faces[k].label;
      }
    } catch (keoArtboardError) {
      for (
        var rollbackAb = doc.artboards.length - 1;
        rollbackAb >= oldAb;
        rollbackAb--
      )
        doc.artboards[rollbackAb].remove();
      throw keoArtboardError;
    }
    prepareKeoGayPages();
    paperPonLayer = createAutoPonLayer("Pon CTL Keo Gay tu dong");
    cutPonLayer = createAutoPonLayer("Pon cat CTL Keo Gay tu dong");
    doc.activeLayer = artworkLayer;

    // ---------- HÀM ĐẶT TRANG ----------
    function centerItem(it, cx, cy) {
      var gb = dcKhungHoacBounds(it); // khung Transform, không phải bound nội dung
      if (!gb || gb.length < 4) return;
      var ccx = (gb[0] + gb[2]) / 2,
        ccy = (gb[1] + gb[3]) / 2;
      var dx = cx - ccx,
        dy = cy - ccy;
      if (isNaN(dx) || isNaN(dy)) return;
      try {
        it.translate(dx, dy);
      } catch (e) {}
    }
    //  AB / TT8: 4 cột SÁT NHAU (không khe), căn giữa, đỉnh cách 2.37cm.
    //  pageArr = 4 trang THẬT (1-based). rot=true xoay 180.
    function placeRow4(pageArr, rot, pos, cumTop, rowIsTop) {
      var acx = (pos[0] + pos[2]) / 2;
      var leftEdge = acx - (pageWpt * 4) / 2;
      var cy = rowIsTop ? cumTop - pageHpt / 2 : cumTop - pageHpt * 1.5;
      for (var c = 0; c < 4; c++) {
        var it = processed[pageArr[c] - 1];
        if (!it) continue;
        if (rot) {
          try {
            it.rotate(180);
          } catch (e) {}
        }
        centerItem(it, leftEdge + c * pageWpt + pageWpt / 2, cy);
      }
    }
    function placeFace48(face, pos) {
      var cumTop = face.smallSelfTurn
        ? (pos[1] + pos[3]) / 2 + pageHpt
        : pos[1] - TOP_GAP;
      placeRow4(face.top, true, pos, cumTop, true);
      placeRow4(face.bottom, false, pos, cumTop, false);
    }
    function placePackedFace(face, pos) {
      var grid = dcKeoGayPackedGrid(face, pageWpt, pageHpt, pos, TOP_GAP);
      for (var ci = 0; ci < grid.cells.length; ci++) {
        var cell = grid.cells[ci],
          it = processed[cell.page - 1];
        if (!it) throw new Error("Thiếu trang ruột " + cell.page);
        it.rotate(cell.angle);
        centerItem(it, cell.cx, cell.cy);
      }
    }
    // TT4: dùng tâm slot danh định, không dùng vùng bao gộp của phần bài đã co vừa.
    // Các trang A4 khác hình dạng vẫn phải khớp vào cùng một lưới cắt.
    function placeFace4(face, pos) {
      var acx = (pos[0] + pos[2]) / 2,
        acy = (pos[1] + pos[3]) / 2;
      for (var cell4 = 0; cell4 < 4; cell4++) {
        var page4 = processed[face.row[cell4] - 1];
        if (!page4) throw new Error("Thiếu trang ruột " + face.row[cell4]);
        var leftPair = cell4 < 2;
        page4.rotate(leftPair ? 90 : -90);
        centerItem(
          page4,
          acx + ((leftPair ? -1 : 1) * (pageHpt + MID_GAP_TT4)) / 2,
          acy + ((cell4 % 2 === 0 ? 1 : -1) * pageWpt) / 2,
        );
      }
    }

    for (var ff = 0; ff < numFaces; ff++) {
      useFaceFrame(ff);
      if (faces[ff].blocks) placePackedFace(faces[ff], abPos[ff]);
      else if (faces[ff].type === "TT4") placeFace4(faces[ff], abPos[ff]);
      else placeFace48(faces[ff], abPos[ff]);
    }

    // ---- Ve PON tu dong tren hai layer rieng, dung loai theo face. ----
    var cutPonCount = 0;
    for (var kp = 0; kp < numFaces; kp++) {
      useFaceFrame(kp);
      var posP = abPos[kp];
      var isTT4Pon = isSmallKeoPaper(faces[kp]);
      addAutoPaperPon(paperPonLayer, posP, isTT4Pon);
      cutPonCount += addAutoCutPon(cutPonLayer, faces[kp], posP);
    }
    try {
      paperPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      paperPonLayer.locked = true;
      cutPonLayer.zOrder(ZOrderMethod.BRINGTOFRONT);
      cutPonLayer.locked = true;
      doc.activeLayer = artworkLayer;
    } catch (autoPonOrderError) {}

    // ============================================================
    //  GHI CHÚ "RUỘT N" (giống signature): mép trái vào 2cm, mép trên xuống 1.1cm.
    //  Điền mặt A của mỗi tay. N = số tay (ruột).
    // ============================================================
    var hasTT4Ruot = false;
    var hasTT8Ruot = false;
    var hasTT16Ruot = false;
    var hasABRuot = false;
    for (var noteFaceIndex = 0; noteFaceIndex < numFaces; noteFaceIndex++) {
      var noteFace = faces[noteFaceIndex];
      if (noteFace.type === "TT4") hasTT4Ruot = true;
      else if (noteFace.type === "TT8") hasTT8Ruot = true;
      else if (noteFace.type === "TT16") hasTT16Ruot = true;
      else if (noteFace.type === "AB") hasABRuot = true;
    }

    function showNoteDialog() {
      var w = new Window("dialog", "Nhập ghi chú");
      w.orientation = "column";
      w.alignChildren = "fill";
      w.margins = 16;
      w.spacing = 10;
      function addRedLabel(text) {
        var label = w.add("statictext", undefined, text);
        try {
          label.graphics.foregroundColor = label.graphics.newPen(
            label.graphics.PenType.SOLID_COLOR,
            [1, 0, 0, 1],
            1,
          );
        } catch (noteLabelColorError) {}
        return label;
      }
      var edTT4 = null;
      var edTT8 = null;
      var edTT16 = null;
      var edAB = null;
      if (hasTT4Ruot) {
        addRedLabel(
          IS_SMALL_A5
            ? "Ghi chú TỰ TRỞ 43 × 32,5 (4 trang):"
            : "Ghi chú TỰ TRỞ 65 × 43 (4 trang):",
        );
        edTT4 = w.add("edittext", undefined, "");
        edTT4.characters = 40;
      }
      if (hasTT8Ruot) {
        addRedLabel(
          IS_SMALL_A5 && smallTT8Fits
            ? "Ghi chú TỰ TRỞ 65 × 43 (8 trang):"
            : "Ghi chú TỰ TRỞ 65 × 86 (8 trang):",
        );
        edTT8 = w.add("edittext", undefined, "");
        edTT8.characters = 40;
      }
      if (hasTT16Ruot) {
        addRedLabel("Ghi chú TỰ TRỞ 65 × 86 (16 trang):");
        edTT16 = w.add("edittext", undefined, "");
        edTT16.characters = 40;
      }
      if (hasABRuot) {
        addRedLabel(
          "Ghi chú TỜ AB (" + (IS_SMALL_A5 ? 32 : 16) + " trang, chỉ mặt A):",
        );
        edAB = w.add("edittext", undefined, "");
        edAB.characters = 40;
      }
      var row = w.add("group");
      row.alignment = "right";
      var btnCancel = row.add("button", undefined, "Bỏ qua", {
        name: "cancel",
      });
      var btnOK = row.add("button", undefined, "Điền ghi chú", { name: "ok" });
      var res = null;
      btnOK.onClick = function () {
        res = {
          tt4: edTT4 ? edTT4.text : "",
          tt8: edTT8 ? edTT8.text : "",
          tt16: edTT16 ? edTT16.text : "",
          ab: edAB ? edAB.text : "",
        };
        w.close();
      };
      btnCancel.onClick = function () {
        res = null;
        w.close();
      };
      w.show();
      return res;
    }
    // Icon duoc duplicate nguyen vector tu file nguon; khong resize o bat ky
    // buoc nao. Template an di, moi ghi chu lay mot ban sao moi tu template.
    // Thiếu file icon (máy khác, chưa chép assets/icon.ai) → null: ghi chú vẫn điền, không có icon.
    function loadNoteIconTemplate() {
      var iconFile = dcNoteIconFile();
      if (!iconFile) return null;
      var iconDoc = app.open(iconFile);
      var roots = [];
      for (var ii = 0; ii < iconDoc.pageItems.length; ii++) {
        var candidate = iconDoc.pageItems[ii];
        try {
          if (candidate.parent && candidate.parent.typename === "Layer")
            roots.push(candidate);
        } catch (noteIconRootError) {}
      }
      if (roots.length === 0) {
        iconDoc.close(SaveOptions.DONOTSAVECHANGES);
        throw new Error("icon.ai không có artwork để duplicate.");
      }
      var sourceGroup = iconDoc.groupItems.add();
      for (var ir = roots.length - 1; ir >= 0; ir--) {
        try {
          roots[ir].move(sourceGroup, ElementPlacement.PLACEATBEGINNING);
        } catch (noteIconMoveError) {}
      }
      var template = null;
      try {
        template = sourceGroup.duplicate(
          artworkLayer,
          ElementPlacement.PLACEATEND,
        );
        template.name = "_Mau icon ghi chu CTL Keo Gay";
        template.hidden = true;
      } catch (noteIconCopyError) {}
      try {
        iconDoc.close(SaveOptions.DONOTSAVECHANGES);
      } catch (noteIconCloseError) {}
      try {
        app.activeDocument = doc;
        doc.activeLayer = artworkLayer;
      } catch (noteIconReturnDocError) {}
      if (!template)
        throw new Error("Không duplicate được icon ghi chú vào bài đang dàn.");
      return template;
    }

    var noteIconTemplate = null;
    function duplicateNoteIcon() {
      if (!noteIconTemplate) return null;
      try {
        var iconCopy = noteIconTemplate.duplicate(
          artworkLayer,
          ElementPlacement.PLACEATEND,
        );
        iconCopy.hidden = false;
        return iconCopy;
      } catch (noteIconDuplicateError) {
        return null;
      }
    }

    function setNoteStyle(tf, isRed) {
      try {
        tf.textRange.characterAttributes.size = 13;
      } catch (e) {}
      try {
        var ink = new CMYKColor();
        if (isRed) {
          ink.cyan = 0;
          ink.magenta = 100;
          ink.yellow = 100;
          ink.black = 0;
        } else {
          ink.cyan = 0;
          ink.magenta = 0;
          ink.yellow = 0;
          ink.black = 100;
        }
        tf.textRange.characterAttributes.fillColor = ink;
      } catch (e) {
        try {
          var rgb = new RGBColor();
          rgb.red = isRed ? 255 : 0;
          rgb.green = 0;
          rgb.blue = 0;
          tf.textRange.characterAttributes.fillColor = rgb;
        } catch (e2) {}
      }
    }
    //  Ghi chú NGANG (AB / TT8, 65x86): mép trái vào 2cm, mép trên xuống 1.1cm.
    function addNote8(text, pos, isRed) {
      if (!text) return;
      try {
        var icon = duplicateNoteIcon();
        var iconW = 0;
        if (icon) {
          try {
            var ib = icon.geometricBounds;
            iconW = ib[2] - ib[0];
          } catch (noteIconBoundsError) {}
        }
        var tf = doc.activeLayer.textFrames.add();
        tf.contents = text;
        setNoteStyle(tf, isRed);
        var x = pos[0] + 20 * MM;
        var y = pos[1] - 11 * MM;
        tf.position = [x + (icon ? iconW + 3 : 0), y];
        if (icon) {
          var tb = tf.visibleBounds;
          moveCenterTo(icon, x + iconW / 2, (tb[1] + tb[3]) / 2);
        }
      } catch (e) {}
    }
    // Ghi chú dọc cho tờ nhỏ. A5 TT4 hết lề trái thì dùng dải trắng trên,
    // vì thu tờ từ 65x43 về 43x32.5 không được để ghi chú đè vào bài.
    function addNote4(text, pos, isRed) {
      if (!text) return;
      try {
        var icon = duplicateNoteIcon();
        var iconH = 0;
        if (icon) {
          try {
            var ib = icon.geometricBounds;
            iconH = ib[1] - ib[3];
          } catch (noteIconBoundsError) {}
        }
        var tf = doc.activeLayer.textFrames.add();
        tf.contents = text;
        setNoteStyle(tf, isRed);
        tf.position = [0, 0];
        try {
          tf.rotate(90);
        } catch (e) {}
        var tb = tf.visibleBounds;
        var targetLeft = pos[0] + 9 * MM;
        var targetBottom = pos[3] + 15 * MM;
        var isSmall4Note =
          IS_SMALL_A5 && Math.abs(pos[2] - pos[0] - ponSmall4.W) < 0.01;
        var small4GridLeft =
          (pos[0] + pos[2] - (2 * pageHpt + MID_GAP_TT4)) / 2;
        if (
          isSmall4Note &&
          targetLeft + tb[2] - tb[0] + 2 * MM > small4GridLeft
        ) {
          tf.rotate(-90);
          tb = tf.visibleBounds;
          var iw = icon ? icon.geometricBounds[2] - icon.geometricBounds[0] : 0;
          var availableH = (pos[1] - pos[3] - 2 * pageWpt) / 2 - 3 * MM;
          var availableW = pos[2] - pos[0] - 40 * MM - (icon ? iw + 3 : 0);
          var noteScale = Math.min(
            1,
            availableH / (tb[1] - tb[3]),
            availableW / (tb[2] - tb[0]),
          );
          if (!(noteScale > 0) || iconH > availableH)
            throw new Error("Không đủ lề trắng để đặt ghi chú A5.");
          if (noteScale < 1)
            tf.textRange.characterAttributes.size = 13 * noteScale;
          tb = tf.visibleBounds;
          var noteLeft = pos[0] + 20 * MM;
          var noteTop = pos[1] - 0.5 * MM;
          tf.translate(noteLeft + (icon ? iw + 3 : 0) - tb[0], noteTop - tb[1]);
          if (icon)
            moveCenterTo(
              icon,
              noteLeft + iw / 2,
              noteTop - Math.max(iconH, tb[1] - tb[3]) / 2,
            );
          return;
        }
        var textBottom = targetBottom + (icon ? iconH + 3 : 0);
        tf.translate(targetLeft - tb[0], textBottom - tb[3]);
        if (icon) {
          tb = tf.visibleBounds;
          moveCenterTo(icon, (tb[0] + tb[2]) / 2, targetBottom + iconH / 2);
        }
      } catch (e) {}
    }

    var note = showNoteDialog();
    var noteIconMissing = false;
    if (note) {
      noteIconTemplate = loadNoteIconTemplate();
      noteIconMissing = !noteIconTemplate;
      for (var ni = 0; ni < numFaces; ni++) {
        var face = faces[ni];
        useFaceFrame(ni);
        // AB: chỉ điền MẶT A (label kết thúc "-A"); mặt B bỏ qua.
        if (face.type === "AB" && face.label.indexOf("-B") >= 0) continue;
        var specificText = "";
        if (face.type === "TT4") specificText = note.tt4;
        else if (face.type === "TT8") specificText = note.tt8;
        else if (face.type === "TT16") specificText = note.tt16;
        else if (face.type === "AB") specificText = note.ab;
        var isSpecificRed = specificText ? true : false;
        var txt =
          "RUỘT " + face.sheetNo + (specificText ? " " + specificText : "");
        if (isSmallKeoPaper(face)) addNote4(txt, abPos[ni], isSpecificRed);
        else addNote8(txt, abPos[ni], isSpecificRed);
      }
      try {
        if (noteIconTemplate) noteIconTemplate.remove();
      } catch (noteIconTemplateRemoveError) {}
      noteIconTemplate = null;
    }

    var keoCleanup = dcRemoveOldCanvasArtboards(doc, oldAb);
    // Việc dò PDF phải dùng cùng hệ toạ độ tài liệu với abPos, trước khi
    // khối finally trả lại chế độ toạ độ theo artboard của người dùng.
    var keoPdfSuffix = dcCtlOffsetPdfPlan(doc, faces, abPos);
    app.redraw();
    alert(
      "Đã dàn keo gáy: " +
        numFaces +
        " artboard.\n" +
        (IS_SMALL_A5
          ? "A5: 32 trang/tờ AB (2 tay 16); phần dư tự trở TT16/TT8/TT4.\n"
          : "A4: 16 trang/tờ AB; phần dư tự trở TT8/TT4.\n") +
        "PON tự động nằm trên cùng. Ghi chú RUỘT N đã điền (mặt A).",
    );
  } catch (e) {
    return "ERR: keo gáy: " + e.toString();
  } finally {
    app.coordinateSystem = previousKeoCoordinates;
  }
  // Kèm danh sách khổ vừa dàn để panel hiện nút Lưu PDF cho từng khổ.
  return (
    "OK: Đã dàn CTL keo gáy trên " +
    usedColumns +
    " cột canvas; đã vẽ " +
    cutPonCount +
    " nét PON cắt. " +
    (IS_SMALL_A5
      ? "A5: 32 trang/tờ AB (2 tay 16), AB trước, tự trở sau."
      : "A4: 16 trang/tờ AB, AB trước, tự trở sau.") +
    (keoCleanup.warning ? " " + keoCleanup.warning : "") +
    (noteIconMissing ? DC_THIEU_ICON_GHI_CHU : "") +
    dcCauCanhBaoPhong(canhBaoPhong) +
    keoPdfSuffix
  );
}

// ============================================================
//  DÀN THEO MẪU (tích hợp vào panel) — 2 hàm gọi từ CEP:
//    dcHocMau()  = FILE 1 (học mẫu, bước 1/2)
//    dcApMau(multiSourcePerArtboard) = FILE 2 (áp mẫu, bước 2/2)
//  Logic giữ nguyên từ 1_hoc_mau.jsx / 2_ap_mau.jsx (bản Loc gửi).
//  Chỉ đổi: bọc thành hàm, trả chuỗi "OK:"/"ERR:" cho panel.
// ============================================================

// ---------- FILE 1: HỌC MẪU ----------
function dcHocMau() {
  var MM = 2.834645669;
  if (app.documents.length === 0) {
    alert("Chưa mở tài liệu.");
    return "ERR: Chưa mở tài liệu.";
  }
  var doc = app.activeDocument;
  var sel = doc.selection;
  if (!sel || sel.length === 0) {
    alert("Hãy chọn TẤT CẢ bản mẫu đã dàn tay.");
    return "ERR: Chưa chọn bản mẫu.";
  }

  // ---------- Hỏi kiểu: 1 mặt / 2 mặt đối xứng ----------
  // Dùng nút riêng cho từng lựa chọn để tránh ScriptUI giữ sai trạng thái
  // radiobutton, khiến mẫu 1 mặt bị lưu nhầm thành "Mặt trước".
  var w = new Window("dialog", "Học mẫu - chọn loại bố cục");
  w.orientation = "column";
  w.alignChildren = "fill";
  w.margins = 14;
  w.spacing = 8;
  w.add("statictext", undefined, "Bấm đúng loại bố cục đang chọn:");
  var which = "";
  var btnOne = w.add("button", undefined, "Học 1 mặt");
  var btnMirror = w.add("button", undefined, "Học 2 mặt - Mặt SAU đối xứng");
  var gg = w.add("group");
  gg.alignment = "right";
  gg.add("button", undefined, "Hủy", { name: "cancel" });
  btnOne.onClick = function () {
    which = "one";
    w.close(1);
  };
  btnMirror.onClick = function () {
    which = "mirror";
    w.close(1);
  };
  if (w.show() !== 1 || which === "") return "ERR: Đã hủy.";

  // ---------- đo và lưu biên dạng thật ----------
  // V3 không chỉ học visibleBounds. Mỗi path Bézier của slot được chuẩn hóa
  // theo khung riêng của nó để có thể dựng lại thành clipping mask khi áp mẫu.
  function rootOfPath(path) {
    try {
      if (path.parent && path.parent.typename === "CompoundPathItem")
        return path.parent;
    } catch (e) {}
    return path;
  }
  function clippingRoot(group) {
    var fallback = null;
    try {
      var pp = group.pathItems;
      for (var i = 0; i < pp.length; i++) {
        var isClip = false;
        try {
          isClip = pp[i].clipping === true;
        } catch (e) {}
        if (!isClip) continue;
        var root = rootOfPath(pp[i]);
        try {
          if (root.parent === group) return root;
        } catch (e2) {}
        if (!fallback) fallback = root;
      }
    } catch (e3) {}
    // Một số bản Illustrator không đưa path nằm trong CompoundPathItem vào
    // group.pathItems, nên quét collection compound trực tiếp thêm một lần.
    try {
      var cps = group.compoundPathItems;
      for (var ci = 0; ci < cps.length; ci++) {
        for (var cj = 0; cj < cps[ci].pathItems.length; cj++) {
          var compoundClip = false;
          try {
            compoundClip = cps[ci].pathItems[cj].clipping === true;
          } catch (e4) {}
          if (!compoundClip) continue;
          try {
            if (cps[ci].parent === group) return cps[ci];
          } catch (e5) {}
          if (!fallback) fallback = cps[ci];
        }
      }
    } catch (e6) {}
    return fallback;
  }
  function clipMaskBounds(item) {
    try {
      if (item.typename === "GroupItem" && item.clipped === true) {
        var root = clippingRoot(item);
        if (root) return root.geometricBounds;
      }
    } catch (e) {}
    return null;
  }
  // Khung object = khung Transform; cách đo cũ chỉ còn là dự phòng khi không đo được.
  function bnd(item) {
    return dcDoKhung(item, function (it) {
      var mb = clipMaskBounds(it);
      if (mb) return mb;
      try {
        return it.visibleBounds;
      } catch (e) {
        try {
          return it.geometricBounds;
        } catch (e2) {
          return null;
        }
      }
    });
  }
  function shapeKind(item) {
    var type = "";
    try {
      type = item.typename;
    } catch (e) {}
    if (type === "GroupItem") {
      try {
        if (item.clipped === true) return "clip";
      } catch (e2) {}
      return "group";
    }
    if (type === "CompoundPathItem") return "compound";
    if (type === "PathItem") return "path";
    if (type === "TextFrame") return "text";
    if (type === "PlacedItem" || type === "RasterItem") return "image";
    return type || "object";
  }
  function readAngle(item) {
    var m = null;
    try {
      m = item.matrix;
    } catch (e) {}
    if (!m) return null;
    var ang = (Math.atan2(m.mValueB, m.mValueA) * 180) / Math.PI;
    ang = ang % 360;
    if (ang < 0) ang += 360;
    return ang;
  }
  function normDeg(ang) {
    ang = ang % 360;
    return ang < 0 ? ang + 360 : ang;
  }
  function directKids(group) {
    var result = [];
    try {
      for (var i = 0; i < group.pageItems.length; i++) {
        var child = group.pageItems[i];
        try {
          if (child.parent === group) result.push(child);
        } catch (e) {}
      }
    } catch (e2) {}
    return result;
  }
  function isMaskDesc(item, maskRoot) {
    if (!maskRoot) return false;
    try {
      if (item === maskRoot) return true;
    } catch (e) {}
    try {
      if (
        item.typename === "PathItem" &&
        (item.clipping === true || rootOfPath(item) === maskRoot)
      )
        return true;
    } catch (e2) {}
    return false;
  }
  function itemAngleWeight(item) {
    var gb = geoBounds(item);
    if (!gb) return 0;
    var iw = Math.abs(gb[2] - gb[0]),
      ih = Math.abs(gb[1] - gb[3]);
    if (iw < 0.01 || ih < 0.01) return 0;
    // Vòng tròn/mask vuông không chứa thông tin hướng. Text và ảnh vẫn được
    // giữ vì pixel bên trong có thể có hướng dù khung là hình vuông.
    var ratio = Math.max(iw, ih) / Math.min(iw, ih);
    var directional = Math.min(1, Math.max(0, (ratio - 1) / 0.2));
    var type = "";
    try {
      type = item.typename;
    } catch (e) {}
    if (type === "TextFrame") directional = Math.max(directional, 0.75);
    if (type === "PlacedItem" || type === "RasterItem")
      directional = Math.max(directional, 0.35);
    if (directional < 0.08) return 0;
    return Math.sqrt(iw * ih) * directional;
  }
  function readContentAngle(slot) {
    var maskRoot = null;
    try {
      if (slot.typename === "GroupItem" && slot.clipped === true)
        maskRoot = clippingRoot(slot);
    } catch (e) {}
    var candidates = [];
    function walk(item, isOuter) {
      if (!item || isMaskDesc(item, maskRoot)) return;
      try {
        if (item.hidden === true || item.opacity === 0) return;
      } catch (e) {}
      var type = "";
      try {
        type = item.typename;
      } catch (e2) {}
      // Không lấy matrix của group vỏ: với clip tròn nó có thể quay mà hình
      // nhìn thấy bên trong không quay. Chỉ học matrix của artwork thực.
      if (!isOuter) {
        var weight = itemAngleWeight(item),
          angle = readAngle(item);
        if (weight > 0 && angle !== null)
          candidates.push({ angle: angle, weight: weight });
      }
      if (type === "GroupItem") {
        var kids = directKids(item);
        for (var k = 0; k < kids.length; k++) walk(kids[k], false);
      }
    }
    walk(slot, true);
    if (candidates.length === 0) return readAngle(slot);
    // Sticker tròn thường dùng 0/90/180/270. Vote tách 0 với 180 để không
    // mất hướng khi khung ngoài là hình tròn hoặc hình vuông.
    var bins = [0, 0, 0, 0],
      total = 0,
      i;
    for (i = 0; i < candidates.length; i++) {
      var q = Math.round(normDeg(candidates[i].angle) / 90) % 4;
      bins[q] += candidates[i].weight;
      total += candidates[i].weight;
    }
    var best = 0;
    for (i = 1; i < 4; i++) if (bins[i] > bins[best]) best = i;
    if (bins[best] >= total * 0.48) return best * 90;
    // Với artwork quay tự do, lấy trung bình vòng có trọng số.
    var sx = 0,
      sy = 0;
    for (i = 0; i < candidates.length; i++) {
      var rad = (candidates[i].angle * Math.PI) / 180;
      sx += Math.cos(rad) * candidates[i].weight;
      sy += Math.sin(rad) * candidates[i].weight;
    }
    return normDeg((Math.atan2(sy, sx) * 180) / Math.PI);
  }
  function isClosedPath(path) {
    try {
      return path.closed === true && path.pathPoints.length >= 3;
    } catch (e) {
      return false;
    }
  }
  function geoBounds(item) {
    try {
      var g = item.geometricBounds;
      if (g && g.length === 4 && g[2] > g[0] && g[1] > g[3]) return g;
    } catch (e) {}
    return null;
  }
  function pointArray(point, prop) {
    try {
      var a = point[prop];
      if (a && a.length >= 2 && isFinite(a[0]) && isFinite(a[1]))
        return [a[0], a[1]];
    } catch (e) {}
    return null;
  }
  function describePath(path, frame) {
    if (!isClosedPath(path)) return null;
    var fw = frame[2] - frame[0],
      fh = frame[1] - frame[3];
    if (!(fw > 0 && fh > 0)) return null;
    var cx = (frame[0] + frame[2]) / 2,
      cy = (frame[1] + frame[3]) / 2;
    var pts = [];
    try {
      for (var i = 0; i < path.pathPoints.length; i++) {
        var pp = path.pathPoints[i];
        var a = pointArray(pp, "anchor"),
          l = pointArray(pp, "leftDirection"),
          r = pointArray(pp, "rightDirection");
        if (!a || !l || !r) return null;
        var typ = "C";
        try {
          if (pp.pointType === PointType.SMOOTH) typ = "S";
        } catch (e) {}
        pts.push({
          ax: (a[0] - cx) / fw,
          ay: (a[1] - cy) / fh,
          lx: (l[0] - cx) / fw,
          ly: (l[1] - cy) / fh,
          rx: (r[0] - cx) / fw,
          ry: (r[1] - cy) / fh,
          typ: typ,
        });
      }
    } catch (e2) {
      return null;
    }
    var even = false;
    try {
      even = path.evenodd === true;
    } catch (e3) {}
    return { closed: true, evenodd: even, pts: pts };
  }
  function describeRoot(root) {
    if (!root) return null;
    var frame = geoBounds(root);
    if (!frame) return null;
    var type = "";
    try {
      type = root.typename;
    } catch (e) {}
    var paths = [],
      i,
      d;
    if (type === "PathItem") {
      d = describePath(root, frame);
      if (d) paths.push(d);
    } else if (type === "CompoundPathItem") {
      try {
        for (i = 0; i < root.pathItems.length; i++) {
          d = describePath(root.pathItems[i], frame);
          if (!d) return null;
          paths.push(d);
        }
      } catch (e2) {
        return null;
      }
    } else return null;
    if (paths.length === 0) return null;
    return {
      root: type === "CompoundPathItem" ? "compound" : "path",
      frame: frame,
      paths: paths,
    };
  }
  function getSlotShape(item) {
    var type = "";
    try {
      type = item.typename;
    } catch (e) {}
    if (type === "PathItem" || type === "CompoundPathItem")
      return describeRoot(item);
    if (type === "GroupItem") {
      var root = null;
      try {
        if (item.clipped === true) root = clippingRoot(item);
      } catch (e2) {}
      // Group ghép nhiều artwork không có một contour duy nhất đáng tin cậy.
      // Không đoán path lớn nhất để tránh cắt mất nội dung; dùng clip mask
      // tường minh nếu có, còn lại raster alpha theo khung của group.
      return describeRoot(root);
    }
    return null;
  }
  function n6(v) {
    return Number(v).toFixed(6);
  }
  function encodeRing(ring) {
    var parts = [];
    for (var i = 0; i < ring.pts.length; i++) {
      var p = ring.pts[i];
      parts.push(
        n6(p.ax) +
          "," +
          n6(p.ay) +
          "," +
          n6(p.lx) +
          "," +
          n6(p.ly) +
          "," +
          n6(p.rx) +
          "," +
          n6(p.ry) +
          "," +
          p.typ,
      );
    }
    return parts.join(";");
  }

  // ---------- đo bố cục đang chọn ----------
  var items = [];
  var X0 = null,
    Y0 = null,
    X1 = null,
    Y1 = null;
  for (var i = 0; i < sel.length; i++) {
    var shape = getSlotShape(sel[i]);
    // Với path/mask thật, geometricBounds chính là khung của silhouette.
    // Các object không có contour vector vẫn học được khung để báo fallback rõ ràng.
    var b = shape ? shape.frame : bnd(sel[i]);
    if (!b) continue;
    var cx = (b[0] + b[2]) / 2,
      cy = (b[1] + b[3]) / 2,
      wI = b[2] - b[0],
      hI = b[1] - b[3];
    var ang = readContentAngle(sel[i]);
    items.push({
      sourceIndex: i,
      cx: cx,
      cy: cy,
      w: wI,
      h: hI,
      landscape: wI >= hI,
      angle: ang === null ? -1 : ang,
      kind: shapeKind(sel[i]),
      shape: shape,
      refCx: cx,
      refCy: cy,
      refW: wI,
      refH: hI,
    });
    if (X0 === null) {
      X0 = b[0];
      Y0 = b[1];
      X1 = b[2];
      Y1 = b[3];
    } else {
      if (b[0] < X0) X0 = b[0];
      if (b[1] > Y0) Y0 = b[1];
      if (b[2] > X1) X1 = b[2];
      if (b[3] < Y1) Y1 = b[3];
    }
  }
  if (items.length === 0) {
    alert("Không đo được bản mẫu nào.");
    return "ERR: Không đo được bản mẫu.";
  }
  var gcx = (X0 + X1) / 2,
    gcy = (Y0 + Y1) / 2;
  var m0 = items[0];
  var sideHi = Math.max(m0.w, m0.h) / MM,
    sideLo = Math.min(m0.w, m0.h) / MM;
  var slots = [];
  for (var k = 0; k < items.length; k++) {
    // Lưu khung của TỪNG slot. Không dùng một khổ chữ nhật chung cho mọi hình.
    slots.push({
      dx: items[k].cx - gcx,
      dy: items[k].cy - gcy,
      land: items[k].landscape,
      angle: items[k].angle,
      w: items[k].w,
      h: items[k].h,
      kind: items[k].kind,
      shape: items[k].shape,
      refCx: items[k].refCx,
      refCy: items[k].refCy,
      refW: items[k].refW,
      refH: items[k].refH,
    });
  }

  // ---------- ghi file tạm ----------
  var f = new File(Folder.temp + "/dan_theo_mau_tmp.txt");

  function writeBlock(fh, tag) {
    fh.write("BLOCK\t" + tag + "\n");
    fh.write("sideHi\t" + sideHi.toFixed(4) + "\n");
    fh.write("sideLo\t" + sideLo.toFixed(4) + "\n");
    fh.write("n\t" + slots.length + "\n");
    for (var s = 0; s < slots.length; s++) {
      fh.write(
        "slot\t" +
          slots[s].dx.toFixed(4) +
          "\t" +
          slots[s].dy.toFixed(4) +
          "\t" +
          (slots[s].land ? "1" : "0") +
          "\t" +
          (slots[s].angle >= 0 ? slots[s].angle.toFixed(4) : "-1") +
          "\t" +
          slots[s].w.toFixed(4) +
          "\t" +
          slots[s].h.toFixed(4) +
          "\t" +
          slots[s].kind +
          "\n",
      );
    }
    // Chỉ lưu vị trí gốc trong lúc việc học mẫu còn đang chờ. Panel
    // dùng chúng để nhận ra đúng slot tham chiếu đứng thẳng mà người dùng đã chọn.
    for (s = 0; s < slots.length; s++) {
      fh.write(
        "learnref\t" +
          s +
          "\t" +
          slots[s].refCx.toFixed(4) +
          "\t" +
          slots[s].refCy.toFixed(4) +
          "\t" +
          slots[s].refW.toFixed(4) +
          "\t" +
          slots[s].refH.toFixed(4) +
          "\n",
      );
    }
    // Mỗi ring nằm trên dòng riêng để đường Bézier phức tạp không tạo line quá dài.
    for (s = 0; s < slots.length; s++) {
      var mask = slots[s].shape;
      if (!mask || !mask.paths || mask.paths.length === 0) continue;
      fh.write(
        "mask\t" + s + "\t" + mask.root + "\t" + mask.paths.length + "\n",
      );
      for (var r = 0; r < mask.paths.length; r++) {
        var ring = mask.paths[r];
        fh.write(
          "ring\t" +
            s +
            "\t" +
            r +
            "\t" +
            (ring.closed ? "1" : "0") +
            "\t" +
            (ring.evenodd ? "1" : "0") +
            "\t" +
            encodeRing(ring) +
            "\n",
        );
      }
    }
  }

  var maskCount = 0;
  for (var mi = 0; mi < slots.length; mi++) if (slots[mi].shape) maskCount++;
  var maskNote =
    "Đã lưu " +
    maskCount +
    "/" +
    slots.length +
    " biên dạng vector để cắt sau khi raster.";
  if (maskCount < slots.length)
    maskNote +=
      "\nCác slot còn lại không có path/mask kín nên sẽ dùng khung raster.";
  function exportSlotPreviews() {
    var result = { files: [], error: "" },
      previewDoc = null,
      originalDoc = doc;
    var stamp = new Date().getTime();
    try {
      previewDoc = app.documents.add(DocumentColorSpace.RGB, 100, 100);
      var opt = new ExportOptionsPNG24();
      try {
        opt.transparency = true;
      } catch (e) {}
      try {
        opt.artBoardClipping = true;
      } catch (e2) {}
      try {
        opt.horizontalScale = 100;
        opt.verticalScale = 100;
      } catch (e3) {}
      for (var pi = 0; pi < sel.length; pi++) {
        app.activeDocument = originalDoc;
        var copied = sel[pi].duplicate(
          previewDoc.layers[0],
          ElementPlacement.PLACEATEND,
        );
        app.activeDocument = previewDoc;
        var pb = bnd(copied);
        if (!pb)
          throw new Error("Không đo được preview vị trí " + (pi + 1) + ".");
        previewDoc.artboards[0].artboardRect = [pb[0], pb[1], pb[2], pb[3]];
        var png = new File(
          Folder.temp + "/dan_theo_mau_thumb_" + stamp + "_" + pi + ".png",
        );
        previewDoc.exportFile(png, ExportType.PNG24, opt);
        try {
          copied.remove();
        } catch (removeCopyError) {}
        if (!png.exists)
          throw new Error("Không xuất được preview vị trí " + (pi + 1) + ".");
        result.files.push(png.fsName);
      }
    } catch (err) {
      result.error = String(err);
    }
    try {
      if (previewDoc) previewDoc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (closeError) {}
    try {
      app.activeDocument = originalDoc;
    } catch (restoreError) {}
    return result;
  }
  function exportLayoutPreview() {
    var result = { file: "", regions: [], error: "" },
      previewDoc = null,
      originalDoc = doc;
    var stamp = new Date().getTime();
    try {
      previewDoc = app.documents.add(DocumentColorSpace.RGB, 100, 100);
      var opt = new ExportOptionsPNG24();
      try {
        opt.transparency = true;
      } catch (e) {}
      try {
        opt.artBoardClipping = true;
      } catch (e2) {}
      try {
        opt.horizontalScale = 100;
        opt.verticalScale = 100;
      } catch (e3) {}

      var copiedItems = [],
        copiedBounds = [];
      for (var pi = 0; pi < items.length; pi++) {
        app.activeDocument = originalDoc;
        var sourceIndex = items[pi].sourceIndex;
        if (sourceIndex < 0 || sourceIndex >= sel.length)
          throw new Error("Không tìm thấy object mẫu " + (pi + 1) + ".");
        copiedItems.push(
          sel[sourceIndex].duplicate(
            previewDoc.layers[0],
            ElementPlacement.PLACEATEND,
          ),
        );
      }

      app.activeDocument = previewDoc;
      var left = null,
        top = null,
        right = null,
        bottom = null;
      for (pi = 0; pi < copiedItems.length; pi++) {
        var pb = bnd(copiedItems[pi]);
        if (!pb)
          throw new Error("Không đo được preview vị trí " + (pi + 1) + ".");
        copiedBounds.push(pb);
        if (left === null) {
          left = pb[0];
          top = pb[1];
          right = pb[2];
          bottom = pb[3];
        } else {
          if (pb[0] < left) left = pb[0];
          if (pb[1] > top) top = pb[1];
          if (pb[2] > right) right = pb[2];
          if (pb[3] < bottom) bottom = pb[3];
        }
      }
      if (left === null || !(right > left) || !(top > bottom))
        throw new Error("Không đo được khung preview tổng.");

      previewDoc.artboards[0].artboardRect = [left, top, right, bottom];
      var png = new File(Folder.temp + "/dan_theo_mau_sheet_" + stamp + ".png");
      previewDoc.exportFile(png, ExportType.PNG24, opt);
      if (!png.exists) throw new Error("Không xuất được preview tổng.");

      var sheetW = right - left,
        sheetH = top - bottom;
      for (pi = 0; pi < copiedBounds.length; pi++) {
        pb = copiedBounds[pi];
        result.regions.push([
          (pb[0] - left) / sheetW,
          (top - pb[1]) / sheetH,
          (pb[2] - pb[0]) / sheetW,
          (pb[1] - pb[3]) / sheetH,
        ]);
      }
      result.file = png.fsName;
    } catch (err) {
      result.error = String(err);
    }
    try {
      if (previewDoc) previewDoc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (closeError) {}
    try {
      app.activeDocument = originalDoc;
    } catch (restoreError) {}
    return result;
  }
  function pendingVisualAngles(tag) {
    var sheet = exportLayoutPreview();
    if (!sheet.error && sheet.file && sheet.regions.length === slots.length) {
      var encoded = [];
      for (var ri = 0; ri < sheet.regions.length; ri++) {
        var region = sheet.regions[ri];
        encoded.push(
          region[0].toFixed(8) +
            "," +
            region[1].toFixed(8) +
            "," +
            region[2].toFixed(8) +
            "," +
            region[3].toFixed(8),
        );
      }
      return (
        "PENDING_SHEET:" + tag + "|" + sheet.file + "|" + encoded.join(";")
      );
    }

    // Raster/Placed có thể đã chứa artwork quay sẵn nên matrix = 0. Export
    // thumbnail để panel so pixel và học đúng 0/90/180/270 của ảnh nhìn thấy.
    var previews = exportSlotPreviews();
    if (previews.error || previews.files.length !== slots.length)
      return (
        "ERR: Không tạo được thumbnail để học hướng artwork. " + previews.error
      );
    return "PENDING:" + tag + "|" + previews.files.join("|");
  }

  if (which === "one") {
    f.encoding = "UTF-8";
    f.open("w");
    f.write(
      "# dan theo mau v5 - raster mask va huong artwork\nMODE\tone\nSTATE\tpending\n",
    );
    writeBlock(f, "F");
    f.close();
    return pendingVisualAngles("F");
  } else {
    f.encoding = "UTF-8";
    f.open("w");
    f.write(
      "# dan theo mau v5 - raster mask va huong artwork\nMODE\ttwo\nSTATE\tpending\n",
    );
    f.write("BACK_MIRROR\tHORIZONTAL\n");
    writeBlock(f, "F");
    f.close();
    return pendingVisualAngles("F");
  }
}

// Panel gọi sau khi đã so pixel các thumbnail do dcHocMau xuất ra.
function dcHocMauXacNhanConChuan(tag) {
  try {
    tag = String(tag || "");
    if (tag !== "F" && tag !== "B") return "ERR: Mặt mẫu không hợp lệ.";
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu.";
    var doc = app.activeDocument;
    if (!doc.selection || doc.selection.length !== 1)
      return "ERR: Hãy chọn đúng 1 con mẫu cùng chiều với con nguồn.";

    var f = new File(Folder.temp + "/dan_theo_mau_tmp.txt");
    if (!f.exists) return "ERR: Không tìm thấy dữ liệu mẫu đang chờ.";
    f.encoding = "UTF-8";
    f.open("r");
    var all = f.read();
    f.close();
    if (all.indexOf("STATE\tpending") < 0)
      return "ERR: Mẫu này không còn ở bước chọn con chuẩn. Hãy Học mẫu lại.";

    var chosen = doc.selection[0];
    var gb = null;
    try {
      gb = chosen.geometricBounds;
    } catch (boundsError) {}
    if (!gb || gb.length !== 4 || !(gb[2] > gb[0]) || !(gb[1] > gb[3])) {
      try {
        gb = chosen.visibleBounds;
      } catch (visibleBoundsError) {}
    }
    if (!gb || gb.length !== 4 || !(gb[2] > gb[0]) || !(gb[1] > gb[3]))
      return "ERR: Không đo được con mẫu đang chọn.";
    var cx = (gb[0] + gb[2]) / 2,
      cy = (gb[1] + gb[3]) / 2;

    var lines = all.split(/\r\n|\r|\n/),
      current = "",
      refs = [],
      i;
    for (i = 0; i < lines.length; i++) {
      var p = lines[i].split("\t");
      if (p[0] === "BLOCK") current = p[1];
      else if (p[0] === "learnref" && current === tag && p.length >= 6) {
        var ref = {
          index: parseInt(p[1], 10),
          cx: parseFloat(p[2]),
          cy: parseFloat(p[3]),
          w: parseFloat(p[4]),
          h: parseFloat(p[5]),
        };
        if (
          isFinite(ref.index) &&
          isFinite(ref.cx) &&
          isFinite(ref.cy) &&
          ref.w > 0 &&
          ref.h > 0
        )
          refs.push(ref);
      }
    }
    if (refs.length === 0)
      return "ERR: Mẫu không có dữ liệu con chuẩn. Hãy Học mẫu lại.";

    var best = null,
      bestDistance = Number.MAX_VALUE;
    for (i = 0; i < refs.length; i++) {
      var dx = cx - refs[i].cx,
        dy = cy - refs[i].cy,
        distance = Math.sqrt(dx * dx + dy * dy);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = refs[i];
      }
    }
    var tolerance = Math.max(best.w, best.h) * 0.35 + 1;
    if (!best || bestDistance > tolerance)
      return "ERR: Con đang chọn không nằm trong bố cục vừa học. Hãy chọn lại 1 con mẫu.";
    return "OK:" + best.index;
  } catch (e) {
    return "ERR: Không xác nhận được con chuẩn: " + e.toString();
  }
}

function dcHocMauCapNhatGoc(tag, csvAngles) {
  var f = new File(Folder.temp + "/dan_theo_mau_tmp.txt");
  if (!f.exists) return "ERR: Không tìm thấy dữ liệu mẫu đang chờ hoàn tất.";
  f.encoding = "UTF-8";
  f.open("r");
  var all = f.read();
  f.close();
  if (all.indexOf("# dan theo mau v5") < 0)
    return "ERR: Dữ liệu mẫu không đúng phiên bản học hướng.";
  var values = String(csvAngles || "").split(","),
    lines = all.split(/\r\n|\r|\n/);
  var autoMirrorBack = false;
  for (var markerIndex = 0; markerIndex < lines.length; markerIndex++) {
    if (lines[markerIndex] === "BACK_MIRROR\tHORIZONTAL") {
      autoMirrorBack = true;
      break;
    }
  }
  var current = "",
    used = 0,
    mode = "one",
    stateWritten = false;
  for (var i = 0; i < lines.length; i++) {
    var p = lines[i].split("\t");
    if (p[0] === "MODE") mode = p[1];
    else if (p[0] === "STATE") {
      lines[i] = "STATE\tready";
      stateWritten = true;
    } else if (p[0] === "BLOCK") current = p[1];
    else if (p[0] === "slot" && current === tag) {
      if (used >= values.length) return "ERR: Thiếu dữ liệu hướng artwork.";
      var angle = parseFloat(values[used++]);
      if (!isFinite(angle)) return "ERR: Dữ liệu hướng artwork không hợp lệ.";
      angle = angle % 360;
      if (angle < 0) angle += 360;
      p[4] = angle.toFixed(4);
      lines[i] = p.join("\t");
    }
  }
  if (used === 0 || used !== values.length)
    return "ERR: Số hướng artwork không khớp số slot.";
  if (!stateWritten) return "ERR: Dữ liệu mẫu đang thiếu trạng thái hoàn tất.";
  f.encoding = "UTF-8";
  f.open("w");
  f.write(lines.join("\n"));
  f.close();
  var msg;
  if (tag === "B")
    msg =
      "Đã HỌC MẶT SAU (" +
      used +
      " vị trí) và nhận diện hướng artwork từ ảnh mẫu.\nGiờ bấm Áp mẫu, chọn nguồn mặt trước rồi mặt sau.";
  else if (mode === "two" && autoMirrorBack)
    msg =
      "Đã HỌC 2 MẶT từ MẶT TRƯỚC (" +
      used +
      " vị trí). Mặt SAU đã tự đối xứng ngang; slot 0°/180° giữ nguyên, 90°/270° đổi chiều.\nGiờ chọn nguồn mặt trước rồi mặt sau, sau đó bấm Áp mẫu.";
  else if (mode === "two")
    msg =
      "Đã HỌC MẶT TRƯỚC (" +
      used +
      " vị trí) và nhận diện hướng artwork từ ảnh mẫu.\nGiờ chọn bố cục MẶT SAU, bấm Học mẫu và chọn 'Mặt SAU'.";
  else
    msg =
      "Đã HỌC 1 mặt (" +
      used +
      " vị trí) và nhận diện hướng artwork từ ảnh mẫu.\nChọn CON NGUỒN rồi bấm Áp mẫu.";
  alert(msg);
  return "OK: " + msg.replace(/\n/g, " ");
}

function dcXoaPreviewMau(pathsText) {
  var paths = String(pathsText || "").split("|");
  for (var i = 0; i < paths.length; i++) {
    try {
      var f = new File(paths[i]);
      if (f.exists) f.remove();
    } catch (e) {}
  }
  return "OK";
}

// ---------- FILE 2: ÁP MẪU ----------
var dcDanTheoMauVersion = 3;
// Chỉ đọc đoạn metadata nhỏ ở đầu file AI: không bao giờ dò giới hạn bằng cách tạo
// hay đổi kích thước artboard trong tài liệu của người dùng. Chỉnh gốc canvas đã lưu
// theo thước tài liệu đã đổi, vẫn giữ khoảng 14400 pt thận trọng của KTS.
function dcDanTheoMauReadCanvasBounds(doc) {
  var file = null,
    opened = false;
  try {
    file = new File(doc.fullName);
    if (!file.exists || !/\.ai$/i.test(file.name)) return null;
    file.encoding = "BINARY";
    opened = file.open("r");
    if (!opened) return null;
    var header = file.read(1024 * 1024);
    var number = "([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?)";
    var template = new RegExp(
      "%AI3_TemplateBox:\\s*" +
        number +
        "\\s+" +
        number +
        "\\s+" +
        number +
        "\\s+" +
        number,
    ).exec(header);
    var page = new RegExp("%%PageOrigin:\\s*" + number + "\\s+" + number).exec(
      header,
    );
    if (!template || !page) return null;
    var x = Number(template[1]),
      y = Number(template[2]);
    // Layer template có nội dung sẽ có khung bounds thật, không phải dấu mốc canvas.
    if (
      Math.abs(x - Number(template[3])) > 0.01 ||
      Math.abs(y - Number(template[4])) > 0.01
    )
      return null;
    var livePage = doc.pageOrigin,
      half = 7200;
    x += livePage[0] - Number(page[1]);
    y += livePage[1] - Number(page[2]);
    if (doc.scaleFactor > 0 && doc.scaleFactor < 1) half /= doc.scaleFactor;
    if (!isFinite(x) || !isFinite(y) || !isFinite(half)) return null;
    return [x - half, y + half, x + half, y - half];
  } catch (readError) {
    // File chưa lưu/không hỗ trợ thì giữ gốc KTS kiểu cũ. Việc tạo artboard
    // native vẫn có chốt chặn và tự rollback nếu canvas đó không dùng được.
    return null;
  } finally {
    if (opened) file.close();
  }
}
// Thuần tính vị trí trên canvas: cùng điểm đầu góc trên trái, cùng khe tờ 10 mm như KTS.
// Chừa đủ chỗ cho cả cặp mặt trước/mặt sau rồi mới xuống hàng, dù PON khác kích thước.
function dcDanTheoMauOutputPositions(
  frontW,
  frontH,
  backW,
  backH,
  count,
  scaleFactor,
  existingRects,
  sourceBounds,
  canvasRect,
) {
  var MM = 2.834645669,
    EPS = 0.01,
    halfSize = 7200,
    gap = 10 * MM;
  var twoSided = backW !== null && backW !== undefined;
  if (isFinite(scaleFactor) && scaleFactor > 0 && scaleFactor < 1)
    halfSize /= scaleFactor;
  var left = -halfSize + gap,
    top = halfSize - gap;
  var right = halfSize - gap,
    bottom = -halfSize + gap;
  if (canvasRect) {
    left = canvasRect[0] + gap;
    top = canvasRect[1] - gap;
    right = canvasRect[2] - gap;
    bottom = canvasRect[3] + gap;
  }
  var bundleW = frontW,
    bundleH = frontH;
  if (twoSided) {
    bundleW += gap + backW;
    bundleH = Math.max(frontH, backH);
  }
  if (
    !isFinite(frontW) ||
    !isFinite(frontH) ||
    frontW <= 0 ||
    frontH <= 0 ||
    (twoSided &&
      (!isFinite(backW) || !isFinite(backH) || backW <= 0 || backH <= 0)) ||
    !isFinite(count) ||
    count < 1 ||
    Math.floor(count) !== count ||
    bundleW > right - left + EPS ||
    bundleH > top - bottom + EPS
  )
    throw new Error(
      "Khổ PON/cặp hai mặt vượt giới hạn canvas. Hãy giảm khổ hoặc mở Large Canvas.",
    );
  function overlaps(a, b) {
    return (
      a[0] < b[2] - EPS &&
      a[2] > b[0] + EPS &&
      a[3] < b[1] - EPS &&
      a[1] > b[3] + EPS
    );
  }
  function contains(a, b) {
    return (
      a[0] <= b[0] + EPS &&
      a[1] >= b[1] - EPS &&
      a[2] >= b[2] - EPS &&
      a[3] <= b[3] + EPS
    );
  }
  var occupied = [],
    positions = [],
    i;
  for (i = 0; i < existingRects.length; i++) {
    var existing = existingRects[i];
    // Bỏ qua khung làm việc phủ cả canvas, chứ không bỏ qua tờ in rộng/hẹp.
    if (
      existing[2] - existing[0] >= (right - left + 2 * gap) * 0.92 &&
      existing[1] - existing[3] >= (top - bottom + 2 * gap) * 0.92
    )
      continue;
    occupied.push(existing.slice(0));
  }
  if (sourceBounds) {
    var covered = false;
    for (i = 0; i < occupied.length; i++) {
      if (contains(occupied[i], sourceBounds)) {
        covered = true;
        break;
      }
    }
    if (!covered) occupied.push(sourceBounds.slice(0));
  }
  var cursorLeft = left,
    cursorTop = top;
  for (var sheet = 0; sheet < count; sheet++) {
    var x = cursorLeft,
      y = cursorTop,
      reserved = false;
    for (var attempt = 0; attempt < 5000; attempt++) {
      if (x + bundleW > right + EPS) {
        x = left;
        y -= bundleH + gap;
        continue;
      }
      if (y - bundleH < bottom - EPS)
        throw new Error(
          "Không còn chỗ trong canvas để tạo đủ tờ. Hãy bớt artboard cũ hoặc bài cũ còn trên canvas, hoặc mở Large Canvas.",
        );
      var bundle = [x, y, x + bundleW, y - bundleH],
        blocker = null;
      for (i = 0; i < occupied.length; i++) {
        if (overlaps(bundle, occupied[i])) {
          blocker = occupied[i];
          break;
        }
      }
      if (blocker) {
        x = blocker[2] + gap;
        continue;
      }
      var front = [x, y, x + frontW, y - frontH],
        back = null;
      if (twoSided)
        back = [front[2] + gap, y, front[2] + gap + backW, y - backH];
      positions.push({ frontRect: front, backRect: back });
      occupied.push(bundle);
      cursorLeft = x + bundleW + gap;
      cursorTop = y;
      reserved = true;
      break;
    }
    if (!reserved)
      throw new Error(
        "Không tìm được vị trí trong canvas để đặt artboard mới.",
      );
  }
  return positions;
}
function dcApMau(multiSourcePerArtboard) {
  // Độ lệch PON, bounds nguồn và vị trí trên canvas đều dùng toạ độ tài liệu,
  // không phụ thuộc artboard đang active hay gốc thước tuỳ chỉnh.
  var previousCoordinates = app.coordinateSystem;
  try {
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    return dcApMauCore(multiSourcePerArtboard);
  } finally {
    app.coordinateSystem = previousCoordinates;
  }
}
function dcApMauCore(multiSourcePerArtboard) {
  var MM = 2.834645669;
  // Mặc định giữ cách dàn gốc: 1 con nguồn -> 1 artboard.
  // Chỉ khi tick trên panel mới gán nhiều nguồn khác nhau vào từng slot.
  var useMultiSource = multiSourcePerArtboard === true;
  if (app.documents.length === 0) {
    alert("Chưa mở tài liệu.");
    return "ERR: Chưa mở tài liệu.";
  }
  var doc = app.activeDocument;
  var sel = doc.selection;
  if (!sel || sel.length === 0) {
    alert("Hãy chọn các CON NGUỒN cần dàn.");
    return "ERR: Chưa chọn con nguồn.";
  }

  // ---------- đọc bố cục đã học ----------
  var f = new File(Folder.temp + "/dan_theo_mau_tmp.txt");
  if (!f.exists) {
    alert("Chưa có dữ liệu mẫu.\nHãy bấm Học mẫu trước.");
    return "ERR: Chưa có dữ liệu mẫu. Học mẫu trước.";
  }
  f.encoding = "UTF-8";
  f.open("r");
  var all = f.read();
  f.close();
  if (all.indexOf("# dan theo mau v5") < 0) {
    alert(
      "Dữ liệu mẫu cũ chưa có hướng artwork nhìn thấy.\nHãy bấm Học mẫu lại để lưu biên dạng và góc thật của từng vị trí.",
    );
    return "ERR: Dữ liệu mẫu cũ. Học mẫu lại để lưu biên dạng và hướng artwork.";
  }
  if (all.indexOf("STATE\tready") < 0) {
    alert(
      "Dữ liệu mẫu đang chờ đọc hướng artwork.\nHãy đợi Học mẫu chạy xong, hoặc bấm Học mẫu lại.",
    );
    return "ERR: Học mẫu chưa hoàn tất nhận diện hướng artwork.";
  }
  var lines = all.split(/\r\n|\r|\n/);

  var MODE = "one";
  var autoMirrorBack = false;
  var blocks = { F: null, B: null };
  var cur = null;
  function decodeRing(data, closed, evenodd) {
    if (!data) return null;
    var source = data.split(";"),
      pts = [];
    for (var ri = 0; ri < source.length; ri++) {
      if (!source[ri]) continue;
      var q = source[ri].split(",");
      if (q.length < 7) return null;
      var n = [];
      for (var qi = 0; qi < 6; qi++) {
        n[qi] = parseFloat(q[qi]);
        if (!isFinite(n[qi])) return null;
      }
      pts.push({
        ax: n[0],
        ay: n[1],
        lx: n[2],
        ly: n[3],
        rx: n[4],
        ry: n[5],
        typ: q[6] === "S" ? "S" : "C",
      });
    }
    if (pts.length < 3) return null;
    return { closed: closed === "1", evenodd: evenodd === "1", pts: pts };
  }
  for (var i = 0; i < lines.length; i++) {
    var ln = lines[i];
    if (!ln || ln.charAt(0) == "#") continue;
    var p = ln.split("\t");
    if (p[0] == "MODE") {
      MODE = p[1];
    } else if (p[0] == "BACK_MIRROR") {
      autoMirrorBack = p[1] === "HORIZONTAL";
    } else if (p[0] == "BLOCK") {
      cur = { sideHi: 0, sideLo: 0, slots: [] };
      blocks[p[1]] = cur;
    } else if (p[0] == "sideHi" && cur) cur.sideHi = parseFloat(p[1]);
    else if (p[0] == "sideLo" && cur) cur.sideLo = parseFloat(p[1]);
    else if (p[0] == "slot" && cur)
      cur.slots.push({
        dx: parseFloat(p[1]),
        dy: parseFloat(p[2]),
        land: p[3] == "1",
        angle: p[4] != null ? parseFloat(p[4]) : -1,
        w: p[5] != null ? parseFloat(p[5]) : 0,
        h: p[6] != null ? parseFloat(p[6]) : 0,
        kind: p[7] || "legacy",
        shape: null,
      });
    else if (p[0] == "mask" && cur) {
      var maskIndex = parseInt(p[1], 10);
      if (isFinite(maskIndex) && cur.slots[maskIndex]) {
        cur.slots[maskIndex].shape = {
          root: p[2] === "compound" ? "compound" : "path",
          expected: parseInt(p[3], 10),
          paths: [],
        };
      }
    } else if (p[0] == "ring" && cur) {
      var ringSlot = parseInt(p[1], 10),
        ringIndex = parseInt(p[2], 10);
      if (isFinite(ringSlot) && isFinite(ringIndex) && cur.slots[ringSlot]) {
        var targetSlot = cur.slots[ringSlot];
        if (!targetSlot.shape)
          targetSlot.shape = { root: "path", expected: 0, paths: [] };
        var decoded = decodeRing(p[5], p[3], p[4]);
        if (decoded) targetSlot.shape.paths[ringIndex] = decoded;
      }
    } else if (p[0] == "sideHi") {
      if (!blocks.F) blocks.F = { sideHi: 0, sideLo: 0, slots: [] };
      blocks.F.sideHi = parseFloat(p[1]);
      cur = blocks.F;
    }
  }
  function mirrorShapeHorizontally(shape) {
    if (!shape || !shape.paths) return null;
    var mirrored = {
      root: shape.root,
      expected: shape.expected,
      paths: [],
    };
    for (var mpi = 0; mpi < shape.paths.length; mpi++) {
      var path = shape.paths[mpi];
      if (!path || !path.pts) continue;
      var mirroredPath = {
        closed: path.closed,
        evenodd: path.evenodd,
        pts: [],
      };
      for (var mpt = 0; mpt < path.pts.length; mpt++) {
        var point = path.pts[mpt];
        mirroredPath.pts.push({
          ax: -point.ax,
          ay: point.ay,
          lx: -point.lx,
          ly: point.ly,
          rx: -point.rx,
          ry: point.ry,
          typ: point.typ,
        });
      }
      mirrored.paths.push(mirroredPath);
    }
    return mirrored;
  }
  function mirroredBackBlock(front) {
    var back = { sideHi: front.sideHi, sideLo: front.sideLo, slots: [] };
    for (var msi = 0; msi < front.slots.length; msi++) {
      var frontSlot = front.slots[msi];
      // Lật đối xứng qua trục dọc của bố cục: bài đứng thẳng/lộn ngược
      // giữ nguyên hướng, còn 90 và 270 độ thì đổi hướng cho nhau.
      var backAngle = -frontSlot.angle;
      backAngle = backAngle % 360;
      if (backAngle < 0) backAngle += 360;
      back.slots.push({
        dx: -frontSlot.dx,
        dy: frontSlot.dy,
        land: frontSlot.land,
        angle: backAngle,
        w: frontSlot.w,
        h: frontSlot.h,
        kind: frontSlot.kind,
        shape: mirrorShapeHorizontally(frontSlot.shape),
      });
    }
    return back;
  }
  if (autoMirrorBack && MODE === "two" && blocks.F && !blocks.B)
    blocks.B = mirroredBackBlock(blocks.F);

  if (!blocks.F || blocks.F.slots.length === 0) {
    alert("Bố cục mẫu rỗng. Học mẫu lại.");
    return "ERR: Bố cục mẫu rỗng.";
  }
  if (MODE === "two" && (!blocks.B || blocks.B.slots.length === 0)) {
    alert("Mẫu 2 mặt nhưng chưa học MẶT SAU. Học mẫu lại MẶT SAU.");
    return "ERR: Chưa học MẶT SAU.";
  }

  // Không bắt đầu xuất từ một file mẫu bị hỏng hoặc chưa đầy đủ. Mọi
  // slot đã học phải có vị trí và kích thước thật; mẫu vẫn có thể trộn
  // hình tròn, hình chữ nhật và mask vector bất kỳ.
  function validateLearnedBlock(block, label) {
    if (!block || !block.slots || block.slots.length === 0)
      return "ERR: Mẫu " + label + " không có vị trí.";
    for (var vi = 0; vi < block.slots.length; vi++) {
      var vs = block.slots[vi];
      if (
        !isFinite(vs.dx) ||
        !isFinite(vs.dy) ||
        !isPositiveSize(vs.w) ||
        !isPositiveSize(vs.h) ||
        !isFinite(vs.angle)
      )
        return (
          "ERR: Mẫu " +
          label +
          " có dữ liệu không hợp lệ ở vị trí " +
          (vi + 1) +
          ". Hãy Học mẫu lại."
        );
    }
    return "";
  }
  var learnedError = validateLearnedBlock(blocks.F, "MẶT TRƯỚC");
  if (!learnedError && MODE === "two")
    learnedError = validateLearnedBlock(blocks.B, "MẶT SAU");
  if (learnedError) {
    alert(learnedError.substring(5));
    return learnedError;
  }

  var slots = blocks.F.slots;
  var sideHi = blocks.F.sideHi;
  var sideLo = blocks.F.sideLo;
  var sideHiPt = sideHi * MM,
    sideLoPt = sideLo * MM;

  // ---------- hàm phụ trợ ----------
  function makeRO() {
    var ro = new RasterizeOptions();
    try {
      ro.resolution = 500;
    } catch (e) {}
    try {
      ro.transparency = true;
    } catch (e) {}
    try {
      ro.padding = 0;
    } catch (e) {}
    try {
      ro.clippingMask = false;
    } catch (e) {}
    try {
      ro.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
    } catch (e) {}
    try {
      ro.convertSpotColors = false;
    } catch (e) {}
    return ro;
  }
  function rootOfPath(path) {
    try {
      if (path.parent && path.parent.typename === "CompoundPathItem")
        return path.parent;
    } catch (e) {}
    return path;
  }
  function clippingRoot(group) {
    var fallback = null;
    try {
      var pp = group.pathItems;
      for (var ci = 0; ci < pp.length; ci++) {
        var isClip = false;
        try {
          isClip = pp[ci].clipping === true;
        } catch (e) {}
        if (!isClip) continue;
        var root = rootOfPath(pp[ci]);
        try {
          if (root.parent === group) return root;
        } catch (e2) {}
        if (!fallback) fallback = root;
      }
    } catch (e3) {}
    try {
      var cps = group.compoundPathItems;
      for (var cpi = 0; cpi < cps.length; cpi++) {
        for (var cpj = 0; cpj < cps[cpi].pathItems.length; cpj++) {
          var compoundClip = false;
          try {
            compoundClip = cps[cpi].pathItems[cpj].clipping === true;
          } catch (e4) {}
          if (!compoundClip) continue;
          try {
            if (cps[cpi].parent === group) return cps[cpi];
          } catch (e5) {}
          if (!fallback) fallback = cps[cpi];
        }
      }
    } catch (e6) {}
    return fallback;
  }
  function clipMaskBounds(item) {
    try {
      if (item.typename === "GroupItem" && item.clipped === true) {
        var root = clippingRoot(item);
        if (root) return root.geometricBounds;
      }
    } catch (e) {}
    return null;
  }
  // Khung object = khung Transform; cách đo cũ chỉ còn là dự phòng khi không đo được.
  function bnd(item) {
    return dcDoKhung(item, function (it) {
      var mb = clipMaskBounds(it);
      if (mb) return mb;
      try {
        return it.visibleBounds;
      } catch (e) {
        try {
          return it.geometricBounds;
        } catch (e2) {
          return null;
        }
      }
    });
  }
  function readAngle(item) {
    var m = null;
    try {
      m = item.matrix;
    } catch (e) {}
    if (!m) return null;
    var ang = (Math.atan2(m.mValueB, m.mValueA) * 180) / Math.PI;
    ang = ang % 360;
    if (ang < 0) ang += 360;
    return ang;
  }
  function normDeg(ang) {
    ang = ang % 360;
    return ang < 0 ? ang + 360 : ang;
  }
  function geoBounds(item) {
    try {
      var g = item.geometricBounds;
      if (g && g.length === 4 && g[2] > g[0] && g[1] > g[3]) return g;
    } catch (e) {}
    return null;
  }
  function directKids(group) {
    var result = [];
    try {
      for (var i = 0; i < group.pageItems.length; i++) {
        var child = group.pageItems[i];
        try {
          if (child.parent === group) result.push(child);
        } catch (e) {}
      }
    } catch (e2) {}
    return result;
  }
  function isMaskDesc(item, maskRoot) {
    if (!maskRoot) return false;
    try {
      if (item === maskRoot) return true;
    } catch (e) {}
    try {
      if (
        item.typename === "PathItem" &&
        (item.clipping === true || rootOfPath(item) === maskRoot)
      )
        return true;
    } catch (e2) {}
    return false;
  }
  function itemAngleWeight(item) {
    var gb = geoBounds(item);
    if (!gb) return 0;
    var iw = Math.abs(gb[2] - gb[0]),
      ih = Math.abs(gb[1] - gb[3]);
    if (iw < 0.01 || ih < 0.01) return 0;
    var ratio = Math.max(iw, ih) / Math.min(iw, ih);
    var directional = Math.min(1, Math.max(0, (ratio - 1) / 0.2));
    var type = "";
    try {
      type = item.typename;
    } catch (e) {}
    if (type === "TextFrame") directional = Math.max(directional, 0.75);
    if (type === "PlacedItem" || type === "RasterItem")
      directional = Math.max(directional, 0.35);
    if (directional < 0.08) return 0;
    return Math.sqrt(iw * ih) * directional;
  }
  function readContentAngle(slot) {
    var maskRoot = null;
    try {
      if (slot.typename === "GroupItem" && slot.clipped === true)
        maskRoot = clippingRoot(slot);
    } catch (e) {}
    var candidates = [];
    function walk(item, isOuter) {
      if (!item || isMaskDesc(item, maskRoot)) return;
      try {
        if (item.hidden === true || item.opacity === 0) return;
      } catch (e) {}
      var type = "";
      try {
        type = item.typename;
      } catch (e2) {}
      if (!isOuter) {
        var weight = itemAngleWeight(item),
          angle = readAngle(item);
        if (weight > 0 && angle !== null)
          candidates.push({ angle: angle, weight: weight });
      }
      if (type === "GroupItem") {
        var kids = directKids(item);
        for (var k = 0; k < kids.length; k++) walk(kids[k], false);
      }
    }
    walk(slot, true);
    if (candidates.length === 0) return readAngle(slot);
    var bins = [0, 0, 0, 0],
      total = 0,
      i;
    for (i = 0; i < candidates.length; i++) {
      var q = Math.round(normDeg(candidates[i].angle) / 90) % 4;
      bins[q] += candidates[i].weight;
      total += candidates[i].weight;
    }
    var best = 0;
    for (i = 1; i < 4; i++) if (bins[i] > bins[best]) best = i;
    if (bins[best] >= total * 0.48) return best * 90;
    var sx = 0,
      sy = 0;
    for (i = 0; i < candidates.length; i++) {
      var rad = (candidates[i].angle * Math.PI) / 180;
      sx += Math.cos(rad) * candidates[i].weight;
      sy += Math.sin(rad) * candidates[i].weight;
    }
    return normDeg((Math.atan2(sy, sx) * 180) / Math.PI);
  }
  function clearlyHorizontalOrVertical(w, h) {
    if (!(w > 0 && h > 0)) return false;
    return Math.max(w, h) / Math.min(w, h) > 1.04;
  }
  function isPositiveSize(value) {
    return typeof value === "number" && isFinite(value) && value > 0;
  }
  // RasterItem/PlacedItem có thể giữ matrix 90 độ bên trong. Khi đó
  // item.resize(x, y) scale theo trục nội bộ, còn visibleBounds lại đo theo
  // trục trang. Không được lấy W/H trang rồi đưa thẳng vào resize. Thử tăng
  // rất nhẹ trục X để biết nó đang tác động lên chiều ngang hay chiều dọc,
  // sau đó scale đúng theo trục thực tế của object. Không tạo clipping mask
  // và cũng không raster thêm RasterItem/PlacedItem.
  function resizeToVisibleSize(item, wantedW, wantedH) {
    if (!isPositiveSize(wantedW) || !isPositiveSize(wantedH))
      throw new Error("Kích thước resize không hợp lệ.");
    var before = bnd(item);
    if (!before) throw new Error("Không đo được biên dạng trước khi resize.");
    var beforeW = before[2] - before[0],
      beforeH = before[1] - before[3];
    if (!isPositiveSize(beforeW) || !isPositiveSize(beforeH))
      throw new Error("Kích thước bản sao không hợp lệ.");

    // 101% đủ lớn để phân biệt trục X/Y bằng point, nhưng không làm giảm
    // chất lượng bitmap: lệnh scale ngay sau đó bù chính xác phần 1% này.
    try {
      item.resize(101, 100, true, true, true, true, 100, Transformation.CENTER);
    } catch (probeCenterError) {
      item.resize(101, 100);
    }
    var probe = bnd(item);
    if (!probe)
      throw new Error("Không đo được biên dạng khi xác định trục resize.");
    var probeW = probe[2] - probe[0],
      probeH = probe[1] - probe[3];
    if (!isPositiveSize(probeW) || !isPositiveSize(probeH))
      throw new Error("Kích thước bản sao sau khi đo trục không hợp lệ.");

    // Nếu X nội bộ làm rộng visibleBounds thì X -> W trang; ngược lại
    // X -> H trang (đây là trường hợp ảnh đã xoay 90/270 độ từ trước).
    var xChangesWidth =
      Math.abs(probeW - beforeW) >= Math.abs(probeH - beforeH);
    var scaleX = xChangesWidth ? wantedW / probeW : wantedH / probeH;
    var scaleY = xChangesWidth ? wantedH / probeH : wantedW / probeW;
    if (!isPositiveSize(scaleX) || !isPositiveSize(scaleY))
      throw new Error("Không tính được tỉ lệ resize.");
    try {
      item.resize(
        scaleX * 100,
        scaleY * 100,
        true,
        true,
        true,
        true,
        100,
        Transformation.CENTER,
      );
    } catch (resizeCenterError) {
      item.resize(scaleX * 100, scaleY * 100);
    }
  }
  function outputLayer(d) {
    var layerName = "__DAN_THEO_MAU_KET_QUA__",
      ly = null;
    for (var i = 0; i < d.layers.length; i++) {
      if (d.layers[i].name === layerName) {
        ly = d.layers[i];
        break;
      }
    }
    if (!ly) {
      ly = d.layers.add();
      ly.name = layerName;
    }
    try {
      ly.locked = false;
    } catch (e) {}
    try {
      ly.visible = true;
    } catch (e) {}
    try {
      d.activeLayer = ly;
    } catch (e) {}
    return ly;
  }

  function isSourceOrAncestor(item, sources) {
    for (var si = 0; si < sources.length; si++) {
      var node = sources[si];
      while (node) {
        try {
          if (node === item) return true;
          if (node.typename === "Layer") break;
          node = node.parent;
        } catch (e) {
          break;
        }
      }
    }
    return false;
  }

  // Lượt chạy trước có thể để sót bài ở đúng toạ độ đó sau khi
  // artboard của nó bị gỡ. Chỉ xoá các object cấp trên cùng thuộc layer kết quả
  // này, đồng thời giữ lại mọi nguồn đang chọn nếu nó tình cờ nằm ở đó.
  function clearPreviousOutput(ly, sources) {
    var stale = [];
    try {
      for (var i = 0; i < ly.pageItems.length; i++) {
        var item = ly.pageItems[i];
        try {
          if (item.parent === ly && !isSourceOrAncestor(item, sources))
            stale.push(item);
        } catch (e) {}
      }
    } catch (e2) {}
    for (var j = stale.length - 1; j >= 0; j--) {
      try {
        stale[j].remove();
      } catch (e3) {}
    }
  }

  var sourceItems = [];
  for (var si = 0; si < sel.length; si++) sourceItems.push(sel[si]);
  var outLayer = outputLayer(doc);
  var errors = [];
  var filledSlotCount = 0,
    outputBatchCount = 0;
  var outputItems = [];
  var destName = doc.name;

  function loadPon(label) {
    var ponFile = File.openDialog(label, "*.ai");
    var R = {
      dup: null,
      W: 0,
      H: 0,
      cx: 0,
      cy: 0,
      offX: 0,
      offY: 0,
    };
    if (!ponFile || !ponFile.exists) return R;
    var pd = app.open(ponFile);
    app.activeDocument = pd;
    if (pd.artboards.length > 0) {
      var pr = pd.artboards[0].artboardRect.slice(0);
      R.W = pr[2] - pr[0];
      R.H = pr[1] - pr[3];
      R.cx = (pr[0] + pr[2]) / 2;
      R.cy = (pr[1] + pr[3]) / 2;
      app.activeDocument = doc;
      var dl = outLayer;
      app.activeDocument = pd;
      var pit = [];
      for (var q = 0; q < pd.pageItems.length; q++) pit.push(pd.pageItems[q]);
      if (pit.length > 0) {
        var pg = pd.groupItems.add();
        for (q = pit.length - 1; q >= 0; q--) {
          try {
            pit[q].move(pg, ElementPlacement.PLACEATBEGINNING);
          } catch (e) {}
        }
        try {
          var gb = pg.geometricBounds;
          var gcx = (gb[0] + gb[2]) / 2,
            gcy = (gb[1] + gb[3]) / 2;
          var acx = (pr[0] + pr[2]) / 2,
            acy = (pr[1] + pr[3]) / 2;
          R.offX = gcx - acx;
          R.offY = gcy - acy;
        } catch (e) {}
        try {
          R.dup = pg.duplicate(dl, ElementPlacement.PLACEATEND);
        } catch (e) {}
      }
    }
    app.activeDocument = pd;
    pd.close(SaveOptions.DONOTSAVECHANGES);
    var dd = null;
    for (var di = 0; di < app.documents.length; di++)
      if (app.documents[di].name === destName) {
        dd = app.documents[di];
        break;
      }
    if (dd) {
      doc = dd;
    }
    app.activeDocument = doc;
    outLayer = outputLayer(doc);
    return R;
  }

  function hasUsablePon(pon) {
    // PON trắng vẫn là PON hợp lệ: chỉ cần artboard có kích thước dương.
    return pon && isPositiveSize(pon.W) && isPositiveSize(pon.H);
  }
  function removePonCopy(pon) {
    try {
      if (pon && pon.dup) pon.dup.remove();
    } catch (e) {}
  }

  var ponF = loadPon(
    MODE === "two"
      ? "Chọn pon MẶT TRƯỚC (.ai)"
      : "Chọn file pon (.ai) - artboard cho mỗi con",
  );
  if (!hasUsablePon(ponF)) {
    removePonCopy(ponF);
    return "ERR: Chưa chọn pon MẶT TRƯỚC có artboard hợp lệ. Chưa tạo kết quả nào.";
  }
  var ponB = null;
  if (MODE === "two") {
    ponB = loadPon("Chọn pon MẶT SAU (.ai)");
    if (!hasUsablePon(ponB)) {
      removePonCopy(ponF);
      removePonCopy(ponB);
      return "ERR: Chưa chọn pon MẶT SAU có artboard hợp lệ. Chưa tạo kết quả nào.";
    }
  }

  var oldAb = doc.artboards.length;

  function planOutputPositions(count) {
    var existingRects = [],
      sourceBounds = null,
      scaleFactor = 1;
    app.activeDocument = doc;
    for (var ai = 0; ai < oldAb; ai++)
      existingRects.push(doc.artboards[ai].artboardRect.slice(0));
    for (var si = 0; si < sourceItems.length; si++) {
      var sb = bnd(sourceItems[si]);
      if (!sb)
        throw new Error("Không đo được biên dạng bài nguồn để tránh khi dàn.");
      if (!sourceBounds) sourceBounds = sb.slice(0);
      else {
        sourceBounds[0] = Math.min(sourceBounds[0], sb[0]);
        sourceBounds[1] = Math.max(sourceBounds[1], sb[1]);
        sourceBounds[2] = Math.max(sourceBounds[2], sb[2]);
        sourceBounds[3] = Math.min(sourceBounds[3], sb[3]);
      }
    }
    try {
      scaleFactor = doc.scaleFactor;
    } catch (scaleError) {}
    var canvasRect = dcDanTheoMauReadCanvasBounds(doc);
    var backW = null,
      backH = null;
    if (ponB) {
      backW = ponB.W;
      backH = ponB.H;
    }
    return dcDanTheoMauOutputPositions(
      ponF.W,
      ponF.H,
      backW,
      backH,
      count,
      scaleFactor,
      existingRects,
      sourceBounds,
      canvasRect,
    );
  }

  function canvasFailure(error) {
    removePonCopy(ponF);
    removePonCopy(ponB);
    try {
      doc.selection = sourceItems;
    } catch (restoreSelectionError) {}
    return "ERR: " + String(error);
  }

  function createPlannedArtboards(jobs) {
    // Thêm artboard thất bại không được âm thầm làm mất tờ hay xoá bài cũ.
    try {
      for (var ji = 0; ji < jobs.length; ji++)
        addAB(jobs[ji].cx, jobs[ji].cy, jobs[ji].pon.W, jobs[ji].pon.H);
    } catch (createError) {
      for (var ai = doc.artboards.length - 1; ai >= oldAb; ai--) {
        try {
          doc.artboards.remove(ai);
        } catch (removeError) {}
      }
      throw new Error(
        "Không tạo được đủ artboard đã tính trong canvas: " + createError,
      );
    }
    // Giữ lại các PON mẫu tạm cần dùng để điền vào các tờ mới.
    var keep = sourceItems.slice(0);
    if (ponF.dup) keep.push(ponF.dup);
    if (ponB && ponB.dup) keep.push(ponB.dup);
    clearPreviousOutput(outLayer, keep);
  }

  // Một job tạo một artboard. Ở chế độ nhiều mẫu, mỗi slot nhận nguồn tương ứng;
  // ở chế độ gốc, tất cả slot dùng cùng một nguồn.
  // Các object lặp vẫn dùng chung raster tạm, không làm giảm chất lượng.
  function danMotCon(block, slotSources, cxBo, cyBo, pon, tag) {
    var bSlots = block.slots;
    var bHiPt = block.sideHi * MM,
      bLoPt = block.sideLo * MM;
    var ponDup = pon ? pon.dup : null;
    var ponW = pon ? pon.W : 0,
      ponH = pon ? pon.H : 0;
    var offX = pon ? pon.offX : 0,
      offY = pon ? pon.offY : 0;

    if (!slotSources || slotSources.length !== bSlots.length) {
      errors.push(
        "Mẫu " +
          tag +
          ": số nguồn (" +
          (slotSources ? slotSources.length : 0) +
          ") không khớp số slot (" +
          bSlots.length +
          ").",
      );
      return;
    }

    var sourceCache = [];
    function isReadyImage(item) {
      try {
        return item.typename === "RasterItem" || item.typename === "PlacedItem";
      } catch (e) {
        return false;
      }
    }
    function rasterForSource(it, sourceNo) {
      for (var rc = 0; rc < sourceCache.length; rc++)
        if (sourceCache[rc].it === it) return sourceCache[rc];
      var entry = { it: it, flat: null, failed: false };
      sourceCache.push(entry);
      var workCopy = null;
      try {
        // Raster theo visibleBounds hoặc clipping mask nên giữ alpha của hình tròn,
        // tam giác, logo, chữ... trước khi nhân vào slot tương ứng.
        workCopy = it.duplicate(outLayer, ElementPlacement.PLACEATEND);
        var sourceFrame = bnd(workCopy);
        if (!sourceFrame) throw new Error("Không đo được biên dạng object.");
        if (isReadyImage(workCopy)) {
          entry.flat = workCopy;
          workCopy = null;
        } else {
          entry.flat = doc.rasterize(workCopy, sourceFrame, makeRO());
        }
        if (!entry.flat)
          throw new Error("Illustrator không trả về RasterItem.");
        // Raster đã chứa sẵn các pixel nhìn thấy của nguồn. Đọc ma trận
        // của một group nguồn lồng bên trong có thể trả về một phép biến đổi
        // 90 độ không liên quan và làm mọi slot đã học bị xoay sai hướng.
      } catch (rasterError) {
        entry.failed = true;
        try {
          if (workCopy) workCopy.remove();
        } catch (cleanupWorkCopyError) {}
        errors.push("Mẫu " + tag + ", nguồn " + sourceNo + ": " + rasterError);
      }
      return entry;
    }

    var made = 0;
    for (var s = 0; s < bSlots.length; s++) {
      var sl = bSlots[s];
      var rasterCopy = null;
      try {
        var sourceEntry = rasterForSource(slotSources[s], s + 1);
        if (sourceEntry.failed || !sourceEntry.flat)
          throw new Error("không raster được nguồn cho slot này.");
        // Không bọc ảnh trong GroupItem ở đây. Với ảnh đã có matrix xoay nội
        // bộ, GroupItem.resize có thể scale theo trục local trong khi bounds
        // lại được đo theo trục trang, làm card dọc thành ngang.
        rasterCopy = sourceEntry.flat.duplicate(
          outLayer,
          ElementPlacement.PLACEATEND,
        );
        // W/H này đã được học RIÊNG cho từng slot. Không dùng ternary lồng
        // nhau ở đây: ExtendScript đã đánh giá biểu thức đó sai và làm mọi ô
        // rơi về khổ chung 12.2 x 8.2. Ưu tiên tuyệt đối số đo thật của slot;
        // chỉ dùng khổ cũ khi template rất cũ không có W/H.
        var useW = Number(sl.w);
        var useH = Number(sl.h);
        if (!(useW > 0) || !(useH > 0)) {
          useW = sl.land ? bHiPt : bLoPt;
          useH = sl.land ? bLoPt : bHiPt;
        }
        if (!(useW > 0) || !(useH > 0))
          throw new Error("Kích thước slot không hợp lệ.");

        // Góc học được là góc tương đối với artwork đang nhìn thấy. Không đọc
        // matrix của nguồn vì Raster/PlacedItem hoặc group lồng nhau có thể trả
        // một góc nội bộ 90 độ dù ảnh thực tế đang đứng thẳng.
        var hasVisualAngle = sl.angle >= 0;
        var rot = 0;
        if (hasVisualAngle) {
          rot = sl.angle % 360;
          if (rot < 0) rot += 360;
          if (rot > 180) rot -= 360;
        } else {
          // Mẫu cũ chưa lưu góc: chỉ suy hướng khi cả nguồn lẫn slot là hình
          // chữ nhật rõ ràng. Hình tròn sẽ giữ nguyên, không bị lật 90 độ.
          var hbA = bnd(rasterCopy);
          if (!hbA) throw new Error("Không đo được biên dạng bản sao.");
          var sourceW = hbA[2] - hbA[0],
            sourceH = hbA[1] - hbA[3];
          if (
            clearlyHorizontalOrVertical(sourceW, sourceH) &&
            clearlyHorizontalOrVertical(sl.w, sl.h)
          ) {
            if (sourceW >= sourceH !== sl.land) rot = 90;
          }
        }

        // Xoay artwork trước, rồi mới resize theo W/H nhìn thấy của slot.
        // resizeToVisibleSize tự nhận biết trục nội bộ của Raster/PlacedItem,
        // nên ảnh có matrix xoay sẵn vẫn ra đúng kích thước cuối cùng.
        if (Math.abs(rot) > 0.01) {
          try {
            rasterCopy.rotate(
              rot,
              true,
              true,
              true,
              true,
              Transformation.CENTER,
            );
          } catch (rotateCenterError) {
            rasterCopy.rotate(rot);
          }
        }
        resizeToVisibleSize(rasterCopy, useW, useH);
        var hb = bnd(rasterCopy);
        if (!hb) throw new Error("Không đo được biên dạng sau khi scale.");
        // Xác nhận sau xoay theo đúng W/H slot. Với ảnh Illustrator có matrix
        // nội bộ khác thường, hiệu chỉnh lần cuối theo visibleBounds để không
        // còn xảy ra ô dọc thành 12.2 x 8.2 cm.
        var finalW = hb[2] - hb[0],
          finalH = hb[1] - hb[3];
        var SIZE_TOLERANCE = 0.75;
        if (
          Math.abs(finalW - useW) > SIZE_TOLERANCE ||
          Math.abs(finalH - useH) > SIZE_TOLERANCE
        ) {
          resizeToVisibleSize(rasterCopy, useW, useH);
          hb = bnd(rasterCopy);
          if (!hb)
            throw new Error("Không đo được biên dạng sau khi hiệu chỉnh.");
          finalW = hb[2] - hb[0];
          finalH = hb[1] - hb[3];
          if (
            Math.abs(finalW - useW) > SIZE_TOLERANCE ||
            Math.abs(finalH - useH) > SIZE_TOLERANCE
          )
            throw new Error("Resize không đạt kích thước slot yêu cầu.");
        }
        var hcx = (hb[0] + hb[2]) / 2,
          hcy = (hb[1] + hb[3]) / 2;
        var targetCx = cxBo + sl.dx,
          targetCy = cyBo + sl.dy;
        rasterCopy.translate(targetCx - hcx, targetCy - hcy);

        // Bản sao đã nằm trực tiếp trong output layer; không tạo group.
        outputItems.push(rasterCopy);
        rasterCopy = null;
        made++;
      } catch (e) {
        try {
          if (rasterCopy) rasterCopy.remove();
        } catch (e2) {}
        errors.push("Mẫu " + tag + ", vị trí " + (s + 1) + ": " + e);
      }
    }
    for (var removeIndex = 0; removeIndex < sourceCache.length; removeIndex++) {
      try {
        if (sourceCache[removeIndex].flat)
          sourceCache[removeIndex].flat.remove();
      } catch (removeFlatError) {}
    }
    if (made === 0) return;

    if (ponDup) {
      try {
        var g = ponDup.duplicate(outLayer, ElementPlacement.PLACEATBEGINNING);
        var ggb = g.geometricBounds;
        var gcx = (ggb[0] + ggb[2]) / 2,
          gcy = (ggb[1] + ggb[3]) / 2;
        g.translate(cxBo + offX - gcx, cyBo + offY - gcy);
      } catch (e) {}
    }
  }

  function addAB(cx, cy, w, h) {
    doc.artboards.add([cx - w / 2, cy + h / 2, cx + w / 2, cy - h / 2]);
  }

  // Nguồn được đọc theo thứ tự từ trên xuống, trong cùng hàng từ trái sang phải.
  // Không dùng thứ tự selection của Illustrator vì thứ tự đó không ổn định.
  function orderSourceItems(items) {
    var measured = [];
    for (var oi = 0; oi < items.length; oi++) {
      var ob = bnd(items[oi]);
      if (!ob) {
        errors.push("Nguồn " + (oi + 1) + ": không đo được biên dạng.");
        continue;
      }
      measured.push({
        it: items[oi],
        cx: (ob[0] + ob[2]) / 2,
        cy: (ob[1] + ob[3]) / 2,
        h: Math.abs(ob[1] - ob[3]),
        original: oi,
      });
    }
    measured.sort(function (a, b) {
      if (Math.abs(a.cy - b.cy) > Math.max(1, Math.min(a.h, b.h) * 0.35))
        return b.cy - a.cy;
      if (Math.abs(a.cx - b.cx) > 0.01) return a.cx - b.cx;
      return a.original - b.original;
    });
    var ordered = [];
    for (var om = 0; om < measured.length; om++) ordered.push(measured[om].it);
    return ordered;
  }

  // Một lô không đủ số slot được bù theo đúng yêu cầu: con cuối, rồi gần cuối,
  // lặp lại hai con đó. Không thay thế những nguồn đã có trong lô.
  function fillSourceBatch(seed, slotCount) {
    var filled = [];
    for (var fi = 0; fi < seed.length; fi++) filled.push(seed[fi]);
    var extra = 0;
    var tailCount = Math.min(2, seed.length);
    while (filled.length < slotCount) {
      var pick = seed[seed.length - 1 - (extra % tailCount)];
      filled.push(pick);
      extra++;
    }
    return { sources: filled, extra: extra };
  }

  function buildSourceBatches(items, slotCount) {
    var batches = [];
    for (var bs = 0; bs < items.length; bs += slotCount) {
      var seed = [];
      for (var bi = bs; bi < items.length && seed.length < slotCount; bi++)
        seed.push(items[bi]);
      if (seed.length > 0) batches.push(fillSourceBatch(seed, slotCount));
    }
    return batches;
  }

  // Chế độ gốc: mỗi nguồn là một artboard riêng, nhân nguồn đó vào toàn bộ slot.
  function buildSingleSourceBatches(items, slotCount) {
    var batches = [];
    for (var ss = 0; ss < items.length; ss++) {
      var repeated = [];
      for (var sl = 0; sl < slotCount; sl++) repeated.push(items[ss]);
      batches.push({ sources: repeated, extra: 0 });
    }
    return batches;
  }

  // Bản hai mặt bù theo từng CẶP, nhờ vậy mặt trước và mặt sau của cùng nguồn
  // luôn đi cùng nhau khi thiếu nguồn.
  function buildPairSourceBatches(frontItems, backItems, slotCount) {
    var batches = [];
    for (var ps = 0; ps < frontItems.length; ps += slotCount) {
      var frontSeed = [],
        backSeed = [];
      for (
        var pi = ps;
        pi < frontItems.length && frontSeed.length < slotCount;
        pi++
      ) {
        frontSeed.push(frontItems[pi]);
        backSeed.push(backItems[pi]);
      }
      var frontPlan = fillSourceBatch(frontSeed, slotCount);
      var backPlan = fillSourceBatch(backSeed, slotCount);
      batches.push({
        front: frontPlan.sources,
        back: backPlan.sources,
        extra: frontPlan.extra,
      });
    }
    return batches;
  }

  // Chế độ gốc cho 2 mặt: một cặp trái/phải tạo một cặp artboard,
  // mỗi mặt nhân chính nguồn của mặt đó vào toàn bộ slot đã học.
  function buildSinglePairSourceBatches(frontItems, backItems, slotCount) {
    var batches = [];
    for (var sp = 0; sp < frontItems.length; sp++) {
      var frontRepeated = [],
        backRepeated = [];
      for (var sl = 0; sl < slotCount; sl++) {
        frontRepeated.push(frontItems[sp]);
        backRepeated.push(backItems[sp]);
      }
      batches.push({ front: frontRepeated, back: backRepeated, extra: 0 });
    }
    return batches;
  }

  if (MODE === "one") {
    var orderedSources = orderSourceItems(sourceItems);
    if (orderedSources.length === 0) {
      removePonCopy(ponF);
      return "ERR: Không có nguồn nào có biên dạng hợp lệ. Chưa tạo kết quả nào.";
    }
    var sourceBatches = useMultiSource
      ? buildSourceBatches(orderedSources, blocks.F.slots.length)
      : buildSingleSourceBatches(orderedSources, blocks.F.slots.length);
    outputBatchCount = sourceBatches.length;
    var positions;
    try {
      positions = planOutputPositions(sourceBatches.length);
    } catch (planError) {
      return canvasFailure(planError);
    }
    var jobs = [];
    for (var bi = 0; bi < sourceBatches.length; bi++) {
      var rect = positions[bi].frontRect;
      jobs.push({
        sources: sourceBatches[bi].sources,
        cx: (rect[0] + rect[2]) / 2,
        cy: (rect[1] + rect[3]) / 2,
        block: blocks.F,
        pon: ponF,
        tag: bi + 1,
      });
      filledSlotCount += sourceBatches[bi].extra;
    }
    try {
      createPlannedArtboards(jobs);
    } catch (createError) {
      return canvasFailure(createError);
    }
    for (var jj = 0; jj < jobs.length; jj++)
      danMotCon(
        jobs[jj].block,
        jobs[jj].sources,
        jobs[jj].cx,
        jobs[jj].cy,
        jobs[jj].pon,
        jobs[jj].tag,
      );
  } else {
    var cxs = [];
    for (var ci = 0; ci < sourceItems.length; ci++) {
      var bb = bnd(sourceItems[ci]);
      if (!bb) {
        removePonCopy(ponF);
        removePonCopy(ponB);
        return (
          "ERR: Nguồn " +
          (ci + 1) +
          " không có biên dạng hợp lệ. Chưa tạo kết quả nào."
        );
      }
      cxs.push({
        it: sourceItems[ci],
        cx: (bb[0] + bb[2]) / 2,
        cy: (bb[1] + bb[3]) / 2,
      });
    }
    var sumX = 0;
    for (var ci2 = 0; ci2 < cxs.length; ci2++) sumX += cxs[ci2].cx;
    var midX = sumX / cxs.length;
    var colTrai = [],
      colPhai = [];
    for (var ci3 = 0; ci3 < cxs.length; ci3++) {
      if (cxs[ci3].cx < midX) colTrai.push(cxs[ci3]);
      else colPhai.push(cxs[ci3]);
    }
    function byY(a, b) {
      return b.cy - a.cy;
    }
    colTrai.sort(byY);
    colPhai.sort(byY);
    if (colTrai.length !== colPhai.length) {
      removePonCopy(ponF);
      removePonCopy(ponB);
      var pairError =
        "ERR: Mẫu 2 mặt cần hai cột bằng nhau (trái=mặt trước, phải=mặt sau). Hiện có trái " +
        colTrai.length +
        ", phải " +
        colPhai.length +
        ". Chưa tạo kết quả nào.";
      alert(pairError.substring(5));
      return pairError;
    }
    if (blocks.F.slots.length !== blocks.B.slots.length) {
      removePonCopy(ponF);
      removePonCopy(ponB);
      var slotError =
        "ERR: Mẫu 2 mặt cần số slot trước/sau bằng nhau để ghép từng cặp nguồn. Hiện có trước " +
        blocks.F.slots.length +
        ", sau " +
        blocks.B.slots.length +
        ". Hãy Học mẫu lại.";
      alert(slotError.substring(5));
      return slotError;
    }
    var frontItems = [],
      backItems = [];
    for (var cp = 0; cp < colTrai.length; cp++) {
      frontItems.push(colTrai[cp].it);
      backItems.push(colPhai[cp].it);
    }
    var pairBatches = useMultiSource
      ? buildPairSourceBatches(frontItems, backItems, blocks.F.slots.length)
      : buildSinglePairSourceBatches(
          frontItems,
          backItems,
          blocks.F.slots.length,
        );
    outputBatchCount = pairBatches.length;

    var pairPositions;
    try {
      pairPositions = planOutputPositions(pairBatches.length);
    } catch (planError) {
      return canvasFailure(planError);
    }
    var jobs2 = [];
    for (var pi2 = 0; pi2 < pairBatches.length; pi2++) {
      var frontRect = pairPositions[pi2].frontRect;
      var backRect = pairPositions[pi2].backRect;
      jobs2.push({
        sources: pairBatches[pi2].front,
        cx: (frontRect[0] + frontRect[2]) / 2,
        cy: (frontRect[1] + frontRect[3]) / 2,
        block: blocks.F,
        pon: ponF,
        tag: pi2 * 2 + 1,
        w: ponF.W,
        h: ponF.H,
      });
      jobs2.push({
        sources: pairBatches[pi2].back,
        cx: (backRect[0] + backRect[2]) / 2,
        cy: (backRect[1] + backRect[3]) / 2,
        block: blocks.B,
        pon: ponB,
        tag: pi2 * 2 + 2,
        w: ponB.W,
        h: ponB.H,
      });
      filledSlotCount += pairBatches[pi2].extra * 2;
    }
    try {
      createPlannedArtboards(jobs2);
    } catch (createError) {
      return canvasFailure(createError);
    }
    for (var jb = 0; jb < jobs2.length; jb++)
      danMotCon(
        jobs2[jb].block,
        jobs2[jb].sources,
        jobs2[jb].cx,
        jobs2[jb].cy,
        jobs2[jb].pon,
        jobs2[jb].tag,
      );
  }

  try {
    if (ponF && ponF.dup) ponF.dup.remove();
  } catch (e) {}
  try {
    if (ponB && ponB.dup) ponB.dup.remove();
  } catch (e) {}
  var artboardCleanupWarning = "";
  if (errors.length === 0) {
    var cleanup = dcRemoveOldCanvasArtboards(doc, oldAb);
    artboardCleanupWarning = cleanup.warning;
    try {
      doc.artboards.setActiveArtboardIndex(cleanup.firstNewIndex);
    } catch (selectNewBoardError) {}
  } else artboardCleanupWarning = " Chưa xóa artboard cũ vì dàn còn lỗi.";

  // Giữ toàn bộ artwork vừa dàn ở trạng thái chọn để chạy Đặt pon ngay.
  try {
    doc.selection = null;
    for (
      var selectedIndex = 0;
      selectedIndex < outputItems.length;
      selectedIndex++
    ) {
      try {
        outputItems[selectedIndex].selected = true;
      } catch (selectOutputError) {}
    }
  } catch (selectOutputsError) {}

  app.redraw();
  var msg =
    MODE === "one"
      ? "Đã dàn " +
        sourceItems.length +
        " nguồn thành " +
        outputBatchCount +
        " artboard; " +
        (useMultiSource
          ? "mỗi artboard gán các nguồn lần lượt vào " +
            blocks.F.slots.length +
            " slot mẫu."
          : "mỗi artboard nhân 1 nguồn vào " +
            blocks.F.slots.length +
            " slot mẫu.")
      : "Đã dàn 2 mặt " +
        sourceItems.length / 2 +
        " cặp nguồn thành " +
        outputBatchCount +
        " cặp artboard (trái=trước, phải=sau); " +
        (useMultiSource
          ? "mỗi artboard gán các nguồn lần lượt vào slot mẫu."
          : "mỗi artboard nhân 1 nguồn tương ứng vào toàn bộ slot mẫu.");
  if (filledSlotCount > 0)
    msg +=
      "\nĐã bù " +
      filledSlotCount +
      " slot còn thiếu bằng con cuối rồi gần cuối của từng lô nguồn.";
  if (errors.length > 0) msg += "\n\nLưu ý:\n- " + errors.join("\n- ");
  msg += artboardCleanupWarning;
  alert(msg);
  return (
    "OK: " +
    (MODE === "one"
      ? "Đã dàn 1 mặt " +
        sourceItems.length +
        " nguồn thành " +
        outputBatchCount +
        " artboard (" +
        (useMultiSource ? "nhiều mẫu/1 artboard" : "1 mẫu/1 artboard") +
        ")." +
        (errors.length ? " (" + errors.length + " lưu ý)" : "")
      : "Đã dàn 2 mặt " +
        outputBatchCount +
        " cặp artboard (" +
        (useMultiSource ? "nhiều mẫu/1 artboard" : "1 mẫu/1 artboard") +
        ")." +
        (errors.length ? " (" + errors.length + " lưu ý)" : "")) +
    artboardCleanupWarning
  );
}

// ============================================================
//  dcAutoSavePDF — Auto Save từng con card ra PDF (mặt trước + mặt sau)
//  Tác giả: LỘC (Code dạo) — thêm cho DanCard
//
//  Ý tưởng:
//    - Chọn (n x 2) object trên trang: mỗi HÀNG = [trước][sau]
//      (sort y giảm dần -> hàng trên trước; trong 1 cặp sort x tăng
//       -> trái = MẶT TRƯỚC, phải = MẶT SAU). Giống dcDan.
//    - Mỗi con card -> 1 file PDF 2 TRANG:
//         trang 1 = mặt trước, trang 2 = mặt sau.
//    - KHÔNG đụng file gốc: nhân đôi 2 object của con card sang 1
//      TÀI LIỆU TẠM, tạo 2 artboard vừa khít, export PDF rồi đóng
//      không lưu. Nhờ vậy PDF chỉ chứa đúng con card đó (đã "xóa
//      rác" một cách an toàn), file nhẹ, và file gốc nguyên vẹn —
//      không cần Ctrl+Z, không rủi ro mất artwork.
//
//  Tên file: 1088 - {STT} - {soHop} hộp - {ghiChu} - [1 mat] - {canMang} - {ngay}.pdf
//    vd: "1088 - 01 - 5 hộp - ghi chú - 1 mat - cm - 16.pdf"
//    "1 mat" chỉ thêm cho con được nhận diện là 1 mặt.
//
//  Tham số (đều là chuỗi, panel truyền vào):
//    prefix   : mã bắt buộc, mặc định "1088"
//    startNo  : STT bắt đầu (vd "1")
//    pad      : đệm số 0 cho STT (vd "2" -> 01,02..; "0" -> 1,2..)
//    soHop    : số hộp (vd "5") -> ghi "5 hộp"
//    canMang  : "cm" (cán màng) hoặc "km" (không màng)
//    ngay     : ngày đặt in (vd "16")
//    outFolder: thư mục lưu; rỗng -> hỏi chọn thư mục
//  Trả về "OK: ..." hoặc "ERR: ..."
// ============================================================
// ============================================================
//  Lưu kết quả Dàn theo mẫu ra PDF sạch.
//  Mỗi lần xuất dựng một document tạm chỉ có object của artboard cần lưu,
//  rồi đóng không lưu, nên file PDF không mang theo object ngoài artboard.
// ============================================================
function dcLuuDanTheoMauPDF_CopyObjectLegacy(saveMode, suffix) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
    var doc = app.activeDocument;
    var mode = String(
      saveMode === undefined || saveMode === null ? "each" : saveMode,
    );
    if (mode !== "each" && mode !== "pair")
      return "ERR: Kiểu lưu PDF không hợp lệ.";

    suffix = String(
      suffix === undefined || suffix === null ? "" : suffix,
    ).replace(/^\s+|\s+$/g, "");

    function positiveRect(rect) {
      return (
        rect &&
        rect.length === 4 &&
        isFinite(rect[0]) &&
        isFinite(rect[1]) &&
        isFinite(rect[2]) &&
        isFinite(rect[3]) &&
        rect[2] > rect[0] &&
        rect[1] > rect[3]
      );
    }
    function itemBounds(item) {
      try {
        var b = item.visibleBounds;
        if (positiveRect(b)) return b;
      } catch (e) {}
      try {
        var g = item.geometricBounds;
        if (positiveRect(g)) return g;
      } catch (e2) {}
      return null;
    }
    function overlaps(rect, bounds) {
      return (
        bounds[2] > rect[0] &&
        bounds[0] < rect[2] &&
        bounds[1] > rect[3] &&
        bounds[3] < rect[1]
      );
    }
    function centerIn(rect, bounds) {
      var cx = (bounds[0] + bounds[2]) / 2;
      var cy = (bounds[1] + bounds[3]) / 2;
      var eps = 0.1;
      return (
        cx >= rect[0] - eps &&
        cx <= rect[2] + eps &&
        cy >= rect[3] - eps &&
        cy <= rect[1] + eps
      );
    }
    function directChildren(group) {
      var result = [];
      try {
        for (var i = 0; i < group.pageItems.length; i++) {
          var child = group.pageItems[i];
          try {
            if (child.parent === group) result.push(child);
          } catch (e) {}
        }
      } catch (e2) {}
      return result;
    }
    function addItemForArtboard(item, rect, result) {
      var bounds = itemBounds(item);
      if (!bounds || !overlaps(rect, bounds)) return;
      if (centerIn(rect, bounds)) {
        result.push(item);
        return;
      }

      // Nhóm dấu cắt có thể trải qua nhiều artboard. Tách nhóm không clip
      // theo object con để mỗi PDF chỉ nhận phần của chính artboard đó.
      var type = "";
      var clipped = false;
      try {
        type = item.typename;
        clipped = item.clipped === true;
      } catch (e) {}
      if (type === "GroupItem" && !clipped) {
        var children = directChildren(item);
        for (var ci = 0; ci < children.length; ci++)
          addItemForArtboard(children[ci], rect, result);
        return;
      }
      result.push(item);
    }
    function collectArtboardItems(rect) {
      var result = [];
      for (var li = 0; li < doc.layers.length; li++) {
        var layer = doc.layers[li];
        try {
          if (layer.visible === false || layer.locked === true) continue;
        } catch (e) {}
        var topItems = [];
        try {
          for (var pi = 0; pi < layer.pageItems.length; pi++) {
            var item = layer.pageItems[pi];
            try {
              if (item.parent === layer) topItems.push(item);
            } catch (e2) {}
          }
        } catch (e3) {}
        for (var ti = 0; ti < topItems.length; ti++)
          addItemForArtboard(topItems[ti], rect, result);
      }
      return result;
    }
    function sanitizeName(value) {
      return String(value)
        .replace(/[\\\/:*?"<>|]/g, "-")
        .replace(/^\s+|\s+$/g, "");
    }
    function makePdfOptions(pageCount) {
      var opt = new PDFSaveOptions();
      try {
        opt.compatibility = PDFCompatibility.ACROBAT5;
      } catch (e) {}
      try {
        opt.generateThumbnails = false;
      } catch (e2) {}
      try {
        opt.preserveEditability = false;
      } catch (e3) {}
      try {
        opt.optimization = true;
      } catch (e4) {}
      try {
        opt.viewAfterSaving = false;
      } catch (e5) {}
      try {
        opt.saveMultipleArtboards = true;
      } catch (e6) {}
      try {
        opt.artboardRange = pageCount === 1 ? "1" : "1-" + pageCount;
      } catch (e7) {}
      return opt;
    }
    function exportPages(pages, filePath) {
      var tmp = null;
      var completed = false;
      try {
        tmp = app.documents.add(DocumentColorSpace.CMYK);
        tmp.artboards[0].artboardRect = pages[0].rect.slice(0);
        for (var ai = 1; ai < pages.length; ai++)
          tmp.artboards.add(pages[ai].rect.slice(0));

        for (var page = 0; page < pages.length; page++) {
          var items = collectArtboardItems(pages[page].rect);
          if (items.length === 0)
            throw new Error(
              "Artboard " +
                (pages[page].index + 1) +
                " không có object để lưu.",
            );
          for (var oi = 0; oi < items.length; oi++) {
            app.activeDocument = doc;
            items[oi].duplicate(tmp.layers[0], ElementPlacement.PLACEATEND);
            app.activeDocument = tmp;
          }
        }
        tmp.saveAs(new File(filePath), makePdfOptions(pages.length));
        completed = true;
      } finally {
        try {
          if (tmp) tmp.close(SaveOptions.DONOTSAVECHANGES);
        } catch (e) {}
        if (!completed) {
          try {
            var incomplete = new File(filePath);
            if (incomplete.exists) incomplete.remove();
          } catch (e2) {}
        }
        try {
          app.activeDocument = doc;
        } catch (e3) {}
      }
    }

    var artboards = [];
    for (var i = 0; i < doc.artboards.length; i++) {
      var rect = doc.artboards[i].artboardRect.slice(0);
      if (!positiveRect(rect))
        return "ERR: Artboard " + (i + 1) + " không có kích thước hợp lệ.";
      artboards.push({ index: i, rect: rect });
    }
    if (artboards.length === 0) return "ERR: Không có artboard nào để lưu.";
    if (mode === "pair" && artboards.length % 2 !== 0)
      return "ERR: Lưu mặt trước + mặt sau cần số artboard chẵn.";

    var folder = dcChonThuMucLuuPDF("Chọn nơi lưu PDF đã dàn theo mẫu");
    if (!folder) return "ERR: Chưa chọn thư mục lưu PDF - đã huỷ.";

    var suffixPart = sanitizeName(suffix);
    var jobs = [];
    for (var ab = 0; ab < artboards.length; ab += mode === "pair" ? 2 : 1) {
      var pages = [artboards[ab]];
      if (mode === "pair") pages.push(artboards[ab + 1]);
      var fileNo = jobs.length + 1;
      var name =
        "file " + fileNo + (suffixPart ? " - " + suffixPart : "") + ".pdf";
      jobs.push({ pages: pages, name: name, path: folder.fsName + "/" + name });
    }

    var seen = {};
    for (var ji = 0; ji < jobs.length; ji++) {
      var key = String(jobs[ji].path).toLowerCase();
      if (seen[key]) return "ERR: Có hai PDF trùng tên " + jobs[ji].name + ".";
      if (new File(jobs[ji].path).exists)
        return (
          "ERR: File đã tồn tại: " +
          jobs[ji].name +
          ". Hãy đổi hậu tố hoặc thư mục."
        );
      seen[key] = true;
    }

    var done = 0;
    var errors = [];
    for (var jobIndex = 0; jobIndex < jobs.length; jobIndex++) {
      try {
        exportPages(jobs[jobIndex].pages, jobs[jobIndex].path);
        done++;
      } catch (exportError) {
        errors.push(
          jobs[jobIndex].name +
            ": " +
            (typeof dcMoTaLoi === "function"
              ? dcMoTaLoi(exportError)
              : exportError.toString()),
        );
      }
    }
    if (done === 0)
      return (
        "ERR: Không lưu được PDF nào." +
        (errors.length ? " " + errors.join(" | ") : "")
      );
    var message =
      "OK: Đã lưu " +
      done +
      " PDF " +
      (mode === "pair" ? "mặt trước + mặt sau" : "theo từng artboard") +
      ".";
    if (errors.length)
      message += " Lỗi " + errors.length + " file: " + errors.join(" | ");
    return message;
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}

// Xuất trực tiếp artboard từ một bản sao AI, không copy từng object.
// Bản sao giúp file người dùng đang mở không bị saveAs thành PDF.
function dcLuuDanTheoMauPDF_SavedAICopyLegacy(saveMode, suffix) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
    var sourceDoc = app.activeDocument;
    var mode = String(
      saveMode === undefined || saveMode === null ? "each" : saveMode,
    );
    if (mode !== "each" && mode !== "pair")
      return "ERR: Kiểu lưu PDF không hợp lệ.";
    // Dàn theo mẫu vừa tạo artboard và object mới, nên document có dấu *.
    // Lưu AI trước khi copy để PDF luôn nhận đúng kết quả vừa dàn.
    if (!sourceDoc.saved) {
      try {
        sourceDoc.save();
      } catch (saveSourceError) {
        return (
          "ERR: Không tự lưu được file AI trước khi xuất PDF. " +
          (typeof dcMoTaLoi === "function"
            ? dcMoTaLoi(saveSourceError)
            : saveSourceError.toString())
        );
      }
    }

    var sourceFile = null;
    try {
      sourceFile = sourceDoc.fullName;
    } catch (e) {}
    if (!sourceFile || !sourceFile.exists || !/\.ai$/i.test(sourceFile.name))
      return "ERR: Chỉ xuất được file dàn đã lưu dưới dạng AI.";

    var artboardCount = sourceDoc.artboards.length;
    if (artboardCount === 0) return "ERR: Không có artboard nào để lưu.";
    if (mode === "pair" && artboardCount % 2 !== 0)
      return "ERR: Lưu mặt trước + mặt sau cần số artboard chẵn.";
    // PDF dùng point và Illustrator sẽ hạ độ chính xác khi ghi MediaBox. Nới
    // không quá 0.01 pt theo cả hai phía để khi mở lại PDF, trường W/H vẫn
    // hiện đúng số cm của artboard gốc (ví dụ 35.4 thay vì 35.399).
    function pdfStableArtboardRect(rect) {
      var left = rect[0],
        top = rect[1],
        right = rect[2],
        bottom = rect[3];
      var width = right - left,
        height = top - bottom;
      var stableWidth = Math.ceil(width * 100 - 0.000001) / 100;
      var stableHeight = Math.ceil(height * 100 - 0.000001) / 100;
      var centerX = (left + right) / 2,
        centerY = (top + bottom) / 2;
      return [
        centerX - stableWidth / 2,
        centerY + stableHeight / 2,
        centerX + stableWidth / 2,
        centerY - stableHeight / 2,
      ];
    }
    var artboardRects = [];
    for (var sourceAb = 0; sourceAb < artboardCount; sourceAb++)
      artboardRects.push(
        pdfStableArtboardRect(sourceDoc.artboards[sourceAb].artboardRect),
      );

    suffix = String(suffix === undefined || suffix === null ? "" : suffix)
      .replace(/^\s+|\s+$/g, "")
      .replace(/[\\\\\/:*?\"<>|]/g, "-");
    var folder = dcChonThuMucLuuPDF("Chọn nơi lưu PDF đã dàn theo mẫu");
    if (!folder) return "ERR: Chưa chọn thư mục lưu PDF - đã huỷ.";

    var jobs = [];
    var span = mode === "pair" ? 2 : 1;
    for (var first = 0; first < artboardCount; first += span) {
      var startNo = first + 1;
      var endNo = first + span;
      var fileNo = jobs.length + 1;
      var fileName = "file " + fileNo + (suffix ? " - " + suffix : "") + ".pdf";
      var outputFile = new File(folder.fsName + "/" + fileName);
      if (outputFile.exists) return "ERR: File đã tồn tại: " + fileName + ".";
      jobs.push({
        file: outputFile,
        name: fileName,
        range: startNo === endNo ? String(startNo) : startNo + "-" + endNo,
      });
    }

    function makePdfOptions(range) {
      var opt = new PDFSaveOptions();
      try {
        opt.compatibility = PDFCompatibility.ACROBAT5;
      } catch (e) {}
      try {
        opt.generateThumbnails = false;
      } catch (e2) {}
      try {
        opt.preserveEditability = false;
      } catch (e3) {}
      try {
        opt.optimization = true;
      } catch (e4) {}
      try {
        opt.viewAfterSaving = false;
      } catch (e5) {}
      try {
        opt.saveMultipleArtboards = true;
      } catch (e6) {}
      try {
        opt.artboardRange = range;
      } catch (e7) {}
      return opt;
    }

    var tempFile = new File(
      Folder.temp.fsName +
        "/DanCardPdf-" +
        new Date().getTime() +
        "-" +
        Math.floor(Math.random() * 1000000) +
        ".ai",
    );
    if (!sourceFile.copy(tempFile))
      return "ERR: Không tạo được bản tạm để xuất PDF.";

    var workDoc = null;
    var done = 0;
    var errors = [];
    try {
      workDoc = app.open(tempFile);
      for (var ji = 0; ji < jobs.length; ji++) {
        try {
          // Range dùng đúng số thứ tự trong bảng Artboards của Illustrator.
          workDoc.saveAs(jobs[ji].file, makePdfOptions(jobs[ji].range));
          done++;
        } catch (saveError) {
          errors.push(
            jobs[ji].name +
              ": " +
              (typeof dcMoTaLoi === "function"
                ? dcMoTaLoi(saveError)
                : saveError.toString()),
          );
        }
      }
    } finally {
      try {
        if (workDoc) workDoc.close(SaveOptions.DONOTSAVECHANGES);
      } catch (closeError) {}
      try {
        if (tempFile.exists) tempFile.remove();
      } catch (removeError) {}
      try {
        sourceDoc.activate();
      } catch (activateError) {}
    }

    if (done === 0)
      return (
        "ERR: Không lưu được PDF nào." +
        (errors.length ? " " + errors.join(" | ") : "")
      );
    var message =
      "OK: Đã lưu " +
      done +
      " PDF theo thứ tự Artboard" +
      (mode === "pair" ? " (1+2, 3+4...)." : ".");
    if (errors.length)
      message += " Lỗi " + errors.length + " file: " + errors.join(" | ");
    return message;
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}

// Xuất từ document tạm: copy artwork một lần, sau đó xuất đúng artboard range.
// Không save file AI người dùng đang mở và không lặp copy cho từng PDF.
function dcLuuDanTheoMauPDF_TempLayoutLegacy(saveMode, suffix) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
    var sourceDoc = app.activeDocument;
    var mode = String(
      saveMode === undefined || saveMode === null ? "each" : saveMode,
    );
    if (mode !== "each" && mode !== "pair")
      return "ERR: Kiểu lưu PDF không hợp lệ.";

    var artboardCount = sourceDoc.artboards.length;
    if (artboardCount === 0) return "ERR: Không có artboard nào để lưu.";
    if (mode === "pair" && artboardCount % 2 !== 0)
      return "ERR: Lưu mặt trước + mặt sau cần số artboard chẵn.";
    var artboardRects = [];
    for (var sourceAb = 0; sourceAb < artboardCount; sourceAb++)
      artboardRects.push(sourceDoc.artboards[sourceAb].artboardRect.slice(0));

    // Document tạm dùng hệ tọa độ riêng, sắp artboard theo lưới cố định.
    // Không mang tọa độ toàn trang từ file gốc sang nên artboard ở cột 2, 3...
    // được xuất giống hệt artboard ở cột đầu.
    function makeWorkArtboardRects(sourceRects) {
      var maxWidth = 0,
        maxHeight = 0;
      for (var rectIndex = 0; rectIndex < sourceRects.length; rectIndex++) {
        maxWidth = Math.max(
          maxWidth,
          sourceRects[rectIndex][2] - sourceRects[rectIndex][0],
        );
        maxHeight = Math.max(
          maxHeight,
          sourceRects[rectIndex][1] - sourceRects[rectIndex][3],
        );
      }
      var perColumn = 15,
        gap = 36,
        result = [];
      for (
        var targetIndex = 0;
        targetIndex < sourceRects.length;
        targetIndex++
      ) {
        var sourceRect = sourceRects[targetIndex];
        var column = Math.floor(targetIndex / perColumn);
        var row = targetIndex % perColumn;
        var left = column * (maxWidth + gap);
        var top = -row * (maxHeight + gap);
        result.push([
          left,
          top,
          left + (sourceRect[2] - sourceRect[0]),
          top - (sourceRect[1] - sourceRect[3]),
        ]);
      }
      return result;
    }
    var workArtboardRects = makeWorkArtboardRects(artboardRects);

    suffix = String(suffix === undefined || suffix === null ? "" : suffix)
      .replace(/^\s+|\s+$/g, "")
      .replace(/[\\\\\/:*?\"<>|]/g, "-");
    var folder = dcChonThuMucLuuPDF("Chọn nơi lưu PDF đã dàn theo mẫu");
    if (!folder) return "ERR: Chưa chọn thư mục lưu PDF - đã huỷ.";

    var jobs = [];
    var span = mode === "pair" ? 2 : 1;
    for (var first = 0; first < artboardCount; first += span) {
      var startNo = first + 1;
      var endNo = first + span;
      var fileNo = jobs.length + 1;
      var fileName = "file " + fileNo + (suffix ? " - " + suffix : "") + ".pdf";
      var outputFile = new File(folder.fsName + "/" + fileName);
      if (outputFile.exists) return "ERR: File đã tồn tại: " + fileName + ".";
      jobs.push({
        file: outputFile,
        name: fileName,
        range: startNo === endNo ? String(startNo) : startNo + "-" + endNo,
      });
    }

    function makePdfOptions(range) {
      var opt = new PDFSaveOptions();
      try {
        opt.compatibility = PDFCompatibility.ACROBAT5;
      } catch (e) {}
      try {
        opt.generateThumbnails = false;
      } catch (e2) {}
      try {
        opt.preserveEditability = false;
      } catch (e3) {}
      try {
        opt.optimization = true;
      } catch (e4) {}
      try {
        opt.viewAfterSaving = false;
      } catch (e5) {}
      try {
        opt.saveMultipleArtboards = true;
      } catch (e6) {}
      try {
        opt.artboardRange = range;
      } catch (e7) {}
      return opt;
    }
    function placementBounds(item) {
      var bounds = null;
      try {
        bounds = item.visibleBounds;
      } catch (visibleBoundsError) {}
      if (
        bounds &&
        bounds.length === 4 &&
        isFinite(bounds[0]) &&
        isFinite(bounds[1]) &&
        isFinite(bounds[2]) &&
        isFinite(bounds[3])
      )
        return bounds.slice(0);
      try {
        bounds = item.geometricBounds;
      } catch (geometricBoundsError) {}
      if (
        bounds &&
        bounds.length === 4 &&
        isFinite(bounds[0]) &&
        isFinite(bounds[1]) &&
        isFinite(bounds[2]) &&
        isFinite(bounds[3])
      )
        return bounds.slice(0);
      return null;
    }
    function copyLayerItems(layerPlan, targetLayer, copyErrors) {
      layerPlan.items.sort(function (a, b) {
        if (a.artboardIndex !== b.artboardIndex)
          return a.artboardIndex - b.artboardIndex;
        return a.z - b.z;
      });
      var copiedItems = [];
      // Giữ document gốc active cho cả layer, tránh nhảy qua lại từng object.
      sourceDoc.activate();
      for (var ii = 0; ii < layerPlan.items.length; ii++) {
        try {
          copiedItems.push({
            source: layerPlan.items[ii],
            item: layerPlan.items[ii].item.duplicate(
              targetLayer,
              ElementPlacement.PLACEATEND,
            ),
          });
        } catch (copyError) {
          copyErrors.push(
            "Layer " +
              layerPlan.name +
              ": " +
              (typeof dcMoTaLoi === "function"
                ? dcMoTaLoi(copyError)
                : copyError.toString()),
          );
        }
      }

      var copied = 0;
      workDoc.activate();
      for (var ci = 0; ci < copiedItems.length; ci++) {
        try {
          // Đặt artwork theo tọa độ tương đối trong artboard của nó. Cách này
          // không phụ thuộc artboard gốc nằm ở cột nào trên canvas.
          var copiedBounds = placementBounds(copiedItems[ci].item);
          if (!copiedBounds)
            throw new Error("Không đo được vùng hiển thị object đã copy.");
          var sourceEntry = copiedItems[ci].source;
          var targetLeft =
            sourceEntry.targetRect[0] +
            (sourceEntry.bounds[0] - sourceEntry.sourceRect[0]);
          var targetTop =
            sourceEntry.targetRect[1] +
            (sourceEntry.bounds[1] - sourceEntry.sourceRect[1]);
          copiedItems[ci].item.translate(
            targetLeft - copiedBounds[0],
            targetTop - copiedBounds[1],
          );
          copied++;
        } catch (positionError) {
          copyErrors.push(
            "Layer " +
              layerPlan.name +
              ": " +
              (typeof dcMoTaLoi === "function"
                ? dcMoTaLoi(positionError)
                : positionError.toString()),
          );
        }
      }
      return copied;
    }

    // Dùng chính selection theo artboard của Illustrator, thay vì tự so tọa độ
    // hay bounds. Group/clipping mask ở artboard nằm ngoài cột dàn vẫn được
    // Illustrator nhận diện và lấy đủ artwork con.
    var originalSelection = [];
    var originalArtboard = 0;
    try {
      for (
        var originalIndex = 0;
        originalIndex < sourceDoc.selection.length;
        originalIndex++
      )
        originalSelection.push(sourceDoc.selection[originalIndex]);
    } catch (originalSelectionError) {}
    try {
      originalArtboard = sourceDoc.artboards.getActiveArtboardIndex();
    } catch (originalArtboardError) {}

    var layerPlans = [];
    function topLevelItem(item) {
      var top = item;
      try {
        while (top.parent && top.parent.typename !== "Layer") top = top.parent;
      } catch (topLevelError) {}
      return top;
    }
    function sourceLayerFor(item) {
      try {
        return item.parent && item.parent.typename === "Layer"
          ? item.parent
          : null;
      } catch (sourceLayerError) {}
      return null;
    }
    function findLayerPlan(layer) {
      for (var planIndex = 0; planIndex < layerPlans.length; planIndex++)
        if (layerPlans[planIndex].layer === layer) return layerPlans[planIndex];
      var plan = { layer: layer, name: "Layer", items: [] };
      try {
        plan.name = layer.name;
      } catch (layerNameError) {}
      layerPlans.push(plan);
      return plan;
    }
    function planContainsItem(plan, item, artboardIndex) {
      for (var itemIndex = 0; itemIndex < plan.items.length; itemIndex++)
        if (
          plan.items[itemIndex].item === item &&
          plan.items[itemIndex].artboardIndex === artboardIndex
        )
          return true;
      return false;
    }
    for (var snapshotAb = 0; snapshotAb < artboardCount; snapshotAb++) {
      sourceDoc.activate();
      sourceDoc.artboards.setActiveArtboardIndex(snapshotAb);
      sourceDoc.selection = null;
      sourceDoc.selectObjectsOnActiveArtboard();
      for (
        var snapshotSelection = 0;
        snapshotSelection < sourceDoc.selection.length;
        snapshotSelection++
      ) {
        try {
          var snapshotItem = topLevelItem(
            sourceDoc.selection[snapshotSelection],
          );
          var snapshotLayer = sourceLayerFor(snapshotItem);
          if (!snapshotLayer || snapshotLayer.visible === false) continue;
          var targetPlan = findLayerPlan(snapshotLayer);
          if (planContainsItem(targetPlan, snapshotItem, snapshotAb)) continue;
          var snapshotBounds = placementBounds(snapshotItem);
          if (!snapshotBounds) continue;
          targetPlan.items.push({
            item: snapshotItem,
            z: snapshotItem.zOrderPosition,
            bounds: snapshotBounds,
            sourceRect: artboardRects[snapshotAb],
            targetRect: workArtboardRects[snapshotAb],
            artboardIndex: snapshotAb,
          });
        } catch (snapshotItemError) {}
      }
    }

    var colorSpace = DocumentColorSpace.CMYK;
    try {
      colorSpace = sourceDoc.documentColorSpace;
    } catch (e) {}
    var workDoc = null;
    var copiedCount = 0;
    var copyErrors = [];
    var done = 0;
    var saveErrors = [];
    try {
      // Illustrator có thể báo lỗi 1200 khi gọi artboards.add() liên tiếp
      // trên document tạm. Tạo đủ artboard ngay khi tạo document, sau đó mới
      // đặt từng rect; cách này không phụ thuộc artboard đang ở cột nào.
      var maxWorkWidth = 1;
      var maxWorkHeight = 1;
      for (
        var sizeIndex = 0;
        sizeIndex < workArtboardRects.length;
        sizeIndex++
      ) {
        var sizeRect = workArtboardRects[sizeIndex];
        maxWorkWidth = Math.max(maxWorkWidth, sizeRect[2] - sizeRect[0]);
        maxWorkHeight = Math.max(maxWorkHeight, sizeRect[1] - sizeRect[3]);
      }
      workDoc = app.documents.add(
        colorSpace,
        maxWorkWidth,
        maxWorkHeight,
        artboardCount,
      );
      if (workDoc.artboards.length !== artboardCount)
        throw new Error("Không tạo đủ artboard tạm để xuất PDF.");
      // Một số file Illustrator bị lỗi 1200 khi gán
      // artboardRect sau khi tạo. Thay vào đó dùng rect native của Illustrator.
      var nativeWorkArtboardRects = [];
      for (var ab = 0; ab < artboardCount; ab++)
        nativeWorkArtboardRects.push(
          workDoc.artboards[ab].artboardRect.slice(0),
        );
      for (
        var nativePlanIndex = 0;
        nativePlanIndex < layerPlans.length;
        nativePlanIndex++
      ) {
        var nativePlanItems = layerPlans[nativePlanIndex].items;
        for (
          var nativeItemIndex = 0;
          nativeItemIndex < nativePlanItems.length;
          nativeItemIndex++
        )
          nativePlanItems[nativeItemIndex].targetRect =
            nativeWorkArtboardRects[
              nativePlanItems[nativeItemIndex].artboardIndex
            ];
      }

      // Layers.add() thêm lên đầu; đi từ layer dưới lên để giữ thứ tự chồng lớp.
      for (var li = 0; li < layerPlans.length; li++) {
        var layerPlan = layerPlans[li];
        var targetLayer = workDoc.layers.add();
        try {
          targetLayer.name = layerPlan.name;
        } catch (e3) {}
        copiedCount += copyLayerItems(layerPlan, targetLayer, copyErrors);
      }
      if (copiedCount === 0)
        return "ERR: Không tìm thấy object nào nằm trong artboard để xuất.";

      for (var ji = 0; ji < jobs.length; ji++) {
        try {
          // Range dùng đúng số thứ tự trong bảng Artboards của Illustrator.
          workDoc.saveAs(jobs[ji].file, makePdfOptions(jobs[ji].range));
          done++;
        } catch (saveError) {
          saveErrors.push(
            jobs[ji].name +
              ": " +
              (typeof dcMoTaLoi === "function"
                ? dcMoTaLoi(saveError)
                : saveError.toString()),
          );
        }
      }
    } finally {
      try {
        if (workDoc) workDoc.close(SaveOptions.DONOTSAVECHANGES);
      } catch (closeError) {}
      try {
        sourceDoc.activate();
        sourceDoc.artboards.setActiveArtboardIndex(originalArtboard);
        sourceDoc.selection = null;
        for (
          var restoreSelection = 0;
          restoreSelection < originalSelection.length;
          restoreSelection++
        )
          originalSelection[restoreSelection].selected = true;
      } catch (activateError) {}
    }

    if (done === 0)
      return (
        "ERR: Không lưu được PDF nào." +
        (saveErrors.length ? " " + saveErrors.join(" | ") : "")
      );
    var message =
      "OK: Đã lưu " +
      done +
      " PDF theo thứ tự Artboard" +
      (mode === "pair" ? " (1+2, 3+4...)." : ".");
    if (copyErrors.length)
      message += " Bỏ qua " + copyErrors.length + " object lỗi khi copy.";
    if (saveErrors.length)
      message +=
        " Lỗi " + saveErrors.length + " file: " + saveErrors.join(" | ");
    return message;
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}

// Xuất từng artboard bằng selection native của Illustrator. Không quét toàn bộ
// document, không lưu AI gốc và mỗi PDF chỉ chứa artwork của artboard cần xuất.
// Bộ xuất đang dùng: chỉ chép phần bài được chọn từ từng artboard gốc.
// Tài liệu nguồn không bao giờ bị lưu hay bị dùng làm bản sao tạm toàn bộ.
function dcLuuDanTheoMauPDF(saveMode, suffix) {
  return dcLuuDanTheoMauPDF_SelectedLegacy(saveMode, suffix);
}

function dcLuuDanTheoMauPDF_SelectedLegacy(saveMode, suffix) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
    var sourceDoc = app.activeDocument;
    var mode = String(
      saveMode === undefined || saveMode === null ? "each" : saveMode,
    );
    if (mode !== "each" && mode !== "pair")
      return "ERR: Kiểu lưu PDF không hợp lệ.";
    var artboardCount = sourceDoc.artboards.length;
    if (artboardCount === 0) return "ERR: Không có artboard nào để lưu.";
    if (mode === "pair" && artboardCount % 2 !== 0)
      return "ERR: Lưu mặt trước + mặt sau cần số artboard chẵn.";

    suffix = String(suffix === undefined || suffix === null ? "" : suffix)
      .replace(/^\s+|\s+$/g, "")
      .replace(/[\\\\\/:*?\"<>|]/g, "-");
    var folder = dcChonThuMucLuuPDF("Chọn nơi lưu PDF đã dàn theo mẫu");
    if (!folder) return "ERR: Chưa chọn thư mục lưu PDF - đã huỷ.";

    var jobs = [];
    var span = mode === "pair" ? 2 : 1;
    for (var first = 0; first < artboardCount; first += span) {
      var fileNo = jobs.length + 1;
      var fileName = "file " + fileNo + (suffix ? " - " + suffix : "") + ".pdf";
      var outputFile = new File(folder.fsName + "/" + fileName);
      if (outputFile.exists) return "ERR: File đã tồn tại: " + fileName + ".";
      var indices = [first];
      if (span === 2) indices.push(first + 1);
      jobs.push({ file: outputFile, name: fileName, indices: indices });
    }

    var originalSelection = [];
    try {
      for (var os = 0; os < sourceDoc.selection.length; os++)
        originalSelection.push(sourceDoc.selection[os]);
    } catch (e) {}
    var originalArtboard = 0;
    try {
      originalArtboard = sourceDoc.artboards.getActiveArtboardIndex();
    } catch (e2) {}

    var colorSpace = DocumentColorSpace.CMYK;
    try {
      colorSpace = sourceDoc.documentColorSpace;
    } catch (e3) {}
    function topLevelItem(item) {
      var top = item;
      try {
        while (top.parent && top.parent.typename === "GroupItem")
          top = top.parent;
      } catch (e) {}
      return top;
    }
    function selectedTopLevelItems() {
      var items = [];
      for (
        var selectedIndex = 0;
        selectedIndex < sourceDoc.selection.length;
        selectedIndex++
      ) {
        var item = topLevelItem(sourceDoc.selection[selectedIndex]);
        var alreadyAdded = false;
        for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
          if (items[itemIndex] === item) {
            alreadyAdded = true;
            break;
          }
        }
        if (!alreadyAdded) items.push(item);
      }
      return items;
    }
    function makePdfOptions(pageCount) {
      var opt = new PDFSaveOptions();
      try {
        opt.compatibility = PDFCompatibility.ACROBAT5;
      } catch (e) {}
      try {
        opt.generateThumbnails = false;
      } catch (e2) {}
      try {
        opt.preserveEditability = false;
      } catch (e3) {}
      try {
        opt.optimization = true;
      } catch (e4) {}
      try {
        opt.viewAfterSaving = false;
      } catch (e5) {}
      try {
        opt.saveMultipleArtboards = true;
      } catch (e6) {}
      try {
        opt.artboardRange = pageCount === 1 ? "1" : "1-" + pageCount;
      } catch (e7) {}
      return opt;
    }
    // Chỉ group trên nguồn vừa đủ lâu để nhân bản một lần, rồi undo. Nhờ vậy
    // file AI đang mở không đổi, và khỏi chép sang tài liệu khác từng object một.
    function copyPageAsOneGroup(page, targetRect, workDoc, errors) {
      var grouped = false;
      try {
        sourceDoc.activate();
        sourceDoc.artboards.setActiveArtboardIndex(page.index);
        sourceDoc.selection = null;
        sourceDoc.selectObjectsOnActiveArtboard();
        var items = selectedTopLevelItems();
        if (items.length === 0)
          throw new Error(
            "Artboard " + (page.index + 1) + " không có object để lưu.",
          );

        var sourceItem = items[0];
        if (items.length > 1) {
          sourceDoc.selection = null;
          for (var selectIndex = 0; selectIndex < items.length; selectIndex++)
            items[selectIndex].selected = true;
          app.executeMenuCommand("group");
          grouped = true;
          var groupedItems = selectedTopLevelItems();
          if (groupedItems.length !== 1)
            throw new Error("Không group được object của artboard.");
          sourceItem = groupedItems[0];
        }

        var sourceBounds = sourceItem.geometricBounds.slice(0);
        var copiedItem = sourceItem.duplicate(
          workDoc.layers[0],
          ElementPlacement.PLACEATEND,
        );
        workDoc.activate();
        var copiedBounds = copiedItem.geometricBounds;
        var targetLeft = targetRect[0] + (sourceBounds[0] - page.rect[0]);
        var targetTop = targetRect[1] + (sourceBounds[1] - page.rect[1]);
        copiedItem.translate(
          targetLeft - copiedBounds[0],
          targetTop - copiedBounds[1],
        );
        return 1;
      } catch (copyError) {
        errors.push(
          "Artboard " +
            (page.index + 1) +
            ": " +
            (typeof dcMoTaLoi === "function"
              ? dcMoTaLoi(copyError)
              : copyError.toString()),
        );
        return 0;
      } finally {
        if (grouped) {
          try {
            sourceDoc.activate();
            app.undo();
          } catch (undoGroupError) {}
        }
      }
    }
    function exportJob(job, errors) {
      var pages = [];
      for (var pi = 0; pi < job.indices.length; pi++) {
        var pageIndex = job.indices[pi];
        pages.push({
          index: pageIndex,
          rect: sourceDoc.artboards[pageIndex].artboardRect.slice(0),
        });
      }

      var workDoc = null;
      var completed = false;
      try {
        var maxPageWidth = 1;
        var maxPageHeight = 1;
        for (
          var pageSizeIndex = 0;
          pageSizeIndex < pages.length;
          pageSizeIndex++
        ) {
          var pageRect = pages[pageSizeIndex].rect;
          maxPageWidth = Math.max(maxPageWidth, pageRect[2] - pageRect[0]);
          maxPageHeight = Math.max(maxPageHeight, pageRect[1] - pageRect[3]);
        }
        // Tạo đủ trang ngay từ đầu. Không gán artboardRect hay gọi
        // artboards.add: cả hai thao tác đều gây lỗi 1200 trên một số file.
        workDoc = app.documents.add(
          colorSpace,
          maxPageWidth,
          maxPageHeight,
          pages.length,
        );
        if (workDoc.artboards.length !== pages.length)
          throw new Error("Không tạo đủ artboard tạm để xuất PDF.");
        var targetRects = [];
        for (var targetIndex = 0; targetIndex < pages.length; targetIndex++)
          targetRects.push(
            workDoc.artboards[targetIndex].artboardRect.slice(0),
          );
        var copied = 0;
        for (var pageIndex = 0; pageIndex < pages.length; pageIndex++)
          copied += copyPageAsOneGroup(
            pages[pageIndex],
            targetRects[pageIndex],
            workDoc,
            errors,
          );
        if (copied !== pages.length)
          throw new Error("Không copy đủ object của artboard.");
        workDoc.saveAs(job.file, makePdfOptions(pages.length));
        completed = true;
      } finally {
        try {
          if (workDoc) workDoc.close(SaveOptions.DONOTSAVECHANGES);
        } catch (closeError) {}
        if (!completed) {
          try {
            if (job.file.exists) job.file.remove();
          } catch (removeError) {}
        }
      }
    }

    var done = 0;
    var copyErrors = [];
    var saveErrors = [];
    try {
      for (var ji = 0; ji < jobs.length; ji++) {
        try {
          exportJob(jobs[ji], copyErrors);
          done++;
        } catch (saveError) {
          saveErrors.push(
            jobs[ji].name +
              ": " +
              (typeof dcMoTaLoi === "function"
                ? dcMoTaLoi(saveError)
                : saveError.toString()),
          );
        }
      }
    } finally {
      try {
        sourceDoc.activate();
        sourceDoc.artboards.setActiveArtboardIndex(originalArtboard);
        sourceDoc.selection = null;
        for (var rs = 0; rs < originalSelection.length; rs++)
          originalSelection[rs].selected = true;
      } catch (restoreError) {}
    }

    if (done === 0)
      return (
        "ERR: Không lưu được PDF nào." +
        (saveErrors.length ? " " + saveErrors.join(" | ") : "")
      );
    var message = "OK: Đã lưu " + done + " PDF theo thứ tự Artboard.";
    if (copyErrors.length)
      message += " Bỏ qua " + copyErrors.length + " object lỗi khi copy.";
    if (saveErrors.length)
      message +=
        " Lỗi " + saveErrors.length + " file: " + saveErrors.join(" | ");
    return message;
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}

function dcAutoSavePDF(
  prefix,
  startNo,
  pad,
  soHop,
  canMang,
  ngay,
  outFolder,
  note,
  hopTheoThuTu,
) {
  try {
    return _dcAutoSavePDFCore(
      prefix,
      startNo,
      pad,
      soHop,
      canMang,
      ngay,
      outFolder,
      note,
      hopTheoThuTu,
    );
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}

function _dcAutoSavePDFCore(
  prefix,
  startNo,
  pad,
  soHop,
  canMang,
  ngay,
  outFolder,
  note,
  hopTheoThuTu,
) {
  if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
  var doc = app.activeDocument;

  // ---------- Chuẩn hoá tham số ----------
  prefix =
    prefix === undefined || prefix === null || String(prefix) === ""
      ? "1088"
      : String(prefix).replace(/^\s+|\s+$/g, "");
  if (prefix === "") return "ERR: Mã không được để trống.";
  var startText =
    startNo === undefined || startNo === null
      ? "1"
      : String(startNo).replace(/^\s+|\s+$/g, "");
  if (startText === "") startText = "1";
  if (!/^\d+$/.test(startText))
    return "ERR: STT bắt đầu phải là số nguyên từ 0 trở lên.";
  var startN = parseInt(startText, 10);
  var padText =
    pad === undefined || pad === null
      ? "0"
      : String(pad).replace(/^\s+|\s+$/g, "");
  if (padText === "") padText = "0";
  if (!/^\d+$/.test(padText))
    return "ERR: Số đệm phải là số nguyên từ 0 đến 8.";
  var padN = parseInt(padText, 10);
  if (padN > 8) return "ERR: Số đệm tối đa là 8.";
  soHop = soHop === undefined || soHop === null ? "" : String(soHop);
  // Ghi chú (tuỳ chọn) -> chèn vào tên file giữa số hộp và cán màng.
  note =
    note === undefined || note === null
      ? ""
      : String(note).replace(/^\s+|\s+$/g, "");
  var notePart = note !== "" ? " - " + note : "";
  // Tách danh sách số hộp theo dấu phẩy: "100, 200" -> ["100","200"].
  //  - con thứ i dùng hopList[i]; thiếu thì dùng phần tử cuối.
  var hopList = [];
  var _hp = soHop.split(",");
  for (var _hi = 0; _hi < _hp.length; _hi++) {
    var _v = _hp[_hi].replace(/^\s+|\s+$/g, "");
    if (_v !== "") hopList.push(_v);
  }
  if (hopList.length === 0) hopList.push("");
  hopTheoThuTu = hopTheoThuTu === true || String(hopTheoThuTu) === "true";
  function hopForIndex(idx) {
    return idx < hopList.length ? hopList[idx] : hopList[hopList.length - 1];
  }
  canMang =
    canMang === undefined || canMang === null || String(canMang) === ""
      ? "cm"
      : String(canMang);
  ngay = ngay === undefined || ngay === null ? "" : String(ngay);

  // ---------- Kiểm tra selection ----------
  //  Đặt bài thành hàng: cột trái = mặt trước, cột phải = mặt sau.
  //  Hàng chỉ có object ở cột trái được coi là con 1 mặt.
  var sel = doc.selection;
  if (!sel || sel.length === 0)
    return "ERR: Chưa chọn object nào. Hãy chọn các object theo hàng (trái = trước, phải = sau).";

  // ---------- Thư mục lưu ----------
  //  CHỈ lưu vào folder người dùng chọn. KHÔNG tự tạo folder mới.
  //  Lưu ý: ExtendScript hiểu path dạng '/'; path Windows '\' + khoảng
  //  trắng + ngoặc phải chuẩn hoá, nếu không folder.exists sẽ báo sai.
  function resolveFolder(p) {
    if (!p) return null;
    p = String(p);
    var cands = [];
    cands.push(p); // nguyên gốc
    cands.push(p.replace(/\\/g, "/")); // đổi \ -> /
    // Bọc dạng URI (encode khoảng trắng, ngoặc...) để ExtendScript đọc đúng.
    try {
      cands.push(decodeURI(p));
    } catch (e) {}
    for (var i = 0; i < cands.length; i++) {
      var f = new Folder(cands[i]);
      if (f.exists) return f;
    }
    return null;
  }

  var folder;
  if (outFolder && String(outFolder) !== "") {
    folder = resolveFolder(outFolder);
    if (!folder) {
      // Không mở được path đã nhập -> mở hộp chọn thay vì báo lỗi cụt.
      folder = dcChonThuMucLuuPDF("Không mở được thư mục đã nhập. Chọn lại");
      if (!folder)
        return (
          "ERR: Thư mục lưu không mở được: " +
          outFolder +
          '\nHãy bấm "Chọn…" để chọn đúng thư mục.'
        );
    }
  } else {
    // Chưa nhập -> mở hộp thoại cho chọn (không tự tạo, không tự đoán).
    folder = dcChonThuMucLuuPDF("Chọn nơi lưu PDF");
    if (!folder) return "ERR: Chưa chọn thư mục lưu — đã huỷ.";
  }

  // ---------- Đọc bao mỗi object (geometricBounds) ----------
  // Illustrator trả về [left, top, right, bottom]; y hướng lên (top > bottom).
  var items = [];
  var minH = Number.MAX_VALUE;
  for (var i = 0; i < sel.length; i++) {
    var g = null;
    try {
      g = dcKhungThanhPham(sel[i]) || sel[i].geometricBounds;
    } catch (boundsError) {}
    if (
      !g ||
      g.length !== 4 ||
      !isFinite(g[0]) ||
      !isFinite(g[1]) ||
      !isFinite(g[2]) ||
      !isFinite(g[3]) ||
      g[2] <= g[0] ||
      g[1] <= g[3]
    )
      return (
        "ERR: Object " +
        (i + 1) +
        " không có khung hợp lệ. Hãy bỏ object lỗi/đang ẩn rồi thử lại."
      );
    var left = g[0],
      top = g[1],
      right = g[2],
      bottom = g[3];
    var h = top - bottom;
    if (h > 0 && h < minH) minH = h;
    items.push({
      o: sel[i],
      top: top,
      left: left,
      cy: (top + bottom) / 2,
      cx: (left + right) / 2,
    });
  }
  if (!isFinite(minH) || minH <= 0) minH = 10;

  // ---------- Gom theo hàng rồi nhận diện 1 mặt / 2 mặt ----------
  //  Các mặt trong cùng hàng có thể lệch dọc một ít. Dùng 45% chiều cao
  //  object nhỏ nhất làm dung sai để không ghép nhầm object ở hai hàng kề nhau.
  // Illustrator có trục Y tăng dần lên trên, nên tâm Y lớn hơn là hàng trên.
  // Sắp giảm dần để STT và file được xuất từ trên xuống dưới.
  items.sort(function (a, b) {
    return b.cy - a.cy;
  });

  var ROW_TOLERANCE = Math.max(minH * 0.45, 4);
  var rows = [];
  for (i = 0; i < items.length; i++) {
    var lastRow = rows.length ? rows[rows.length - 1] : null;
    if (!lastRow || Math.abs(items[i].cy - lastRow.cy) > ROW_TOLERANCE) {
      rows.push({ cy: items[i].cy, items: [items[i]] });
    } else {
      var oldCount = lastRow.items.length;
      lastRow.items.push(items[i]);
      lastRow.cy = (lastRow.cy * oldCount + items[i].cy) / (oldCount + 1);
    }
  }

  // Lấy vị trí cột từ những hàng có đủ 2 mặt. Chỉ dùng để kiểm tra các
  // hàng lẻ: object đơn phải nằm gần cột trái, nếu nằm gần cột phải thì
  // có khả năng người dùng chọn thiếu mặt trước nên dừng để tránh xuất sai.
  var leftColumnTotal = 0,
    rightColumnTotal = 0,
    twoSideRows = 0;
  for (i = 0; i < rows.length; i++) {
    var rowItems = rows[i].items;
    rowItems.sort(function (a, b) {
      return a.cx - b.cx;
    });
    if (rowItems.length > 2)
      return (
        "ERR: Hàng " +
        (i + 1) +
        " có " +
        rowItems.length +
        " object. Mỗi hàng chỉ đặt 1 object (1 mặt) hoặc 2 object (trước + sau)."
      );
    if (rowItems.length === 2) {
      leftColumnTotal += rowItems[0].left;
      rightColumnTotal += rowItems[1].left;
      twoSideRows++;
    }
  }

  var leftColumnX = twoSideRows ? leftColumnTotal / twoSideRows : 0;
  var rightColumnX = twoSideRows ? rightColumnTotal / twoSideRows : 0;

  // Mỗi hàng đủ 2 object là con 2 mặt. Hàng chỉ có cột trái là con 1 mặt.
  var cards = [];
  var oneSideCards = 0;
  for (i = 0; i < rows.length; i++) {
    var row = rows[i].items;
    if (row.length === 2) {
      cards.push({ front: row[0].o, back: row[1].o, oneSide: false });
      continue;
    }

    var single = row[0];
    if (
      twoSideRows > 0 &&
      Math.abs(single.left - rightColumnX) < Math.abs(single.left - leftColumnX)
    )
      return (
        "ERR: Hàng " +
        (i + 1) +
        " chỉ có object ở gần cột phải. Hãy chọn thêm mặt trước ở cột trái, hoặc đặt con 1 mặt ở cột trái."
      );

    cards.push({ front: single.o, back: null, oneSide: true });
    oneSideCards++;
  }

  // Checkbox "Ghép số hộp theo thứ tự từng con": mỗi hàng đã được sort từ
  // trên xuống dưới, nên card thứ i nhận đúng số hộp thứ i và chỉ xuất 1 PDF.
  if (hopTheoThuTu && hopList.length !== cards.length)
    return (
      "ERR: Đang bật ghép số hộp theo thứ tự, nhưng có " +
      cards.length +
      " con card và " +
      hopList.length +
      " số hộp. Hãy nhập đúng một số hộp cho mỗi con."
    );

  // ---------- Tuỳ chọn PDF (nhẹ, giữ vector, không hạ chất lượng) ----------
  function makePdfOptions() {
    var opt = new PDFSaveOptions();
    try {
      opt.compatibility = PDFCompatibility.ACROBAT5;
    } catch (e) {}
    opt.generateThumbnails = false;
    opt.preserveEditability = false; // KHÔNG nhúng dữ liệu AI -> file nhẹ
    try {
      opt.optimization = true;
    } catch (e) {}
    try {
      opt.viewAfterSaving = false;
    } catch (e) {}
    // Ép xuất TẤT CẢ artboard (2 trang: trước + sau).
    try {
      opt.saveMultipleArtboards = true;
    } catch (e) {}
    // Không set artboardRange -> mặc định toàn bộ artboard.
    return opt;
  }

  // ---------- Xuất 1 con card ra PDF 2 trang ----------
  //  Theo đúng cách cross-doc đã chạy ổn trong panel (dcHocMau):
  //    - PHẢI active doc GỐC trước mỗi lần .duplicate()
  //    - Duplicate xong mới đo bounds thật rồi set artboardRect
  //  Tránh lỗi 1220 "Illegal Argument".
  var MM = 2.834645669;
  var GAP = 20 * MM; // khoảng cách 2 mặt trong doc tạm (pt)

  // Bounds an toàn: ưu tiên visibleBounds, fallback geometricBounds.
  function bndOf(item) {
    try {
      return item.visibleBounds;
    } catch (e) {
      try {
        return item.geometricBounds;
      } catch (e2) {
        return null;
      }
    }
  }

  // Lấy khung của CLIP MASK trên object (nếu có). Con card đã clip
  // 9.2x5.6 -> trả về đúng bao của đường clip, KHÔNG tính phần lòi ra
  // ngoài như visibleBounds. Không có clip -> trả null.
  function clipRectOf(item) {
    try {
      if (item.typename === "GroupItem" && item.clipped === true) {
        var p = item.pageItems;
        for (var i = 0; i < p.length; i++) {
          try {
            if (p[i].clipping === true) return p[i].geometricBounds;
          } catch (eC) {}
        }
      }
    } catch (e) {}
    return null;
  }
  // Khung con = khung Transform (clip → khung clip, group → khung group), LUÔN LUÔN —
  // anh Lộc 22/10: "auto save cũng sẽ save pdf của transform". Transform không đo được
  // mới dự phòng khung clip / visibleBounds như cũ.
  function frameOf(item) {
    var khung = null;
    try {
      khung = dcKhungThanhPham(item);
    } catch (khungError) {}
    if (khung) return khung;
    var c = clipRectOf(item);
    if (c) return c;
    return bndOf(item);
  }

  function exportCard(card, filePath) {
    // Luôn đóng tài liệu tạm. Nếu Illustrator lỗi giữa chừng
    // khi xuất một PDF thì xoá file dở dang đó, không để nó lẫn
    // với các file đã xuất thành công.
    var tmp = null,
      completed = false;
    try {
      // Doc tạm nhỏ, KHÔNG truyền khổ (dùng mặc định) -> tránh 1220.
      tmp = app.documents.add(DocumentColorSpace.CMYK);
      var lay = tmp.layers[0];

      // --- Mặt trước: duplicate từ doc gốc (phải active gốc trước) ---
      app.activeDocument = doc;
      var dupF = card.front.duplicate(lay, ElementPlacement.PLACEATEND);
      app.activeDocument = tmp;
      // Đo theo KHUNG CLIP có sẵn trên object (không lấy phần lòi ra).
      var gf = frameOf(dupF); // [left, top, right, bottom]
      if (!gf) throw new Error("Không đo được mặt trước.");

      var ab = tmp.artboards;
      // Trang 1 = mặt trước (khớp đúng khung clip).
      ab[0].artboardRect = [gf[0], gf[1], gf[2], gf[3]];

      if (!card.oneSide && card.back) {
        // --- Con 2 MẶT: thêm mặt sau -> 2 trang ---
        app.activeDocument = doc;
        var dupB = card.back.duplicate(lay, ElementPlacement.PLACEATEND);
        app.activeDocument = tmp;
        var gb = frameOf(dupB);
        if (!gb) throw new Error("Không đo được mặt sau.");

        // Dời mặt sau sang phải mặt trước (cạnh nhau), cùng mép trên.
        //  Dời theo mép của KHUNG CLIP để 2 trang khớp nhau.
        var wantLeft = gf[2] + GAP;
        var wantTop = gf[1];
        dupB.translate(wantLeft - gb[0], wantTop - gb[1]);
        var gb2 = frameOf(dupB);
        if (!gb2) throw new Error("Không đo được mặt sau sau khi dời trang.");
        ab.add([gb2[0], gb2[1], gb2[2], gb2[3]]); // trang 2: mặt sau
      }

      tmp.saveAs(new File(filePath), makePdfOptions());
      completed = true;
    } finally {
      try {
        if (tmp) tmp.close(SaveOptions.DONOTSAVECHANGES);
      } catch (closeTempError) {}
      if (!completed) {
        try {
          var incomplete = new File(filePath);
          if (incomplete.exists) incomplete.remove();
        } catch (removeIncompleteError) {}
      }
    }
  }

  // ---------- Tạo tên file an toàn ----------
  function pad0(n, width) {
    var s = String(n);
    while (s.length < width) s = "0" + s;
    return s;
  }
  function sanitize(s) {
    // Loại ký tự cấm trong tên file Windows.
    return String(s)
      .replace(/[\\\/:*?"<>|]/g, "-")
      .replace(/\s+$/g, "");
  }
  function makePdfName(sttValue, card, hopValue) {
    var sttStr = padN > 0 ? pad0(sttValue, padN) : String(sttValue);
    var oneSidePart = card.oneSide ? " - 1 mat" : "";
    return sanitize(
      prefix +
        " - " +
        sttStr +
        " - " +
        hopValue +
        " hop" +
        notePart +
        oneSidePart +
        " - " +
        canMang +
        " - " +
        ngay +
        ".pdf",
    );
  }
  function buildOutputPlan() {
    var result = [],
      seen = {},
      nextStt = startN;
    for (var pi = 0; pi < cards.length; pi++) {
      var firstHop = hopTheoThuTu ? pi : 0;
      var lastHop = hopTheoThuTu ? pi + 1 : hopList.length;
      for (var ph = firstHop; ph < lastHop; ph++) {
        var fileName = makePdfName(nextStt, cards[pi], hopList[ph]);
        var filePath = folder.fsName + "/" + fileName;
        var fileKey = String(filePath).toLowerCase();
        if (!fileName || fileName === ".pdf")
          return { error: "Tên file PDF rỗng sau khi chuẩn hoá." };
        if (fileName.length > 220 || filePath.length > 245)
          return {
            error:
              "Tên hoặc đường dẫn PDF quá dài ở STT " +
              nextStt +
              ". Hãy rút gọn ghi chú hoặc chọn thư mục ngắn hơn.",
          };
        if (seen[fileKey])
          return {
            error:
              "Có hai file trùng tên: " +
              fileName +
              ". Hãy đổi STT, số hộp hoặc ghi chú.",
          };
        if (new File(filePath).exists)
          return {
            error:
              "File đã tồn tại: " +
              fileName +
              ". Auto Save dừng để không ghi đè file cũ.",
          };
        seen[fileKey] = true;
        result.push({
          card: cards[pi],
          stt: nextStt,
          sttStr: padN > 0 ? pad0(nextStt, padN) : String(nextStt),
          full: filePath,
        });
        nextStt++;
      }
    }
    return { files: result, error: "" };
  }

  // ---------- Vòng lặp xuất ----------
  //  Mỗi CON CARD xuất 1 file cho MỖI số hộp trong danh sách.
  //  Vd chọn 1 con + nhập "100,200,300" -> 3 file cùng con đó,
  //  số hộp 100/200/300. STT tăng theo từng FILE.
  var done = 0,
    errs = [];
  var plan = buildOutputPlan();
  if (plan.error) return "ERR: " + plan.error;
  var totalFiles = plan.files.length;
  for (i = 0; i < plan.files.length; i++) {
    var job = plan.files[i];
    try {
      exportCard(job.card, job.full);
      done++;
    } catch (e2) {
      errs.push(
        "Con " +
          job.sttStr +
          ": " +
          (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e2) : e2.toString()),
      );
    }
  }

  // Trả tiêu điểm về file gốc.
  try {
    app.activeDocument = doc;
  } catch (e) {}

  var msg =
    "OK: Đã lưu " +
    done +
    "/" +
    totalFiles +
    " file PDF.\n" +
    "Nhận diện: " +
    oneSideCards +
    " con 1 mặt, " +
    (cards.length - oneSideCards) +
    " con 2 mặt.\n" +
    "Thư mục: " +
    folder.fsName;
  if (twoSideRows === 0 && cards.length > 0)
    msg += "\nKhông có hàng 2 cột: toàn bộ selection được coi là con 1 mặt.";
  if (errs.length) {
    msg =
      (done > 0 ? "OK: " : "ERR: ") +
      "Lưu được " +
      done +
      "/" +
      totalFiles +
      " file.\n" +
      "Nhận diện: " +
      oneSideCards +
      " con 1 mặt, " +
      (cards.length - oneSideCards) +
      " con 2 mặt.\n" +
      "Lỗi:\n- " +
      errs.join("\n- ") +
      "\nThư mục: " +
      folder.fsName;
    if (twoSideRows === 0 && cards.length > 0)
      msg += "\nKhông có hàng 2 cột: toàn bộ selection được coi là con 1 mặt.";
  }
  return msg;
}

// ============================================================
//  dcChonThuMucLuuPDF — mở Save As Windows đầy đủ và trả thư mục được chọn.
// ============================================================
function dcChonThuMucLuuPDF(dialogTitle) {
  var startFolder = Folder.myDocuments;
  try {
    if (Folder.current && Folder.current.exists) startFolder = Folder.current;
  } catch (currentFolderError) {}
  // saveDlg của một File có sẵn tên sẽ mở cửa sổ Windows đầy đủ nhưng người
  // dùng chỉ cần chọn thư mục và bấm Save; tên này không bao giờ được tạo.
  var defaultFile = new File(startFolder.fsName + "/chon-thu-muc.pdf");
  var picked = defaultFile.saveDlg(
    dialogTitle + " - chọn thư mục rồi bấm Save",
    "*.pdf",
  );
  if (!picked) return null;
  try {
    return picked.parent && picked.parent.exists ? picked.parent : null;
  } catch (e) {}
  return null;
}

// ============================================================
//  dcPickFolder — trả đường dẫn cho ô Thư mục lưu của Auto Save.
// ============================================================
function dcPickFolder() {
  try {
    var f = dcChonThuMucLuuPDF("Chọn nơi lưu PDF");
    if (!f) return "ERR:huỷ";
    return "OK:" + f.fsName;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ============================================================
//  dcClipTheoTransform — Clip từng object đang chọn đúng bằng khung
//  Transform của nó (anh Lộc 22/10: "clip đã clip được transform rồi thì
//  bỏ chỗ nhập kích thước đi").
//
//  Mỗi object chưa clip được bọc bằng một mask chữ nhật = dcKhungThanhPham
//  (group → khung group, hình → khung hình); phần nét/hiệu ứng tràn ngoài
//  khung bị cắt. Object đã có clip giữ nguyên (khung đã chuẩn). Luôn đo theo
//  Transform, không phụ thuộc tick ở header — đó chính là mục đích của nút.
//  Trả về "OK: ..." hoặc "ERR: ...".
// ============================================================
var dcClipToSizeVersion = 9;

function dcClipTheoTransform() {
  try {
    return _dcClipTheoTransformCore();
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}

function _dcClipTheoTransformCore() {
  if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
  var doc = app.activeDocument;
  var selection = doc.selection;
  if (!selection || selection.length === 0)
    return "ERR: Hãy chọn ít nhất 1 object để clip.";

  // Thao tác cuối giống autoClip của Dàn Card: expand appearance để khung mới
  // là khung thật, không còn hiệu ứng treo bên ngoài.
  function expandAppearanceLikeDanCard(item) {
    try {
      app.selection = null;
      item.selected = true;
      app.executeMenuCommand("expandStyle");
      var expanded = app.selection;
      if (expanded && expanded.length === 1) {
        var result = expanded[0];
        app.selection = null;
        return result;
      }
      app.selection = null;
    } catch (expandError) {}
    return item;
  }

  function khungCua(item) {
    var khung = null;
    try {
      khung = dcKhungThanhPham(item);
    } catch (khungError) {}
    if (!khung) {
      try {
        khung = item.visibleBounds;
      } catch (visibleError) {
        try {
          khung = item.geometricBounds;
        } catch (geometricError) {}
      }
    }
    if (
      !khung ||
      khung.length !== 4 ||
      khung[2] - khung[0] <= 0.001 ||
      khung[1] - khung[3] <= 0.001
    )
      throw new Error("không đo được khung Transform của object.");
    return [khung[0], khung[1], khung[2], khung[3]];
  }

  var keptClipCount = 0; // clip group sẵn có: giữ nguyên, không tính là "đã clip"
  var sizes = []; // [{text, count}] theo thứ tự gặp
  function ghiKho(khung) {
    var text = dcKhungText(khung);
    for (var s = 0; s < sizes.length; s++) {
      if (sizes[s].text === text) {
        sizes[s].count++;
        return;
      }
    }
    sizes.push({ text: text, count: 1 });
  }
  function clipTheoKhung(item) {
    try {
      if (item.typename === "GroupItem" && item.clipped === true) {
        keptClipCount++;
        return item;
      }
    } catch (alreadyClipError) {}
    var khung = khungCua(item);
    var layer = item.layer;
    var mask = layer.pathItems.rectangle(
      khung[1],
      khung[0],
      khung[2] - khung[0],
      khung[1] - khung[3],
    );
    mask.filled = false;
    mask.stroked = false;
    var group = layer.groupItems.add();
    mask.move(group, ElementPlacement.PLACEATBEGINNING);
    item.move(group, ElementPlacement.PLACEATEND);
    mask.clipping = true;
    group.clipped = true;
    ghiKho(khung);
    return expandAppearanceLikeDanCard(group);
  }

  var snapshot = [];
  for (var i = 0; i < selection.length; i++) snapshot.push(selection[i]);
  var results = [];
  var errors = [];
  for (i = 0; i < snapshot.length; i++) {
    try {
      results.push(clipTheoKhung(snapshot[i]));
    } catch (clipError) {
      errors.push("Object " + (i + 1) + ": " + clipError);
    }
  }
  try {
    doc.selection = null;
    for (i = 0; i < results.length; i++) results[i].selected = true;
    app.redraw();
  } catch (selectionError) {}

  var clippedCount = results.length - keptClipCount;
  var khoText = "";
  if (sizes.length === 1) khoText = ": " + sizes[0].text;
  else if (sizes.length > 1) {
    var parts = [];
    for (var k = 0; k < sizes.length; k++)
      parts.push(sizes[k].text + " (" + sizes[k].count + " object)");
    khoText = ": " + parts.join(", ");
  }
  var message =
    "Đã clip " +
    clippedCount +
    "/" +
    snapshot.length +
    " object theo khung Transform" +
    khoText +
    (keptClipCount
      ? "; " + keptClipCount + " object đã có clip, giữ nguyên."
      : ".");
  if (errors.length)
    return (
      (results.length ? "OK: " : "ERR: ") + message + "\n" + errors.join("\n")
    );
  return "OK: " + message;
}

// ============================================================
//  dcResizeSelectionToSize - Resize tung object dang chon theo W x H.
//  Giu tam object va uu tien visibleBounds de kich thuoc nhin thay la chuan.
// ============================================================
function dcResizeSelectionToSize(wText, hText, unit) {
  try {
    if (app.documents.length === 0) return "ERR: Chưa mở tài liệu nào.";
    var doc = app.activeDocument;
    // prettier-ignore
    var perUnit = { cm: 28.34645669, mm: 2.834645669, "in": 72, pt: 1 };
    unit =
      unit === undefined || unit === null || String(unit) === ""
        ? "cm"
        : String(unit);
    var unitSize = perUnit[unit];
    if (!unitSize) return "ERR: Đơn vị không hợp lệ.";

    var targetW = parseFloat(String(wText).replace(",", ".")) * unitSize;
    var targetH = parseFloat(String(hText).replace(",", ".")) * unitSize;
    if (
      !isFinite(targetW) ||
      !isFinite(targetH) ||
      targetW <= 0 ||
      targetH <= 0
    )
      return "ERR: Kích thước Rộng x Cao phải lớn hơn 0.";

    var selection = doc.selection;
    if (!selection || selection.length === 0)
      return "ERR: Hãy chọn ít nhất một object để resize.";

    // Khung thành phẩm: theo bảng Transform khi cờ bật, không thì visibleBounds như cũ.
    function boundsOf(item) {
      return dcDoKhung(item, function (it) {
        try {
          return it.visibleBounds;
        } catch (e) {
          try {
            return it.geometricBounds;
          } catch (e2) {
            return null;
          }
        }
      });
    }

    function sizeOf(bounds) {
      if (!bounds) return null;
      var width = bounds[2] - bounds[0];
      var height = bounds[1] - bounds[3];
      if (!isFinite(width) || !isFinite(height) || width <= 0 || height <= 0)
        return null;
      return { width: width, height: height };
    }

    function centerOf(bounds) {
      return { x: (bounds[0] + bounds[2]) / 2, y: (bounds[1] + bounds[3]) / 2 };
    }

    function resizeAtCenter(item, scaleX, scaleY) {
      var before = boundsOf(item);
      if (!before) throw new Error("Không đo được object trước khi resize.");
      var center = centerOf(before);
      try {
        item.resize(
          scaleX * 100,
          scaleY * 100,
          true,
          true,
          true,
          true,
          100,
          Transformation.CENTER,
        );
      } catch (resizeCenterError) {
        item.resize(scaleX * 100, scaleY * 100);
      }
      var after = boundsOf(item);
      if (!after) throw new Error("Không đo được object sau khi resize.");
      var afterCenter = centerOf(after);
      item.translate(center.x - afterCenter.x, center.y - afterCenter.y);
      return boundsOf(item);
    }

    function resizeOne(item) {
      var before = boundsOf(item);
      var beforeSize = sizeOf(before);
      if (!beforeSize) throw new Error("Kích thước object không hợp lệ.");

      // Thu tang truc X 1% de biet X noi bo dang anh huong ngang hay doc.
      var probe = resizeAtCenter(item, 1.01, 1);
      var probeSize = sizeOf(probe);
      if (!probeSize) throw new Error("Không đo được trục resize của object.");
      var xChangesWidth =
        Math.abs(probeSize.width - beforeSize.width) >=
        Math.abs(probeSize.height - beforeSize.height);
      var scaleX = xChangesWidth
        ? targetW / probeSize.width
        : targetH / probeSize.height;
      var scaleY = xChangesWidth
        ? targetH / probeSize.height
        : targetW / probeSize.width;
      if (!isFinite(scaleX) || !isFinite(scaleY) || scaleX <= 0 || scaleY <= 0)
        throw new Error("Không tính được tỉ lệ resize.");

      var finalBounds = resizeAtCenter(item, scaleX, scaleY);
      var finalSize = sizeOf(finalBounds);
      if (!finalSize)
        throw new Error("Không đo được kích thước sau khi resize.");

      // Bu them mot lan cho Raster/PlacedItem hoac object co truc xoay noi bo.
      if (
        Math.abs(finalSize.width - targetW) > 0.5 ||
        Math.abs(finalSize.height - targetH) > 0.5
      ) {
        var fixX = xChangesWidth
          ? targetW / finalSize.width
          : targetH / finalSize.height;
        var fixY = xChangesWidth
          ? targetH / finalSize.height
          : targetW / finalSize.width;
        finalBounds = resizeAtCenter(item, fixX, fixY);
        finalSize = sizeOf(finalBounds);
      }
      if (
        !finalSize ||
        Math.abs(finalSize.width - targetW) > 1 ||
        Math.abs(finalSize.height - targetH) > 1
      )
        throw new Error("Không thể đặt đúng kích thước cho object này.");
      return item;
    }

    var sources = [];
    for (var i = 0; i < selection.length; i++) sources.push(selection[i]);
    var results = [];
    var errors = [];
    for (i = 0; i < sources.length; i++) {
      try {
        results.push(resizeOne(sources[i]));
      } catch (itemError) {
        errors.push("Object " + (i + 1) + ": " + itemError);
      }
    }

    try {
      doc.selection = null;
      for (i = 0; i < results.length; i++) results[i].selected = true;
      app.redraw();
    } catch (e) {}

    var message =
      "Đã resize " +
      results.length +
      "/" +
      sources.length +
      " object thành " +
      wText +
      " x " +
      hText +
      " " +
      unit +
      ".";
    if (errors.length)
      return (
        (results.length ? "OK: " : "ERR: ") + message + "\n" + errors.join("\n")
      );
    return "OK: " + message;
  } catch (e) {
    return (
      "ERR: " + (typeof dcMoTaLoi === "function" ? dcMoTaLoi(e) : e.toString())
    );
  }
}
