﻿# Lịch sử cập nhật — Công cụ bình

_Tác giả: Lộc (Code dạo) · Tester: Tân (1 cú) · Duẫn (CTL Offset)_

## v2.18.0 — Dàn bế trộn nhiều mẫu theo khu

- Dàn nhiều mẫu KHÁC khuôn lên một tờ bằng bộ chia khu mới: tool tự nhận biết mẫu nào cùng khuôn, mẫu nào khác khuôn (kể cả file đặt xoay 90/180/270), rồi tự nghĩ ra nhiều cách chia tờ thành khu (dải ngang, dải dọc, hai tầng, đổi thứ tự), ước lượng, dàn thật các cách tốt nhất và chọn cách nhiều con nhất.
- Mỗi mẫu một cụm liền, không xen lộn xộn: trong khu dàn như một mẫu (xếp hàng lồng theo đường bế thật), các khu khép sát nhau theo đường bế rồi lấp chỗ trống bằng chính khuôn của khu đó. Số con các mẫu chia đều trước, dư hoặc thiếu do lấp chỗ trống thì chấp nhận; bài nào cũng có mặt.
- Nhiều bài in chung một khuôn: dàn như một mẫu rồi gom mỗi bài thành một cụm liền (hết hàng này tới hàng khác) thay cho cách chia xoay vòng A-B-C xen kẽ từng con như trước; chênh tối đa 1 con.
- Thêm tick **Chia khu cách nhau** (hiện khi tick "Dàn nhiều mẫu vào một tờ", mặc định tắt) và ô **Khoảng cách khu (mm)** mặc định 5: bật thì các khu khác khuôn cách nhau đúng khoảng đó, tắt thì cách nhau bằng khe thường. Panel hiện "Đang suy nghĩ… phương án x/y" trong lúc tính.
- Chia đều trước, rồi mới lấp: tool tìm mức chia đều lớn nhất cho mọi mẫu, và chỉ bớt tối đa 20% mẫu lớn khi nhờ đó mẫu nhỏ chen được nhiều con hơn hẳn (ví dụ thẻ treo + tròn 8 mm: 24 + 34 con thành 18 + 284 con). Bài nào cũng có mặt; mỗi bài vẫn một cụm.
- Số đo trên tờ 33 × 35,4 cm, khe 2 mm (cũ → mới, áp sát / cách 5 mm): tròn 25 + tim + sao 48 → 89 / 88 con; card 92 × 56 + tròn 30: 23 → 43 / 58; lá + mèo + thỏ: 30 → 46 / 46; vòm + trăng khuyết + giọt nước + xương: 32 → 54 / 48; 6 khuôn nhỏ: ~150 → 231 / 233. Mỗi tờ mất 2–12 giây, 8 khuôn khác nhau khoảng 10–15 giây.
- Không chia khu được (tờ quá nhỏ cho đủ mọi mẫu) thì tool quay về cách dàn xen kẽ cũ và ghi rõ "Chia khu không xếp đủ mọi mẫu, tạm dùng cách dàn xen kẽ cũ." Mọi phương án vẫn qua chốt chặn độc lập về khe, khoảng cách khu, lề và né PON theo đường bế thật trước khi vẽ. Cập nhật xong cần đóng hẳn Illustrator rồi mở lại.

---

## v2.17.2 — Võ sĩ "1 cú" mới cho tester Tân

- Thay hình tester Tân bằng nhân vật võ sĩ "1 cú" do tool tự vẽ (2D, không dùng 3D): tóc xanh than vuốt ngược, áo hoodie tím khoá vàng, băng quấn tay, quần sọc hồng, giày trắng đế cam.
- Chuyển động theo khung xương, cập nhật từng khung hình: lướt vào có tàn ảnh và vệt gió, trượt dừng tung bụi, nhún nhẹ trong thế thủ.
- Gồng tụ lực: nắm đấm và mắt sáng dần, hạt sáng hút vào tay, người rung nhẹ trước khi bung đòn.
- Cú đấm thẳng đúng tư thế: hông dồn tới, vai xoay, tay duỗi thẳng, tay kia che cằm, gót chân sau xoay lên; khựng hình lúc trúng rồi chữ "Tân 1 cú" nổ, nứt kính, bay mảnh và tụ lại như trước.
- Hiệu ứng canvas vẫn vẽ 30 hình/giây để nhẹ máy; không đổi chức năng dàn.

---

## v2.17.1 — Dàn bế decal xếp hàng lồng theo biên dạng thật

- Dàn bế decal dùng lõi mới "xếp hàng lồng": tự tìm cách lồng khuôn theo đường bế thật cho mọi hình (tròn, tim, sao, giọt nước, mũ cong, con vật…), không cần chọn kiểu dàn hay cài sẵn cho từng loại khuôn.
- Dàn được nhiều con hơn: thử 44 dạng khuôn × khe 1 và 2 mm được 4.692 con so với 4.390 của bản cũ (+6,9%), không ca nào ít hơn; khuôn tròn 2,5 cm được 174 con, 3 cm 118 con, 4 cm 67 con.
- Tự dịch từng hàng và dịch cả cụm qua trái/phải để né PON, rồi canh giữa tờ; khép đúng khe theo đường bế thật, không co giãn hay sửa khuôn.
- Cùng số con thì chọn bố cục gọn, đều hàng; khuôn trong file nguồn đặt xoay hướng nào cũng ra cùng một kết quả.
- Bộ dàn cũ vẫn chạy song song và chỉ được chọn khi nhiều con hơn; mọi phương án đều qua kiểm tra khe, lề và PON trước khi vẽ.
- Cập nhật xong cần đóng hẳn Illustrator rồi mở lại.

---

## v2.17.0 — Dàn bế decal: xếp hàng lồng theo biên dạng thật (21/10/2026)

- Viết mới lõi tìm bố cục **Dàn bế** cho decal nhiều hình dạng. Không nhận diện tên hình, không cài sẵn tọa độ hay số con cho mẫu nào: lõi đọc đường bế thật (điểm neo/tay nắm đã làm phẳng), dựng bảng tiếp xúc giữa bốn hướng xoay rồi tạo **mẫu hàng**: một hướng, cặp đối đầu 180°, cặp lồng sóng cùng hướng, cặp vuông góc. Các hàng chồng lồng sát nhau theo kiểu thẳng, so le, zigzag hoặc thuận/ngược (hàng xoay 180° xen kẽ).
- **Ghép dải**: phần thân dùng kiểu hàng dày nhất, dải sát đáy/đỉnh dùng kiểu khác (ví dụ đứng + nằm) để tận dụng phần tờ còn dư; pha của dải được dò để lồng khít vào hàng bên dưới.
- **Dịch cả cụm**: dịch từng hàng, rồi dịch nguyên dải trên/dưới qua trái/phải và chấm bằng **số con thật sau khi né PON**; sau đó dịch cả khối và canh giữa tờ. PON chặn thì giữ đúng tâm một trục và ghi rõ trong kết quả. Cuối cùng khép đúng khe bằng tiếp xúc chính xác và lấp thêm con vào chỗ trống từ bốn phía nếu còn vừa.
- Thứ tự ưu tiên: **nhiều con nhất** → cùng số con thì chọn bố cục **gọn hơn** (ít đổi kiểu hàng, so le đều, ít con lấp lẻ, lề cân hai bên). Thử cả hàng ngang và hàng dọc tờ; với ngân sách thường của panel (3 giây) chạy thêm lượt thứ hai với khuôn xoay 180° để bù chỗ lượt đầu bỏ sót khi nhiều mẫu bằng điểm nhau.
- Kết quả **không phụ thuộc** khuôn trong file nguồn đặt xoay hướng nào hay path bắt đầu ở điểm nào (lấy hướng chuẩn theo hình học); chạy lại cùng đầu vào cho đúng cùng vị trí. Nhiều bài chung khuôn vẫn dàn một lần, chia bài xoay vòng, chênh tối đa 1 con.
- Bộ tìm cũ (silhouette) vẫn chạy **thi đua**, chỉ được chọn khi nhiều con hơn (ví dụ khuôn chữ L lồng ghép: **71 con**). Khuôn **khác nhau** trên cùng tờ vẫn dùng bộ cũ để cân bằng số con. Mọi phương án của lõi mới phải qua **chốt chặn hình học độc lập** (khe, lề, né PON tính từ mép chấm) trước khi trả về; không co, giãn hay sửa khuôn.
- Đo trên **44 biên dạng × 2 khe (1 và 2 mm)** — tròn, elip, tim, giọt nước, khiên, sao, mũi tên, tam giác, hình thang, lục/bát giác, trăng khuyết, compound có lỗ, muỗng, lá, mũ cong, vòm 40 × 70, mèo, thỏ… — tờ **33 × 35,4 cm**, PON 5 mm cách mép 10 mm: tổng **4.692 con** so với **4.390** của bản cũ (**+6,9%**), nhiều hơn ở **68 ca**, bằng **20 ca**, **không ca nào ít hơn**. Trên máy thử, thời gian trung bình khoảng **3,4 giây/tờ** (bản cũ khoảng 5 giây; ca chậm nhất từ 56 giây xuống khoảng 10 giây).
- Khuôn tròn thực tế của xưởng (khe 1 mm): 2,5 cm **174** con (khuôn xưởng 162), 3 cm **118** (114), 4 cm **67** (63), 5 cm **42** (42), 6 cm **28** (27), 7,5 cm **18** (18), 8 cm **16** (14).
- Thêm bộ test **dan_be_rows.test.js** và thư viện biên dạng tổng quát **dan_be_shape_library.js**. Mốc canh giữa của khuôn mũ cong 1 mm: nay dàn nhiều hơn 94 con, khối dày hơn chạm vùng né PON nên cho lệch tâm có báo, vẫn kiểm tra PON thật sự chặn tâm. **41 bộ kiểm thử tự động đạt**, giữ nguyên các giới hạn thời gian cũ.
- Nạp lõi Dàn bế **10**, giữ cầu nối **12**. Không đổi giao diện, CTL/KTS, raster hay JPG. **Chưa chạy trong Illustrator thật** ở lần cập nhật này: cần tắt hẳn Illustrator, mở lại rồi thử với file khuôn thật. Chỉ cài local, chưa phát hành GitHub.

---

## v2.16.20 — PHÁT HÀNH SAU TEST

- PHÁT HÀNH SAU TEST

---

## v2.16.19 — Đọc đủ đường bao ngoài của khuôn có lỗ (06/10/2026)

- Sửa đọc **Group khuôn**: giữ đường bao khép kín kể cả khi nó là clipping path. Trước đây đường bao này bị bỏ qua, nên tool có thể dùng vòng tròn/lỗ bên trong làm biên dạng để dàn.
- Đọc đường cong kín có **1–2 điểm neo** bằng đường Bézier thật, thay vì loại vì ít điểm neo. Đường kín không tạo được biên dạng được báo lỗi, không âm thầm chuyển sang dùng lỗ bên trong.
- Dàn vẫn dùng toàn bộ biên dạng ngoài; khi nhân bản/xoay giữ nguyên Group gốc, gồm đường bao và các lỗ, màu stroke và tay nắm. Không đoán vai trò theo tên màu hay thứ tự path; giữ nguyên union của Group và lỗ even/odd của Compound Path.
- Thêm **12 ca kiểm thử**: Group lồng, clipping path, đường ngoài thẳng/cong hai điểm neo, đảo thứ tự đường ngoài/lỗ, Compound Path và tính bất biến của nguồn. Khôi phục riêng hai điều kiện cũ trong bộ thử làm tái hiện **8 ca đọc nhầm đường ngoài 40 mm thành lỗ 14 mm**. Các bộ kiểm thử bridge/panel/hai mặt/canvas và chức năng CEP liên quan đạt.
- Chạy **Illustrator thật** trên ba tài liệu thử riêng: Group có đường bao clipping, Group có đường ngoài cong hai điểm neo và Compound Path với lỗ đứng trước. Cả ba đều đọc đủ khuôn **92 × 56 mm**, không dùng vòng tròn lỗ 12 mm làm khuôn; qua bốn hướng xoay với nguyên màu, điểm neo/tay nắm, kích thước và độ lệch lỗ so với đường bao. Nguồn và trạng thái tài liệu người dùng không thay đổi.
- Nạp cầu nối Dàn bế **12**, giữ lõi tìm bố cục **9**; không đổi thuật toán KTS/CTL hoặc cấu hình raster/JPG. Chỉ cập nhật local, chưa phát hành GitHub.

---

## v2.16.18 — Dàn bế ghép nhiều cụm khác hướng (06/10/2026)

- Bổ sung tìm kiếm ghép **nhiều cụm khác hướng, khác pha và số cột** trên cùng tờ, kể cả xoay cụm ở dải dư. Khoảng tiếp xúc lấy từ biên dạng khuôn thật; không nhận diện tên hình, không đặt sẵn tọa độ hoặc số con cho mẫu.
- Rút kinh nghiệm từ ca lưới ngang **28 con**: giữ các hàng hữu ích quanh PON thay vì bỏ cả hàng khi một con ở góc bị chặn; thử mọi điểm chuyển giữa các họ hàng. Phần cơ sở hữu hạn chạy trước tìm thêm có hạn giờ, giữ phương án đã kiểm chứng khi hết thời gian. Tìm thêm giữ cả số con lẫn biên phía trước thấp, không chỉ chọn cụm có số con lớn ngay tại bước đầu.
- Mọi phương án ghép mới qua cả kiểm tra lưới và hình học liên tục theo đúng khe/lề/PON yêu cầu; không co khuôn, sửa điểm neo/tay nắm hay giảm khe để tăng số con. Giữ các bộ tìm cũ làm phương án cạnh tranh, giới hạn khối lượng tìm tổ hợp để không làm chậm bài hàng nghìn khuôn nhỏ.
- Đo đọc trực tiếp hai artboard **33 × 35,4 cm** của file so sánh: khuôn **40 × 70 mm**, tool cũ **28 con/khe nhỏ nhất 5,000495 mm**; bản dàn tay **30 con/khe nhỏ nhất 4,452765 mm** (lề và PON đạt). Dựng độc lập một phương án **30 con/khe 5,001 mm**, đủ lề/PON, làm mốc hồi quy; không lấy tọa độ dàn tay thiếu khe làm đáp án.
- Giảm quét PON lặp lại bằng phép lọc khung bao/đĩa chắc chắn rời nhau; cặp gần vẫn quét biên dạng như cũ. Lưu điểm đánh giá và cận trên số con theo cụm, bỏ việc dựng phương án trung gian chắc chắn không vào danh sách nhưng vẫn ghép tiếp cụm đó. Phương án cơ sở trước/sau tối ưu tốc độ giống từng slot; bộ hồi quy tốc độ chạy khoảng **10 giây**, dưới giới hạn **20 giây** cũ, không nới giới hạn kiểm thử.
- **38 bộ kiểm thử tự động đạt**: mốc 30 con ở khe 5 mm qua bốn hướng xoay, hai tỷ lệ bổ sung, lặp thời gian tìm ngắn và nhiều bài chung khuôn; khe 0, đa giác bất đối xứng, hình lõm, compound có lỗ, tròn/muỗng/lá và các chức năng khác. Khuôn cong 53 × 26,51 mm ở khe 2 mm tăng từ mốc 86 lên **92 con**, vẫn canh giữa và qua kiểm tra vật lý; chỉ đổi khẳng định số con lịch sử của test thành cận dưới, giữ các chốt hình học và thời gian.
- Chạy bản sửa trong Illustrator trên tài liệu thử riêng với khuôn gốc **40 × 70 mm**, giấy **33 × 35,4 cm**, khe **5 mm**, một/hai mặt: tìm được **31 con**, canh giữa chính xác. Đo độc lập **465 cặp mỗi mặt** từ điểm neo/tay nắm thật: khe nhỏ nhất **5,000499 mm**, né mép PON nhỏ nhất **8,521094 mm**, đủ lề, không chồng khuôn, không đổi kích thước và giữ đăng ký mặt sau. Tài liệu người dùng và trạng thái ứng dụng không thay đổi.
- Nạp lõi Dàn bế **9**, giữ cầu nối **11**. Không đổi CTL/KTS, raster hay JPG. Đây là cải tiến tìm kiếm có kiểm chứng, không cam kết tối ưu toán học tuyệt đối cho mọi biên dạng.

---

## v2.16.17 — Dàn bế phục hồi khe sát giới hạn (06/10/2026)

- Sửa lỗi **“Bộ kiểm tra an toàn từ chối phương án canh tâm”** ở khuôn có cạnh thẳng và đường cong: bố cục lưới đạt khe danh định, nhưng thiếu khoảng dự phòng sai số đường cong 0,0005 mm. Trước khi khép khe, mở nhẹ **vị trí đặt** và kiểm tra lại; không đổi kích thước, tỷ lệ, điểm neo hay tay nắm khuôn/bài.
- Kẹp phép dịch khối vào giới hạn lề trước khi canh tâm, không dùng một khối vượt mép làm phương án dự phòng. Mọi vị trí nhận đều qua kiểm tra đầy đủ khe/PON/lề. Thử đủ giới hạn mở cho phép; nếu chưa phục hồi được thì tìm lại với lưới thận trọng, tối đa hai lượt, không bỏ chốt chặn.
- Áp dụng chung theo hình học, không nhận diện riêng tên hình hoặc gắn công thức cho khuôn mẫu. Giữ sửa khe tròn v2.16.16, khe 0, luân phiên mẫu và đăng ký hai mặt.
- Kiểm chứng **37 bộ kiểm thử tự động**. Khuôn sáu điểm **42 × 72 mm**: khe 5 mm → **27 con**, khe 1,5 mm → **28 con**; **40 × 70 mm**: lần lượt **28/32 con**. Qua cả bốn hướng xoay, hai bài chung khuôn, giới hạn phục hồi và trường hợp thực sự không đủ chỗ; giữ nguyên nguồn và kích thước.
- Chạy Illustrator trên tài liệu thử riêng với đường bế thực **42 × 72 mm**, giấy **33 × 35,4 cm**, khe **5 mm**, một/hai mặt: **27 con**. Đo độc lập **351 cặp mỗi mặt** từ điểm neo/tay nắm gốc, khe nhỏ nhất **5,000499 mm**, không chồng khuôn, không co bài, giữ đăng ký mặt sau. Tài liệu người dùng và trạng thái ứng dụng không thay đổi.
- Nạp lõi Dàn bế **8**, giữ cầu nối **11**. Chỉ cài local, chưa phát hành GitHub; không đổi CTL/KTS, raster hoặc JPG.

---

## v2.16.16 — Dàn bế khép đúng khe dương (06/10/2026)

- Sửa khe nhập **1,5 mm** nhưng khuôn tròn ra **1,75 mm**, hiển thị thành **1,8 mm**: bước tìm làm tròn ra ngoài theo lưới 0,25 mm, nhưng bước khử phần đệm trước đây chỉ chạy khi khe bằng 0. Nay tinh chỉnh **vị trí đặt** cho cả khe dương, không thu nhỏ/đổi tỷ lệ khuôn hoặc bài.
- Khép đồng đều trước, rồi tinh chỉnh từng trục để khe cùng hàng/cột và khe chéo đều được kiểm tra theo biên dạng thật. Tờ thông thường hoàn thành ba bước chính, không bỏ dở vì hết lát thời gian tìm kiếm. Đường cong dùng độ chính xác **0,00025 mm** với dự phòng sai số; không dùng đường cong thô để ép khuôn vào nhau.
- Giữ kiểm tra hình học, lề và vùng né PON. Đĩa bao chỉ nhận nhanh các cặp chắc chắn xa nhau; cặp gần vẫn đo đường bế thật. Ca **13.440 khuôn tròn nhỏ** vẫn qua kiểm tra tốc độ hữu hạn.
- Kiểm chứng **36 bộ kiểm thử tự động**: các khe tròn 0,7 / 1,1 / 1,5 / 1,9 mm, kích thước lẻ, nhiều bài chung khuôn, muỗng, lá, compound, khe 0, một/hai mặt và các chức năng khác.
- Chạy trực tiếp Illustrator trên tài liệu thử riêng: tròn **50 × 50 mm**, giấy **33 × 35,4 cm**, khe **1,5 mm** → **42 con**, một/hai mặt. Đo độc lập điểm neo/tay nắm đường cong thực trên **861 cặp mỗi mặt**: khe nhỏ nhất **1,500490 mm**, không chồng khuôn; giữ nguyên kích thước, nguồn và đăng ký hai mặt. Tài liệu người dùng và trạng thái ứng dụng không thay đổi.
- Nạp lõi Dàn bế **7**, cầu nối **11**. Chỉ cài local, chưa phát hành GitHub; không đổi CTL/KTS, raster 500 ppi hay JPG 300 ppi.

---

## v2.16.15 — bản vá sửa báo lỗi, code tiếng việt

- bản vá sửa báo lỗi, code tiếng việt

---

## v2.16.14 — Dàn bế lặp cụm lồng nhau, sửa khe 0 (05/10/2026)

- Thêm tìm kiếm **cụm hai hàng đối hướng lặp lại**. Khoảng lồng giữa hai hàng và bước sang cụm kế tiếp được tính riêng từ biên dạng thật; không ép mọi hàng có cùng bước. Kiểm tra cả A/A, B/B, A/B, B/A, bốn hướng xoay và các pha dịch. Áp dụng chung, không gắn công thức theo tên hình hay số con.
- Khe **0 mm** không còn giữ phần đệm 0,25/0,5 mm của lưới khi đặt kết quả: co khoảng cách **vị trí**, không co khuôn/bài. Cho phép biên thẳng chạm nhau nhưng không cho chồng diện tích. Với đường cong, đọc chính xác đến **0,00025 mm**, giữ dự phòng sai số khoảng **0,0005 mm** để đường cong gốc không chồng nhau; không dùng xấp xỉ thô để ép chạm. Kiểm tra khoảng cách theo chỉ mục cạnh để tránh so sánh mọi cạnh với nhau.
- Loại phương án khe 0 bị chồng thật ở phần ô lẻ; giữ phương án an toàn qua bước thêm con, sửa cạnh và canh tâm. Sửa kiểm tra biên trùng/lỗ compound và chồng lấn rất nhỏ, không phụ thuộc điểm bắt đầu hay chiều path. Các hình tròn nhỏ hàng chục nghìn con vẫn được kiểm tra hình học cuối.
- Rà JSX vừa được định dạng lại: giữ phần định dạng, bỏ code ô PPI CTL cũ xuất hiện lại theo yêu cầu; JPG vẫn cố định 300 ppi. Sửa ba khóa `"in"` bị formatter bỏ ngoặc kép gây lỗi cú pháp ES3; thêm `prettier-ignore` đúng ba dòng để không tái diễn. Kiểm tra biên dịch toàn bộ thư viện và cầu nối bằng engine Illustrator, không thực thi thư viện hay sửa tài liệu người dùng.
- Kiểm chứng khuôn muỗng gốc **46,0864 × 122 mm**, giấy **33 × 35,4 cm**, lề **4 mm**, tâm chấm PON cách mép **10 mm**, né mép chấm **7,5 mm**: **24 con với khe nhập 1 mm**, và **24 con với khe 0**, cả một/hai mặt. Canh giữa, không đổi kích thước/điểm neo/tay nắm đường cong; mặt sau giữ đăng ký lật ngang. Kiểm tra độc lập đường cong thực của Illustrator trên từng cặp khuôn: khe nhỏ nhất khoảng **1,40779 mm** và **0,00050008 mm**, không chồng khuôn. Các tài liệu người dùng và trạng thái ứng dụng không thay đổi.
- **35 bộ kiểm thử tự động qua**, gồm nhiều tỷ lệ/hướng, biên dạng lẻ, tròn/lá/muỗng, khe dương, PON, một/hai mặt và nhiều mẫu. Nạp lõi Dàn bế **6**, cầu nối **10**. Chỉ cài local, chưa phát hành GitHub; không đổi CTL/KTS, raster 500 ppi hay JPG 300 ppi. Đây là phương án đã kiểm chứng, không cam kết tối ưu toán học tuyệt đối cho mọi biên dạng.

---

## v2.16.13 — Dàn bế thống nhất làm tròn biên dạng (05/10/2026)

- Sửa lỗi từ chối phương án an toàn ở một số kích thước do sai số đổi tọa độ Illustrator sang mm: cạnh 122 mm có thể thành 122,0000000125 mm. Khung bao đã bỏ sai số cực nhỏ nhưng scanline chưa bỏ, nên phát sinh thêm một ô va chạm 0,25 mm không có thật. Dùng cùng ngưỡng sai số số học cho cả hai; vẫn làm tròn ra ngoài khi cạnh vượt ô thực sự.
- Áp dụng chung cho biên dạng và kích thước bất kỳ, không nhận diện riêng muỗng hay cố định công thức theo tên hình. Giữ kiểm tra khe/lề/PON bằng cả lưới và hình học liên tục, không thu nhỏ bài hoặc bỏ kiểm tra an toàn. Nạp lõi Dàn bế 5.
- Sửa bộ đọc JSON trên ExtendScript để giữ đúng `true`/`false`; tránh lỗi engine trả về `NaN` khi dùng chuỗi toán tử điều kiện. Nạp cầu nối 9 và tự nạp lại nếu engine còn bản 8.
- Kiểm chứng mẫu muỗng thực **46,0864 × 122 mm**, giấy **33 × 35,4 cm**, khe **1 mm**: **20 con** trong Illustrator, một/hai mặt, không đổi kích thước; lề trái/phải khoảng **19,3318 mm**, trên/dưới khoảng **15,9568 mm**. Tài liệu người dùng không thay đổi. Kiểm thử thêm nhiều tỷ lệ, bốn hướng xoay, hai kích thước chung tờ và sai số sát biên ô; các mẫu tròn, lá, khuôn cong và muỗng cũ vẫn qua kiểm tra. Chỉ cài local, chưa phát hành GitHub.

---

## v2.16.12 — Dàn bế canh tâm theo kích thước thật (05/10/2026)

- Sửa lệch tâm khoảng 0,12 mm do canh khung lưới 0,25 mm thay vì biên dạng thực. Sau khi tìm dàn, dịch **toàn bộ khối khuôn/bài** theo kích thước thật và khổ giấy đầy đủ; không làm tròn vị trí cuối về lưới. Không đổi số con, góc xoay, thứ tự mẫu hay khoảng cách giữa các khuôn.
- Vị trí mới phải giữ lề và khoảng né PON bằng kiểm tra hình học liên tục. Nếu PON bất đối xứng chặn tâm tờ, chọn phép dịch an toàn gần tâm hơn trong phạm vi tìm kiếm; không bỏ/thu nhỏ mẫu để ép vào tâm. Mặt sau vẫn đối xứng lật ngang. Nạp lõi Dàn bế 4.
- Kiểm chứng trên Illustrator với khuôn cong mẫu, một/hai mặt: giữ **94 con/khe 1 mm**; lề trái/phải khoảng **9,8745 mm**, trên/dưới khoảng **8,369 mm**, sai số tâm dưới **0,001 mm**. Khổ, khuôn, tâm bài và PON đúng; tài liệu người dùng đang mở không thay đổi. Các kiểm thử khe/PON, kích thước giấy lẻ và tâm bị PON chặn giữ nguyên số con. Chỉ cài local, chưa phát hành GitHub.

---

## v2.16.11 — Dàn bế ghép đối đầu trong cùng hàng (05/10/2026)

- Thêm phương án xoay xen kẽ **A → B → A ngay trong cùng hàng**, không chỉ đổi hướng giữa các hàng. Khoảng ghép lấy từ biên dạng đường bế thật và khe nhập, cho phép lồng phần nghiêng/lõm của khung bao. Thử đủ bốn hướng trước khi tìm kiếm bổ sung; không nhận diện riêng tên hình hay gắn công thức chỉ cho mẫu lá.
- Giữ kiểm tra cuối bằng cả scanline và khoảng cách hình học liên tục: không chồng khuôn, không thu bài, giữ lề và khoảng né mép PON. Các bài cùng khuôn vẫn phân luân phiên; hai mặt giữ đăng ký lật ngang, chữ/hình mặt sau không bị lật gương.
- Khuôn cong 7 điểm **53 × 26,51 mm** đọc từ file mẫu: trên giấy **33 × 35,4 cm**, lề **4 mm**, chấm PON **5 mm** có tâm cách mép **10 mm**, né PON **7,5 mm** → **94 con/khe 1 mm**, **86 con/khe 2 mm**. Đây là kết quả kiểm chứng theo các khoảng an toàn trên, không cam kết tối ưu toán học tuyệt đối hoặc đồng nhất với bản dàn tay chưa đo khe/PON.
- Giảm dựng lưới va chạm lặp lại cho các cụm đã chứng minh cách nhau an toàn; các trường hợp lõm/lỗ có thể khóa nhau vẫn kiểm tra lưới như cũ. Ca vuông **2 mm**, giấy 33 × 35,4 cm, khe 1 mm không PON: hơn 10.000 con trong khoảng **0,6 giây** trên máy thử, so với hơn 5 giây ở bản cũ. Nạp lõi Dàn bế 3.
- Kiểm chứng: 31 bộ kiểm thử tự động; tròn 42 con, muỗng 10 con, lá 50 con giữ nguyên. Đã chạy Illustrator trên tài liệu thử riêng với khuôn cong thật ở chế độ một/hai mặt: 94 con, đúng kích thước/góc xoay/tâm bài/PON/đối xứng đường bế. Các tài liệu người dùng đang mở không thay đổi. Chỉ cài local, chưa phát hành GitHub.
- Theo yêu cầu bỏ qua ô PPI, không thêm ô này; JPG CTL vẫn **300 ppi**, raster xử lý bài vẫn **500 ppi**.

---

## v2.16.10 — phát hành sau oke test

- phát hành sau oke test

---

## v2.16.9 — KTS tự nhân tối đa con lớn trước, con nhỏ sau (05/10/2026)

- Theo yêu cầu mới, bỏ giới hạn con lớn bằng số object đã chọn trong chế độ ghép nhiều kích thước. Tự nhân mẫu lớn đến mức tối đa tìm được, rồi mới nhân mẫu nhỏ lấp phần còn lại; không lấy nhiều con nhỏ để đổi bớt con lớn. Có hơn hai nhóm kích thước thì ưu tiên lần lượt từ lớn xuống nhỏ, chia bản sao tương đối đều trong cùng nhóm. Mẫu nhỏ có thể chưa được dàn nếu con lớn đã lấp kín tờ.
- Đổi ghi chú in đậm trên panel thành **“Tự nhân bản tối đa con lớn trước, rồi nhân bản con nhỏ lấp phần còn lại.”** Giữ nguyên kích thước thật, lề 3 mm, đường ra dao thẳng, gom cụm và ưu tiên ít công cắt trong các phương án cùng số con. Chỉ xóa nguồn đã dùng sau khi tạo đủ bản sao trước/sau; giữ nguyên nguồn không lọt.
- Giấy **33 × 35,4 cm**: một mẫu hoặc 5/6 mẫu lớn **18,4 × 5,6 cm** + mẫu nhỏ **9,2 × 5,6 cm** → **8 lớn + 3 nhỏ**. Ca 6 mẫu lớn **15,2 × 7,2 cm** cũng → **8 lớn + 3 nhỏ**. Không bắt chuẩn bị đủ object lớn trước như v2.16.7.
- Nạp engine KTS 22; giữ giới hạn tìm kiếm 128 con/tờ và cảnh báo khi chạm giới hạn. Đây là tìm kiếm có giới hạn với đường cắt đã kiểm chứng, không cam kết tối ưu toán học tuyệt đối. Không đổi Dàn bế, CTL, raster/JPG hay chế độ mỗi mẫu một tờ. Chỉ cài local, chưa phát hành GitHub.
- Kiểm chứng: 30 bộ kiểm thử tự động qua; có ca một mẫu lớn tự nhân lên 8 con, nhiều mẫu lớn chia bản sao, nguồn nhỏ dọc, ưu tiên ba nhóm kích thước, nguồn dư/quá khổ, 128 con, hai mặt và lỗi tạo bản sao không xóa nguồn. Phát lại độc lập từng đường dao để kiểm tra không cắt qua bài. Đã chuẩn bị 12 ca native; chưa chạy trực tiếp bản này vì Illustrator đang đóng/không có kết nối COM, không tự mở ứng dụng hay sửa tài liệu người dùng.

---

## v2.16.8 — Đóng ghim A4: TT4 đúng khung 20,9 × 30 cm (05/10/2026)

- Sửa kiểm tra TT4 A4 trên tờ **64,8 × 41,8 cm**: artwork vốn canh giữa, nhưng lưới kiểm tra/PON lại chừa cố định 9 mm trên. Khung **20,9 × 30 cm** xoay ra cao đúng **41,8 cm**, không cần cộng thêm 9 mm thành 427 mm rồi báo vượt giấy. Lưới danh định TT4 nay canh giữa cùng artwork; PON cắt bám đúng lưới mới.
- Giữ nguyên kích thước nhập, không thu **20,9 × 30 cm** xuống nhỏ hơn. Trang nhỏ hơn tự có lề trên/dưới bằng nhau; **20 × 30 cm** vẫn chừa 9 mm mỗi đầu. Khổ thực sự quá lớn vẫn báo trước khi raster hoặc sửa nguồn. Không đổi bù độ dày gáy của ruột, A5, AB **85,8 × 62,5 cm**, vị trí ghi chú/icon hay lưu AI/JPG/ZIP.
- Nạp lại engine Đóng ghim 40. Chỉ cài local, chưa phát hành GitHub.
- Kiểm chứng: 30 bộ kiểm thử tự động qua; 4 ca trên Illustrator qua (bìa 20,9 × 30 cm, bìa 20 × 29,7 cm, từ chối khung 21 × 30 cm thực sự vượt TT4 trước khi raster, AB 21,2 × 30 cm không đổi). Đo bốn trang bìa TT4 đúng 20,9 × 30 cm sau xoay; PON cắt/giấy, ghi chú và kế hoạch lưu đúng. Các tài liệu người dùng đang mở và trạng thái ứng dụng được giữ nguyên.

---

## v2.16.7 — KTS ưu tiên số con lớn đã chuẩn bị, con nhỏ lấp phần dư (05/10/2026)

- In đậm trên panel: **“Tối ưu con lớn trước, con nhỏ sau. Hãy chuẩn bị đúng số lượng cần của con lớn trước.”** Chỉ áp dụng cách xử lý mới cho ghép **nhiều kích thước** chung tờ; chế độ cùng kích thước/mỗi mẫu một tờ giữ nguyên.
- Không tự nhân thêm con lớn. Ưu tiên dàn nhiều nhất các object lớn đã chọn, mỗi object lớn tối đa một lần; thiếu chỗ thì giữ nguyên object chưa dàn để làm tiếp. Sau đó mới nhân mẫu nhỏ lấp phần dư. Chỉ xóa nguồn đã dùng sau khi tất cả bản sao trước/sau đã tạo xong; mẫu nhỏ dù nhân nhiều bản cũng chỉ xóa nguồn một lần. Nếu tạo bản sao lỗi, chưa xóa nguồn; nếu không xóa được nguồn thì báo rõ trên panel.
- Bổ sung tìm kiếm chia vùng theo kích thước thật cho hai nhóm kích thước, phối hợp tìm kiếm chung và gom cụm cắt. Phương án phải có thứ tự tách bằng dao thẳng, không khóa đường cắt. Ưu tiên số con lớn, số con nhỏ, rồi công hạ dao/đường cắt. Giữ kích thước, xoay 0°/90°, lề 3 mm và đăng ký hai mặt; không thu nhỏ bài. Tìm kiếm có giới hạn, không cam kết tối ưu toán học tuyệt đối. Giới hạn ghép 128 con/tờ và báo nếu chạm giới hạn này, tránh nhân hàng nghìn mẫu nhỏ làm treo Illustrator.
- Giấy **33 × 35,4 cm**: 5 object lớn **18,4 × 5,6 cm** + mẫu nhỏ **9,2 × 5,6 cm** → **5 lớn + 10 nhỏ**; chuẩn bị 6 lớn → **6 lớn + 7 nhỏ**. Chọn 9 lớn chỉ lọt 8 → **8 lớn + 3 nhỏ**, giữ lại 1 nguồn lớn. Ca 6 lớn **15,2 × 7,2 cm** → **6 lớn + 7 nhỏ**; chọn 9 → **8 lớn + 3 nhỏ**, giữ lại 1 nguồn lớn.
- Nạp lại engine KTS 21. Chỉ cài local, chưa phát hành GitHub; không thay Dàn bế, CTL hay raster/JPG.
- Kiểm chứng: 30 bộ kiểm thử tự động qua; 10 ca trên Illustrator qua (1/2 mặt, nhiều nhóm, 5/6 con lớn, mẫu nhỏ nguồn dọc, chọn dư 9 con lớn). Đúng số con, kích thước và đăng ký hai mặt; chỉ xóa nguồn đã dàn sau khi tạo đủ hai mặt, giữ nguyên nguồn chưa dàn. Các tài liệu người dùng đang mở không đổi. Kiểm thử độc lập phát lại từng đường dao, có ca lỗi tạo bản sao giữ toàn bộ nguồn, nguồn quá khổ và cảnh báo 128 con.

---

## v2.16.6 — KTS nhiều kích thước: lấp khe và có đường cắt dao (05/10/2026)

- Sửa việc dừng nhân mẫu nhỏ khi các mẫu lớn hết chỗ: chia số con tương đối đều trước, sau đó lấp phần trống bằng mẫu còn vừa, không giới hạn mẫu nhỏ chỉ được dư 1 con. Giữ kích thước thật, lề 3 mm và đăng ký trước/sau.
- Phương án ghép phải có thứ tự cắt dao thẳng, không xếp khóa nhau. So sánh các phương án theo số con, diện tích sử dụng rồi công cắt: gom các hàng/cột cùng kích thước liền nhau, ưu tiên các cụm có thể chồng và dùng chung lần cắt. Không chỉ đếm đoạn cắt từng ô. Đây là tìm kiếm có giới hạn, không cam kết tối ưu toán học tuyệt đối cho mọi bộ mẫu.
- Ca 6 mẫu **15,2 × 7,2 cm** và 1 mẫu **9,2 × 5,6 cm**, giấy **33 × 35,4 cm**: dàn **8 con lớn thành cụm 2 cột × 4 hàng phía trên**, **3 con nhỏ cùng một hàng dưới cùng**, tổng 11 con. Không để hàng nhỏ chen giữa cụm lớn. Thứ tự tách từng vùng có 13 đường; ước tính 9 lần hạ dao khi chồng các cụm đồng dạng, chưa tính xén lề 3 mm của giấy. Không vẽ thêm đường lên artwork.
- Nạp lại engine KTS 20; không thay Dàn bế, CTL hay raster/JPG. Chỉ cài local, chưa phát hành GitHub.
- Kiểm chứng: 30 bộ kiểm thử tự động qua; chạy riêng trên Illustrator cả ca nhiều kích thước thông thường và ca 6 lớn + 1 nhỏ, mỗi ca 1/2 mặt. Ca người dùng đều ra 11 con, đúng cụm lớn trên/nhỏ dưới, không đổi kích thước, không chồng bài, đăng ký hai mặt đúng; các tài liệu đang mở của người dùng không đổi. Kiểm thử độc lập phát lại từng đường dao và loại bố cục khóa đường cắt.

---

## v2.16.5 — Keo gáy khớp chính xác kích thước panel (05/10/2026)

- Theo xác nhận mới **“Khớp chính xác hai cạnh theo panel”**, Keo gáy lấy rộng/cao nhập làm kích thước thật của object, thay chế độ giữ tỷ lệ trong khung tối đa. Không thêm khung trắng. Nguồn khác tỷ lệ sẽ được chỉnh hai trục cho khớp.
- Bù chênh kích thước bitmap sau raster: nhập **21,2 × 30 cm** cho AB thì object ra đúng **21,2 × 30 cm**, không còn 29,9716 cm do tỷ lệ 3722 × 5262 pixel. Scale theo trục tài liệu để xử lý cả ảnh nguồn đã xoay.
- Giữ AB **85,8 × 62,5 cm**, thứ tự trang/A–B, PON giấy/cắt và ghi chú. Tờ nhỏ giữ mức thu khung về cạnh **20,9 cm** trước khi khớp object vào khung đó; không thu các trang AB. Không đổi Đóng ghim giữa hay raster 500 ppi/JPG 300 ppi.
- Nạp lại engine Keo gáy 13. Chỉ cài local, chưa phát hành GitHub.
- Kiểm chứng: 30 bộ kiểm thử tự động qua, có ca bitmap 3722 × 5262 pixel và nguồn xoay. Ba bài mẫu riêng trên Illustrator qua: bitmap xoay AB + tự trở 4, nguồn vector/bốn tỷ lệ khác nhau AB + tự trở 4, A5 tự trở 4 khổ tối đa. Đo AB ra 21,2000 × 30,0000 cm; PON, A/B, tâm ô, ghi chú và khổ tờ nhỏ đúng. Không chạy sửa trên bài người dùng đang mở.

---

## v2.16.4 — AB CTL 85,8 × 62,5 cm (05/10/2026)

- Đổi riêng **tờ AB A4/A5** của cả **Đóng ghim giữa và Keo gáy** sang rộng **85,8 cm**, cao **62,5 cm**, đúng số đã xác nhận. Giữ nguyên kích thước bài, thứ tự trang và đăng ký A/B; không đổi khổ bìa hay tờ tự trở.
- PON giấy bám bốn góc của artboard mới, PON cắt bám lưới bài. Canvas và các nút lưu lấy khổ AB mới từ kết quả dàn. Keo gáy không nhận nhầm AB ngắn hơn là tờ nhỏ để thu bài về 20,9 cm.
- Theo xác nhận bổ sung, **giữ nguyên cách đặt ghi chú và icon hiện tại**, không đổi vị trí tương đối/cỡ chữ/kích thước icon. Đóng ghim giữ lề nhíp A4/lưới A5 hiện tại; Keo gáy giữ lề trên 23,7 mm và kiểm tra trang A5 lớn vẫn vừa tờ mới. Không bóp/di chuyển ghi chú cùng khung giấy.
- Nạp lại engine Đóng ghim 39 / Keo gáy 12. Chỉ cài local, chưa phát hành GitHub.
- Kiểm chứng: 30 bộ kiểm thử tự động qua. Illustrator chạy bốn bài mẫu riêng: ghim AB A4 21,2 × 30 cm/A5 15 × 21,15 cm; keo gáy A4 AB + tự trở 4/A5 AB + tự trở 8. Đo khổ AB, trang nằm trong giấy, PON ở góc mới, ghi chú và khổ tự trở không đổi. Các file người dùng đang mở được giữ nguyên.

---

## v2.16.3 — PHÁT HÀNH BẢN SAVE PDF CTL

- PHÁT HÀNH BẢN SAVE PDF CTL

---

## v2.16.2 — Keo gáy A4 tối đa 21,2 × 30 cm (03/10/2026)

- **Tờ 65 × 86**: khung A4 tối đa **21,2 × 30 cm**. Phóng/thu đồng đều hai trục cho bài nằm vừa khung, canh giữa phần dư; không kéo méo để ép tỷ lệ nguồn vào khung. Giữ thứ tự trang và đăng ký A/B.
- **Tờ 65 × 43 / 43 × 32,5**: dùng khung riêng, thu đều cạnh tương ứng về tối đa **20,9 cm** nếu cần; không thu các trang nằm trên tờ lớn. A4 khung 21,2 × 30 xuống tờ nhỏ thành khoảng **20,9 × 29,575 cm**, không bóp riêng ngang. PON cắt và vị trí trang theo đúng khung của từng tờ; giữ kích thước giấy thực 64,8 × 41,8 / 42,8 × 31,3 cm.
- Tự trở 4 trang canh theo tâm ô cố định, không theo bounds tổng của hai bài có tỷ lệ khác nhau. Dấu cắt ở sát biên giấy vẫn có chiều dài, không biến thành điểm. Kiểm tra giới hạn khung/khổ giấy trước khi raster; nạp engine phiên bản 11. Chỉ cài local, chưa phát hành GitHub.
- Kiểm chứng: 30 bộ kiểm thử tự động qua; native Illustrator chạy bài mẫu A4 20 trang gồm A/B + tự trở 4 với bốn tỷ lệ nguồn khác nhau, đo cùng scale X/Y, đúng tâm ô, A/B và PON, nguồn không chọn giữ nguyên. Chạy thêm A5 tự trở 4 ở khổ nhập 15 × 21,15 cm, thu đều cạnh dài xuống 20,9 cm và kiểm tra ghi chú/PON nằm trong tờ nhỏ.

---

## v2.16.1 — CTL lưu bộ AI/JPG/ZIP, Keo gáy không bóp, raster 500 ppi (03/10/2026)

- **Lưu CTL Offset**: thêm ô **Nội dung sau RUỘT N / BÌA**. Mỗi tờ xuất `.ai`, `.jpg` và `.zip` cùng tên vào thư mục đã chọn; ZIP chứa đúng hai file AI + JPG, vẫn giữ hai file rời. A/B chung một AI hai artboard và một JPG toàn bài (**Use Artboards tắt**). Giữ các nút theo khổ vừa dàn, không đổi lưu PDF ở tab khác.
- JPG dùng Export As native: **CMYK, Quality 10 Maximum, Baseline Standard, 300 ppi, Type Optimized (Hinted), Embed ICC Profile**. Kiểm tra native trên máy hiện tại nhúng **U.S. Web Coated (SWOP) v2**. JPG giữ 300 ppi theo xác nhận riêng, không tăng cùng raster xử lý bài.
- Nén ZIP chạy nền sau khi xuất, không chặn Illustrator trong lúc nén. Tên tiếng Việt/ký tự hợp lệ được truyền như dữ liệu, không ghép vào lệnh shell; lệnh không dài theo số ruột. Không ghi đè AI/JPG/ZIP có sẵn. Xuất JPG/nén lỗi thì giữ AI đã lưu và các JPG hoàn tất, báo rõ lỗi; ZIP chỉ đổi sang tên cuối sau khi kiểm tra đủ hai file. Chỉ copy/group/dịch nguyên cụm trên bản sao, không thay đổi tài liệu nguồn.
- **Keo gáy**: bỏ ép ngang/dọc riêng. Phóng/thu đồng đều hai trục, giữ tỷ lệ; kiểm tra toàn bộ trang trước khi tạo artboard/raster. Sai tỷ lệ với khổ nhập thì báo số trang và giữ nguồn; kiểm tra khung nguồn với dung sai 0,2 mm, không tự thêm viền trắng lớn. Sau raster vẫn dùng cùng tỷ lệ hai trục, tính đến làm tròn pixel, không báo sai giữa chừng khi phóng nguồn nhỏ. Không thu nhỏ thêm để vừa tờ, không đổi thứ tự trang, A/B hay khổ PON. Nạp engine phiên bản 10.
- **Raster xử lý bài**: thống nhất **500 ppi** cho nút Raster, logic raster/clip và các bước raster khi dàn card, catalogue, CTL, keo gáy, theo mẫu; cập nhật thông báo/tooltip. Helper chung ép 500 ppi cả với caller cũ. Ảnh có sẵn ở luồng vốn bỏ qua raster vẫn được giữ, không nội suy lại để giả tăng chất lượng.
- Kiểm chứng native Illustrator 28: lưu/mở lại AI bìa và ruột A/B, đủ vector/raster/PON/ghi chú, nguồn không đổi; đọc JPG xác nhận CMYK, Baseline, 300 ppi, chất lượng tối đa và ICC SWOP. Nén/mở ZIP, so hai nội dung byte-for-byte với file rời; thử tên Unicode/ký tự đặc biệt, trùng file, thiếu JPG và lỗi xử lý. Đo nút Raster/entry JSX/helper chung đều 500 ppi, Keo gáy giữ hai trục đồng đều và từ chối tỷ lệ sai trước raster. Chỉ cài local, chưa phát hành GitHub.

---

## v2.16.0 — phát hanh test ok

- phát hanh test ok

---

## v2.15.20 — KTS ghép nhiều kích thước, sửa canvas CTL và lưu AI theo cụm (03/10/2026)

- **Dàn KTS**: tick **Dàn nhiều mẫu vào một tờ** để ghép các kích thước khác nhau chung tờ. Đo riêng từng mẫu, thử nhiều cách xếp/xoay 0°/90° và tận dụng ô trống theo đúng kích thước; không quy tất cả mẫu về ô lớn nhất, không thu nhỏ bài. Tự nhân bản, số con giữa các mẫu chênh tối đa 1. Nếu không ghép được ít nhất một con mỗi mẫu thì báo trước khi tạo kết quả. Tìm kiếm có giới hạn, không cam kết tối ưu tuyệt đối.
- Bài hai mặt vẫn khóa cặp **trái = trước, phải = sau** theo hàng. Mặt sau dùng chung sơ đồ vị trí đã chọn, đối xứng trái–phải, không lật gương chữ/hình. Canh giữa theo ô chung để sai số đo nhỏ của hai mặt không làm lệch đăng ký. Giữ lề 3 mm, khe 0 mm, chế độ cùng kích thước cũ và xóa artboard cũ chỉ khi dàn thành công.
- **CTL bấm ghim/keo gáy**: đọc biên canvas thực từ phần đầu file AI đã lưu thay vì mặc định ±7200 pt, vẫn bắt đầu tại vị trí nguồn. Kiểm tra/tạo đủ khung trước khi raster hoặc thay PON; lỗi biên/tạo khung thì dọn riêng khung mới, giữ nguồn. Trả lại chế độ tọa độ của người dùng.
- **Keo gáy A5 tự trở 8 trang** 14,5 × 20,7 cm dùng đúng artboard **64,8 × 41,8 cm**: bài 58 × 41,4 cm vừa tờ, không bị điều kiện cộng dư lề PON đẩy lên khổ lớn. Nét PON sát biên được giới hạn trong tờ, không bóp bài. Nếu bài thực sự không vừa thì vẫn dùng khổ lớn. Ghi chú/nút Lưu AI lấy đúng khổ kết quả.
- **Lưu AI CTL**: trên tài liệu tạm, gom bài + PON + ghi chú của mỗi artboard thành một cụm và dịch vị trí **một lần cho cả cụm**, rồi trả nhóm về layer tương ứng. Không snap từng object nữa. Bỏ group nguồn rỗng do raster; chỉ mở khóa bản sao/layer tạm, không group, di chuyển hay mở khóa nguồn. Illustrator vẫn phải copy object qua tài liệu tạm; chưa đo tăng tốc trên bài sản xuất lớn. Giữ bìa/ruột thành file riêng, A/B chung file AI, không ghi đè file có sẵn.
- Kiểm chứng: 27 file kiểm thử tự động; KTS chạy native một/hai mặt với 3 kích thước 90 × 50, 60 × 40, 75 × 65 mm ra 25 con (9–8–8), đo không chồng bài, đủ lề, đúng đối xứng và nguồn không đổi. CTL chạy trên bản sao file canvas lệch gốc, cả hai kiểu dàn thành công; hai ca vượt biên bị chặn trước raster và giữ nguồn. Lưu/mở lại 3 AI bìa/ruột tự trở/ruột A+B, kiểm tra bài/PON/ghi chú và nguồn không đổi. Chỉ cài local, chưa phát hành GitHub.

---

## v2.15.19 — XUẤT TEST OK

- XUẤT TEST OK

---

## v2.15.18 — Keo gáy đồng bộ khổ giấy/PON, A5 tự trở 4 trang (03/10/2026)

- Keo gáy dùng cùng khổ artboard thực với Đóng ghim giữa: form 65 × 86 = **85,8 × 63,8 cm**, form 65 × 43 = **64,8 × 41,8 cm**. Bỏ khổ cũ 85,9 × 62,6 / 64,9 × 41,9 lấy từ bounds ngoài của PON.
- Đồng bộ độ dài/nét PON giấy và đặt tim hai nét tại đúng từng góc artboard, không lùi vào nửa stroke như trước. Mỗi tờ vẫn có bốn dấu góc (8 nét).
- Form A5 AB 32 trang / TT16 thêm dấu cắt trên và dưới tại biên cột 1 và 3: **thêm 4 nét**, tổng 16 nét cắt/tờ, để chia cụm 2 trang. Giữ thứ tự trang, xoay và đối xứng A/B; không vẽ nét xuyên artwork.
- A5 tự trở 4 trang dùng form **43 × 32,5**, artboard thực **42,8 × 31,3 cm**, khe giữa 5 mm như Bấm ghim. A4 tự trở 4 vẫn dùng form 65 × 43. Kiểm tra vừa giấy trước khi raster/tạo artboard; PON cắt sát biên giữ cả stroke trong tờ.
- Ghi chú A5 4 trang chuyển sang dải trắng trên khi lề trái không đủ, đo kích thước chữ/icon và thu chữ khi cần, không đè vào bài. Ô ghi chú hiện tên form nhỏ đúng; nút Lưu AI lấy đúng khổ mới từ artboard. Không đổi định dạng lưu AI hay vị trí bắt đầu dàn.
- Nút Keo gáy nạp script phiên bản 8, tránh dùng engine cũ. Đạt 25 file kiểm thử tự động và 6 lần thử trực tiếp trong Illustrator: A5 4 trang thường/tối đa/nguồn ngang, A5 60 trang, A4 32 trang và A5 40 trang khổ tràn. Đo khổ giấy/PON bốn góc, đủ bốn nét chia cụm, bài/ghi chú không chồng lấn hoặc tràn tờ, A/B đối diện đúng, giữ object ngoài selection và trả lại trạng thái app. Đã xem ảnh render; cài local, chưa phát hành GitHub.

---

## v2.15.17 — Copy ghi chú trong Dàn theo mẫu, CTL Offset lưu AI (03/10/2026)

- Chuyển toàn bộ Copy ghi chú từ Dàn KTS sang mục thu gọn/mở rộng **Copy ghi chú** trong tab **Dàn theo mẫu**, đặt sau Áp mẫu và trước Lưu PDF. Mặc định thu gọn.
- Giữ ô F1, F2… và hai nút **Điền ghi chú bài 1 mặt** (artboard 1, 2, 3…) / **Điền ghi chú bài 2 mặt** (artboard 1, 3, 5…). Để trống vẫn copy nguyên ghi chú; không đổi logic JSX.
- Thông báo tiến trình/kết quả/lỗi hiện ngay trong mục mới, không chạy sang tab Dàn KTS. Hai nút cùng khóa trong lúc xử lý và mở lại khi có kết quả.
- Đổi riêng nút lưu trong tab **CTL Offset** (Đóng ghim giữa + Keo gáy) thành **Lưu AI** theo khổ vừa dàn. Bìa/từng ruột vẫn ra file riêng; hai artboard A/B của cùng ruột nằm chung một `.ai`, giữ tên artboard, layer, object và ghi chú có thể chỉnh sửa. Các tab khác vẫn lưu PDF.
- Lưu AI thuần có nén, nhúng ảnh liên kết và profile màu, không tạo kèm phần PDF. Giữ cơ chế kiểm tra khổ, không ghi đè file có sẵn, xóa riêng đầu ra chưa hoàn tất khi lỗi và trả lại trạng thái tài liệu nguồn. Không group/di chuyển/undo trên nguồn; chưa thay cơ chế copy từng object nên không cam kết hết thời gian chờ trên file lớn.
- Không đổi vị trí/bắt đầu PON hoặc cách dàn CTL theo yêu cầu bỏ số 2. Nút lưu nạp script phiên bản 3 để thay engine PDF cũ.
- Kiểm thử vị trí/ID không trùng, mở–thu accordion, gọi đúng chế độ một/hai mặt, tiền tố và thông báo; giữ kiểm thử sao chép ghi chú hiện tại. Lưu và mở lại trực tiếp 3 file AI trong Illustrator (bìa, ruột tự trở, ruột A/B), kiểm tra đủ artboard/kích thước/tên, vector/raster/PON/ghi chú và nguồn không thay đổi. Bản sửa cài local, chưa phát hành GitHub.

---

## v2.15.16 — Keo gáy A5 ghép 32 trang trên cùng tờ AB (03/10/2026)

- A4 giữ form 16 trang/tờ AB. A5 tự nhận theo khổ một trang đến 15 × 21,15 cm, ghép hai tay 16 trang liên tiếp lên cùng một cặp artboard A/B: 1–32, rồi 33–64… Không dùng form gấp 32 mới và không thêm trang trắng.
- Giữ nguyên thứ tự trang của form A4 trong từng tay; xoay cụm để vừa tờ lớn 65 × 86. Mặt B đảo vị trí hai cụm và góc xoay để lật ngang đúng cặp trang, không lật gương chữ/hình. Hỗ trợ nguồn nhập ngang như 20 × 14 cm.
- Luôn dàn phần AB trước; phần dư A5 làm tự trở 16 trang rồi 8/4 trang. Ví dụ 48 trang = AB 32 + TT16; 60 trang = AB 32 + TT16 + TT8 + TT4. Phần dư 12 vẫn giữ thứ tự lồng TT8/TT4 cũ.
- PON cắt bám theo lưới hai cụm, không vẽ nét vào giữa artwork. TT8 A5 dùng tờ 65 × 43 khi cả bài và PON vừa; nếu phần tràn vượt tờ nhỏ thì dùng tờ lớn, không tự bóp bài.
- Thêm ghi chú và nút lưu PDF cho TT16; mỗi cặp AB vẫn lưu chung một PDF, tờ tự trở lưu riêng. Lập dữ liệu PDF trước khi trả lại chế độ tọa độ artboard, tránh mất nút lưu PDF.
- Kiểm tra toàn bộ vị trí canvas trước khi raster; tạo artboard lỗi thì dọn khung mới, giữ khung nguồn. Chỉ xóa artboard cũ sau khi dàn thành công. Nút Keo gáy nạp script phiên bản 7 thay cho engine cũ.
- Kiểm chứng trực tiếp trên 6 tài liệu thử riêng trong Illustrator: A5 32/60 trang, khổ tràn 15 × 21,15, nguồn ngang, TT16 riêng và A4 32 trang; kiểm tra trang đối diện, góc xoay raster, PON, ghi chú và dữ liệu PDF. Đạt 23 file kiểm thử tự động. Bản sửa cài local, chưa phát hành GitHub.

---

## v2.15.15 — Đặt PON tiếp mà không xóa layer (03/10/2026)

- Dấu cắt tự động không còn bỏ qua toàn bộ layer PON: chỉ nhận diện nét PON do tool tạo, vẫn xử lý bài/ảnh/group nằm trong cùng layer.
- Dùng lại layer `Dau cat tu dong`, giữ dấu cũ và thêm dấu cho bài mới. Bấm lại cùng vị trí không tạo nét trùng; hỗ trợ dấu cũ chưa có nhãn nhận diện.
- Tạm mở khóa layer để vẽ, khôi phục trạng thái khóa và layer đang làm việc; chuẩn hóa tọa độ khi xử lý nhiều artboard. Lỗi tạo nét chỉ dọn nét mới của lượt lỗi, không xóa PON cũ.
- Thêm kiểm tra phiên bản script khi bấm Đánh dấu cắt để nạp bản sửa thay cho engine cũ.
- Kiểm chứng trực tiếp trong Illustrator: 8 ca đặt liên tục/đặt lại, bài trong layer PON, dấu cũ/mới được chọn kèm, layer khóa/ẩn và artboard khác; giữ nguyên bài và dấu cũ. Đạt toàn bộ 22 file kiểm thử tự động. Bản sửa cài local, chưa phát hành GitHub.

---

## v2.15.14 — Giới hạn canvas và chỉ giữ artboard kết quả mới (03/10/2026)

- Artboard đầu bắt đầu ở góc trên trái vùng canvas như KTS, theo lựa chọn mới thay cho vị trí file PON. Chạy ngang rồi xuống hàng; chừa 10 mm giữa các tờ, tránh artboard và bài nguồn. PON vẫn quyết định khổ tờ và vị trí tương đối các dấu.
- Giữ cặp trước–sau cạnh nhau, canh mép trên và tính bước hàng theo tờ cao hơn nếu hai PON khác khổ. Bỏ xếp cố định 15 tờ mỗi cột; giữ nguyên slot, hướng artwork và chế độ nhiều mẫu.
- Lập kế hoạch đủ tờ trước khi tạo; hết chỗ thì giữ kết quả cũ. Tạo artboard lỗi thì dọn artboard mới và báo lỗi, không bỏ tờ âm thầm. Đọc tối đa 1 MB metadata AI để bù gốc tọa độ canvas; file chưa lưu/không đọc được dùng gốc KTS cũ với kiểm tra lỗi tạo artboard. Không tạo artboard dò hoặc đổi gốc thước trong tài liệu nguồn.
- Các luồng bắt đầu từ góc canvas (KTS, Dàn bế, Offset tự trở/AB/nhiều khổ, Dàn theo mẫu): dàn xong thành công mới xóa toàn bộ artboard cũ, chỉ giữ artboard vừa tạo và chọn tờ đầu. Bước dọn chỉ xóa khung, không thêm thao tác xóa object/layer nguồn. Dàn lỗi giữ artboard cũ; nếu Illustrator không xóa được khung nào thì báo rõ, không xóa kết quả mới.
- Vá lỗi Offset tự trở một khổ gọi hàm PON giấy chưa được định nghĩa. Tạo đủ PON ở bốn góc như các nhánh KTS và Offset nhiều khổ trước khi dọn artboard.
- Kiểm chứng trực tiếp trong Illustrator bằng tài liệu thử riêng: 7 ca Dàn theo mẫu (gốc thước, một/hai mặt, nhiều mẫu, 26 tờ xuống hàng, 14 cặp khác khổ, hết canvas giữ kết quả cũ), cùng 9 ca dọn artboard KTS/Offset/Bế và lỗi đầu vào. Không chạy xóa artboard trên bài thật đang mở.
- Đạt toàn bộ 21 file kiểm thử tự động; đã cài bản 2.15.14 vào CEP trên máy này sau khi sao lưu bản 2.15.13. Chưa phát hành lên GitHub.

---

## v2.15.4 — Khổ bế tùy chỉnh và PON tự tạo (02/10/2026)

- Bỏ chọn/import file PON trong Dàn bế. Thêm hai ô khổ giấy (cm), mặc định **33 × 35,4 cm**; bên dưới là bốn ô theo thứ tự **trên / dưới / trái / phải** (mm), mặc định **10 / 10 / 10 / 10**.
- Tự tạo bốn chấm PON tròn **5 mm** (0,5 × 0,5 cm), đen 100K, không viền. Các khoảng nhập đo từ **mép artboard đến tâm chấm**; né PON vẫn đo từ mép chấm. Khổ giấy và PON áp dụng cho toàn bộ tờ/cặp hai mặt trong lượt chạy.
- Đặt tờ đầu như Dàn KTS: bắt đầu ở góc trên trái canvas, cách biên canvas 10 mm; đi từ trái sang phải, né artboard và bài nguồn, hết ngang tự xuống hàng. Cặp hai mặt luôn đi cùng hàng, hỗ trợ giới hạn Large Canvas.
- Kiểm tra toàn bộ vị trí trước khi tạo đầu ra; khổ vượt canvas, PON ra ngoài tờ/chồng nhau hoặc số nhập sai sẽ báo lỗi. Không mở/đóng file PON và không sửa bài gốc.
- Giữ khe khuôn, lề, né PON, một/hai mặt, tờ riêng/gộp mẫu và lõi nesting hiện tại. Không thay đổi KTS, CTL hay các chức năng khác.
- Kiểm chứng trực tiếp trong Illustrator bằng tài liệu thử riêng: khổ mặc định 33 × 35,4 cm và khổ đổi 32 × 34 cm với bốn khoảng PON khác nhau; tạo cặp trước/sau, đủ bốn chấm 5 mm mỗi mặt, tâm chấm đúng số nhập và tờ đầu đúng vị trí KTS. Không lưu đè bài gốc.

---

## v2.15.3 — Dàn bế tag hai mặt (02/10/2026)

- Thêm tick **Dàn bế 2 mặt (tag)**. Nguồn được chọn theo từng hàng, thứ tự trái → phải: **Khuôn → mặt trước → mặt sau**. Nếu không chọn object, dùng ba layer **Khuôn bế**, **Mặt trước**, **Mặt sau** cùng số mẫu.
- Khóa từng bộ ba trước khi dàn; thiếu mặt, hàng không rõ hoặc vị trí trái/phải trùng nhau sẽ báo lỗi, không đoán ghép sang mẫu khác.
- Chỉ tối ưu bố cục khuôn một lần. Mỗi tờ tạo cặp artboard trước/sau để **lật ngang như KTS**; mặt sau dùng đúng mẫu, vị trí đối xứng và góc xoay ngược. Không lật gương chữ/hình.
- Khuôn mặt sau là ảnh phản chiếu hình học của khuôn mặt trước đã xoay, kể cả hình lõm/bất đối xứng. PON cũng đối xứng theo tờ và giữ nguyên kích thước chấm. Mỗi mặt giữ layer Khuôn, Bài và PON riêng.
- Giữ chế độ một mặt mặc định, mỗi mẫu một tờ riêng hoặc tick gộp nhiều mẫu. Hai mặt dùng chung số con/tờ, không đếm đôi; file PON chỉ hỏi một lần cho cả lượt.
- Không đổi lõi nesting, khe/lề/né PON, KTS hay CTL. Có kiểm thử bộ ba, nguồn ba layer, bốn góc xoay, đúng mẫu trước/sau, biên khuôn/PON đối xứng và thu hồi đầu ra khi lỗi ở bất kỳ mặt nào.
- Kiểm chứng trong Illustrator trên tài liệu thử riêng: hai mẫu khuôn lõm/bất đối xứng, tám tag với đủ bốn góc xoay; chế độ riêng tạo bốn artboard, chế độ gộp tạo hai. Kiểm tra từng đỉnh khuôn, hướng artwork mặt sau và PON lệch vị trí giữa các góc. Không sửa/lưu đè bài gốc.

---

## v2.15.2 — Khóa cặp KTS và tờ riêng cho từng mẫu bế (02/10/2026)

- Dàn KTS hai mặt: gom hàng nguồn theo kích thước object rồi khóa trái = trước, phải = sau. Lệch Y rất nhỏ không còn đảo vai hai mặt; nguồn không rõ cặp sẽ báo lỗi trước khi dàn.
- Mặt trước và mặt sau dùng chung danh sách mẫu/vị trí đã khóa, giữ nguyên xoay và đối xứng in hai mặt. Không cần khóa layer nguồn bằng tay.
- Dàn bế mặc định mỗi mẫu một artboard, nhân bản đầy tờ riêng. Thêm tick **Dàn nhiều mẫu vào một tờ** để dùng lại cách gộp/luân phiên các mẫu.
- Chỉ chọn file PON một lần cho cả lượt; mỗi tờ giữ đủ bốn chấm, layer Khuôn và Bài riêng. Tái dùng kết quả tính khi biên khuôn giống hệt, cập nhật trạng thái giữa các mẫu.
- Kiểm tra toàn bộ bố cục trước khi vẽ; nếu tạo tờ/layer/bản sao bị lỗi, chỉ thu hồi đầu ra vừa tạo trong lượt đó, không xóa bài nguồn.
- Không đổi lõi dàn biên khuôn, khe/lề/né PON, CTL hay Dàn Offset. Bổ sung kiểm thử đảo mặt, vị trí đối xứng, tờ riêng/tờ gộp và phục hồi khi lỗi.
- Kiểm chứng trực tiếp trong Illustrator trên tài liệu thử riêng: 7 cặp KTS qua cả hai chế độ (147 vị trí đối xứng khi tách mẫu, 21 khi gộp); Dàn bế hai mẫu tròn tạo tờ riêng 42/108 con hoặc tờ gộp 47 con, đúng tâm khuôn và đủ PON. Không lưu đè bài gốc.

---

## v2.15.1 — Dọn Dàn bế cũ và tách nạp script (02/10/2026)

- Bỏ bộ tính Dàn bế cũ `dcDanBe()` và mã phiên bản `dcDanBeVersion` khỏi `dan_card_lib.jsx`; nút Dàn bế chỉ dùng luồng mới.
- Tách kiểm tra/nạp thư viện chung và cầu nối Dàn bế: chỉ nạp lại JSX đang thiếu hoặc cũ, không phụ thuộc hàm Dàn bế đã bỏ.
- Bỏ mục **Dàn Decal** cũ trong tab Dàn file, handler nút và bảng tọa độ/hàm JSX chỉ phục vụ mục đó. Dàn decal theo khuôn tiếp tục dùng **Dàn tối ưu → Dàn bế**.
- Giữ nguyên các phần CTL, Dàn KTS/Offset, Raster, Clip, Resize và các chức năng khác. Không xóa file ghi nhớ PON của người dùng.
- Bổ sung kiểm thử nạp script độc lập và chạy lại bộ kiểm thử Dàn bế. Không xóa bản sao lưu, file AI thử hoặc dữ liệu nguồn.

---

## v2.15.0 — Dàn bế theo biên khuôn thật (02/10/2026)

- Tách thành `js/dan_be_nester.js` (tính bố cục trong CEP) và `jsx/dan_be_bridge.jsx` (đọc/vẽ trong Illustrator). Luồng mới: đọc khuôn/PON → tìm cách xếp → tạo kết quả.
- Tự thử xoay 0°/90°/180°/270°, xếp xen kẽ, tận dụng chỗ lõm và vùng trống; kiểm tra giao nhau và khoảng cách theo đường khuôn, không chỉ theo hình chữ nhật bao ngoài.
- Giữ các ô nhập: khe giữa hai khuôn mặc định **2 mm**, khuôn cách mép tờ **4 mm**, né PON **7,5 mm tính từ mép chấm**. Khe không tự cộng phần tràn artwork.
- Mỗi lần chạy hỏi file PON AI, đọc khổ artboard và vị trí bốn chấm. Giữ khuôn và bài ở layer riêng; artwork đã tràn được nhân bản, xoay và canh tâm theo khuôn.
- Cải thiện tìm bố cục hình tròn và hình dạng bất quy tắc, cân bằng nhiều loại bài; thử xoay/đổi vị trí cụm sát mép để tăng lề mà không giảm số con.
- Đã thử trực tiếp trên bản sao trong Illustrator: mẫu thìa **10 con**, lề nhỏ nhất khoảng **14,79 mm** sau chỉnh bố cục; tròn 5 cm **42 con** trên tờ PON 33 × 35,4 cm với khe 1 mm, lề 4 mm và né PON 7,5 mm. Mẫu lá đạt **50 con** trong kiểm thử hồi quy.
- Kiểm thử thêm khuôn giả lập mèo, thỏ, sao lõm, hình có lỗ, hình L và nhiều loại trộn chung; có kiểm tra khe, lề, né PON độc lập.
- Giới hạn: đây là bộ tìm kiếm nhiều phương án, chưa bảo đảm số con lớn nhất tuyệt đối với mọi khuôn. Cần đường khuôn vector đóng hợp lệ; đường cong được lấy mẫu để tính hình học.

---

## v2.14.0 — vá lại "in"

- vá lại "in"

---

## v2.13.21 — cài lại cho máy nv

- cài lại cho máy nv

---

## v2.13.20 — Dựng lại lưới, PON và bóp của CTL Offset

- \*Khổ artboard cố định, không co theo khổ trang\*\*
- Trước đây artboard tính từ khổ trang nhập nên nhập 13×20 cm ra artboard 81,27×55,87 cm — một khổ giấy không có thật. Nay chỉ còn ba tờ cố định: **42,8×31,3** (bìa A5), **64,8×41,8** (tự trở 8 A5, TT4), **85,8×63,8** (ruột A5, A4 main).
- Bài canh giữa theo chiều ngang tờ. Khổ trang chỉ quyết định bài nằm thế nào trên tờ, không đổi khổ tờ.
- Trang quá lớn không lọt tờ thì báo lỗi rõ (dư bao nhiêu mm theo chiều nào), không âm thầm phình artboard ra.
- \*Lưới họ A5 tì vào mép dưới artboard\*\*
- Mọi khổ trang từ A5 trở xuống (≤ 15 × 21,15 cm) đều neo lưới vào mép dưới, lề thừa dồn lên trên. PON đáy vì vậy luôn bắt đầu từ đáy tờ với bất kỳ khổ trang nào.
- Nhờ đó khổ tối đa 15 × 21,15 cm chạy được. Trước đây lề nhíp 24 mm cộng cứng làm bài cao 63,9 cm, dư đúng 1 mm so với tờ 63,8 cm nên bị chặn.
- Họ A4 giữ nguyên cách treo từ mép trên xuống với lề nhíp cố định.
- \*Hằng số lưới giải lại từ ba khổ form chuẩn\*\*
- Các số 0,1766805 / 3,351722 / −0,647805 / 13,176 / 24,351972 mm là sai số đo từ file mẫu chứ không phải thiết kế. Giải ngược từ ba khổ chuẩn với trang A5 14,9 × 21,15 cm ra số nguyên: lề hông 0 / 22 / 3 mm, lề trên+dưới 15 / 0 / 27 mm.
- Bỏ lề âm −0,65 mm của ruột A5 và bỏ luôn `fitLift`. Trước đây lưới lòi khỏi artboard 0,65 mm nên PON đáy vẽ ra ngoài giấy, phải nhấc artwork lên bù.
- \*PON cắt\*\*
- Thêm mốc ở biên trang bên trong mỗi nửa để cắt ra cụm 2 rồi xếp lại: ruột A5 từ 26 lên **44 nét**, tự trở 8 A5 từ 18 lên **22 nét**.
- Mọi giao điểm đều là chữ L đủ (nét dọc quay vào rãnh trống kèm chân ngang), kể cả chỗ giao khe giữa với khe hàng 15 mm — trước đây chỗ đó chỉ có chân ngang.
- Bỏ các số bù lắt nhắt `coverOuterLift` 0,2 mm và `coverBottomOutset` 0,3 mm; dấu nay nằm đúng trên đường cắt.
- Thêm luật chung: không nét nào được nằm ngoài artboard. Mốc lọt ra ngoài bị kéo về mép và số lượng được báo trong dòng kết quả.
- Số nét báo ra nay đếm thật, không còn trả số cứng 12 / 10.
- \*PON giấy\*\*
- Cùng khổ giấy thì cùng kiểu dấu. Trước đây trên cùng tờ 65×86, job A4 vẽ nét dọc 21,091 pt / nét 3,971 còn job A5 vẽ 21,53 pt / nét 1,997. Nay chỉ còn hai bộ: form lớn 18,766 / 21,091 / 3,971, form nhỏ 14,173 / 14,106 / 1,995.
- \*Gọn lại phần code\*\*
- Năm loại form gom về **một bản mô tả** mỗi loại (số cột, số hàng, khe, lề nhíp, tờ giấy, kiểu neo). Lưới danh định và cả hai loại PON đều sinh ra từ bản mô tả đó, thay cho năm nhánh code riêng.
- Ba đoạn bóp viết trùng nhau ở ba chỗ gom về một hàm `squeezeAboutCentre`.
- `dcRunSignature8` từ 2.292 xuống 2.103 dòng.
- \*Phần A4\*\*
- Topology PON của A4 giữ nguyên: A4 main 20 nét, TT4 10 nét, trùng khớp từng nét so với bản cũ khi cùng lưới; PON giấy không đổi.
- Riêng khổ artboard A4 nay cũng cố định như A5 (85,8×63,8 và 64,8×41,8) thay vì tính động theo khổ trang.

---

## v2.13.19 — Khóa ruột A5 vào artboard khi bóp tâm

- Sửa riêng ruột A5 16/32 trang: khi bóp từng cụm 2 trang quanh tâm, cụm ruột đầu được nâng đúng phần mép còn vượt (0,147805 mm với tờ 1). Bài không còn tràn đáy artboard.
- Không đổi kích thước/artboard, không đổi lưới PON giấy hay PON cắt, và không kéo PON theo ruột. Khe đóng ghim vẫn là khe.
- Giữ nguyên topology PON L của mẫu A5 65×86: mốc ở đầu/cuối cụm 2 trang và khe 15 mm. Không tự ý thêm mốc tại seam từng trang khi chưa đổi quy cách PON.

---

## v2.13.18 — PON đáy A5 65×86 và bóp tâm cụm 2 trang

- PON cắt đáy của form A5 65×86 nay dài đúng 4 mm và kết thúc tại tâm PON giấy/baseline artboard, khớp file mẫu; không còn dừng sớm 0,352 mm trùng với đáy ruột đã bóp.
- A5 ruột 16/32 trang bóp từng cụm 2 trang quanh tâm cụm. Khe giữa vẫn là khe (không có đường cắt qua), và PON giấy/PON cắt vẫn đứng yên trên lưới khổ gốc.
- Đã đối chiếu form 43×32.5: giữ nguyên đủ 12 PON cắt của mẫu, không thêm hoặc dịch PON bìa.

---

## v2.13.17 — Khóa PON CTL Offset vào lưới gốc

- Tất cả group/resize/translate của CTL Offset nay ghi thẳng vào layer bài, không còn phụ thuộc `activeLayer` trong lúc ruột đang bóp.
- Sau khi dàn, bóp và thêm ghi chú xong, tool đối chiếu lại tọa độ PON giấy/PON cắt với lưới danh nghĩa ban đầu, khôi phục nếu có thay đổi bất thường, rồi khóa và đưa hai layer PON lên trên cùng.
- Giữ nguyên tọa độ/topology PON 65×86 A5 của hai file mẫu: PON không nhận bất kỳ độ bóp nào theo `sheetNo`.

---

## v2.13.16 — Không đưa PON cũ vào ruột khi chạy lại CTL Offset

- Xóa đúng hai layer PON do CTL Offset tạo (`Pon CTL Offset tu dong` và `Pon cat CTL Offset tu dong`) trước khi đọc selection/raster nguồn.
- Nhờ vậy PON của lần dàn trước không thể bị raster hóa rồi bóp cùng ruột, trong khi PON mới vẫn đứng ở lưới khổ gốc.
- Tăng mã nạp ExtendScript để Illustrator bắt buộc đọc bản sửa này trong engine đang mở.

---

## v2.13.15 — Sửa lỗi nạp ExtendScript

- Đổi tên đơn vị inch thành `"in"` trong toàn bộ object JavaScript. Illustrator ExtendScript coi `in` không có dấu nháy là từ khóa dành riêng, khiến CTL Offset không thể nạp.

---

## v2.13.14 — Nạp lại lưới CTL Offset sau overwrite

- Tăng mã nạp CTL Offset để Illustrator bắt buộc đọc lại phần dàn bình đã khôi phục, không dùng hàm cũ còn giữ trong bộ nhớ ExtendScript.
- Giữ nguyên quy tắc v2.13.13: artboard/PON lấy từ lưới khổ gốc; chỉ artwork ruột bóp dần; A5 16/32 trang giữ nguyên khe 15 mm.
- PON giấy giữ quy tắc CTL Offset: tâm bốn nét nằm trên biên artboard; khổ artboard không đổi.

---

## v2.13.13 — Lưới PON CTL Offset theo khổ gốc

- Thay toàn bộ khổ artboard cố định bằng một lưới danh nghĩa theo đúng kích thước 1 trang nhập. Khổ nhỏ hơn A4/A5 vẫn tự tính artboard, PON giấy và PON cắt theo bố cục tương ứng.
- Quy tắc luồng được khóa lại: bìa ở đúng khổ gốc; mỗi ruột bóp dần 1 mm/tờ trên artwork; PON cắt, PON giấy và artboard luôn giữ lưới khổ gốc trước bóp.
- A5 ruột 16/32 trang bóp riêng từng block 2 trang, ghim cạnh trong để khe 15 mm không đổi. Với trang rộng 15 cm, ruột 1 co đúng còn 14.95 cm thay vì 14.9756 cm.
- A4 TT4/TT8/A-B bỏ hoàn toàn công thức làm PON chạy theo `sheetNo`; TT8/A-B có lại bốn PON ngắn ở hàng giữa, không hề tạo đường cắt dài qua khe đóng ghim.
- PON cắt A5 bìa/ruột dùng cùng lưới danh nghĩa; form 65×86 giữ đủ topology 36 nét của file mẫu. PON chỉ đảo hướng khi đầu nét chuẩn bị vượt mép artboard.
- Ghi chú A5 dùng vùng trống đo từ hai file mẫu (bìa và ruột chính); SMALL8 đặt nhãn ngoài giấy vì không có vùng trống an toàn trong lưới.

---

## v2.13.12 — Chốt ba form CTL Offset A5 theo file mẫu

- Khóa artboard theo tâm bốn PON giấy: A5 4 trang = 42.8 × 31.3 cm, A5 8 trang = 64.8 × 41.8 cm, A5 16 trang/A-B = 85.8 × 63.8 cm. Hai form có số lẻ vẫn giữ trị số chính xác trong file để Illustrator hiển thị đúng kích thước mẫu.
- PON cắt bìa A5 42.8 × 31.3 khớp 12 nét của file mẫu, gồm hai chân ngang ở khe 5 mm và hai mốc đáy lệch ra 0.3 mm; không có đường cắt qua hàng giữa.
- PON cắt ruột A5 85.8 × 63.8 khớp 34 nét của file mẫu: đủ cả hai chân trái/phải ở tim khe dọc, bảy mốc đầu trên, hai mép khe ngang 15 mm và ba mốc đáy trung tâm. Khe ngang vẫn là khe gấp/xả, không phải đường cắt.
- A5 8 trang dùng lưới trim 20.9 cm/hàng trong artboard 64.8 × 41.8; nguồn A5 cao 21.15 cm giữ phần bleed chồng 1.25 mm ở hai mép ngoài và 2.5 mm ở khe hàng.
- Xác nhận A4 riêng biệt: TT4 vẫn 64.8 × 41.8, TT8/A-B vẫn 85.8 × 63.8; PON cắt bám mép bài sau bóp 1 mm/tờ, không thêm PON ở khe ngang đóng ghim.

---

## v2.13.11 — PON bám bài A4 sau bóp

- Giữ nguyên bóp 1 mm/tờ của CTL Offset A4; trang 20 cm thành 19.95 cm ở nửa cụm là đúng quy cách bóp.
- PON cắt TT4, TT8 và A/B A4 nay tính theo mép thực sau bóp: hai mép ngoài vào squeeze/2, hai mép khe giữa ra squeeze/2. PON không còn lệch tổng 2 mm so với bài.
- Kích thước artboard và PON giấy không đổi: 65×86 A4 vẫn là 85.8 × 63.8 cm, tâm bốn PON giấy nằm trên biên artboard.

---

## v2.13.10 — Sửa form A4 65×86

- Artboard CTL Offset A4 65×86 là 85.8 × 63.8 cm, không còn dùng chiều cao 62.5 cm của form cũ.
- Bỏ dịch 2 mm ở hai mốc ngoài của PON cắt A4 65×86: PON nay bám đúng mép cụm bài.
- Với PON giấy của Dàn Offset và CTL Offset, biên artboard luôn đi qua tâm của cả bốn nét PON, đúng mốc kích thước trong Illustrator.

---

## v2.13.9 — CTL Offset A5 khớp hai form mẫu

- Dàn 65×86 A5 được dựng lại đúng form mẫu: lưới 4×4 xoay, khe dọc 6 mm và khe ngang 15 mm; khe ngang là vùng xả/gấp, không phải đường cắt.
- PON cắt 65×86 bám đúng 31 mốc của form mẫu: bảy mốc đầu trên, các mốc ở hai phía khe ngang và ba mốc đáy trung tâm; không đánh PON ở đường chia trang không cần cắt.
- PON cắt 43×32.5 dùng đúng hai dấu L ngoài và ba mốc trong khe 5 mm, không thêm PON vào đường chia hàng.
- Tách PON giấy hai form: 43×32.5 dùng góc 3 mm/1 pt; 65×86 dùng góc 18.766 × 21.53 pt/1.997 pt. Cả hai lấy biên artboard làm tâm nét PON.
- Bỏ PON ngang giữa của form A4 65×86 vì đó là khe gấp/đóng ghim, không phải đường cắt.

---

## v2.13.8 — Chuẩn hoá PON cắt CTL Offset theo mép xả

- Tách rõ đường chia bố cục và mép có PON: không còn tự đánh PON cắt ở đường chia hàng của 43×32.5, 65×43 và 65×86 A5.
- Khôi phục năm mốc dọc của form A4 65×43 (hai mép ngoài và ba mốc khe dọc), không đánh dấu trên khe ngang giữa hai hàng.
- Form A5 65×86 giữ ba mốc khe giữa, bổ sung hai mốc giữa từng panel ở đầu trên/dưới; bỏ các mốc sai trên mép hàng.
- PON mặc định hướng ra ngoài; chỉ lật vào trong khi đầu nét sẽ chạm mép artboard.

---

## v2.13.7 — Hoàn thiện PON cắt ngang A5

- A5 có PON ở hai đầu mọi đường cắt ngang của lưới; chỉ đánh dấu, không vẽ đè đường cắt lên bài.
- Sửa hướng PON góc ngoài phía trên của form 43×32.5 để luôn hướng ra ngoài cụm bài.

---

## v2.13.6 — Hoàn nguyên PON CTL Offset, sửa ghi chú CTL KTS

- Hoàn nguyên kiểu PON CTL Offset sau phần thử theo ảnh KTS; giữ bộ PON trước đó.
- Ghi chú Catalogue/CTL KTS bám vùng trống ngay phía trên cụm bài, không bám cố định theo mép giấy.

---

## v2.13.5 — Hoàn tất PON cắt ngang CTL Offset

- Mỗi đường cắt ngang giữa hai hàng có dấu PON ở cả mép trái và mép phải của cụm bài.
- Áp dụng cho 43×32.5, 65×43, 65×86 tự trở và A/B, cho cả nhánh A5 lẫn A4.

---

## v2.13.4 — PON cắt CTL Offset theo kiểu KTS

- Hai biên ngoài của mọi khổ CTL Offset dùng dấu L cùng kích thước và hướng như PON cắt KTS.
- Mốc cắt ở các khe giữa vẫn theo đúng lưới từng kiểu dàn; PON giấy 4 góc không thay đổi.

---

## v2.13.3 — Rà PON CTL Offset và ghi chú A5

- PON cắt 65×86 A5 (tự trở và A/B) có đủ hai biên ngoài cùng ba mốc khe giữa.
- PON cắt 43×32.5 có đủ mốc cắt dưới; PON 65×86 A4 bỏ độ lệch 2 mm ở hai biên ngoài.
- Tất cả ghi chú CTL KTS A5 dùng đúng vị trí trong artboard đã chuẩn hoá ở dàn A4.

---

## v2.13.1 — Bổ sung PON giấy và PON cắt A5

- Dàn Offset tự trở vẽ PON giấy đủ bốn góc trên layer riêng, với mọi khổ giấy nhập.
- CTL Offset A5 nạp lại bộ vẽ PON; khổ 65×43 có đủ năm mốc cắt ở đầu trên và dưới.

---

## v2.13.0 — Hoàn chỉnh dàn tự trở

- Hoàn chỉnh dàn tự trở

---

## v2.12.10 — Rút gọn Dàn Offset

- Bỏ lựa chọn AB trùng với Dàn KTS; Dàn Offset chỉ còn tự trở trên một artboard.

---

## v2.12.9 — Dàn Offset AB

- Dàn AB tạo artboard A (mặt trước) và B (mặt sau) cùng khổ giấy.
- Mỗi artboard có PON giấy ở đủ 4 góc theo chính kích thước nhập.
- Chọn AB lần đầu đặt sẵn khổ 85.8 × 63.8 cm; mỗi chế độ nhớ khổ giấy riêng.

---

## v2.12.8 — Clip kích thước không dừng cả selection bản vá

- Clip kích thước không dừng cả selection bản vá

---

## v2.12.7 — Clip kích thước không dừng cả selection

- Lỗi khi dò clip cha hoặc khung nền của một object không còn làm dừng toàn bộ lệnh Clip.
- Object đó dùng fallback; nếu vẫn không clip được, panel báo rõ object lỗi và vẫn xử lý các object còn lại.

---

## v2.12.6 — Thu gọn Dàn tối ưu

- Hai mục Dàn KTS và Dàn Offset trong tab Dàn tối ưu đều đóng khi panel vừa mở.

---

## v2.12.5 — Nhiều khổ không theo thứ tự chọn

- Với dàn Offset tự trở nhiều khổ, cặp không vừa bị bỏ qua để thử cặp kích thước khác.
- Bộ xếp chọn phương án có số cặp nhiều nhất, không dùng thứ tự chọn làm ưu tiên.

---

## v2.12.4 — Dàn Offset tự trở nhiều khổ

- Dàn chung các cặp có kích thước thành phẩm khác nhau trên một tờ tự trở.
- Tối đa số cặp đặt được, chỉ xóa cặp nguồn đã dàn; cặp còn lại giữ nguyên để chạy tờ sau.
- Bóp chỉ dùng khi tăng được số cặp; hai mặt của từng cặp vẫn kiểm tra khớp khung.

---

## v2.12.3 — Bản vá lỗi dàn, ctl, thêm chức nắng dàn offset

- Bản vá lỗi dàn, ctl, thêm chức nắng dàn offset

---

## v2.12.2 — Bản cải tiến bình ctl offset + kts ko cần dùng pon, linh hoạt trên mọi mặt trận a4 a5

- Bản cải tiến bình ctl offset + kts ko cần dùng pon, linh hoạt trên mọi mặt trận a4 a5

---

## v2.12.1 — Bản vá sửa lỗi raster + clip khi gặp file tào lao của khách.

- Raster đưa raster chuẩn nhất về phần clip
- Clip chuyển về giống như clip card nhưng vẫn có vài nhược điểm khi gặp file siêu chó.

---

## v2.12.0 — beta thêm chức năng tự động dàn tối ưu

- Dàn tối ưu nhất trên 1 tờ giấy với kích thước tùy chỉnh

---

## v2.10.20 — Thayy đổi chức năng cách dùng của dan theo mau cho chuẩn nhất sau khi dàn và nhanh hơn

- Bỏ snapshot từng con khi học mẫu ==> snap cả cụm rồi cắt từng con ra để xem
- Có thêm chức năng chọn con chuẩn khi học mẫu để đi chiều dàn cho đúng

---

## v2.10.19 — Bản vá cập nhật

- Bản vá cập nhật

---

## v2.10.18 — vá các vấn đề trong chức năng dàn theo mẫu, và thêm chức năng dàn theo hộp linh động trong autosave

- vá các vấn đề trong chức năng dàn theo mẫu, và thêm chức năng dàn theo hộp linh động trong autosave

---

## v2.10.17 — Khong group dau cat tu dong

- Cac net dau cat tu dong duoc ve truc tiep tren layer Dau cat tu dong, khong gom thanh mot group.

---

## v2.10.16 — Gom object truoc khi luu PDF

- Moi artboard duoc group tam, copy mot lan vao trang PDF nhe roi Undo ngay tren file goc. Khong luu AI goc, khong tao hoac doi artboard tam, va huy PDF do dang neu copy khong du.

---

## v2.10.15 — Ổn định lưu PDF artboard

- Lưu PDF bằng bản sao AI và artboard gốc, bỏ hoàn toàn nhánh tạo hoặc chỉnh artboard tạm gây lỗi 1200.

---

## v2.10.14 — Sửa lỗi 1200 khi lưu PDF

- Không gán lại artboardRect trong document tạm, tránh lỗi 1200 khi lưu PDF mặt trước và mặt sau.

---

## v2.10.13 — Tăng thời gian thông báo

- Thông báo cập nhật hiển thị khoảng 15 giây thay vì bị tắt sớm.

---

## v2.10.12 — Bỏ viền trắng tab

- Bỏ viền focus trắng dưới tab đang chọn và khôi phục lệnh dọn task cập nhật cũ.

---

## v2.10.11 — Sửa lưu PDF nhiều artboard

- Tạo sẵn toàn bộ artboard trong document tạm để tránh lỗi 1200 khi lưu PDF mặt trước và mặt sau.

---

## v2.10.10 — Sửa bước thay updater

- Sửa tham số PowerShell xung đột với biến hệ thống, bảo đảm updater tự thay file và dọn task cũ ổn định.

---

## v2.10.9 — Dọn task cập nhật cũ

- Xóa task kiểm tra cũ chạy PowerShell trực tiếp, chỉ giữ task chạy ẩn để không còn cửa sổ CMD chớp mỗi phút.

---

## v2.10.8 — Ẩn cửa sổ kiểm tra cập nhật

- Sửa tác vụ kiểm tra cập nhật mỗi phút chạy hoàn toàn ẩn, không hiện cửa sổ CMD hoặc PowerShell.

---

## v2.10.7 — test tiếp 2

- test tiếp 2

---

## v2.10.6 — test tiếp

- test tiếp

---

## v2.10.5 — test thông báo cloudflare

- test thông báo cloudflare

---

## v2.10.4 — test thông báo qua cloudflare

- test thông báo qua cloudflare

---

## v2.10.3 — Test Thông báo Window

- Test Thông báo Window

---

## v2.10.2 — Thêm chức năng nếu có cập nhật sẽ thông báo tại window

- Thêm chức năng nếu có cập nhật sẽ thông báo tại window

---

## v2.10.1 — vá lỗi hiển thị panel

- vá lỗi hiển thị panel

---

## v2.10.0 — Thêm chức năng save PDF từng artboard

- Save PDF từng artboard:
- Có chọn được save 1 mặt hay 2 mặt
- Có tự động đánh số File 1, File 2,...
- Nhập tiêu đề đứng sau File 1, File2,...

---

## v2.9.11 — Bản vá đặt Pon

- Vá lỗi đặt pon khi đánh Pon vượt mép

---

## v2.9.10 — Chỉnh sửa loại Pon cho card cắt

- Các loại card cắt sẽ dùng cùng Pon khổ 33x35.4 vì dupicate pon quá lâu có khi là lỗi nên sẽ mất rất nhiều thời gian.
- Pon khổ 33x35.4 sẽ dùng chung 1 loại là Pon trăng ko có bất cứ gì trên đó.

---

## v2.9.9 — thêm chức năng cho tự động đánh Pon

- Thêm ô nhập Khoảng cách từ Pon đến bài.

---

## v2.9.8 — update tu ve Pon cat

- Phát triển thêm chế độ tự động đánh Pon cắt cho bài cần cắt.

---

## v2.9.7 — Ban va dantheomau

- Chỉnh sửa các vấn đề về dàn hình tròn, hình vuông, cân bằng và đi sâu vào snapShot.

---

## v2.9.6 — Khoi phuc 2 che do dan theo mau

- Khôi phục 2 chế độ dàn theo mẫu mà đã làm từ trước vì lỡ thay thế 2 chế độ với nhau để test.

---

## v2.9.5 — Them icon va tien do cap nhat

- Phát hành tự động qua PhatHanhCapNhat.bat.

---

## v2.9.4 — Nhận bản mới không chờ cache GitHub Raw

- Updater đọc `latest.json` qua GitHub Contents API, tránh cache tối đa năm
  phút của GitHub Raw khi vừa publish bản mới.
- Bộ cài tự đổi cấu hình GitHub Raw cũ sang API ở lần cài tiếp theo.

---

## v2.9.3 — Kiểm nghiệm thủ công bằng CMD

- Bản phát hành thử nghiệm không thay đổi chức năng panel, dùng để kiểm tra
  lối tắt CMD cập nhật thủ công trong Start Menu.

---

## v2.9.2 — Kiểm nghiệm cập nhật online

- Bản phát hành thử nghiệm không thay đổi chức năng panel, dùng để xác nhận
  toàn bộ luồng tải ZIP, xác minh SHA-256 và thay bản cũ tự động.

---

## v2.9.1 — Cập nhật ngay không cần đăng xuất

- Bộ cài tạo lối tắt **Cập nhật Công cụ bình** trong Start Menu. Đóng hẳn
  Illustrator rồi bấm lối tắt này để kiểm tra và cài bản mới ngay, không cần
  khởi động lại hoặc đăng xuất Windows.
- Updater đọc được `latest.json` từ GitHub Raw trên cả Windows PowerShell 5,
  kể cả khi file có UTF-8 BOM.
- Nếu Windows chặn Task Scheduler, updater tự chạy từ Startup của user khi
  đăng nhập Windows.

---

## v2.9.0 — Cập nhật online an toàn

- Thêm updater Windows độc lập với panel: kiểm tra `latest.json` qua HTTPS,
  tải ZIP mới, xác minh SHA-256 và chỉ thay panel khi Illustrator đã đóng.
- Bản cũ được sao lưu trước khi thay; nếu cài gói mới không hoàn tất thì tự
  khôi phục bản cũ.
- Bộ cài lần đầu đặt updater tại `%LOCALAPPDATA%\CongCuBinhUpdater` và tạo
  tác vụ kiểm tra lúc đăng nhập khi đã cấu hình URL phát hành.
- Thêm `Configure-OnlineUpdate.ps1` để gắn GitHub Release một lần, cùng
  `Publish-OnlineUpdate.ps1` để tạo đúng ZIP và `latest.json` cho mỗi bản.
- Thêm đồng bộ LAN từ máy quản lý thẳng tới AppData từng nhân viên: theo dõi
  folder nguồn, staging + backup rồi thay bản mới; nhân viên không cần tải
  file hoặc chạy `install.bat`.

---

## v2.8.0 — Dàn nhiều mẫu nguồn vào một artboard

**Dàn theo mẫu:**

- Mỗi artboard không còn nhân một object cho toàn bộ cụm. Nếu mẫu đã học có
  `n` slot thì `n` nguồn được gán lần lượt vào `n` slot theo thứ tự từ trên
  xuống, trái sang phải.
- Chọn nhiều hơn `n` nguồn sẽ tự chia thành các lô `n` nguồn và tạo artboard
  tiếp theo; mỗi lô vẫn giữ đúng từng loại, không thay thế nguồn cũ.
- Lô thiếu nguồn được bù bằng bản sao của **con cuối**, rồi **con gần cuối**.
  Ví dụ 5 slot với A, B, C sẽ thành A–B–C–C–B.
- Mỗi nguồn chỉ raster một lần trong artboard, rồi mới xoay, resize và clip
  theo slot của nó. Nguồn gốc không bị sửa.
- Bản hai mặt áp cùng logic theo cặp nguồn ở hai cột (trái=trước,
  phải=sau); chặn chạy khi mẫu trước/sau có số slot khác nhau.

---

## v2.7.0 — Ổn định Auto Save, Dàn theo mẫu và dàn bình

**Auto Save PDF:**

- Rà selection theo hàng từ **trên xuống dưới**, rồi trái sang phải. Mỗi hàng
  chỉ nhận **1 object (một mặt)** hoặc **2 object (trước + sau)**.
- Card một mặt được xuất PDF một trang và tự chèn ` - 1 mat` trước phần
  `cm/km` trong tên file. Card hai mặt vẫn xuất PDF hai trang.
- Kiểm tra STT, số đệm, object không có khung hợp lệ, tên file trùng, file PDF
  đã tồn tại và đường dẫn quá dài trước khi xuất; vì vậy không còn xuất dở
  dang một phần danh sách.
- Sửa nút chọn thư mục lưu và lỗi CEP gọi nhầm hàm khi panel còn dùng bộ nhớ
  cũ. Sau khi cài bản mới cần đóng hẳn Illustrator rồi mở lại để nạp script.

**Dàn theo mẫu:**

- Học và áp theo **từng ô mẫu**, gồm vị trí, kích thước và góc xoay; không
  còn ép toàn bộ artwork về cùng một hướng.
- Hỗ trợ artwork là Raster/Placed không có ma trận xoay: lấy hướng đang nhìn
  thấy làm góc 0 rồi áp đúng góc đã học. Dùng được với hình tròn và mẫu có
  các ô xoay 180°.
- Chặn dàn khi số object mặt trước/mặt sau không khớp hoặc pon/artboard mẫu
  không hợp lệ.

**Catalogue, CTL Offset và Keo gáy:**

- Nhận diện chính xác RasterItem, PlacedItem và group ảnh đã clip (kể cả mask
  Compound Path). Những object này được giữ nguyên, không raster lần nữa.
- Vector, chữ và group lẫn vector được raster một lần theo khung thật; nếu
  raster lỗi, tool dừng và báo lỗi thay vì tiếp tục tạo bình sai.

---

## v2.6.0 — Auto Save PDF, Clip, giao diện mới

**Tab Auto Save (mới):**

- Chọn (n×2) object → tự lưu mỗi con card thành **1 file PDF 2 trang**
  (trang 1 mặt trước, trang 2 mặt sau). File gốc KHÔNG bị sửa: mỗi con được
  nhân đôi sang tài liệu tạm, tạo 2 artboard vừa khít rồi xuất PDF.
- Tên file theo mẫu: `1088 - {STT} - {số} hộp - {cm/km} - {ngày}.pdf`.
  Ô **Mã 1088 khoá cứng**, chữ cam đậm. STT tự tăng, có đệm số 0, xem trước
  tên file trực tiếp.
- Dropdown **cm (cán màng) / km (không màng)**. Nút **"Chọn…"** mở hộp chọn
  thư mục lưu; chỉ lưu đúng folder đã chọn, không tự tạo folder mới.
- Nút **Clip 9.2 × 5.6 (tự xoay)**: cắt object đang chọn thành khung
  9.2×5.6 cm, canh giữa; object đứng dọc thì tự xoay khung thành 5.6×9.2.
- Thứ tự con sắp theo **mép trên** (gom hàng), đúng thứ tự dù card cao thấp
  khác nhau.

**Nút Clip (header, cạnh Raster):**

- Clip từng object thành khung KT nhập vào (cm/mm/in), canh giữa. Dùng sau
  khi tự bấm Raster.

**Khác:**

- **Raster đổi 400 → 450 ppi** (CMYK, nền trong suốt).
- **Giao diện tông xanh-đen (slate)** mới; scrollbar mảnh, ẩn thanh cuộn
  ngang, bỏ nút mũi tên thô; các bảng kết quả hiển thị gọn hơn.
- Bấm/Tab vào ô nhập nào thì **tự bôi đen** để gõ đè nhanh.
- Sửa lỗi truyền đường dẫn Windows (dấu `\` bị nuốt) khiến lưu sai folder;
  hỗ trợ path có khoảng trắng và dấu ngoặc.
- Xác nhận **CTL Offset**: object đã là hình (RasterItem/PlacedItem) thì
  KHÔNG raster lại, giữ nguyên chất lượng.
- Kèm **macro Corel (VBA)**: raster bitmap CMYK 450 dpi nền trong suốt,
  tuỳ chọn tự xuất PDF (tên = tên file .cdr, dùng setting PDF của Corel).

---

## v2.5.6 — Cập nhật khuôn decal 2, 2.5 và 9 cm

- Đổi bộ 268 tâm đang gán nhầm từ **2.5 cm** sang **2 cm**.
- Thêm đúng **162 tâm** của khuôn **2.5 cm** mới; PDF lưu mỗi vòng hai lần nên chỉ giữ một tâm thật.
- Thay 12 tâm khuôn **9 cm** bằng toạ độ vector gốc trong PDF; danh sách CEP sắp từ 1.5 → 2 → 2.5 → 3... cm.

---

## v2.5.5 — Tất cả toạ độ decal là tâm vòng tròn

- Chuẩn hoá toàn bộ kích thước `.5`: mỗi `[x, y]` là tâm thật của một vòng
  tròn trong file PDF khuôn, tính từ góc trên-trái artboard.
- Không còn dùng trung điểm giữa hai vòng tròn hoặc cộng/trừ bán kính. Đã áp
  dụng lại cho 1.5, 2.5, 5.5 và 8.5 cm.

---

## v2.5.4 — Lấy trực tiếp lưới PDF 1.5 cm

- Bỏ tâm trung điểm gây lệch **0.125 cm**.
- Dùng thẳng 464 tâm vòng tròn trong `khuon decal tròn 1.5cm.pdf` theo thứ tự
  trên → dưới, trái → phải.

---

## v2.5.3 — Sửa tâm dàn theo khuôn `.5`

- Khuôn **1.5 cm**: lấy điểm giữa của hai đường tròn tương ứng, thay vì lệch
  sang một đường; giữ **464 chỗ**.
- Khuôn **8.5 cm**: đọc lại file khuôn mới, thay bố cục cũ 12 chỗ bằng **14
  chỗ** và đặt đúng tâm giữa hai đường tròn.
- Rà lại các khuôn `.5` khác: 2.5 và 5.5 đã dùng tâm giữa hai đường; 3.5,
  4.5, 6.5, 7.5 và 9.5 giữ tọa độ khớp khuôn hiện có.

---

## v2.5.2 — Đồng bộ khuôn 1.5 cm

- Đọc trực tiếp path vector của khuôn 1.5 cm mới và đồng bộ bộ tâm decal:
  **454 → 464 chỗ**.
- Bổ sung 10 tâm ở mép phải, đồng thời bỏ 1 tâm thừa ở hàng cuối để dàn khớp
  lưới khuôn.

---

## v2.5.1 — Đủ cỡ decal trên CEP

- Đồng bộ CEP với toàn bộ bộ tọa độ decal đã có: **1.5, 2.5, rồi 3–9.5 cm
  mỗi 0.5 cm**.
- Danh sách cỡ decal hiển thị theo thứ tự tăng dần từ trên xuống dưới, kèm số
  chỗ tương ứng.

---

## v2.5.0 — Nòng nâng, đạn vọt trời, cả cụm vỡ & ghép lại

**Cải tiến màn xe tăng (tester mặc định)**

- **Nòng pháo nâng chếch lên** trước khi bắn (có giật khi khai hoả).
- **Đạn bắn thẳng lên** vượt khỏi panel, mất hút, rồi **rơi thẳng từ trên
  xuống** trúng chữ (thay cho vòng cung ngắn).
- **Cả cụm "Tân 1 cú"** cùng vỡ (mỗi chữ 10 mảnh) khi trúng.
- Mảnh **rơi xuống đất nằm đó (không biến mất)**, sau đó **bay lên ghép lại**
  thành cụm chữ, gradient chạy tiếp. Vòng lặp ~12s.

---

## v2.4.1 — Tinh chỉnh màn xe tăng cho mượt & trúng chữ

**Sửa / cải tiến**

- Sửa toạ độ vụ nổ dùng offset (miễn nhiễm co giãn giao diện) -> nổ **trúng ngay
  chữ Tân**, không lệch.
- Xe tăng **dừng cách chữ một khoảng** bên phải, nòng không còn đè lên "1 cú".
- Vụ nổ **to & rõ hơn** (flash + tia lửa toả đều + khói), lửa cháy gom quanh chữ,
  khói đầu nòng dịu lại; rung cả cụm chữ khi trúng.

---

## v2.4.0 — Xe tăng bắn chữ "Tân" (vòng lặp hoành tráng)

**Giao diện (tester mặc định)**

- Thêm màn **xe tăng** (SVG) chạy từ mép phải vào, dừng lại **bắn** vào chữ Tân:
  khói đầu nòng -> **đạn bay vòng cung** lên rồi rơi xuống -> **nổ** (particle
  flash + tia lửa + khói) -> **cháy** tại chỗ -> chữ **Tân 1 cú nứt vỡ (xám
  cháy) rơi xuống** -> xe tăng **lùi về** mép phải -> chữ **tự ghép lại** với
  gradient chạy như cũ -> **lặp vô hạn** (chu kỳ ~12s).
- Toàn bộ nổ/khói/lửa vẽ bằng **canvas particle** (không dùng Phaser, không phụ
  thuộc ảnh/mạng ngoài). Hiệu ứng **điện vẫn chạy** song song.

---

## v2.3.2 — Gỡ Saitama, trả "Tân 1 cú" về cũ

**Sửa**

- Bỏ toàn bộ hiệu ứng stickman Saitama + chữ Tân vỡ mảnh. Cụm **"Tân 1 cú"** trở
  lại đúng như cũ: chữ gradient + "1 cú" + hiệu ứng điện. (UFO Duẫn ở tab CTL
  Offset giữ nguyên.)

---

## v2.3.1 — Saitama vẽ bằng SVG (đẹp hơn)

**Giao diện**

- Thay stickman ghép từ ô vuông bằng **hình SVG Saitama** vẽ nét mượt: đầu hói,
  mặt "vô cảm", đồ vàng, áo choàng trắng bay, găng đỏ. Tay đấm là group SVG co
  -> duỗi hết cỡ. Nhìn gọn và đẹp hơn.

---

## v2.3.0 — Stickman Saitama đấm chữ "Tân"

**Giao diện (tester mặc định)**

- Thêm **stickman Saitama** (đầu xanh, đồ vàng, áo choàng trắng bay) bên trái
  chữ Tân: lấy đà rồi **đấm một phát** theo vòng lặp ~4.2s.
- Khi trúng: **sóng xung kích** lan ra + tia lửa toé; chữ **Tân hoá màu xám xi
  măng** rồi **bể rã thành từng mảnh** rơi xuống.
- **Phục hồi**: chữ Tân hiện lại với **gradient chạy bình thường** như cũ.
- **Hiệu ứng điện vẫn giữ** nguyên chạy song song.

---

## v2.2.3 — Credits không tràn khi thu hẹp panel

**Sửa**

- Khu Author/Tester giờ **tự xuống dòng** (wrap) và co gap linh hoạt khi kéo
  panel hẹp lại -> cụm **TESTER (UFO Duẫn) không bị đẩy tràn** ra ngoài mép phải
  nữa, luôn hiển thị đủ hiệu ứng.

---

## v2.2.2 — Duẫn: hiện đủ dấu ngã, hết cắt

**Sửa**

- Chữ **Duẫn** hết bị cắt **mép trên (mất dấu ~)**: tăng line-height + thêm
  đệm trên cho dấu thanh, hạ chữ xuống một chút.
- Dùng **gradient riêng** cho chữ (bỏ background-attachment:fixed của
  rainbow-text — thứ làm chữ lệch/cắt khi tô màu vào chữ).

---

## v2.2.1 — Duẫn: hiện lâu hơn + nhiễu rồi tắt

**Sửa / thêm**

- Chữ **Duẫn hiện lâu hơn** (kéo chu kỳ 4.6 -> 6.5s, giữ chữ gần như suốt).
- Trước khi tắt có pha **nhiễu (glitch)**: giật ngang, chớp, lệch màu — rồi mới
  tắt kiểu tivi.
- Nới khung UFO (104 -> 120px) cho **hết cắt chữ**.

---

## v2.2.0 — UFO Duẫn: nâng cấp đẹp & ảo

**Giao diện**

- UFO giờ **lượn nghiêng lắc**, có **quầng sáng** mờ phía sau, đèn bụng **đổi
  màu** chạy vòng, vòm kính có điểm sáng, người ngoài hành tinh **nhấp nháy mắt**
  và nhô lên.
- Tia chiếu thêm **hạt sáng lấp lánh rơi** xuống, **vũng sáng** loang nơi tia
  chạm, và **vòng sóng** lan ra liên tục.
- Chữ **Duẫn** hiện ra **lung linh** (glow + phóng nhẹ), vẫn tắt kiểu **tivi**.

---

## v2.1.1 — Duẫn: tắt kiểu TV + hết bị cắt chữ

**Sửa**

- Hiệu ứng biến mất của chữ **Duẫn** đổi thành kiểu **tắt tivi**: dẹp thành một
  vạch ngang sáng rồi co lại thành chấm và tắt.
- Nới rộng khung UFO (74 -> 96px) để **không cắt mất chữ** Duẫn.

---

## v2.1.0 — UFO chiếu tia hiện chữ "Duẫn"

**Giao diện (tab CTL Offset)**

- Tester "Duẫn" giờ có **con UFO** bay bồng bềnh phía trên, chiếu **tia sáng**
  xuống. Chu kỳ ~4.4s: bật tia -> chữ **Duẫn hiện ra** (phóng to, rõ dần); tắt
  tia -> chữ **biến mất** (mờ + tan). Hoàn toàn bằng CSS animation.
- UFO có vòm kính + người ngoài hành tinh mắt đen, 3 đèn bụng nhấp nháy; chữ
  Duẫn vẫn giữ màu gradient chạy.

---

## v2.0.5 — Vòng Lộc sát hình mẫu hơn

**Giao diện**

- Tia **dày & dài hơn** (360 tia, đa số dài), mảnh hơn -> viền rực như ảnh.
- Thêm **quầng sáng nền** ấm bên trái / lạnh bên phải -> cả vòng như phát sáng.
- Đốm nhiều hơn (150), tụ thành **vành bokeh** ôm sát vòng.
- Vòng tròn **mảnh & nét** hơn, bớt trắng.

---

## v2.0.4 — Bớt trắng ở vòng

**Giao diện**

- Giảm mạnh phần trắng: vòng tròn giờ **chủ đạo là màu** (đỏ/cam/vàng bên trái,
  xanh bên phải); **trắng chỉ hiện tại vùng cục sáng vừa quét**, nền không còn
  trắng cả vòng. Chấm chói đầu cục nhỏ lại, gốc tia bớt trắng.

---

## v2.0.3 — Dời "Code dạo" lại gần hào quang

**Giao diện**

- Đẩy chữ **Code dạo** sang trái ~3mm (lề trái 34 → 23px) cho gần vòng hào
  quang hơn.

---

## v2.0.2 — Cục sáng chạy vòng

**Giao diện**

- Thêm **1 cục sáng chạy vòng quanh** đường tròn: chạy tới đâu thì tia + vòng +
  đốm ở đó **rực sáng mạnh nhất**, vệt phía sau **mờ dần** (nơi cục chưa tới /
  đã đi xa giữ độ sáng nền thấp hơn).
- Có chấm chói dẫn đầu tại đầu cục; vòng trắng và quầng màu dày/sáng hơn ở vùng
  cục đang quét.

---

## v2.0.1 — Vòng Lộc làm lại giống hình mẫu

**Giao diện**

- Vẽ lại hiệu ứng cho **giống ảnh gốc**: rất nhiều **tia bắn thẳng ra ngoài**
  quanh vòng, độ dài ngẫu nhiên (viền lởm chởm), mỗi tia tự "thở" sáng-mờ và
  đổi độ dài liên tục.
- **Vòng tròn trắng sáng nét** ở giữa (lõi trắng + quầng màu theo góc).
- Bên trong rải **đốm vuông + tròn** nhiều màu, trôi nhẹ và nhấp nháy.
- Màu: trái ấm (vàng → cam → đỏ → hồng), phải lạnh (tím xanh → xanh dương).

---

## v2.0.0 — Fix tia bị đứt đuôi

**Sửa**

- Tia sáng không còn bị **cắt cụt đuôi nhọn**: phóng to khung canvas (104 →
  168px) để chứa trọn ngọn tia, giữ nguyên cỡ vòng tròn + chữ Lộc.
- Kẹp độ dài tia và tầm bay của đốm trong mép canvas an toàn (`RMAX`) để không
  vật nào bị cắt ở rìa.

---

## v1.9.9 — Vòng Lộc: ánh sáng chạy theo quỹ đạo

**Giao diện**

- Đổi cách vẽ vòng tia sáng: thay vì hạt tạo hình tròn, giờ có các **"runner"
  quét vòng quanh** theo quỹ đạo tròn; **chạy tới đâu, vòng + tia + đốm ở đó
  rực sáng tới đó** rồi mờ dần phía sau (đúng như hình mẫu).
- Tia hướng ra ngoài phân bố đều quanh vòng, chỉ bừng sáng khi runner quét qua;
  màu vẫn ấm bên trái, lạnh bên phải.

---

## v1.9.8 — Dời "Code dạo" khỏi vòng Lộc

**Giao diện**

- Đẩy chữ **Code dạo** sang phải (thêm lề trái) và nâng lên trên lớp canvas
  để không bị vòng tia sáng che.

---

## v1.9.7 — Chỉnh vòng Lộc hiện đủ

**Giao diện**

- Thu nhỏ vòng tia sáng (canvas 132 → 104px) để hiện trọn hình tròn.
- Đẩy ô **AUTHOR** sang phải (thêm lề trái) để vòng không bị cắt mép trái panel.
- Tăng khoảng cách AUTHOR ↔ TESTER (gap 24 → 56px) để tia không lan sang chữ
  tester.

---

## v1.9.6 — Vòng tia sáng quanh chữ "Lộc"

**Giao diện**

- Chữ **Lộc** (author) đổi thành hiệu ứng **vòng tròn tia sáng nổ** (canvas):
  nhiều tia + đốm vuông/tròn chạy quỹ đạo ngẫu nhiên liên tục toả ra ngoài,
  vòng tròn phát sáng, chữ Lộc glow ở giữa.
- Màu theo hình mẫu: nửa **trái ấm** (vàng → cam → đỏ → hồng), nửa **phải lạnh**
  (tím xanh → xanh dương). Render bằng `requestAnimationFrame`, tự co theo DPR.

---

## v1.9.5 — Chữ nút gradient sặc sỡ

**Giao diện**

- Chữ trong các nút chính (Dàn card, Dàn Decal, Học mẫu, Áp mẫu, Dàn
  Catalogue, CTL Offset, Đổi tên, Variable...) đổi thành **gradient nhiều màu
  chạy động** (hồng → cam → vàng → xanh lá → xanh dương → tím), chữ đậm 800,
  có viền sáng nhẹ cho nổi bật.
- Bọc text mỗi nút chính trong `<span class="btn-label">` để áp gradient mà
  không ảnh hưởng viền conic xoay sẵn có.

---

## v1.9.4 — Thêm tab "Dàn theo mẫu"

**Thêm mới**

- Tab mới **"Dàn theo mẫu"** nằm giữa **Dàn file** và **Catalogue**, tích hợp
  2 tool JSX rời (`1_hoc_mau.jsx` + `2_ap_mau.jsx`) vào panel.
- **Học mẫu** (`dcHocMau`): chọn tất cả bản đã dàn tay của 1 con mẫu, học bố
  cục 1 mặt hoặc 2 mặt (mặt trước / mặt sau, học 2 lần). Đọc góc xoay qua
  matrix RasterItem, lưu bố cục vào file tạm `Folder.temp/dan_theo_mau_tmp.txt`.
- **Áp mẫu** (`dcApMau`): chọn các con nguồn, tool raster + resize mỗi con về
  khổ mẫu rồi dàn theo bố cục đã học. 2 mặt: đặt nguồn 2 cột (trái = trước,
  phải = sau), tạo hết artboard theo thứ tự rồi mới dàn, hỏi pon 2 lần.
- Logic giữ nguyên từ 2 file gốc; chỉ bọc thành hàm và trả chuỗi `OK:` / `ERR:`
  để panel hiển thị kết quả.

---

## v1.9.3 — Raster clip trước khi raster

**Sửa / cải tiến**

- Nút **Raster** luôn bọc object được chọn qua một clipping group ngoài theo
  khung group/clip cha, rồi mới raster. Áp dụng cả với object thường, group và
  clip group.
- Raster giữ CMYK, 400 ppi và nền trong suốt; object gốc chỉ bị thay khi
  Illustrator đã tạo raster thành công.
- Bỏ các nhánh thử nghiệm đọc Transform, khung W × H nhập tay và autoFix khỏi
  nút Raster.

---

## v1.9.2 — Card raster như CTL, card đôi, Keo gáy, cảnh báo sai KT

**Thêm**

- **Keo gáy** (tab CTL Offset): dán keo gáy, mỗi tay 16 trang liên tiếp dàn AB
  (không bóp, không khe, cách mép trên 2.37cm). Phần dư cuối tự trở (TT8/TT4).
  Tab CTL Offset chia 2 phần mở rộng: Đóng ghim giữa + Keo gáy.
- **Card đôi 18.4×5.6** (layout 9.2×5.6): tự nhận card rộng gấp đôi, chiếm 2 chỗ.
  Ưu tiên dải 2 dưới, rồi khối 12 (cột phải→trái, hàng 1+2, xoay đứng). Nhân bản
  đều k = 20/(nhỏ + đôi×2), tối đa 5 chỗ đôi, con cùng mẫu gom liền nhau. Panel
  báo số con đôi nhận diện (18.4×5.6).
- **Cảnh báo sai kích thước**: đo sau raster (trước resize), nếu có con lệch khổ
  thì vẫn dàn xong nhưng hộp thoại kết quả báo "CÓ N CON SAI KÍCH THƯỚC - xem kỹ
  trước khi OK", và ô thông báo panel cũng ghi rõ.

**Sửa / cải tiến**

- **Card raster như CTL cho MỌI loại**: raster 400ppi theo khung (card clip →
  khung mask giữ mép) → resize về đúng khổ → ra 1 ảnh phẳng, rồi mới dàn. Bỏ
  bước bọc clip sau raster. Toàn bộ raster nâng lên 400ppi.
- **Card để dọc tự xoay về ngang** theo chiều đã chọn; card 2 mặt xoay ngược
  chiều nhau (trước/sau).
- **Các accordion không mở rộng sẵn** - mặc định thu gọn, bấm mới mở.
- **Ô thông báo panel** chữ to hơn, in đậm, màu nền/chữ rõ theo trạng thái.

---

## v1.9.1 — Variable Importer: giữ dấu tiếng Việt

**Sửa**

- Khi nạp CSV/TXT UTF-8, Variable Importer tự **chuẩn hóa Unicode NFC** trước
  khi tạo dữ liệu Variables. Các chữ tiếng Việt được lưu dạng ký tự + dấu tách
  rời (ví dụ `a` + dấu ngã) nay được ghép về dạng chuẩn, nên không còn hiện mất
  dấu trong Illustrator.

---

## v1.9 — Card raster & card đôi, Keo gáy

**Thêm**

- **Card đôi 18.4×5.6** (layout 9.2×5.6): tool tự nhận card rộng gấp đôi và
  xếp chiếm 2 chỗ. Ưu tiên dải 2 dưới trước, rồi khối 12 (cột phải→trái,
  hàng 1+2, xoay đứng, 2 mặt ngược chiều). Nhân bản đều: mỗi mẫu (đôi/nhỏ)
  ra cùng số bản, k = 20 / (số nhỏ + số đôi×2). Card đôi tối đa 5 chỗ đôi.
  Con cùng mẫu gom liền nhau cho dễ đếm. Panel báo số con đôi nhận diện.
- **Keo gáy** (tab CTL Offset): dán keo gáy, tuần tự — mỗi tay 16 trang liên
  tiếp, dàn AB (không bóp, không khe, cách mép trên 2.37cm). Phần dư cuối
  tự trở (TT8/TT4). Bìa tự dàn tay. Pon 65×86 + pon TT4 65×43.
- Tab **CTL Offset** chia 2 phần mở rộng: **Đóng ghim giữa** + **Keo gáy**.

**Sửa / cải tiến**

- **Card: raster rồi clip** cho MỌI loại (như CTL): raster 400ppi theo khung
  nội dung thật → clip về đúng kích thước chọn. Nâng toàn bộ raster lên 400ppi
  (card + catalogue + offset + keo gáy).
- **Card để dọc tự xoay về ngang**: card nào nằm lệch chiều đã chọn thì tự clip
  đúng chiều rồi xoay về chuẩn. Card 2 mặt xoay ngược chiều nhau (trước/sau).

---

## v1.8 — CTL Offset, Catalogue khổ tùy chỉnh, Decal 7cm

**Thêm**

- Tab mới **CTL Offset** — dàn bình bài AB + tự trở cho **in offset khổ lớn 65×68**:
  - Bìa = 4 trang ngoài cùng làm tự trở TT4 (khổ 65×43); phần ruột chia theo
    dư khi chia 16 (dư 12 = TT4 + TT8; dư 8 = TT8; dư 4 = TT4), còn lại là các
    tờ AB (16 trang/tờ, 2 mặt).
  - Đóng gáy giữa lồng nhau; tờ AB đặt 4 cụm-4-con đúng vị trí (A: C3|C1, B: C2|C4).
  - Kích thước 1 trang + "Có bìa" nhập ngay trên panel.
  - Nhập kích thước bìa/ruột: **bóp theo tờ** (bìa không bóp, ruột 1 → -0.1cm,
    ruột 2 → -0.2cm...), bóp đều giữ tâm mỗi cụm.
  - Pon riêng cho mỗi khổ: pon chính (65×86) cho TT8/AB, pon riêng (65×43) cho TT4.
    Pon nằm trên cùng, nhớ đường dẫn theo khổ.
  - Ghi chú "RUỘT N" (+ chữ thêm) và ghi chú bìa; TT4 chữ dọc.
  - Khi mở tab CTL Offset, tên tester đổi thành **Duẫn**.
- **Catalogue khổ tùy chỉnh** (nhỏ hơn A4 / nhỏ hơn A5): chọn "Khổ khác" trong
  từng mục, nhập kích thước đích (cm) ngay trên panel. Nhớ pon riêng theo từng khổ.
- **Decal tròn 7cm** (20 chỗ) thêm vào tab Dàn Decal.

**Sửa**

- Tab Catalogue gọn lại: mỗi mục (A4 / A5) dùng 1 dropdown chọn khổ + ô nhập,
  thay vì nhiều nút rời.
- Sửa lỗi A5: 1 cột chỉ 12 dòng (trước để 16 gây tràn).

---

## v1.7 — Dàn Catalogue A4/A5

**Thêm**

- Tab **Catalogue** với nút chạy dàn trang khổ **A4** và **A5 dọc**.
- Đóng gói hai script catalogue cùng CEP, nên extension không còn phụ thuộc vào file JSX ở thư mục Downloads.

---

Ghi lại các thay đổi qua từng bản, để tiện theo dõi đã sửa/thêm gì.

---

## v1.6 — Báo lỗi rõ ràng

**Sửa**

- Mọi lỗi khi dàn giờ hiện **thông báo tiếng Việt rõ ràng** ngay ô kết quả
  trên panel (màu vàng/cam), thay vì mã lỗi khó hiểu (vd "Error 45...").
- **Sai kích thước**: báo rõ object nào sai, KT hiện tại vs KT cần.
- Thêm bảng dịch mã lỗi ExtendScript sang tiếng Việt.
- Chống crash khi object không hợp lệ trong lúc đo kích thước (bọc an toàn
  visibleUnion / visSizeMM + try-catch tổng cho dcDan).
- Nhánh voucher: mọi lỗi (sai KT, số lượng không chia hết) đều báo rõ.

## v1.5 — Giao diện đẹp hơn

**Thêm**

- Tên **Lộc** và **Tân** chạy **gradient cầu vồng 7 màu** động (như hiệu ứng
  chữ chạy gradient trong mẫu sama).
- 3 tab đổi màu sáng hơn: tab đang chọn có nền gradient hồng-cam + gạch chân.

---

## v1.4 — Gộp tab + thêm công cụ

**Thêm**

- Tab **Dàn file**: gộp Dàn Card + Dàn Decal thành 1 tab, dạng
  **accordion** (mở/thu bằng mũi tên ▼/▶).
- Tab **Đổi tên**: đổi tên hàng loạt object (tiền tố, số/chữ thường/HOA,
  vị trí bắt đầu, đệm số 0, hướng đếm trên/dưới).
- Tab **Variable**: nút mở công cụ Variable Importer (nhập dữ liệu biến,
  tạo nhiều bản từ template) — chạy giao diện gốc.

---

## v1.3 — Decal đa khổ + chia mẫu

**Thêm**

- Tab **Decal** hỗ trợ 5 khổ: 3cm (114 chỗ), 4cm (63 chỗ), 5cm (42 chỗ),
  6cm (27 chỗ), 8cm (14 chỗ).
- Chọn nhiều object → **chia đều theo thứ tự** (vd 27 chỗ, 2 mẫu → 14/13):
  mẫu 1 điền nửa đầu, mẫu 2 điền nửa sau.
- Mỗi object tự **clip theo hình tròn** đúng kích thước của nó.

**Sửa**

- **Tọa độ tâm decal**: trước đo lệch 3cm (nửa bán kính) ở trục X.
  Nay đo đúng tâm thật, khớp với số Transform panel của Illustrator
  (hình đầu tiên = 4.3 × 5.2 cm).
- **Lỗi bắt chọn lại file pon**: file nhớ đường dẫn dùng dấu `=` gây đọc sai
  khi key/đường dẫn có dấu chấm. Nay đổi sang dấu TAB → chọn pon **1 lần**
  cho mỗi khổ (33×35.4 / 33×35), mọi cỡ decal **dùng chung**, không hỏi lại.

**Đổi tên**

- Panel đổi từ "Dàn Card" → **"Công cụ bình"** (vì giờ dàn cả card lẫn decal).

---

## v1.2 — Tab Decal (bản đầu)

**Thêm**

- Giao diện **2 tab**: [Dàn Card] [Decal], chuyển qua lại.
- Tab Decal: dàn object vào tọa độ 27 vòng tròn 6cm (đọc từ file khuôn mẫu).
- Import pon + copy artboard cho decal (giống card).
- **Bù ruler origin**: dịch pon + decal cho khớp artboard (sửa lỗi
  "pon với artboard mỗi thứ một chỗ").
- Xử lý object trước khi dàn giống card: đo KT, raster nếu sai, clip, expand.

---

## v1.1 — Giao diện + font

**Thêm**

- Header vẽ bằng CSS (không dùng ảnh): tên tác giả + tester.
- Nhúng 4 font: Lộc (thư pháp), Code dạo (pixel), Tân (thư pháp), 1 cú.
- File **install.bat** + **bat_debug_mode.bat**: cài bằng bấm đúp,
  không cần vào regedit hay copy tay.

**Đổi**

- "GOKU" → "1 cú".

---

## v1.0 — CEP bản đầu

**Thêm**

- Chuyển tool dàn card từ script (.jsx) sang **CEP extension** (panel gắn
  trong Illustrator, Window > Extensions).
- Port toàn bộ logic dàn card: 6 loại card, clip, import pon, rasterize
  background, ghép cặp, căn giữa — giữ nguyên từ bản script.
- Panel chọn loại card (radio) + nút Dàn, thay cho dialog ScriptUI cũ.

---

# Giai đoạn trước CEP — bản script (.jsx)

_Thời kỳ tool còn chạy dạng file script, mở qua File > Scripts._

## Tối ưu tốc độ dàn

**Tìm ra nguyên nhân chậm (đo thời gian từng bước)**

- Đo được: khúc "mở + nhập pon" chiếm ~92% thời gian (38s / 42s tổng).
- Đào sâu: KHÔNG phải do `app.open` (chỉ 0.5s), mà do **duplicate 96 object
  pon** vào file card nặng (31.536 object) — mỗi thao tác thêm object bắt
  Illustrator cập nhật cả cây 31k object.
- Kết luận: đổi công cụ (C++, .exe, CEP) đều không giúp — nút thắt nằm ở
  Illustrator cập nhật document nặng.

**Thử các cách tăng tốc**

- Cách 1 (group pon rồi duplicate 1 lần): giảm 37.5s → 24.6s.
- Cách giữ tab pon mở: bỏ (app.open vốn không chậm).
- Cách copy/paste: nhanh trên doc trống (0.2s) nhưng vào file nặng vẫn chậm.
- Chốt: giữ cách 1 (group duplicate) — nhanh nhất trong điều kiện dàn tại chỗ.

## Sửa lỗi lớn

- **Kích thước voucher sai** (đo 375mm thay vì 152×72): do object là group
  có background đúng KT nhưng nội dung tràn ra. Sửa bằng `autoFixByBackground`
  — tìm background khớp KT rồi rasterize theo đó.
- **Lỗi 'AOoC'** (Error 54 / 1200) khi thao tác document sau khi mở/đóng pon:
  bỏ `userInteractionLevel`, lấy lại document theo tên (tránh tham chiếu cũ).
- **Bounds sai do path ẩn**: dùng `visibleUnion` — chỉ tính object thật nhìn
  thấy, bỏ path trong suốt.
- **Lệch ruler origin** giữa file pon và file đang mở: dịch pon cho khớp
  artboard sau khi import.

## Tính năng đã xây (bản script)

- 6 loại card với công thức slot riêng (2 mặt trước/sau).
- Tự động import pon + tạo/xóa artboard theo pon.
- Dialog 2 bước chọn loại card + kiểu voucher.
- File config (`dan_card_config.txt`) nhớ đường dẫn pon cho từng loại.
- Voucher 15.2×7.2 (có thể ghép thêm card 9.2×5.6).
- Công cụ phụ: đổi tên hàng loạt (rename_selection).

---

_Ghi chú: mỗi lần cập nhật chỉ cần bấm đúp `install.bat` để cài bản mới._
